﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVDotNetLibサンプル PictureBox
'・PictureBoxのイメージをCVイメージデータに変換するサンプルです。
'・終了させるにはウィンドウを閉じてください。
'//////////////////////////////////////////////////////////////


'OpenCVDotNetLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Imports System.Runtime.InteropServices


Public Class Form1

    'API定義
    Private Declare Auto Sub MoveMemory Lib "Kernel32.dll" _
        Alias "RtlMoveMemory" (ByVal dest As IntPtr, ByVal src As IntPtr, ByVal size As Integer)

    ''' <summary>
    ''' フォームロード時の処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'ソース画像の準備
        MakeSourceImage()

        'ソース画像からCVイメージデータ(IplImage)を取得
        Dim img As IplImage = CreateIplImageFromPictureBox(Pic_Src)
        '本来であれば上記のimgが不要になった時点（フォームが閉じられた時など）に
        'cvReleaseImageで破棄する必要があるが、
        'このサンプルでは省略する。

        'CVイメージデータを別ウィンドウに表示
        cvNamedWindow("dst", 1)
        cvShowImage("dst", img)

    End Sub

    ''' <summary>
    ''' ソース画像（左側）を生成します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub MakeSourceImage()

#If False Then

        'ピクチャーボックスにHelloと描画
        Dim sz As Size = Pic_Src.ClientSize
        Dim bmp As New Bitmap(sz.Width, sz.Height, Imaging.PixelFormat.Format32bppRgb)
        Dim g As Graphics = Graphics.FromImage(bmp)
        g.Clear(Color.Black)
        g.DrawString("Hello", Me.Font, Brushes.White, sz.Width \ 4, sz.Height \ 4)

#Else

        'ファイルから読み込み
        Dim bmp As New Bitmap(GetOpenCVInstallDirectory() + "\samples\c\airplane.jpg")

#End If

        'PictureBoxのイメージに設定
        Pic_Src.Image = bmp

    End Sub

    ''' <summary>
    ''' PictureBoxのイメージからOpenCVイメージデータ(IplImage)を生成します。
    ''' </summary>
    ''' <param name="Pic">イメージが格納されているPictureBox</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function CreateIplImageFromPictureBox(ByVal Pic As PictureBox) As IplImage

        'CVイメージデータの生成
        Dim sz As Size = Pic.ClientSize
        Dim img As IplImage = cvCreateImage(New CvSize(sz.Width, sz.Height), IPL_DEPTH_8U, 3)

        'PictureBoxのイメージをサイズ等を返還して取り出し
        Dim srcbmp As New Bitmap(sz.Width, sz.Height, Imaging.PixelFormat.Format24bppRgb)
        Dim g As Graphics = Graphics.FromImage(srcbmp)
        g.DrawImage(Pic.Image, 0, 0)
        g.Dispose()

        '取り出したイメージの画像データを
        'CVイメージデータに書き出す
        Dim rct As New Rectangle(0, 0, sz.Width, sz.Height)
        Dim bd As System.Drawing.Imaging.BitmapData = srcbmp.LockBits(rct, Imaging.ImageLockMode.ReadOnly, Imaging.PixelFormat.Format24bppRgb)
        MoveMemory(img.imageData.Ptr, bd.Scan0, img.imageSize)
        srcbmp.UnlockBits(bd)

        Return img
    End Function


End Class
