﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Pic_Src = New System.Windows.Forms.PictureBox
        CType(Me.Pic_Src, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pic_Src
        '
        Me.Pic_Src.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pic_Src.Location = New System.Drawing.Point(8, 8)
        Me.Pic_Src.Name = "Pic_Src"
        Me.Pic_Src.Size = New System.Drawing.Size(160, 160)
        Me.Pic_Src.TabIndex = 0
        Me.Pic_Src.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(175, 173)
        Me.Controls.Add(Me.Pic_Src)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Pic_Src, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pic_Src As System.Windows.Forms.PictureBox

End Class
