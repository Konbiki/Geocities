﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVDotNetLibサンプル Camera1
'・カメラデバイスから画像を取り込み表示します。
'・このサンプルはVBのフォームを使用しません。
'　.Net FrameworkのGUIを使用する場合は、
'　サンプルCamera2を参照して下さい。
'・終了させるにはESCキーを押すか、CAMERAウィンドウを閉じてください。
'//////////////////////////////////////////////////////////////


'OpenCVDotNetLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Module Camera1

    '画像を表示するウィンドウの名称
    Private Const WINDOWNAME As String = "CAMERA"

    'メイン
    Sub Main()

        'カメラキャプチャの作成(カメラの準備)
        Dim cap As CvCapture
        cap = cvCreateCameraCapture(0) '0番のカメラを使用

        '表示用ウィンドウの作成
        cvNamedWindow(WINDOWNAME, CV_WINDOW_AUTOSIZE) '自動サイズ変更

        'メインループ
        Dim img As IplImage
        Dim key As Integer
        Do
            'カメラからの１フレーム読込
            img = cvQueryFrame(cap)

            '画像の表示
            cvShowImage(WINDOWNAME, img)

            'キー入力チェック
            key = cvWaitKey(10) '10msだけキー入力を待つ
            If key = 27 Then Exit Do '27=ESCキーのキーコード

            '終了確認（キー入力以外でウィンドウが閉じられた場合用）
            If cvGetWindowHandle(WINDOWNAME) = UPointer.Null Then Exit Do
        Loop

        '表示ウィンドウの破棄
        cvDestroyWindow(WINDOWNAME)

        'カメラキャプチャの破棄
        cvReleaseCapture(cap)

    End Sub

End Module
