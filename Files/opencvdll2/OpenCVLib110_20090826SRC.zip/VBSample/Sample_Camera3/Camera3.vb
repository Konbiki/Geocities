﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル Camera3
'・カメラデバイスから画像を取り込み、VBフォーム上に表示します。
'・このサンプルでは.Net FrameworkのGUIを使用していますが、
'　プログラム構造はCamera1サンプルに近く、
'　画像の表示のみにフォームを使用しています。
'・画像表示はPictureBoxのビットマップイメージを切り替えることで行ってます。
'　この方法ですとVBの機能で画像の上に描画したりすることができます。
'　ただし、この方法は高速ではありませんので、
'　他サンプルよりフレームレートが落ちるかもしれません。
'・終了させるにはESCキーを押すか、ウィンドウを閉じてください。
'//////////////////////////////////////////////////////////////

'OpenCVDotNetLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

'System.Windows.FormとSystem.Drawingコンポーネントを参照設定してください。
'（コンソールアプリで作成しているため）
Imports System.Windows.Forms
Imports System.Drawing

Module Camera3

    'メイン
    Sub Main()

        'カメラキャプチャの作成(カメラの準備)
        Dim cap As CvCapture
        cap = cvCreateCameraCapture(0) '0番のカメラを使用

        'キャプチャサイズ選択
        cvSetCaptureProperty(cap, CV_CAP_PROP_FRAME_WIDTH, 640)
        cvSetCaptureProperty(cap, CV_CAP_PROP_FRAME_HEIGHT, 480)

        '画像サイズの取得
        Dim sx As Integer, sy As Integer
        Dim img As IplImage
        img = cvQueryFrame(cap)
        sx = img.width
        sy = img.height

        '表示フォームの作成
        Dim pic As PictureBox = New PictureBox  '表示用PictureBox
        pic.Location = New Point(0, 0)
        pic.Size = New Size(sx, sy)
        Dim frm As New Form                     'フォーム
        frm.ClientSize = New Size(sx, sy)
        frm.Controls.Add(pic)
        AddHandler frm.KeyDown, AddressOf OnKeyDown 'キー押下イベント
        frm.Show()
        frm.Refresh()

        'メインループ
        Do While frm.Created
            Application.DoEvents()  'メッセージ処理

            'カメラからの１フレーム読込
            img = cvQueryFrame(cap)

            '表示
            img.UpdateBitmapImage()
            pic.Image = img.BitmapImage
            pic.Refresh()
        Loop

        '後始末
        cvReleaseCapture(cap)
        frm.Close()

    End Sub

    'フォームでキーが押された時の処理です。
    Private Sub OnKeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)

        'フォームを閉じる
        Dim frm As Form = TryCast(sender, Form)
        If frm IsNot Nothing Then
            frm.Close()
        End If

    End Sub

End Module
