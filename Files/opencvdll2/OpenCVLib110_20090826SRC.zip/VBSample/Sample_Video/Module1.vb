﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVDotNetLibサンプル PictureBox
'・PictureBoxのイメージをCVイメージデータに変換するサンプルです。
'・終了させるにはウィンドウを閉じてください。
'//////////////////////////////////////////////////////////////


'OpenCVDotNetLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Module Module1

    '定数
    Private Const WINDOWNAME As String = "Video"
    Private Const FILENAME As String = "test.avi"

    Sub Main()

        Console.WriteLine("output {0}\{1}", CurDir, FILENAME)

        'カメラキャプチャの作成
        Dim cap As CvCapture = cvCreateCameraCapture(0)

        '表示用ウィンドウ作成
        cvNamedWindow(WINDOWNAME, CV_WINDOW_AUTOSIZE)

        'ビデオライタの作成
        Dim img As IplImage = cvQueryFrame(cap)
        Dim sz As CvSize = New CvSize(img.width, img.height)

        'Dim codec As Integer = CV_FOURCC_PROMPT
        Dim codec As Integer = 0
        'Dim codec As Integer = MakeFOURCC("M"c, "J"c, "P"c, "G"c)
        'Dim codec As Integer = MakeFOURCC("P"c, "I"c, "M"c, "1"c)
        'Dim codec As Integer = MakeFOURCC("D"c, "I"c, "B"c, " "c)
        'Dim codec As Integer = MakeFOURCC("I"c, "4"c, "2"c, "0"c)

        Dim vdw As CvVideoWriter = cvCreateVideoWriter(FILENAME, codec, 15.0, sz, 1)

        'メインループ
        Do
            '１フレーム読込
            img = cvQueryFrame(cap)

            '１フレーム書き込み
            cvWriteFrame(vdw, img)

            '表示
            cvShowImage(WINDOWNAME, img)

            'キー入力待ち
            Dim key As Integer = cvWaitKey(10)
            If key = 27 Then
                'ESCキー押下
                Exit Do
            End If
        Loop

        '破棄
        cvReleaseVideoWriter(vdw)
        cvDestroyWindow(WINDOWNAME)
        cvReleaseCapture(cap)

    End Sub

    Function MakeFOURCC(ByVal c1 As Char, ByVal c2 As Char, ByVal c3 As Char, ByVal c4 As Char) As Integer
        Dim ret As Integer = 0
        ret += Asc(c1)
        ret += Asc(c2) << 8
        ret += Asc(c3) << 16
        ret += Asc(c4) << 24
        Return ret
    End Function

End Module
