﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　楕円のフィッティング cvFitEllipse2
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV
Imports System.Runtime.InteropServices

Module Start

    Sub Main()

        Dim src_img As IplImage = Nothing, dst_img As IplImage
        Dim src_img_gray As IplImage = Nothing
        Dim tmp_img As IplImage
        Dim storage As CvMemStorage = cvCreateMemStorage(0)
        Dim contours As CvSeq = Nothing
        Dim ellipse As New CvBox2D
        Dim it As New CvTreeNodeIterator
        Dim pt() As CvPoint2D32f = CvPoint2D32f.CreateNewArray(4)

        '(1)画像を読み込む
        Dim argv1 As String = GetOpenCVInstallDirectory() + "\samples\c\airplane.jpg"
        src_img = cvLoadImage(argv1, CV_LOAD_IMAGE_COLOR)

        src_img_gray = cvCreateImage(cvGetSize(src_img), IPL_DEPTH_8U, 1)
        cvCvtColor(src_img, src_img_gray, CV_BGR2GRAY)
        tmp_img = cvCreateImage(cvGetSize(src_img), IPL_DEPTH_8U, 1)
        dst_img = cvCloneImage(src_img)

        '(2)二値化と輪郭の検出
        cvThreshold(src_img_gray, tmp_img, 95, 255, CV_THRESH_BINARY)
        cvFindContours(tmp_img, storage, contours, CvContour.StructSize, _
            CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, New CvPoint(0, 0))

        '(3)ツリーノードイテレータの初期化
        cvInitTreeNodeIterator(it, contours.Address, 3)
        Do
            Dim contours_ptr As UPointer = cvNextTreeNode(it)   '次のノードのポインタを取得
            If contours_ptr.IsNull Then Exit Do '次ノードポインタがNULLなら終了
            contours = New CvSeq(contours_ptr)  '次ノードポインタの示すアドレスをCvSeq型データのアドレスとして見る（CvSeq型にキャストと同等）
            If contours.total > 6 Then

                '(4)楕円のフィッティング
                ellipse = cvFitEllipse2(contours)       '対象ノードの輪郭線情報で楕円フィッティング
                ellipse.angle = 90.0F - ellipse.angle   '90度回転

                '(5)輪郭，楕円，包含矩形の描画
                cvDrawContours(dst_img, contours, CV_RGB(255, 0, 0), CV_RGB(255, 0, 0), 0, 1, CV_AA, New CvPoint(0, 0)) '輪郭線描画
                cvEllipseBox(dst_img, ellipse, CV_RGB(0, 0, 255), 2) '楕円描画
                cvBoxPoints(ellipse, pt)    '楕円を包含する矩形の頂点を取得
                cvLine(dst_img, cvPointFrom32f(pt(0)), cvPointFrom32f(pt(1)), CV_RGB(0, 255, 0)) '矩形の描画
                cvLine(dst_img, cvPointFrom32f(pt(1)), cvPointFrom32f(pt(2)), CV_RGB(0, 255, 0))
                cvLine(dst_img, cvPointFrom32f(pt(2)), cvPointFrom32f(pt(3)), CV_RGB(0, 255, 0))
                cvLine(dst_img, cvPointFrom32f(pt(3)), cvPointFrom32f(pt(0)), CV_RGB(0, 255, 0))
            End If

        Loop

        '(6)画像の表示
        cvNamedWindow("Fitting", CV_WINDOW_AUTOSIZE)
        cvShowImage("Fitting", dst_img)
        cvWaitKey(0)

        cvDestroyWindow("Fitting")
        cvReleaseImage(src_img)
        cvReleaseImage(dst_img)
        cvReleaseImage(src_img_gray)
        cvReleaseImage(tmp_img)
        cvReleaseMemStorage(storage)

    End Sub

End Module
