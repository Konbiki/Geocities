/*M///////////////////////////////////////////////////////////////////////////////////////
//
//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
//
//  By downloading, copying, installing or using the software you agree to this license.
//  If you do not agree to this license, do not download, install,
//  copy or use the software.
//
//
//                          License Agreement
//                For Open Source Computer Vision Library
//
// Copyright (C) 2000-2008, Intel Corporation, all rights reserved.
// Copyright (C) 2009, Willow Garage Inc., all rights reserved.
// Third party copyrights are property of their respective owners.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistribution's of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//   * Redistribution's in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//   * The name of the copyright holders may not be used to endorse or promote products
//     derived from this software without specific prior written permission.
//
// This software is provided by the copyright holders and contributors "as is" and
// any express or implied warranties, including, but not limited to, the implied
// warranties of merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the Intel Corporation or contributors be liable for any direct,
// indirect, incidental, special, exemplary, or consequential damages
// (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused
// and on any theory of liability, whether in contract, strict liability,
// or tort (including negligence or otherwise) arising in any way out of
// the use of this software, even if advised of the possibility of such damage.
//
//M*/

////#ifndef _CXCORE_TYPES_H_
////#define _CXCORE_TYPES_H_
////
////#if !defined _CRT_SECURE_NO_DEPRECATE && _MSC_VER > 1300
////#define _CRT_SECURE_NO_DEPRECATE /* to avoid multiple Visual Studio 2005 warnings */
////#endif
////
////#if _MSC_VER >= 1500
////#ifndef _BIND_TO_CURRENT_CRT_VERSION
////  #define _BIND_TO_CURRENT_CRT_VERSION 1
////#endif
////#ifndef _BIND_TO_CURRENT_VCLIBS_VERSION
////  #define _BIND_TO_CURRENT_VCLIBS_VERSION 1
////#endif
////#endif
////
////#ifndef SKIP_INCLUDES
////  #include <assert.h>
////  #include <stdlib.h>
////  #include <string.h>
////  #include <float.h>
////
////#if !defined _MSC_VER && !defined __BORLANDC__
////  #include <stdint.h>
////#endif
////
////  #if defined __ICL
////    #define CV_ICC   __ICL
////  #elif defined __ICC
////    #define CV_ICC   __ICC
////  #elif defined __ECL
////    #define CV_ICC   __ECL
////  #elif defined __ECC
////    #define CV_ICC   __ECC
////  #endif
////
////  #if ((defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64) && \
////      (_MSC_VER >= 1400 || defined CV_ICC)) \
////      || (defined __SSE2__ && defined __GNUC__ && __GNUC__ >= 4)
////    #include <emmintrin.h>
////    #define CV_SSE2 1
////  #else
////    #define CV_SSE2 0
////  #endif
////
////  #if ((defined __SSE__ || defined __MMX__) && defined __GNUC__ && __GNUC__ >= 3)
////    #include <mmintrin.h>
////  #endif
////
////  #if defined __BORLANDC__
////    #include <fastmath.h>
////  #else
////    #include <math.h>
////  #endif
////
////  #ifdef HAVE_IPL
////      #ifndef __IPL_H__
////          #if defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64
////              #include <ipl.h>
////          #else
////              #include <ipl/ipl.h>
////          #endif
////      #endif
////  #elif defined __IPL_H__
////      #define HAVE_IPL
////  #endif
////#endif // SKIP_INCLUDES
////
////#if defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64
////    #define CV_CDECL __cdecl
////    #define CV_STDCALL __stdcall
////#else
////    #define CV_CDECL
////    #define CV_STDCALL
////#endif
////
////#ifndef CV_EXTERN_C
////    #ifdef __cplusplus
////        #define CV_EXTERN_C extern "C"
////        #define CV_DEFAULT(val) = val
////    #else
////        #define CV_EXTERN_C
////        #define CV_DEFAULT(val)
////    #endif
////#endif
////
////#ifndef CV_EXTERN_C_FUNCPTR
////    #ifdef __cplusplus
////        #define CV_EXTERN_C_FUNCPTR(x) extern "C" { typedef x; }
////    #else
////        #define CV_EXTERN_C_FUNCPTR(x) typedef x
////    #endif
////#endif
////
////#ifndef CV_INLINE
////#if defined __cplusplus
////    #define CV_INLINE inline
////#elif (defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64 || defined WINCE) && !defined __GNUC__
////    #define CV_INLINE __inline
////#else
////    #define CV_INLINE static
////#endif
////#endif /* CV_INLINE */
////
////#if (defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64 || defined WINCE) && defined CVAPI_EXPORTS
////    #define CV_EXPORTS __declspec(dllexport)
////#else
////    #define CV_EXPORTS
////#endif
////
////#ifndef CVAPI
////    #define CVAPI(rettype) CV_EXTERN_C CV_EXPORTS rettype CV_CDECL
////#endif
////
////#if defined _MSC_VER || defined __BORLANDC__
////typedef __int64 int64;
////typedef unsigned __int64 uint64;
////#else
////typedef int64_t int64;
////typedef uint64_t uint64;
////#endif
////
////#ifndef HAVE_IPL
////typedef unsigned char uchar;
////typedef unsigned short ushort;
////#endif
////
////typedef signed char schar;

/* CvArr* is used to pass arbitrary
 * array-like data structures
 * into functions where the particular
 * array type is recognized at runtime:
 */
// typedef void CvArr;
// Unsupport : CvArr

// typedef union Cv32suf
// {
//     int i;
//     unsigned u;
//     float f;
// }
// Cv32suf;
DEFINE_STRUCT( Cv32suf )
{STRUCT_BASIC( Cv32suf )
	DEFINE_PROPERTY_V( int, i )
	DEFINE_PROPERTY_V( unsigned, u )
	DEFINE_PROPERTY_V( float, f )
};

// typedef union Cv64suf
// {
//     int64 i;
//     uint64 u;
//     double f;
// }
// Cv64suf;
DEFINE_STRUCT( Cv64suf )
{STRUCT_BASIC( Cv64suf )
	DEFINE_PROPERTY_V( long long, i )
	DEFINE_PROPERTY_V( unsigned long long, u )
	DEFINE_PROPERTY_V( double, f )
};

/****************************************************************************************\
*                             Common macros and inline functions                         *
\****************************************************************************************/

// #define CV_PI   3.1415926535897932384626433832795
#pragma push_macro( "CV_PI" )
#undef CV_PI
static const double CV_PI
#pragma pop_macro( "CV_PI" )
	= CV_PI;
// #define CV_LOG2 0.69314718055994530941723212145818
#pragma push_macro( "CV_LOG2" )
#undef CV_LOG2
static const double CV_LOG2
#pragma pop_macro( "CV_LOG2" )
	= CV_LOG2;

// #define CV_SWAP(a,b,t) ((t) = (a), (a) = (b), (b) = (t))
// Unsupport : CV_SWAP

////#ifndef MIN
// #define MIN(a,b)  ((a) > (b) ? (b) : (a))
#pragma push_macro( "MIN" )
#undef MIN
static int MIN( int a, int b )
#pragma pop_macro( "MIN" )
{ return MIN( a, b ); }

#pragma push_macro( "MIN" )
#undef MIN
static float MIN( float a, float b )
#pragma pop_macro( "MIN" )
{ return MIN( a, b ); }

#pragma push_macro( "MIN" )
#undef MIN
static double MIN( double a, double b )
#pragma pop_macro( "MIN" )
{ return MIN( a, b ); }
////#endif

////#ifndef MAX
// #define MAX(a,b)  ((a) < (b) ? (b) : (a))
#pragma push_macro( "MAX" )
#undef MAX
static int MAX( int a, int b )
#pragma pop_macro( "MAX" )
{ return MAX( a, b ); }

#pragma push_macro( "MAX" )
#undef MAX
static float MAX( float a, float b )
#pragma pop_macro( "MAX" )
{ return MAX( a, b ); }

#pragma push_macro( "MAX" )
#undef MAX
static double MAX( double a, double b )
#pragma pop_macro( "MAX" )
{ return MAX( a, b ); }
////#endif

/* min & max without jumps */
// #define  CV_IMIN(a, b)  ((a) ^ (((a)^(b)) & (((a) < (b)) - 1)))
// Unsupport : CV_IMIN

// #define  CV_IMAX(a, b)  ((a) ^ (((a)^(b)) & (((a) > (b)) - 1)))
// Unsupport : CV_IMAX

/* absolute value without jumps */
////#ifndef __cplusplus
////#define  CV_IABS(a)     (((a) ^ ((a) < 0 ? -1 : 0)) - ((a) < 0 ? -1 : 0))
////#else
// #define  CV_IABS(a)     abs(a)
#pragma push_macro( "CV_IABS" )
#undef CV_IABS
static int CV_IABS( int a )
#pragma pop_macro( "CV_IABS" )
{ return CV_IABS( a ); }
////#endif
// #define  CV_CMP(a,b)    (((a) > (b)) - ((a) < (b)))
#pragma push_macro( "CV_CMP" )
#undef CV_CMP
static int CV_CMP( int a, int b )
#pragma pop_macro( "CV_CMP" )
{ return CV_CMP( a, b ); }

#pragma push_macro( "CV_CMP" )
#undef CV_CMP
static int CV_CMP( float a, float b )
#pragma pop_macro( "CV_CMP" )
{ return CV_CMP( a, b ); }

#pragma push_macro( "CV_CMP" )
#undef CV_CMP
static int CV_CMP( double a, double b )
#pragma pop_macro( "CV_CMP" )
{ return CV_CMP( a, b ); }
// #define  CV_SIGN(a)     CV_CMP((a),0)
#pragma push_macro( "CV_SIGN" )
#undef CV_SIGN
static int CV_SIGN( int a )
#pragma pop_macro( "CV_SIGN" )
{ return CV_SIGN( a ); }

#pragma push_macro( "CV_SIGN" )
#undef CV_SIGN
static int CV_SIGN( float a )
#pragma pop_macro( "CV_SIGN" )
{ return CV_SIGN( a ); }

#pragma push_macro( "CV_SIGN" )
#undef CV_SIGN
static int CV_SIGN( double a )
#pragma pop_macro( "CV_SIGN" )
{ return CV_SIGN( a ); }

// CV_INLINE  int  cvRound( double value )
// {
// ////#if CV_SSE2 && !defined __APPLE__
// ////    __m128d t = _mm_set_sd( value );
// ////    return _mm_cvtsd_si32(t);
// ////#elif (defined WIN32 || defined _WIN32) && !defined WIN64 && !defined _WIN64 && defined _MSC_VER
// ////    int t;
// ////    __asm
// ////    {
// ////        fld value;
// ////        fistp t;
// ////    }
// ////    return t;
// ////#elif defined HAVE_LRINT || defined CV_ICC || defined __GNUC__
// ////    return (int)lrint(value);
// ////#else
//     // while this is not IEEE754-compliant rounding, it's usually a good enough approximation
//     return (int)(value + 0.5);
// ////#endif
// }
DEFINE_FUNCTION( V(int), cvRound, 1( V(double,value) ) ) 


// CV_INLINE  int  cvFloor( double value )
// {
// ////#ifdef __GNUC__
// ////    int i = (int)value;
// ////    return i - (i > value);
// ////#elif CV_SSE2
// ////    __m128d t = _mm_set_sd( value );
// ////    int i = _mm_cvtsd_si32(t);
// ////    return i - _mm_movemask_pd(_mm_cmplt_sd(t, _mm_cvtsi32_sd(t,i)));
// ////#else
//     int i = cvRound(value);
//     Cv32suf diff;
//     diff.f = (float)(value - i);
//     return i - (diff.i < 0);
// ////#endif
// }
DEFINE_FUNCTION( V(int), cvFloor, 1( V(double,value) ) ) 


// CV_INLINE  int  cvCeil( double value )
// {
// ////#ifdef __GNUC__
// ////    int i = (int)value;
// ////    return i + (i < value);
// ////#elif CV_SSE2
// ////    __m128d t = _mm_set_sd( value );
// ////    int i = _mm_cvtsd_si32(t);
// ////    return i + _mm_movemask_pd(_mm_cmplt_sd(_mm_cvtsi32_sd(t,i), t));
// ////#else
//     int i = cvRound(value);
//     Cv32suf diff;
//     diff.f = (float)(i - value);
//     return i + (diff.i < 0);
// ////#endif
// }
DEFINE_FUNCTION( V(int), cvCeil, 1( V(double,value) ) ) 

// #define cvInvSqrt(value) ((float)(1./sqrt(value)))
// Unsupport : cvInvSqrt
// #define cvSqrt(value)  ((float)sqrt(value))
// Unsupport : cvSqrt

// CV_INLINE int cvIsNaN( double value )
// {
// ////#if 1/*defined _MSC_VER || defined __BORLANDC__
// ////    return _isnan(value);
// ////#elif defined __GNUC__
// ////    return isnan(value);
// ////#else*/
//     Cv64suf ieee754;
//     ieee754.f = value;
//     return ((unsigned)(ieee754.u >> 32) & 0x7fffffff) +
//            ((unsigned)ieee754.u != 0) > 0x7ff00000;
// ////#endif
// }
DEFINE_FUNCTION( V(int), cvIsNaN, 1( V(double,value) ) ) 


// CV_INLINE int cvIsInf( double value )
// {
// ////#if 1/*defined _MSC_VER || defined __BORLANDC__
// ////    return !_finite(value);
// ////#elif defined __GNUC__
// ////    return isinf(value);
// ////#else*/
//     Cv64suf ieee754;
//     ieee754.f = value;
//     return ((unsigned)(ieee754.u >> 32) & 0x7fffffff) == 0x7ff00000 &&
//            (unsigned)ieee754.u == 0;
// ////#endif
// }
DEFINE_FUNCTION( V(int), cvIsInf, 1( V(double,value) ) ) 


/*************** Random number generation *******************/

// typedef uint64 CvRNG;
// Unsupport : CvRNG

// CV_INLINE CvRNG cvRNG( int64 seed CV_DEFAULT(-1))
// {
//     CvRNG rng = seed ? (uint64)seed : (uint64)(int64)-1;
//     return rng;
// }
DEFINE_FUNCTION_ALIAS( V(unsigned long long), cvRNG, cvRNG_, 1( V(long long,seed) ) ) 

/* Return random 32-bit unsigned integer: */
// CV_INLINE unsigned cvRandInt( CvRNG* rng )
// {
//     uint64 temp = *rng;
//     temp = (uint64)(unsigned)temp*4164903690U + (temp >> 32);
//     *rng = temp;
//     return (unsigned)temp;
// }
DEFINE_FUNCTION( V(unsigned), cvRandInt, 1( VP(unsigned long long,rng) ) ) 
DEFINE_FUNCTION( V(unsigned), cvRandInt, 1( P(unsigned long long*,rng) ) ) 

/* Returns random floating-point number between 0 and 1: */
// CV_INLINE double cvRandReal( CvRNG* rng )
// {
//     return cvRandInt(rng)*2.3283064365386962890625e-10 /* 2^-32 */;
// }
DEFINE_FUNCTION( V(double), cvRandReal, 1( VP(unsigned long long,rng) ) ) 
DEFINE_FUNCTION( V(double), cvRandReal, 1( P(unsigned long long*,rng) ) ) 

/****************************************************************************************\
*                                  Image type (IplImage)                                 *
\****************************************************************************************/

////#ifndef HAVE_IPL

/*
 * The following definitions (until #endif)
 * is an extract from IPL headers.
 * Copyright (c) 1995 Intel Corporation.
 */
// #define IPL_DEPTH_SIGN 0x80000000
#pragma push_macro( "IPL_DEPTH_SIGN" )
#undef IPL_DEPTH_SIGN
static const int IPL_DEPTH_SIGN
#pragma pop_macro( "IPL_DEPTH_SIGN" )
	= IPL_DEPTH_SIGN;

// #define IPL_DEPTH_1U     1
#pragma push_macro( "IPL_DEPTH_1U" )
#undef IPL_DEPTH_1U
static const int IPL_DEPTH_1U
#pragma pop_macro( "IPL_DEPTH_1U" )
	= IPL_DEPTH_1U;
// #define IPL_DEPTH_8U     8
#pragma push_macro( "IPL_DEPTH_8U" )
#undef IPL_DEPTH_8U
static const int IPL_DEPTH_8U
#pragma pop_macro( "IPL_DEPTH_8U" )
	= IPL_DEPTH_8U;
// #define IPL_DEPTH_16U   16
#pragma push_macro( "IPL_DEPTH_16U" )
#undef IPL_DEPTH_16U
static const int IPL_DEPTH_16U
#pragma pop_macro( "IPL_DEPTH_16U" )
	= IPL_DEPTH_16U;
// #define IPL_DEPTH_32F   32
#pragma push_macro( "IPL_DEPTH_32F" )
#undef IPL_DEPTH_32F
static const int IPL_DEPTH_32F
#pragma pop_macro( "IPL_DEPTH_32F" )
	= IPL_DEPTH_32F;

// #define IPL_DEPTH_8S  (IPL_DEPTH_SIGN| 8)
#pragma push_macro( "IPL_DEPTH_8S" )
#undef IPL_DEPTH_8S
static const int IPL_DEPTH_8S
#pragma pop_macro( "IPL_DEPTH_8S" )
	= IPL_DEPTH_8S;
// #define IPL_DEPTH_16S (IPL_DEPTH_SIGN|16)
#pragma push_macro( "IPL_DEPTH_16S" )
#undef IPL_DEPTH_16S
static const int IPL_DEPTH_16S
#pragma pop_macro( "IPL_DEPTH_16S" )
	= IPL_DEPTH_16S;
// #define IPL_DEPTH_32S (IPL_DEPTH_SIGN|32)
#pragma push_macro( "IPL_DEPTH_32S" )
#undef IPL_DEPTH_32S
static const int IPL_DEPTH_32S
#pragma pop_macro( "IPL_DEPTH_32S" )
	= IPL_DEPTH_32S;

// #define IPL_DATA_ORDER_PIXEL  0
#pragma push_macro( "IPL_DATA_ORDER_PIXEL" )
#undef IPL_DATA_ORDER_PIXEL
static const int IPL_DATA_ORDER_PIXEL
#pragma pop_macro( "IPL_DATA_ORDER_PIXEL" )
	= IPL_DATA_ORDER_PIXEL;
// #define IPL_DATA_ORDER_PLANE  1
#pragma push_macro( "IPL_DATA_ORDER_PLANE" )
#undef IPL_DATA_ORDER_PLANE
static const int IPL_DATA_ORDER_PLANE
#pragma pop_macro( "IPL_DATA_ORDER_PLANE" )
	= IPL_DATA_ORDER_PLANE;

// #define IPL_ORIGIN_TL 0
#pragma push_macro( "IPL_ORIGIN_TL" )
#undef IPL_ORIGIN_TL
static const int IPL_ORIGIN_TL
#pragma pop_macro( "IPL_ORIGIN_TL" )
	= IPL_ORIGIN_TL;
// #define IPL_ORIGIN_BL 1
#pragma push_macro( "IPL_ORIGIN_BL" )
#undef IPL_ORIGIN_BL
static const int IPL_ORIGIN_BL
#pragma pop_macro( "IPL_ORIGIN_BL" )
	= IPL_ORIGIN_BL;

// #define IPL_ALIGN_4BYTES   4
#pragma push_macro( "IPL_ALIGN_4BYTES" )
#undef IPL_ALIGN_4BYTES
static const int IPL_ALIGN_4BYTES
#pragma pop_macro( "IPL_ALIGN_4BYTES" )
	= IPL_ALIGN_4BYTES;
// #define IPL_ALIGN_8BYTES   8
#pragma push_macro( "IPL_ALIGN_8BYTES" )
#undef IPL_ALIGN_8BYTES
static const int IPL_ALIGN_8BYTES
#pragma pop_macro( "IPL_ALIGN_8BYTES" )
	= IPL_ALIGN_8BYTES;
// #define IPL_ALIGN_16BYTES 16
#pragma push_macro( "IPL_ALIGN_16BYTES" )
#undef IPL_ALIGN_16BYTES
static const int IPL_ALIGN_16BYTES
#pragma pop_macro( "IPL_ALIGN_16BYTES" )
	= IPL_ALIGN_16BYTES;
// #define IPL_ALIGN_32BYTES 32
#pragma push_macro( "IPL_ALIGN_32BYTES" )
#undef IPL_ALIGN_32BYTES
static const int IPL_ALIGN_32BYTES
#pragma pop_macro( "IPL_ALIGN_32BYTES" )
	= IPL_ALIGN_32BYTES;

// #define IPL_ALIGN_DWORD   IPL_ALIGN_4BYTES
#pragma push_macro( "IPL_ALIGN_DWORD" )
#undef IPL_ALIGN_DWORD
static const int IPL_ALIGN_DWORD
#pragma pop_macro( "IPL_ALIGN_DWORD" )
	= IPL_ALIGN_DWORD;
// #define IPL_ALIGN_QWORD   IPL_ALIGN_8BYTES
#pragma push_macro( "IPL_ALIGN_QWORD" )
#undef IPL_ALIGN_QWORD
static const int IPL_ALIGN_QWORD
#pragma pop_macro( "IPL_ALIGN_QWORD" )
	= IPL_ALIGN_QWORD;

// #define IPL_BORDER_CONSTANT   0
#pragma push_macro( "IPL_BORDER_CONSTANT" )
#undef IPL_BORDER_CONSTANT
static const int IPL_BORDER_CONSTANT
#pragma pop_macro( "IPL_BORDER_CONSTANT" )
	= IPL_BORDER_CONSTANT;
// #define IPL_BORDER_REPLICATE  1
#pragma push_macro( "IPL_BORDER_REPLICATE" )
#undef IPL_BORDER_REPLICATE
static const int IPL_BORDER_REPLICATE
#pragma pop_macro( "IPL_BORDER_REPLICATE" )
	= IPL_BORDER_REPLICATE;
// #define IPL_BORDER_REFLECT    2
#pragma push_macro( "IPL_BORDER_REFLECT" )
#undef IPL_BORDER_REFLECT
static const int IPL_BORDER_REFLECT
#pragma pop_macro( "IPL_BORDER_REFLECT" )
	= IPL_BORDER_REFLECT;
// #define IPL_BORDER_WRAP       3
#pragma push_macro( "IPL_BORDER_WRAP" )
#undef IPL_BORDER_WRAP
static const int IPL_BORDER_WRAP
#pragma pop_macro( "IPL_BORDER_WRAP" )
	= IPL_BORDER_WRAP;

// typedef struct _IplImage
// {
//     int  nSize;             /* sizeof(IplImage) */
//     int  ID;                /* version (=0)*/
//     int  nChannels;         /* Most of OpenCV functions support 1,2,3 or 4 channels */
//     int  alphaChannel;      /* Ignored by OpenCV */
//     int  depth;             /* Pixel depth in bits: IPL_DEPTH_8U, IPL_DEPTH_8S, IPL_DEPTH_16S,
//                                IPL_DEPTH_32S, IPL_DEPTH_32F and IPL_DEPTH_64F are supported.  */
//     char colorModel[4];     /* Ignored by OpenCV */
//     char channelSeq[4];     /* ditto */
//     int  dataOrder;         /* 0 - interleaved color channels, 1 - separate color channels.
//                                cvCreateImage can only create interleaved images */
//     int  origin;            /* 0 - top-left origin,
//                                1 - bottom-left origin (Windows bitmaps style).  */
//     int  align;             /* Alignment of image rows (4 or 8).
//                                OpenCV ignores it and uses widthStep instead.    */
//     int  width;             /* Image width in pixels.                           */
//     int  height;            /* Image height in pixels.                          */
//     struct _IplROI *roi;    /* Image ROI. If NULL, the whole image is selected. */
//     struct _IplImage *maskROI;      /* Must be NULL. */
//     void  *imageId;                 /* "           " */
//     struct _IplTileInfo *tileInfo;  /* "           " */
//     int  imageSize;         /* Image data size in bytes
//                                (==image->height*image->widthStep
//                                in case of interleaved data)*/
//     char *imageData;        /* Pointer to aligned image data.         */
//     int  widthStep;         /* Size of aligned image row in bytes.    */
//     int  BorderMode[4];     /* Ignored by OpenCV.                     */
//     int  BorderConst[4];    /* Ditto.                                 */
//     char *imageDataOrigin;  /* Pointer to very origin of image data
//                                (not necessarily aligned) -
//                                needed for correct deallocation */
// }
// IplImage;
DEFINE_STRUCT_PROTOTYPE( IplROI )
DEFINE_STRUCT_PROTOTYPE( IplTileInfo )
DEFINE_STRUCT( IplImage )
{STRUCT_BASIC( IplImage )
	DEFINE_PROPERTY_V( int, nSize )
	DEFINE_PROPERTY_V( int, ID )
	DEFINE_PROPERTY_V( int, nChannels )
	DEFINE_PROPERTY_V( int, alphaChannel )
	DEFINE_PROPERTY_V( int, depth )
	DEFINE_PROPERTY_VA( char, colorModel, 4 )
	DEFINE_PROPERTY_VA( char, channelSeq, 4 )
	DEFINE_PROPERTY_V( int, dataOrder )
	DEFINE_PROPERTY_V( int, origin )
	DEFINE_PROPERTY_V( int, align )
	DEFINE_PROPERTY_V( int, width )
	DEFINE_PROPERTY_V( int, height )
	DEFINE_PROPERTY_SP( IplROI, roi )
	DEFINE_PROPERTY_SP( IplImage, maskROI )
	DEFINE_PROPERTY_P( void*, imageId )
	DEFINE_PROPERTY_SP( IplTileInfo, tileInfo )
	DEFINE_PROPERTY_V( int, imageSize )
	DEFINE_PROPERTY_VP( char, imageData )
	DEFINE_PROPERTY_V( int, widthStep )
	DEFINE_PROPERTY_VA( int, BorderMode, 4 )
	DEFINE_PROPERTY_VA( int, BorderConst, 4 )
	DEFINE_PROPERTY_VP( char, imageDataOrigin )
private:
Bitmap^	mBmp;	// �C���[�W��ێ����܂��B

// .Net Framework�p�̃r�b�g�}�b�v�C���[�W���쐬���܂��B
void CreateBitmapImage()
{
	// �r�b�g�}�b�v����
	CreateBitmap( this, mBmp );
}
public:

// �r�b�g�}�b�v���X�V���܂��B
void UpdateBitmapImage()
{
	CreateBitmapImage();
}

// �r�b�g�}�b�v��Ԃ��܂��B
property Bitmap^ BitmapImage
{
	Bitmap^ get()	{ return mBmp; }
}
};

// typedef struct _IplTileInfo IplTileInfo;
DEFINE_HANDLE( IplTileInfo )

// typedef struct _IplROI
// {
//     int  coi; /* 0 - no COI (all channels are selected), 1 - 0th channel is selected ...*/
//     int  xOffset;
//     int  yOffset;
//     int  width;
//     int  height;
// }
// IplROI;
DEFINE_STRUCT( IplROI )
{STRUCT_BASIC( IplROI )
	DEFINE_PROPERTY_V( int, coi )
	DEFINE_PROPERTY_V( int, xOffset )
	DEFINE_PROPERTY_V( int, yOffset )
	DEFINE_PROPERTY_V( int, width )
	DEFINE_PROPERTY_V( int, height )
};

// typedef struct _IplConvKernel
// {
//     int  nCols;
//     int  nRows;
//     int  anchorX;
//     int  anchorY;
//     int *values;
//     int  nShiftR;
// }
// IplConvKernel;
DEFINE_STRUCT( IplConvKernel )
{STRUCT_BASIC( IplConvKernel )
	DEFINE_PROPERTY_V( int, nCols )
	DEFINE_PROPERTY_V( int, nRows )
	DEFINE_PROPERTY_V( int, anchorX )
	DEFINE_PROPERTY_V( int, anchorY )
	DEFINE_PROPERTY_VP( int, values )
	DEFINE_PROPERTY_V( int, nShiftR )
};

// typedef struct _IplConvKernelFP
// {
//     int  nCols;
//     int  nRows;
//     int  anchorX;
//     int  anchorY;
//     float *values;
// }
// IplConvKernelFP;
DEFINE_STRUCT( IplConvKernelFP )
{STRUCT_BASIC( IplConvKernelFP )
	DEFINE_PROPERTY_V( int, nCols )
	DEFINE_PROPERTY_V( int, nRows )
	DEFINE_PROPERTY_V( int, anchorX )
	DEFINE_PROPERTY_V( int, anchorY )
	DEFINE_PROPERTY_VP( float, values )
};

// #define IPL_IMAGE_HEADER 1
#pragma push_macro( "IPL_IMAGE_HEADER" )
#undef IPL_IMAGE_HEADER
static const int IPL_IMAGE_HEADER
#pragma pop_macro( "IPL_IMAGE_HEADER" )
	= IPL_IMAGE_HEADER;
// #define IPL_IMAGE_DATA   2
#pragma push_macro( "IPL_IMAGE_DATA" )
#undef IPL_IMAGE_DATA
static const int IPL_IMAGE_DATA
#pragma pop_macro( "IPL_IMAGE_DATA" )
	= IPL_IMAGE_DATA;
// #define IPL_IMAGE_ROI    4
#pragma push_macro( "IPL_IMAGE_ROI" )
#undef IPL_IMAGE_ROI
static const int IPL_IMAGE_ROI
#pragma pop_macro( "IPL_IMAGE_ROI" )
	= IPL_IMAGE_ROI;

////#endif/*HAVE_IPL*/

/* extra border mode */
// #define IPL_BORDER_REFLECT_101    4
#pragma push_macro( "IPL_BORDER_REFLECT_101" )
#undef IPL_BORDER_REFLECT_101
static const int IPL_BORDER_REFLECT_101
#pragma pop_macro( "IPL_BORDER_REFLECT_101" )
	= IPL_BORDER_REFLECT_101;

// #define IPL_IMAGE_MAGIC_VAL  ((int)sizeof(IplImage))
// ToDo
// #define CV_TYPE_NAME_IMAGE "opencv-image"
#pragma push_macro( "CV_TYPE_NAME_IMAGE" )
#undef CV_TYPE_NAME_IMAGE
static const String^ CV_TYPE_NAME_IMAGE
#pragma pop_macro( "CV_TYPE_NAME_IMAGE" )
	= CV_TYPE_NAME_IMAGE;

// #define CV_IS_IMAGE_HDR(img) \
//     ((img) != NULL && ((const IplImage*)(img))->nSize == sizeof(IplImage))
// Unsupport : CV_IS_IMAGE_HDR

// #define CV_IS_IMAGE(img) \
//     (CV_IS_IMAGE_HDR(img) && ((IplImage*)img)->imageData != NULL)
// Unsupport : CV_IS_IMAGE

/* for storing double-precision
   floating point data in IplImage's */
// #define IPL_DEPTH_64F  64
#pragma push_macro( "IPL_DEPTH_64F" )
#undef IPL_DEPTH_64F
static const int IPL_DEPTH_64F
#pragma pop_macro( "IPL_DEPTH_64F" )
	= IPL_DEPTH_64F;

/* get reference to pixel at (col,row),
   for multi-channel images (col) should be multiplied by number of channels */
// #define CV_IMAGE_ELEM( image, elemtype, row, col )       \
//     (((elemtype*)((image)->imageData + (image)->widthStep*(row)))[(col)])
// Unsupport : CV_IMAGE_ELEM

/****************************************************************************************\
*                                  Matrix type (CvMat)                                   *
\****************************************************************************************/

// #define CV_CN_MAX     64
#pragma push_macro( "CV_CN_MAX" )
#undef CV_CN_MAX
static const int CV_CN_MAX
#pragma pop_macro( "CV_CN_MAX" )
	= CV_CN_MAX;
// #define CV_CN_SHIFT   3
#pragma push_macro( "CV_CN_SHIFT" )
#undef CV_CN_SHIFT
static const int CV_CN_SHIFT
#pragma pop_macro( "CV_CN_SHIFT" )
	= CV_CN_SHIFT;
// #define CV_DEPTH_MAX  (1 << CV_CN_SHIFT)
#pragma push_macro( "CV_DEPTH_MAX" )
#undef CV_DEPTH_MAX
static const int CV_DEPTH_MAX
#pragma pop_macro( "CV_DEPTH_MAX" )
	= CV_DEPTH_MAX;

// #define CV_8U   0
#pragma push_macro( "CV_8U" )
#undef CV_8U
static const int CV_8U
#pragma pop_macro( "CV_8U" )
	= CV_8U;
// #define CV_8S   1
#pragma push_macro( "CV_8S" )
#undef CV_8S
static const int CV_8S
#pragma pop_macro( "CV_8S" )
	= CV_8S;
// #define CV_16U  2
#pragma push_macro( "CV_16U" )
#undef CV_16U
static const int CV_16U
#pragma pop_macro( "CV_16U" )
	= CV_16U;
// #define CV_16S  3
#pragma push_macro( "CV_16S" )
#undef CV_16S
static const int CV_16S
#pragma pop_macro( "CV_16S" )
	= CV_16S;
// #define CV_32S  4
#pragma push_macro( "CV_32S" )
#undef CV_32S
static const int CV_32S
#pragma pop_macro( "CV_32S" )
	= CV_32S;
// #define CV_32F  5
#pragma push_macro( "CV_32F" )
#undef CV_32F
static const int CV_32F
#pragma pop_macro( "CV_32F" )
	= CV_32F;
// #define CV_64F  6
#pragma push_macro( "CV_64F" )
#undef CV_64F
static const int CV_64F
#pragma pop_macro( "CV_64F" )
	= CV_64F;
// #define CV_USRTYPE1 7
#pragma push_macro( "CV_USRTYPE1" )
#undef CV_USRTYPE1
static const int CV_USRTYPE1
#pragma pop_macro( "CV_USRTYPE1" )
	= CV_USRTYPE1;

// #define CV_MAT_DEPTH_MASK       (CV_DEPTH_MAX - 1)
#pragma push_macro( "CV_MAT_DEPTH_MASK" )
#undef CV_MAT_DEPTH_MASK
static const int CV_MAT_DEPTH_MASK
#pragma pop_macro( "CV_MAT_DEPTH_MASK" )
	= CV_MAT_DEPTH_MASK;
// #define CV_MAT_DEPTH(flags)     ((flags) & CV_MAT_DEPTH_MASK)
// Unsupport : CV_MAT_DEPTH

// #define CV_MAKETYPE(depth,cn) (CV_MAT_DEPTH(depth) + (((cn)-1) << CV_CN_SHIFT))
// Unsupport : CV_MAKETYPE
// #define CV_MAKE_TYPE CV_MAKETYPE
// unsupport

// #define CV_8UC1 CV_MAKETYPE(CV_8U,1)
#pragma push_macro( "CV_8UC1" )
#undef CV_8UC1
static const int CV_8UC1
#pragma pop_macro( "CV_8UC1" )
	= CV_8UC1;
// #define CV_8UC2 CV_MAKETYPE(CV_8U,2)
#pragma push_macro( "CV_8UC2" )
#undef CV_8UC2
static const int CV_8UC2
#pragma pop_macro( "CV_8UC2" )
	= CV_8UC2;
// #define CV_8UC3 CV_MAKETYPE(CV_8U,3)
#pragma push_macro( "CV_8UC3" )
#undef CV_8UC3
static const int CV_8UC3
#pragma pop_macro( "CV_8UC3" )
	= CV_8UC3;
// #define CV_8UC4 CV_MAKETYPE(CV_8U,4)
#pragma push_macro( "CV_8UC4" )
#undef CV_8UC4
static const int CV_8UC4
#pragma pop_macro( "CV_8UC4" )
	= CV_8UC4;
// #define CV_8UC(n) CV_MAKETYPE(CV_8U,(n))
// Unsupport : CV_8UC

// #define CV_8SC1 CV_MAKETYPE(CV_8S,1)
#pragma push_macro( "CV_8SC1" )
#undef CV_8SC1
static const int CV_8SC1
#pragma pop_macro( "CV_8SC1" )
	= CV_8SC1;
// #define CV_8SC2 CV_MAKETYPE(CV_8S,2)
#pragma push_macro( "CV_8SC2" )
#undef CV_8SC2
static const int CV_8SC2
#pragma pop_macro( "CV_8SC2" )
	= CV_8SC2;
// #define CV_8SC3 CV_MAKETYPE(CV_8S,3)
#pragma push_macro( "CV_8SC3" )
#undef CV_8SC3
static const int CV_8SC3
#pragma pop_macro( "CV_8SC3" )
	= CV_8SC3;
// #define CV_8SC4 CV_MAKETYPE(CV_8S,4)
#pragma push_macro( "CV_8SC4" )
#undef CV_8SC4
static const int CV_8SC4
#pragma pop_macro( "CV_8SC4" )
	= CV_8SC4;
// #define CV_8SC(n) CV_MAKETYPE(CV_8S,(n))
// Unsupport : CV_8SC

// #define CV_16UC1 CV_MAKETYPE(CV_16U,1)
#pragma push_macro( "CV_16UC1" )
#undef CV_16UC1
static const int CV_16UC1
#pragma pop_macro( "CV_16UC1" )
	= CV_16UC1;
// #define CV_16UC2 CV_MAKETYPE(CV_16U,2)
#pragma push_macro( "CV_16UC2" )
#undef CV_16UC2
static const int CV_16UC2
#pragma pop_macro( "CV_16UC2" )
	= CV_16UC2;
// #define CV_16UC3 CV_MAKETYPE(CV_16U,3)
#pragma push_macro( "CV_16UC3" )
#undef CV_16UC3
static const int CV_16UC3
#pragma pop_macro( "CV_16UC3" )
	= CV_16UC3;
// #define CV_16UC4 CV_MAKETYPE(CV_16U,4)
#pragma push_macro( "CV_16UC4" )
#undef CV_16UC4
static const int CV_16UC4
#pragma pop_macro( "CV_16UC4" )
	= CV_16UC4;
// #define CV_16UC(n) CV_MAKETYPE(CV_16U,(n))
// Unsupport : CV_16UC

// #define CV_16SC1 CV_MAKETYPE(CV_16S,1)
#pragma push_macro( "CV_16SC1" )
#undef CV_16SC1
static const int CV_16SC1
#pragma pop_macro( "CV_16SC1" )
	= CV_16SC1;
// #define CV_16SC2 CV_MAKETYPE(CV_16S,2)
#pragma push_macro( "CV_16SC2" )
#undef CV_16SC2
static const int CV_16SC2
#pragma pop_macro( "CV_16SC2" )
	= CV_16SC2;
// #define CV_16SC3 CV_MAKETYPE(CV_16S,3)
#pragma push_macro( "CV_16SC3" )
#undef CV_16SC3
static const int CV_16SC3
#pragma pop_macro( "CV_16SC3" )
	= CV_16SC3;
// #define CV_16SC4 CV_MAKETYPE(CV_16S,4)
#pragma push_macro( "CV_16SC4" )
#undef CV_16SC4
static const int CV_16SC4
#pragma pop_macro( "CV_16SC4" )
	= CV_16SC4;
// #define CV_16SC(n) CV_MAKETYPE(CV_16S,(n))
// Unsupport : CV_16SC

// #define CV_32SC1 CV_MAKETYPE(CV_32S,1)
#pragma push_macro( "CV_32SC1" )
#undef CV_32SC1
static const int CV_32SC1
#pragma pop_macro( "CV_32SC1" )
	= CV_32SC1;
// #define CV_32SC2 CV_MAKETYPE(CV_32S,2)
#pragma push_macro( "CV_32SC2" )
#undef CV_32SC2
static const int CV_32SC2
#pragma pop_macro( "CV_32SC2" )
	= CV_32SC2;
// #define CV_32SC3 CV_MAKETYPE(CV_32S,3)
#pragma push_macro( "CV_32SC3" )
#undef CV_32SC3
static const int CV_32SC3
#pragma pop_macro( "CV_32SC3" )
	= CV_32SC3;
// #define CV_32SC4 CV_MAKETYPE(CV_32S,4)
#pragma push_macro( "CV_32SC4" )
#undef CV_32SC4
static const int CV_32SC4
#pragma pop_macro( "CV_32SC4" )
	= CV_32SC4;
// #define CV_32SC(n) CV_MAKETYPE(CV_32S,(n))
// Unsupport : CV_32SC

// #define CV_32FC1 CV_MAKETYPE(CV_32F,1)
#pragma push_macro( "CV_32FC1" )
#undef CV_32FC1
static const int CV_32FC1
#pragma pop_macro( "CV_32FC1" )
	= CV_32FC1;
// #define CV_32FC2 CV_MAKETYPE(CV_32F,2)
#pragma push_macro( "CV_32FC2" )
#undef CV_32FC2
static const int CV_32FC2
#pragma pop_macro( "CV_32FC2" )
	= CV_32FC2;
// #define CV_32FC3 CV_MAKETYPE(CV_32F,3)
#pragma push_macro( "CV_32FC3" )
#undef CV_32FC3
static const int CV_32FC3
#pragma pop_macro( "CV_32FC3" )
	= CV_32FC3;
// #define CV_32FC4 CV_MAKETYPE(CV_32F,4)
#pragma push_macro( "CV_32FC4" )
#undef CV_32FC4
static const int CV_32FC4
#pragma pop_macro( "CV_32FC4" )
	= CV_32FC4;
// #define CV_32FC(n) CV_MAKETYPE(CV_32F,(n))
// Unsupport : CV_32FC

// #define CV_64FC1 CV_MAKETYPE(CV_64F,1)
#pragma push_macro( "CV_64FC1" )
#undef CV_64FC1
static const int CV_64FC1
#pragma pop_macro( "CV_64FC1" )
	= CV_64FC1;
// #define CV_64FC2 CV_MAKETYPE(CV_64F,2)
#pragma push_macro( "CV_64FC2" )
#undef CV_64FC2
static const int CV_64FC2
#pragma pop_macro( "CV_64FC2" )
	= CV_64FC2;
// #define CV_64FC3 CV_MAKETYPE(CV_64F,3)
#pragma push_macro( "CV_64FC3" )
#undef CV_64FC3
static const int CV_64FC3
#pragma pop_macro( "CV_64FC3" )
	= CV_64FC3;
// #define CV_64FC4 CV_MAKETYPE(CV_64F,4)
#pragma push_macro( "CV_64FC4" )
#undef CV_64FC4
static const int CV_64FC4
#pragma pop_macro( "CV_64FC4" )
	= CV_64FC4;
// #define CV_64FC(n) CV_MAKETYPE(CV_64F,(n))
// Unsupport : CV_64FC

// #define CV_AUTO_STEP  0x7fffffff
#pragma push_macro( "CV_AUTO_STEP" )
#undef CV_AUTO_STEP
static const int CV_AUTO_STEP
#pragma pop_macro( "CV_AUTO_STEP" )
	= CV_AUTO_STEP;
// #define CV_WHOLE_ARR  cvSlice( 0, 0x3fffffff )
// ToDo

// #define CV_MAT_CN_MASK          ((CV_CN_MAX - 1) << CV_CN_SHIFT)
#pragma push_macro( "CV_MAT_CN_MASK" )
#undef CV_MAT_CN_MASK
static const int CV_MAT_CN_MASK
#pragma pop_macro( "CV_MAT_CN_MASK" )
	= CV_MAT_CN_MASK;
// #define CV_MAT_CN(flags)        ((((flags) & CV_MAT_CN_MASK) >> CV_CN_SHIFT) + 1)
// Unsupport : CV_MAT_CN
// #define CV_MAT_TYPE_MASK        (CV_DEPTH_MAX*CV_CN_MAX - 1)
#pragma push_macro( "CV_MAT_TYPE_MASK" )
#undef CV_MAT_TYPE_MASK
static const int CV_MAT_TYPE_MASK
#pragma pop_macro( "CV_MAT_TYPE_MASK" )
	= CV_MAT_TYPE_MASK;
// #define CV_MAT_TYPE(flags)      ((flags) & CV_MAT_TYPE_MASK)
// Unsupport : CV_MAT_TYPE
// #define CV_MAT_CONT_FLAG_SHIFT  14
#pragma push_macro( "CV_MAT_CONT_FLAG_SHIFT" )
#undef CV_MAT_CONT_FLAG_SHIFT
static const int CV_MAT_CONT_FLAG_SHIFT
#pragma pop_macro( "CV_MAT_CONT_FLAG_SHIFT" )
	= CV_MAT_CONT_FLAG_SHIFT;
// #define CV_MAT_CONT_FLAG        (1 << CV_MAT_CONT_FLAG_SHIFT)
#pragma push_macro( "CV_MAT_CONT_FLAG" )
#undef CV_MAT_CONT_FLAG
static const int CV_MAT_CONT_FLAG
#pragma pop_macro( "CV_MAT_CONT_FLAG" )
	= CV_MAT_CONT_FLAG;
// #define CV_IS_MAT_CONT(flags)   ((flags) & CV_MAT_CONT_FLAG)
// Unsupport : CV_IS_MAT_CONT
// #define CV_IS_CONT_MAT          CV_IS_MAT_CONT
// ToDo
// #define CV_MAT_TEMP_FLAG_SHIFT  15
#pragma push_macro( "CV_MAT_TEMP_FLAG_SHIFT" )
#undef CV_MAT_TEMP_FLAG_SHIFT
static const int CV_MAT_TEMP_FLAG_SHIFT
#pragma pop_macro( "CV_MAT_TEMP_FLAG_SHIFT" )
	= CV_MAT_TEMP_FLAG_SHIFT;
// #define CV_MAT_TEMP_FLAG        (1 << CV_MAT_TEMP_FLAG_SHIFT)
#pragma push_macro( "CV_MAT_TEMP_FLAG" )
#undef CV_MAT_TEMP_FLAG
static const int CV_MAT_TEMP_FLAG
#pragma pop_macro( "CV_MAT_TEMP_FLAG" )
	= CV_MAT_TEMP_FLAG;
// #define CV_IS_TEMP_MAT(flags)   ((flags) & CV_MAT_TEMP_FLAG)
// Unsupport : CV_IS_TEMP_MAT

// #define CV_MAGIC_MASK       0xFFFF0000
#pragma push_macro( "CV_MAGIC_MASK" )
#undef CV_MAGIC_MASK
static const int CV_MAGIC_MASK
#pragma pop_macro( "CV_MAGIC_MASK" )
	= CV_MAGIC_MASK;
// #define CV_MAT_MAGIC_VAL    0x42420000
#pragma push_macro( "CV_MAT_MAGIC_VAL" )
#undef CV_MAT_MAGIC_VAL
static const int CV_MAT_MAGIC_VAL
#pragma pop_macro( "CV_MAT_MAGIC_VAL" )
	= CV_MAT_MAGIC_VAL;
// #define CV_TYPE_NAME_MAT    "opencv-matrix"
#pragma push_macro( "CV_TYPE_NAME_MAT" )
#undef CV_TYPE_NAME_MAT
static const String^ CV_TYPE_NAME_MAT
#pragma pop_macro( "CV_TYPE_NAME_MAT" )
	= CV_TYPE_NAME_MAT;

// typedef struct CvMat
// {
//     int type;
//     int step;
// 
//     /* for internal use only */
//     int* refcount;
//     int hdr_refcount;
// 
//     union
//     {
//         uchar* ptr;
//         short* s;
//         int* i;
//         float* fl;
//         double* db;
//     } data;
// 
// ////#ifdef __cplusplus
// ////    union
// ////    {
// ////        int rows;
// ////        int height;
// ////    };
// ////
// ////    union
// ////    {
// ////        int cols;
// ////        int width;
// ////    };
// ////#else
//     int rows;
//     int cols;
// ////#endif
// 
// }
// CvMat;
DEFINE_STRUCT( CvMat )
{STRUCT_BASIC( CvMat )
	DEFINE_PROPERTY_V( int, type )
	DEFINE_PROPERTY_V( int, step )
	DEFINE_PROPERTY_VP( int, refcount )
	DEFINE_PROPERTY_V( int, hdr_refcount )
DEFINE_PROPERTY_P_CORE( , this->BasePtr->data.ptr, this->BasePtr->data.ptr, unsigned char *, data )
	DEFINE_PROPERTY_V( int, rows )
	DEFINE_PROPERTY_V( int, cols )
DEFINE_SETUP_CONSTRUCTOR( CvMat, cvMat, 4( V(int,rows), V(int,cols), V(int,type), P(void*,data) ) )
DEFINE_SETUP_CONSTRUCTOR( CvMat, cvMat, 3( V(int,rows), V(int,cols), V(int,type) ) )
};


// #define CV_IS_MAT_HDR(mat) \
//     ((mat) != NULL && \
//     (((const CvMat*)(mat))->type & CV_MAGIC_MASK) == CV_MAT_MAGIC_VAL && \
//     ((const CvMat*)(mat))->cols > 0 && ((const CvMat*)(mat))->rows > 0)
// Unsupport : CV_IS_MAT_HDR

// #define CV_IS_MAT(mat) \
//     (CV_IS_MAT_HDR(mat) && ((const CvMat*)(mat))->data.ptr != NULL)
// Unsupport : CV_IS_MAT

// #define CV_IS_MASK_ARR(mat) \
//     (((mat)->type & (CV_MAT_TYPE_MASK & ~CV_8SC1)) == 0)
// Unsupport : CV_IS_MASK_ARR

// #define CV_ARE_TYPES_EQ(mat1, mat2) \
//     ((((mat1)->type ^ (mat2)->type) & CV_MAT_TYPE_MASK) == 0)
// Unsupport : CV_ARE_TYPES_EQ

// #define CV_ARE_CNS_EQ(mat1, mat2) \
//     ((((mat1)->type ^ (mat2)->type) & CV_MAT_CN_MASK) == 0)
// Unsupport : CV_ARE_CNS_EQ

// #define CV_ARE_DEPTHS_EQ(mat1, mat2) \
//     ((((mat1)->type ^ (mat2)->type) & CV_MAT_DEPTH_MASK) == 0)
// Unsupport : CV_ARE_DEPTHS_EQ

// #define CV_ARE_SIZES_EQ(mat1, mat2) \
//     ((mat1)->rows == (mat2)->rows && (mat1)->cols == (mat2)->cols)
// Unsupport : CV_ARE_SIZES_EQ

// #define CV_IS_MAT_CONST(mat)  \
//     (((mat)->rows|(mat)->cols) == 1)
// Unsupport : CV_IS_MAT_CONST

/* Size of each channel item,
   0x124489 = 1000 0100 0100 0010 0010 0001 0001 ~ array of sizeof(arr_type_elem) */
// #define CV_ELEM_SIZE1(type) \
//     ((((sizeof(size_t)<<28)|0x8442211) >> CV_MAT_DEPTH(type)*4) & 15)
// Unsupport : CV_ELEM_SIZE1

/* 0x3a50 = 11 10 10 01 01 00 00 ~ array of log2(sizeof(arr_type_elem)) */
// #define CV_ELEM_SIZE(type) \
//     (CV_MAT_CN(type) << ((((sizeof(size_t)/4+1)*16384|0x3a50) >> CV_MAT_DEPTH(type)*2) & 3))
// Unsupport : CV_ELEM_SIZE

/* Inline constructor. No data is allocated internally!!!
 * (Use together with cvCreateData, or use cvCreateMat instead to
 * get a matrix with allocated data):
 */
// CV_INLINE CvMat cvMat( int rows, int cols, int type, void* data CV_DEFAULT(NULL))
// {
//     CvMat m;
// 
//     assert( (unsigned)CV_MAT_DEPTH(type) <= CV_64F );
//     type = CV_MAT_TYPE(type);
//     m.type = CV_MAT_MAGIC_VAL | CV_MAT_CONT_FLAG | type;
//     m.cols = cols;
//     m.rows = rows;
//     m.step = m.cols*CV_ELEM_SIZE(type);
//     m.data.ptr = (uchar*)data;
//     m.refcount = NULL;
//     m.hdr_refcount = 0;
// 
//     return m;
// }
DEFINE_FUNCTION_ALIAS( S(CvMat), cvMat, cvMat_, 4( V(int,rows), V(int,cols), V(int,type), P(void*,data) ) ) 
DEFINE_FUNCTION_ALIAS( S(CvMat), cvMat, cvMat_, 3( V(int,rows), V(int,cols), V(int,type) ) ) 


// #define CV_MAT_ELEM_PTR_FAST( mat, row, col, pix_size )  \
//     (assert( (unsigned)(row) < (unsigned)(mat).rows &&   \
//              (unsigned)(col) < (unsigned)(mat).cols ),   \
//      (mat).data.ptr + (size_t)(mat).step*(row) + (pix_size)*(col))
// Unsupport : CV_MAT_ELEM_PTR_FAST

// #define CV_MAT_ELEM_PTR( mat, row, col )                 \
//     CV_MAT_ELEM_PTR_FAST( mat, row, col, CV_ELEM_SIZE((mat).type) )
// Unsupport : CV_MAT_ELEM_PTR

// #define CV_MAT_ELEM( mat, elemtype, row, col )           \
//     (*(elemtype*)CV_MAT_ELEM_PTR_FAST( mat, row, col, sizeof(elemtype)))
// Unsupport : CV_MAT_ELEM


// CV_INLINE  double  cvmGet( const CvMat* mat, int row, int col )
// {
//     int type;
// 
//     type = CV_MAT_TYPE(mat->type);
//     assert( (unsigned)row < (unsigned)mat->rows &&
//             (unsigned)col < (unsigned)mat->cols );
// 
//     if( type == CV_32FC1 )
//         return ((float*)(mat->data.ptr + (size_t)mat->step*row))[col];
//     else
//     {
//         assert( type == CV_64FC1 );
//         return ((double*)(mat->data.ptr + (size_t)mat->step*row))[col];
//     }
// }
DEFINE_FUNCTION( V(double), cvmGet, 3( SP(CvMat,mat), V(int,row), V(int,col) ) ) 


// CV_INLINE  void  cvmSet( CvMat* mat, int row, int col, double value )
// {
//     int type;
//     type = CV_MAT_TYPE(mat->type);
//     assert( (unsigned)row < (unsigned)mat->rows &&
//             (unsigned)col < (unsigned)mat->cols );
// 
//     if( type == CV_32FC1 )
//         ((float*)(mat->data.ptr + (size_t)mat->step*row))[col] = (float)value;
//     else
//     {
//         assert( type == CV_64FC1 );
//         ((double*)(mat->data.ptr + (size_t)mat->step*row))[col] = (double)value;
//     }
// }
DEFINE_FUNCTION( N(void), cvmSet, 4( SP(CvMat,mat), V(int,row), V(int,col), V(double,value) ) ) 


// CV_INLINE int cvIplDepth( int type )
// {
//     int depth = CV_MAT_DEPTH(type);
//     return CV_ELEM_SIZE1(depth)*8 | (depth == CV_8S || depth == CV_16S ||
//            depth == CV_32S ? IPL_DEPTH_SIGN : 0);
// }
DEFINE_FUNCTION( V(int), cvIplDepth, 1( V(int,type) ) ) 


/****************************************************************************************\
*                       Multi-dimensional dense array (CvMatND)                          *
\****************************************************************************************/

// #define CV_MATND_MAGIC_VAL    0x42430000
#pragma push_macro( "CV_MATND_MAGIC_VAL" )
#undef CV_MATND_MAGIC_VAL
static const int CV_MATND_MAGIC_VAL
#pragma pop_macro( "CV_MATND_MAGIC_VAL" )
	= CV_MATND_MAGIC_VAL;
// #define CV_TYPE_NAME_MATND    "opencv-nd-matrix"
#pragma push_macro( "CV_TYPE_NAME_MATND" )
#undef CV_TYPE_NAME_MATND
static const String^ CV_TYPE_NAME_MATND
#pragma pop_macro( "CV_TYPE_NAME_MATND" )
	= CV_TYPE_NAME_MATND;

// #define CV_MAX_DIM            32
#pragma push_macro( "CV_MAX_DIM" )
#undef CV_MAX_DIM
static const int CV_MAX_DIM
#pragma pop_macro( "CV_MAX_DIM" )
	= CV_MAX_DIM;
// #define CV_MAX_DIM_HEAP       (1 << 16)
#pragma push_macro( "CV_MAX_DIM_HEAP" )
#undef CV_MAX_DIM_HEAP
static const int CV_MAX_DIM_HEAP
#pragma pop_macro( "CV_MAX_DIM_HEAP" )
	= CV_MAX_DIM_HEAP;

// typedef struct CvMatND
// {
//     int type;
//     int dims;
// 
//     int* refcount;
//     int hdr_refcount;
// 
//     union
//     {
//         uchar* ptr;
//         float* fl;
//         double* db;
//         int* i;
//         short* s;
//     } data;
// 
//     struct
//     {
//         int size;
//         int step;
//     }
//     dim[CV_MAX_DIM];
// }
// CvMatND;
DEFINE_STRUCT( CvMatND_DIM )
{
	CvMatND_DIM( UNAME(CvMatND)* Src, int Index ) : StructBase( Src, 0, false )
	{
		mIndex = Index;
	}

	DEFINE_ACCESSMETHOD( CvMatND )
	DEFINE_PROPERTY_V_CORE( , this->BasePtr->dim[ mIndex ].size, int, size )
	DEFINE_PROPERTY_V_CORE( , this->BasePtr->dim[ mIndex ].step, int, step )

private:
	int		mIndex;
};
DEFINE_STRUCT( CvMatND )
{STRUCT_BASIC( CvMatND )
	DEFINE_PROPERTY_V( int, type )
	DEFINE_PROPERTY_V( int, dims )
	DEFINE_PROPERTY_VP( int, refcount )
	DEFINE_PROPERTY_V( int, hdr_refcount )
DEFINE_PROPERTY_P_CORE( , this->BasePtr->data.ptr, this->BasePtr->data.ptr, unsigned char *, data )
DEFINE_PROPERTY_CORE_S( , MNAME(CvMatND_DIM), dim, 1,
	{ /* �������̏��� */
		if( _dim == nullptr ) { _dim = gcnew array<MNAME(CvMatND_DIM)^>( CV_MAX_DIM ); }
		if( _dim[ Index ] == nullptr ) { _dim[ Index ] = gcnew MNAME(CvMatND_DIM)( this->BasePtr, Index ); }
		return _dim[ Index ];
	},
	{ /* �擾���̏��� */
		return Get_dim( Index );
	},
	{ /* ������̏��� */
		throw gcnew System::NotImplementedException( "�������O�����\���̃f�[�^�ւ̑���̓T�|�[�g����Ă��܂���B" );
	} )
};

// #define CV_IS_MATND_HDR(mat) \
//     ((mat) != NULL && (((const CvMatND*)(mat))->type & CV_MAGIC_MASK) == CV_MATND_MAGIC_VAL)
// Unsupport : CV_IS_MATND_HDR

// #define CV_IS_MATND(mat) \
//     (CV_IS_MATND_HDR(mat) && ((const CvMatND*)(mat))->data.ptr != NULL)
// Unsupport : CV_IS_MATND


/****************************************************************************************\
*                      Multi-dimensional sparse array (CvSparseMat)                      *
\****************************************************************************************/

// #define CV_SPARSE_MAT_MAGIC_VAL    0x42440000
#pragma push_macro( "CV_SPARSE_MAT_MAGIC_VAL" )
#undef CV_SPARSE_MAT_MAGIC_VAL
static const int CV_SPARSE_MAT_MAGIC_VAL
#pragma pop_macro( "CV_SPARSE_MAT_MAGIC_VAL" )
	= CV_SPARSE_MAT_MAGIC_VAL;
// #define CV_TYPE_NAME_SPARSE_MAT    "opencv-sparse-matrix"
#pragma push_macro( "CV_TYPE_NAME_SPARSE_MAT" )
#undef CV_TYPE_NAME_SPARSE_MAT
static const String^ CV_TYPE_NAME_SPARSE_MAT
#pragma pop_macro( "CV_TYPE_NAME_SPARSE_MAT" )
	= CV_TYPE_NAME_SPARSE_MAT;

// struct CvSet;

// typedef struct CvSparseMat
// {
//     int type;
//     int dims;
//     int* refcount;
//     int hdr_refcount;
// 
//     struct CvSet* heap;
//     void** hashtable;
//     int hashsize;
//     int valoffset;
//     int idxoffset;
//     int size[CV_MAX_DIM];
// }
// CvSparseMat;
DEFINE_STRUCT_PROTOTYPE( CvSet )
DEFINE_STRUCT( CvSparseMat )
{STRUCT_BASIC( CvSparseMat )
	DEFINE_PROPERTY_V( int, type )
	DEFINE_PROPERTY_V( int, dims )
	DEFINE_PROPERTY_VP( int, refcount )
	DEFINE_PROPERTY_V( int, hdr_refcount )
	DEFINE_PROPERTY_SP( CvSet, heap )
	DEFINE_PROPERTY_P( void**, hashtable )
	DEFINE_PROPERTY_V( int, hashsize )
	DEFINE_PROPERTY_V( int, valoffset )
	DEFINE_PROPERTY_V( int, idxoffset )
	DEFINE_PROPERTY_VA( int, size, CV_MAX_DIM )
};

// #define CV_IS_SPARSE_MAT_HDR(mat) \
//     ((mat) != NULL && \
//     (((const CvSparseMat*)(mat))->type & CV_MAGIC_MASK) == CV_SPARSE_MAT_MAGIC_VAL)
// Unsupport : CV_IS_SPARSE_MAT_HDR

// #define CV_IS_SPARSE_MAT(mat) \
//     CV_IS_SPARSE_MAT_HDR(mat)
// Unsupport : CV_IS_SPARSE_MAT

/**************** iteration through a sparse array *****************/

// typedef struct CvSparseNode
// {
//     unsigned hashval;
//     struct CvSparseNode* next;
// }
// CvSparseNode;
DEFINE_STRUCT( CvSparseNode )
{STRUCT_BASIC( CvSparseNode )
	DEFINE_PROPERTY_V( unsigned, hashval )
	DEFINE_PROPERTY_SP( CvSparseNode, next )
};

// typedef struct CvSparseMatIterator
// {
//     CvSparseMat* mat;
//     CvSparseNode* node;
//     int curidx;
// }
// CvSparseMatIterator;
DEFINE_STRUCT( CvSparseMatIterator )
{STRUCT_BASIC( CvSparseMatIterator )
	DEFINE_PROPERTY_SP( CvSparseMat, mat )
	DEFINE_PROPERTY_SP( CvSparseNode, node )
	DEFINE_PROPERTY_V( int, curidx )
};

// #define CV_NODE_VAL(mat,node)   ((void*)((uchar*)(node) + (mat)->valoffset))
// Unsupport : CV_NODE_VAL
// #define CV_NODE_IDX(mat,node)   ((int*)((uchar*)(node) + (mat)->idxoffset))
// Unsupport : CV_NODE_IDX

/****************************************************************************************\
*                                         Histogram                                      *
\****************************************************************************************/

// typedef int CvHistType;
// Unsupport : CvHistType

// #define CV_HIST_MAGIC_VAL     0x42450000
#pragma push_macro( "CV_HIST_MAGIC_VAL" )
#undef CV_HIST_MAGIC_VAL
static const int CV_HIST_MAGIC_VAL
#pragma pop_macro( "CV_HIST_MAGIC_VAL" )
	= CV_HIST_MAGIC_VAL;
// #define CV_HIST_UNIFORM_FLAG  (1 << 10)
#pragma push_macro( "CV_HIST_UNIFORM_FLAG" )
#undef CV_HIST_UNIFORM_FLAG
static const int CV_HIST_UNIFORM_FLAG
#pragma pop_macro( "CV_HIST_UNIFORM_FLAG" )
	= CV_HIST_UNIFORM_FLAG;

/* indicates whether bin ranges are set already or not */
// #define CV_HIST_RANGES_FLAG   (1 << 11)
#pragma push_macro( "CV_HIST_RANGES_FLAG" )
#undef CV_HIST_RANGES_FLAG
static const int CV_HIST_RANGES_FLAG
#pragma pop_macro( "CV_HIST_RANGES_FLAG" )
	= CV_HIST_RANGES_FLAG;

// #define CV_HIST_ARRAY         0
#pragma push_macro( "CV_HIST_ARRAY" )
#undef CV_HIST_ARRAY
static const int CV_HIST_ARRAY
#pragma pop_macro( "CV_HIST_ARRAY" )
	= CV_HIST_ARRAY;
// #define CV_HIST_SPARSE        1
#pragma push_macro( "CV_HIST_SPARSE" )
#undef CV_HIST_SPARSE
static const int CV_HIST_SPARSE
#pragma pop_macro( "CV_HIST_SPARSE" )
	= CV_HIST_SPARSE;
// #define CV_HIST_TREE          CV_HIST_SPARSE
#pragma push_macro( "CV_HIST_TREE" )
#undef CV_HIST_TREE
static const int CV_HIST_TREE
#pragma pop_macro( "CV_HIST_TREE" )
	= CV_HIST_TREE;

/* should be used as a parameter only,
   it turns to CV_HIST_UNIFORM_FLAG of hist->type */
// #define CV_HIST_UNIFORM       1
#pragma push_macro( "CV_HIST_UNIFORM" )
#undef CV_HIST_UNIFORM
static const int CV_HIST_UNIFORM
#pragma pop_macro( "CV_HIST_UNIFORM" )
	= CV_HIST_UNIFORM;

// typedef struct CvHistogram
// {
//     int     type;
//     CvArr*  bins;
//     float   thresh[CV_MAX_DIM][2];  /* For uniform histograms.                      */
//     float** thresh2;                /* For non-uniform histograms.                  */
//     CvMatND mat;                    /* Embedded matrix header for array histograms. */
// }
// CvHistogram;
DEFINE_STRUCT( CvHistogram )
{STRUCT_BASIC( CvHistogram )
	DEFINE_PROPERTY_V( int, type )
DEFINE_PROPERTY_P( UNAME(CvArr)*, bins )
	DEFINE_PROPERTY_VA2( float, thresh, CV_MAX_DIM, 2 )
	DEFINE_PROPERTY_VPP( float, thresh2 )
	DEFINE_PROPERTY_S( CvMatND, mat )
};

// #define CV_IS_HIST( hist ) \
//     ((hist) != NULL  && \
//      (((CvHistogram*)(hist))->type & CV_MAGIC_MASK) == CV_HIST_MAGIC_VAL && \
//      (hist)->bins != NULL)
// Unsupport : CV_IS_HIST

// #define CV_IS_UNIFORM_HIST( hist ) \
//     (((hist)->type & CV_HIST_UNIFORM_FLAG) != 0)
// Unsupport : CV_IS_UNIFORM_HIST

// #define CV_IS_SPARSE_HIST( hist ) \
//     CV_IS_SPARSE_MAT((hist)->bins)
// Unsupport : CV_IS_SPARSE_HIST

// #define CV_HIST_HAS_RANGES( hist ) \
//     (((hist)->type & CV_HIST_RANGES_FLAG) != 0)
// Unsupport : CV_HIST_HAS_RANGES

/****************************************************************************************\
*                      Other supplementary data type definitions                         *
\****************************************************************************************/

/*************************************** CvRect *****************************************/

// typedef struct CvRect
// {
//     int x;
//     int y;
//     int width;
//     int height;
// }
// CvRect;
DEFINE_STRUCT( CvRect )
{STRUCT_BASIC( CvRect )
	DEFINE_PROPERTY_V( int, x )
	DEFINE_PROPERTY_V( int, y )
	DEFINE_PROPERTY_V( int, width )
	DEFINE_PROPERTY_V( int, height )
DEFINE_SETUP_CONSTRUCTOR( CvRect, cvRect, 4( V(int,x), V(int,y), V(int,width), V(int,height) ) )
};

// CV_INLINE  CvRect  cvRect( int x, int y, int width, int height )
// {
//     CvRect r;
// 
//     r.x = x;
//     r.y = y;
//     r.width = width;
//     r.height = height;
// 
//     return r;
// }
DEFINE_FUNCTION_ALIAS( S(CvRect), cvRect, cvRect_, 4( V(int,x), V(int,y), V(int,width), V(int,height) ) ) 


// CV_INLINE  IplROI  cvRectToROI( CvRect rect, int coi )
// {
//     IplROI roi;
//     roi.xOffset = rect.x;
//     roi.yOffset = rect.y;
//     roi.width = rect.width;
//     roi.height = rect.height;
//     roi.coi = coi;
// 
//     return roi;
// }
DEFINE_FUNCTION( S(IplROI), cvRectToROI, 2( S(CvRect,rect), V(int,coi) ) ) 


// CV_INLINE  CvRect  cvROIToRect( IplROI roi )
// {
//     return cvRect( roi.xOffset, roi.yOffset, roi.width, roi.height );
// }
DEFINE_FUNCTION( S(CvRect), cvROIToRect, 1( S(IplROI,roi) ) ) 

/*********************************** CvTermCriteria *************************************/

// #define CV_TERMCRIT_ITER    1
#pragma push_macro( "CV_TERMCRIT_ITER" )
#undef CV_TERMCRIT_ITER
static const int CV_TERMCRIT_ITER
#pragma pop_macro( "CV_TERMCRIT_ITER" )
	= CV_TERMCRIT_ITER;
// #define CV_TERMCRIT_NUMBER  CV_TERMCRIT_ITER
#pragma push_macro( "CV_TERMCRIT_NUMBER" )
#undef CV_TERMCRIT_NUMBER
static const int CV_TERMCRIT_NUMBER
#pragma pop_macro( "CV_TERMCRIT_NUMBER" )
	= CV_TERMCRIT_NUMBER;
// #define CV_TERMCRIT_EPS     2
#pragma push_macro( "CV_TERMCRIT_EPS" )
#undef CV_TERMCRIT_EPS
static const int CV_TERMCRIT_EPS
#pragma pop_macro( "CV_TERMCRIT_EPS" )
	= CV_TERMCRIT_EPS;

// typedef struct CvTermCriteria
// {
//     int    type;  /* may be combination of
//                      CV_TERMCRIT_ITER
//                      CV_TERMCRIT_EPS */
//     int    max_iter;
//     double epsilon;
// }
// CvTermCriteria;
DEFINE_STRUCT( CvTermCriteria )
{STRUCT_BASIC( CvTermCriteria )
	DEFINE_PROPERTY_V( int, type )
	DEFINE_PROPERTY_V( int, max_iter )
	DEFINE_PROPERTY_V( double, epsilon )
DEFINE_SETUP_CONSTRUCTOR( CvTermCriteria, cvTermCriteria, 3( V(int,type), V(int,max_iter), V(double,epsilon) ) )
};

// CV_INLINE  CvTermCriteria  cvTermCriteria( int type, int max_iter, double epsilon )
// {
//     CvTermCriteria t;
// 
//     t.type = type;
//     t.max_iter = max_iter;
//     t.epsilon = (float)epsilon;
// 
//     return t;
// }
DEFINE_FUNCTION_ALIAS( S(CvTermCriteria), cvTermCriteria, cvTermCriteria_, 3( V(int,type), V(int,max_iter), V(double,epsilon) ) ) 


/******************************* CvPoint and variants ***********************************/

// typedef struct CvPoint
// {
//     int x;
//     int y;
// }
// CvPoint;
DEFINE_STRUCT( CvPoint )
{STRUCT_BASIC( CvPoint )
	DEFINE_PROPERTY_V( int, x )
	DEFINE_PROPERTY_V( int, y )
DEFINE_SETUP_CONSTRUCTOR( CvPoint, cvPoint, 2( V(int,x), V(int,y) ) )
};


// CV_INLINE  CvPoint  cvPoint( int x, int y )
// {
//     CvPoint p;
// 
//     p.x = x;
//     p.y = y;
// 
//     return p;
// }
DEFINE_FUNCTION_ALIAS( S(CvPoint), cvPoint, cvPoint_, 2( V(int,x), V(int,y) ) ) 


// typedef struct CvPoint2D32f
// {
//     float x;
//     float y;
// }
// CvPoint2D32f;
DEFINE_STRUCT( CvPoint2D32f )
{STRUCT_BASIC( CvPoint2D32f )
	DEFINE_PROPERTY_V( float, x )
	DEFINE_PROPERTY_V( float, y )
DEFINE_SETUP_CONSTRUCTOR( CvPoint2D32f, cvPoint2D32f, 2( V(float,x), V(float,y) ) )
};


// CV_INLINE  CvPoint2D32f  cvPoint2D32f( double x, double y )
// {
//     CvPoint2D32f p;
// 
//     p.x = (float)x;
//     p.y = (float)y;
// 
//     return p;
// }
DEFINE_FUNCTION_ALIAS( S(CvPoint2D32f), cvPoint2D32f, cvPoint2D32f_, 2( V(double,x), V(double,y) ) ) 


// CV_INLINE  CvPoint2D32f  cvPointTo32f( CvPoint point )
// {
//     return cvPoint2D32f( (float)point.x, (float)point.y );
// }
DEFINE_FUNCTION( S(CvPoint2D32f), cvPointTo32f, 1( S(CvPoint,point) ) ) 


// CV_INLINE  CvPoint  cvPointFrom32f( CvPoint2D32f point )
// {
//     CvPoint ipt;
//     ipt.x = cvRound(point.x);
//     ipt.y = cvRound(point.y);
// 
//     return ipt;
// }
DEFINE_FUNCTION( S(CvPoint), cvPointFrom32f, 1( S(CvPoint2D32f,point) ) ) 


// typedef struct CvPoint3D32f
// {
//     float x;
//     float y;
//     float z;
// }
// CvPoint3D32f;
DEFINE_STRUCT( CvPoint3D32f )
{STRUCT_BASIC( CvPoint3D32f )
	DEFINE_PROPERTY_V( float, x )
	DEFINE_PROPERTY_V( float, y )
	DEFINE_PROPERTY_V( float, z )
DEFINE_SETUP_CONSTRUCTOR( CvPoint3D32f, cvPoint3D32f, 3( V(float,x), V(float,y), V(float,z) ) )
};


// CV_INLINE  CvPoint3D32f  cvPoint3D32f( double x, double y, double z )
// {
//     CvPoint3D32f p;
// 
//     p.x = (float)x;
//     p.y = (float)y;
//     p.z = (float)z;
// 
//     return p;
// }
DEFINE_FUNCTION_ALIAS( S(CvPoint3D32f), cvPoint3D32f, cvPoint3D32f_, 3( V(double,x), V(double,y), V(double,z) ) ) 


// typedef struct CvPoint2D64f
// {
//     double x;
//     double y;
// }
// CvPoint2D64f;
DEFINE_STRUCT( CvPoint2D64f )
{STRUCT_BASIC( CvPoint2D64f )
	DEFINE_PROPERTY_V( double, x )
	DEFINE_PROPERTY_V( double, y )
};


// CV_INLINE  CvPoint2D64f  cvPoint2D64f( double x, double y )
// {
//     CvPoint2D64f p;
// 
//     p.x = x;
//     p.y = y;
// 
//     return p;
// }
DEFINE_FUNCTION_ALIAS( S(CvPoint2D64f), cvPoint2D64f, cvPoint2D64f_, 2( V(double,x), V(double,y) ) ) 


// typedef struct CvPoint3D64f
// {
//     double x;
//     double y;
//     double z;
// }
// CvPoint3D64f;
DEFINE_STRUCT( CvPoint3D64f )
{STRUCT_BASIC( CvPoint3D64f )
	DEFINE_PROPERTY_V( double, x )
	DEFINE_PROPERTY_V( double, y )
	DEFINE_PROPERTY_V( double, z )
DEFINE_SETUP_CONSTRUCTOR( CvPoint3D64f, cvPoint3D64f, 3( V(double,x), V(double,y), V(double,z) ) )
};


// CV_INLINE  CvPoint3D64f  cvPoint3D64f( double x, double y, double z )
// {
//     CvPoint3D64f p;
// 
//     p.x = x;
//     p.y = y;
//     p.z = z;
// 
//     return p;
// }
DEFINE_FUNCTION_ALIAS( S(CvPoint3D64f), cvPoint3D64f, cvPoint3D64f_, 3( V(double,x), V(double,y), V(double,z) ) ) 


/******************************** CvSize's & CvBox **************************************/

// typedef struct
// {
//     int width;
//     int height;
// }
// CvSize;
DEFINE_STRUCT( CvSize )
{STRUCT_BASIC( CvSize )
	DEFINE_PROPERTY_V( int, width )
	DEFINE_PROPERTY_V( int, height )
DEFINE_SETUP_CONSTRUCTOR( CvSize, cvSize, 2( V(int,width), V(int,height) ) )
};

// CV_INLINE  CvSize  cvSize( int width, int height )
// {
//     CvSize s;
// 
//     s.width = width;
//     s.height = height;
// 
//     return s;
// }
DEFINE_FUNCTION_ALIAS( S(CvSize), cvSize, cvSize_, 2( V(int,width), V(int,height) ) ) 

// typedef struct CvSize2D32f
// {
//     float width;
//     float height;
// }
// CvSize2D32f;
DEFINE_STRUCT( CvSize2D32f )
{STRUCT_BASIC( CvSize2D32f )
	DEFINE_PROPERTY_V( float, width )
	DEFINE_PROPERTY_V( float, height )
DEFINE_SETUP_CONSTRUCTOR( CvSize2D32f, cvSize2D32f, 2( V(double,width), V(double,height) ) )
};


// CV_INLINE  CvSize2D32f  cvSize2D32f( double width, double height )
// {
//     CvSize2D32f s;
// 
//     s.width = (float)width;
//     s.height = (float)height;
// 
//     return s;
// }
DEFINE_FUNCTION_ALIAS( S(CvSize2D32f), cvSize2D32f, cvSize2D32f_, 2( V(double,width), V(double,height) ) ) 

// typedef struct CvBox2D
// {
//     CvPoint2D32f center;  /* Center of the box.                          */
//     CvSize2D32f  size;    /* Box width and length.                       */
//     float angle;          /* Angle between the horizontal axis           */
//                           /* and the first side (i.e. length) in degrees */
// }
// CvBox2D;
DEFINE_STRUCT( CvBox2D )
{STRUCT_BASIC( CvBox2D )
	DEFINE_PROPERTY_S( CvPoint2D32f, center )
	DEFINE_PROPERTY_S( CvSize2D32f, size )
	DEFINE_PROPERTY_V( float, angle )
};


/* Line iterator state: */
// typedef struct CvLineIterator
// {
//     /* Pointer to the current point: */
//     uchar* ptr;
// 
//     /* Bresenham algorithm state: */
//     int  err;
//     int  plus_delta;
//     int  minus_delta;
//     int  plus_step;
//     int  minus_step;
// }
// CvLineIterator;
DEFINE_STRUCT( CvLineIterator )
{STRUCT_BASIC( CvLineIterator )
	DEFINE_PROPERTY_VP( unsigned char, ptr )
	DEFINE_PROPERTY_V( int, err )
	DEFINE_PROPERTY_V( int, plus_delta )
	DEFINE_PROPERTY_V( int, minus_delta )
	DEFINE_PROPERTY_V( int, plus_step )
	DEFINE_PROPERTY_V( int, minus_step )
};



/************************************* CvSlice ******************************************/

// typedef struct CvSlice
// {
//     int  start_index, end_index;
// }
// CvSlice;
DEFINE_STRUCT( CvSlice )
{STRUCT_BASIC( CvSlice )
	DEFINE_PROPERTY_V( int, start_index )
	DEFINE_PROPERTY_V( int, end_index )
DEFINE_SETUP_CONSTRUCTOR( CvSlice, cvSlice, 2( V(int,start), V(int,end) ) )
};

// CV_INLINE  CvSlice  cvSlice( int start, int end )
// {
//     CvSlice slice;
//     slice.start_index = start;
//     slice.end_index = end;
// 
//     return slice;
// }
DEFINE_FUNCTION_ALIAS( S(CvSlice), cvSlice, cvSlice_, 2( V(int,start), V(int,end) ) ) 

// #define CV_WHOLE_SEQ_END_INDEX 0x3fffffff
#pragma push_macro( "CV_WHOLE_SEQ_END_INDEX" )
#undef CV_WHOLE_SEQ_END_INDEX
static const int CV_WHOLE_SEQ_END_INDEX
#pragma pop_macro( "CV_WHOLE_SEQ_END_INDEX" )
	= CV_WHOLE_SEQ_END_INDEX;
// #define CV_WHOLE_SEQ  cvSlice(0, CV_WHOLE_SEQ_END_INDEX)
// ToDo


/************************************* CvScalar *****************************************/

// typedef struct CvScalar
// {
//     double val[4];
// }
// CvScalar;
DEFINE_STRUCT( CvScalar )
{STRUCT_BASIC( CvScalar )
	DEFINE_PROPERTY_VA( double, val, 4 )
DEFINE_SETUP_CONSTRUCTOR( CvScalar, cvScalar, 4( V(double,val0), V(double,val1), V(double,val2), V(double,val3) ) )
DEFINE_SETUP_CONSTRUCTOR( CvScalar, cvScalar, 3( V(double,val0), V(double,val1), V(double,val2) ) )
DEFINE_SETUP_CONSTRUCTOR( CvScalar, cvScalar, 2( V(double,val0), V(double,val1) ) )
DEFINE_SETUP_CONSTRUCTOR( CvScalar, cvScalar, 1( V(double,val0) ) )
};

// CV_INLINE  CvScalar  cvScalar( double val0, double val1 CV_DEFAULT(0),
//                                double val2 CV_DEFAULT(0), double val3 CV_DEFAULT(0))
// {
//     CvScalar scalar;
//     scalar.val[0] = val0; scalar.val[1] = val1;
//     scalar.val[2] = val2; scalar.val[3] = val3;
//     return scalar;
// }
DEFINE_FUNCTION_ALIAS( S(CvScalar), cvScalar, cvScalar_, 4( V(double,val0), V(double,val1), V(double,val2), V(double,val3) ) ) 
DEFINE_FUNCTION_ALIAS( S(CvScalar), cvScalar, cvScalar_, 3( V(double,val0), V(double,val1), V(double,val2) ) ) 
DEFINE_FUNCTION_ALIAS( S(CvScalar), cvScalar, cvScalar_, 2( V(double,val0), V(double,val1) ) ) 
DEFINE_FUNCTION_ALIAS( S(CvScalar), cvScalar, cvScalar_, 1( V(double,val0) ) ) 


// CV_INLINE  CvScalar  cvRealScalar( double val0 )
// {
//     CvScalar scalar;
//     scalar.val[0] = val0;
//     scalar.val[1] = scalar.val[2] = scalar.val[3] = 0;
//     return scalar;
// }
DEFINE_FUNCTION( S(CvScalar), cvRealScalar, 1( V(double,val0) ) ) 

// CV_INLINE  CvScalar  cvScalarAll( double val0123 )
// {
//     CvScalar scalar;
//     scalar.val[0] = val0123;
//     scalar.val[1] = val0123;
//     scalar.val[2] = val0123;
//     scalar.val[3] = val0123;
//     return scalar;
// }
DEFINE_FUNCTION( S(CvScalar), cvScalarAll, 1( V(double,val0123) ) ) 

/****************************************************************************************\
*                                   Dynamic Data structures                              *
\****************************************************************************************/

/******************************** Memory storage ****************************************/

// typedef struct CvMemBlock
// {
//     struct CvMemBlock*  prev;
//     struct CvMemBlock*  next;
// }
// CvMemBlock;
DEFINE_STRUCT( CvMemBlock )
{STRUCT_BASIC( CvMemBlock )
	DEFINE_PROPERTY_SP( CvMemBlock, prev )
	DEFINE_PROPERTY_SP( CvMemBlock, next )
};

// #define CV_STORAGE_MAGIC_VAL    0x42890000
#pragma push_macro( "CV_STORAGE_MAGIC_VAL" )
#undef CV_STORAGE_MAGIC_VAL
static const int CV_STORAGE_MAGIC_VAL
#pragma pop_macro( "CV_STORAGE_MAGIC_VAL" )
	= CV_STORAGE_MAGIC_VAL;

// typedef struct CvMemStorage
// {
//     int signature;
//     CvMemBlock* bottom;           /* First allocated block.                   */
//     CvMemBlock* top;              /* Current memory block - top of the stack. */
//     struct  CvMemStorage* parent; /* We get new blocks from parent as needed. */
//     int block_size;               /* Block size.                              */
//     int free_space;               /* Remaining free space in current block.   */
// }
// CvMemStorage;
DEFINE_STRUCT( CvMemStorage )
{STRUCT_BASIC( CvMemStorage )
	DEFINE_PROPERTY_V( int, signature )
	DEFINE_PROPERTY_SP( CvMemBlock, bottom )
	DEFINE_PROPERTY_SP( CvMemBlock, top )
	DEFINE_PROPERTY_SP( CvMemStorage, parent )
	DEFINE_PROPERTY_V( int, block_size )
	DEFINE_PROPERTY_V( int, free_space )
};

// #define CV_IS_STORAGE(storage)  \
//     ((storage) != NULL &&       \
//     (((CvMemStorage*)(storage))->signature & CV_MAGIC_MASK) == CV_STORAGE_MAGIC_VAL)
// Unsupport : CV_IS_STORAGE


// typedef struct CvMemStoragePos
// {
//     CvMemBlock* top;
//     int free_space;
// }
// CvMemStoragePos;
DEFINE_STRUCT( CvMemStoragePos )
{STRUCT_BASIC( CvMemStoragePos )
	DEFINE_PROPERTY_SP( CvMemBlock, top )
	DEFINE_PROPERTY_V( int, free_space )
};


/*********************************** Sequence *******************************************/

// typedef struct CvSeqBlock
// {
//     struct CvSeqBlock*  prev; /* Previous sequence block.                   */
//     struct CvSeqBlock*  next; /* Next sequence block.                       */
//   int    start_index;         /* Index of the first element in the block +  */
//                               /* sequence->first->start_index.              */
//     int    count;             /* Number of elements in the block.           */
//     schar* data;              /* Pointer to the first element of the block. */
// }
// CvSeqBlock;
DEFINE_STRUCT( CvSeqBlock )
{STRUCT_BASIC( CvSeqBlock )
	DEFINE_PROPERTY_SP( CvSeqBlock, prev )
	DEFINE_PROPERTY_SP( CvSeqBlock, next )
	DEFINE_PROPERTY_V( int, start_index )
	DEFINE_PROPERTY_V( int, count )
	DEFINE_PROPERTY_VP( signed char, data )
};


// #define CV_TREE_NODE_FIELDS(node_type)                               \
//     int       flags;             /* Miscellaneous flags.     */      \
//     int       header_size;       /* Size of sequence header. */      \
//     struct    node_type* h_prev; /* Previous sequence.       */      \
//     struct    node_type* h_next; /* Next sequence.           */      \
//     struct    node_type* v_prev; /* 2nd previous sequence.   */      \
//     struct    node_type* v_next  /* 2nd next sequence.       */
// Unsupport : CV_TREE_NODE_FIELDS

/*
   Read/Write sequence.
   Elements can be dynamically inserted to or deleted from the sequence.
*/
// #define CV_SEQUENCE_FIELDS()                                              \
//     CV_TREE_NODE_FIELDS(CvSeq);                                           \
//     int       total;          /* Total number of elements.            */  \
//     int       elem_size;      /* Size of sequence element in bytes.   */  \
//     schar*    block_max;      /* Maximal bound of the last block.     */  \
//     schar*    ptr;            /* Current write pointer.               */  \
//     int       delta_elems;    /* Grow seq this many at a time.        */  \
//     CvMemStorage* storage;    /* Where the seq is stored.             */  \
//     CvSeqBlock* free_blocks;  /* Free blocks list.                    */  \
//     CvSeqBlock* first;        /* Pointer to the first sequence block. */
// Unsupport : CV_SEQUENCE_FIELDS

// typedef struct CvSeq
// {
//     CV_SEQUENCE_FIELDS()
// }
// CvSeq;
DEFINE_STRUCT( CvSeq )
{STRUCT_BASIC( CvSeq )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvSeq, h_prev )
	DEFINE_PROPERTY_SP( CvSeq, h_next )
	DEFINE_PROPERTY_SP( CvSeq, v_prev )
	DEFINE_PROPERTY_SP( CvSeq, v_next )
	DEFINE_PROPERTY_V( int, total )
	DEFINE_PROPERTY_V( int, elem_size )
	DEFINE_PROPERTY_VP( signed char, block_max )
	DEFINE_PROPERTY_VP( signed char, ptr )
	DEFINE_PROPERTY_V( int, delta_elems )
	DEFINE_PROPERTY_SP( CvMemStorage, storage )
	DEFINE_PROPERTY_SP( CvSeqBlock, free_blocks )
	DEFINE_PROPERTY_SP( CvSeqBlock, first )
};

// #define CV_TYPE_NAME_SEQ             "opencv-sequence"
#pragma push_macro( "CV_TYPE_NAME_SEQ" )
#undef CV_TYPE_NAME_SEQ
static const String^ CV_TYPE_NAME_SEQ
#pragma pop_macro( "CV_TYPE_NAME_SEQ" )
	= CV_TYPE_NAME_SEQ;
// #define CV_TYPE_NAME_SEQ_TREE        "opencv-sequence-tree"
#pragma push_macro( "CV_TYPE_NAME_SEQ_TREE" )
#undef CV_TYPE_NAME_SEQ_TREE
static const String^ CV_TYPE_NAME_SEQ_TREE
#pragma pop_macro( "CV_TYPE_NAME_SEQ_TREE" )
	= CV_TYPE_NAME_SEQ_TREE;

/*************************************** Set ********************************************/
/*
  Set.
  Order is not preserved. There can be gaps between sequence elements.
  After the element has been inserted it stays in the same place all the time.
  The MSB(most-significant or sign bit) of the first field (flags) is 0 iff the element exists.
*/
// #define CV_SET_ELEM_FIELDS(elem_type)   \
//     int  flags;                         \
//     struct elem_type* next_free;
// Unsupport : CV_SET_ELEM_FIELDS

// typedef struct CvSetElem
// {
//     CV_SET_ELEM_FIELDS(CvSetElem)
// }
// CvSetElem;
DEFINE_STRUCT( CvSetElem )
{STRUCT_BASIC( CvSetElem )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_SP( CvSetElem, next_free )
};

// #define CV_SET_FIELDS()      \
//     CV_SEQUENCE_FIELDS()     \
//     CvSetElem* free_elems;   \
//     int active_count;
// Unsupport : CV_SET_FIELDS

// typedef struct CvSet
// {
//     CV_SET_FIELDS()
// }
// CvSet;
DEFINE_STRUCT( CvSet )
{STRUCT_BASIC( CvSet )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvSeq, h_prev )
	DEFINE_PROPERTY_SP( CvSeq, h_next )
	DEFINE_PROPERTY_SP( CvSeq, v_prev )
	DEFINE_PROPERTY_SP( CvSeq, v_next )
	DEFINE_PROPERTY_V( int, total )
	DEFINE_PROPERTY_V( int, elem_size )
	DEFINE_PROPERTY_VP( signed char, block_max )
	DEFINE_PROPERTY_VP( signed char, ptr )
	DEFINE_PROPERTY_V( int, delta_elems )
	DEFINE_PROPERTY_SP( CvMemStorage, storage )
	DEFINE_PROPERTY_SP( CvSeqBlock, free_blocks )
	DEFINE_PROPERTY_SP( CvSeqBlock, first )
	DEFINE_PROPERTY_SP( CvSetElem, free_elems )
	DEFINE_PROPERTY_V( int, active_count )
};


// #define CV_SET_ELEM_IDX_MASK   ((1 << 26) - 1)
#pragma push_macro( "CV_SET_ELEM_IDX_MASK" )
#undef CV_SET_ELEM_IDX_MASK
static const int CV_SET_ELEM_IDX_MASK
#pragma pop_macro( "CV_SET_ELEM_IDX_MASK" )
	= CV_SET_ELEM_IDX_MASK;
// #define CV_SET_ELEM_FREE_FLAG  (1 << (sizeof(int)*8-1))
#pragma push_macro( "CV_SET_ELEM_FREE_FLAG" )
#undef CV_SET_ELEM_FREE_FLAG
static const int CV_SET_ELEM_FREE_FLAG
#pragma pop_macro( "CV_SET_ELEM_FREE_FLAG" )
	= CV_SET_ELEM_FREE_FLAG;

/* Checks whether the element pointed by ptr belongs to a set or not */
// #define CV_IS_SET_ELEM( ptr )  (((CvSetElem*)(ptr))->flags >= 0)
// Unsupport : CV_IS_SET_ELEM

/************************************* Graph ********************************************/

/*
  We represent a graph as a set of vertices.
  Vertices contain their adjacency lists (more exactly, pointers to first incoming or
  outcoming edge (or 0 if isolated vertex)). Edges are stored in another set.
  There is a singly-linked list of incoming/outcoming edges for each vertex.

  Each edge consists of

     o   Two pointers to the starting and ending vertices
         (vtx[0] and vtx[1] respectively).

	 A graph may be oriented or not. In the latter case, edges between
	 vertex i to vertex j are not distinguished during search operations.

     o   Two pointers to next edges for the starting and ending vertices, where
         next[0] points to the next edge in the vtx[0] adjacency list and
         next[1] points to the next edge in the vtx[1] adjacency list.
*/
// #define CV_GRAPH_EDGE_FIELDS()      \
//     int flags;                      \
//     float weight;                   \
//     struct CvGraphEdge* next[2];    \
//     struct CvGraphVtx* vtx[2];
// Unsupport : CV_GRAPH_EDGE_FIELDS


// #define CV_GRAPH_VERTEX_FIELDS()    \
//     int flags;                      \
//     struct CvGraphEdge* first;
// Unsupport : CV_GRAPH_VERTEX_FIELDS


// typedef struct CvGraphEdge
// {
//     CV_GRAPH_EDGE_FIELDS()
// }
// CvGraphEdge;
DEFINE_STRUCT_PROTOTYPE( CvGraphVtx )
DEFINE_STRUCT( CvGraphEdge )
{STRUCT_BASIC( CvGraphEdge )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( float, weight )
	DEFINE_PROPERTY_SPA( CvGraphEdge, next, 2 )
	DEFINE_PROPERTY_SPA( CvGraphVtx, vtx, 2 )
};

// typedef struct CvGraphVtx
// {
//     CV_GRAPH_VERTEX_FIELDS()
// }
// CvGraphVtx;
DEFINE_STRUCT( CvGraphVtx )
{STRUCT_BASIC( CvGraphVtx )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_SP( CvGraphEdge, first )
};

// typedef struct CvGraphVtx2D
// {
//     CV_GRAPH_VERTEX_FIELDS()
//     CvPoint2D32f* ptr;
// }
// CvGraphVtx2D;
DEFINE_STRUCT( CvGraphVtx2D )
{STRUCT_BASIC( CvGraphVtx2D )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_SP( CvGraphEdge, first )
	DEFINE_PROPERTY_SP( CvPoint2D32f, ptr )
};

/*
   Graph is "derived" from the set (this is set a of vertices)
   and includes another set (edges)
*/
// #define  CV_GRAPH_FIELDS()   \
//     CV_SET_FIELDS()          \
//     CvSet* edges;
// Unsupport : CV_GRAPH_FIELDS

// typedef struct CvGraph
// {
//     CV_GRAPH_FIELDS()
// }
// CvGraph;
DEFINE_STRUCT( CvGraph )
{STRUCT_BASIC( CvGraph )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvSeq, h_prev )
	DEFINE_PROPERTY_SP( CvSeq, h_next )
	DEFINE_PROPERTY_SP( CvSeq, v_prev )
	DEFINE_PROPERTY_SP( CvSeq, v_next )
	DEFINE_PROPERTY_V( int, total )
	DEFINE_PROPERTY_V( int, elem_size )
	DEFINE_PROPERTY_VP( signed char, block_max )
	DEFINE_PROPERTY_VP( signed char, ptr )
	DEFINE_PROPERTY_V( int, delta_elems )
	DEFINE_PROPERTY_SP( CvMemStorage, storage )
	DEFINE_PROPERTY_SP( CvSeqBlock, free_blocks )
	DEFINE_PROPERTY_SP( CvSeqBlock, first )
	DEFINE_PROPERTY_SP( CvSetElem, free_elems )
	DEFINE_PROPERTY_V( int, active_count )
	DEFINE_PROPERTY_SP( CvSet, edges )
};

// #define CV_TYPE_NAME_GRAPH "opencv-graph"
#pragma push_macro( "CV_TYPE_NAME_GRAPH" )
#undef CV_TYPE_NAME_GRAPH
static const String^ CV_TYPE_NAME_GRAPH
#pragma pop_macro( "CV_TYPE_NAME_GRAPH" )
	= CV_TYPE_NAME_GRAPH;

/*********************************** Chain/Countour *************************************/

// typedef struct CvChain
// {
//     CV_SEQUENCE_FIELDS()
//     CvPoint  origin;
// }
// CvChain;
DEFINE_STRUCT( CvChain )
{STRUCT_BASIC( CvChain )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvSeq, h_prev )
	DEFINE_PROPERTY_SP( CvSeq, h_next )
	DEFINE_PROPERTY_SP( CvSeq, v_prev )
	DEFINE_PROPERTY_SP( CvSeq, v_next )
	DEFINE_PROPERTY_V( int, total )
	DEFINE_PROPERTY_V( int, elem_size )
	DEFINE_PROPERTY_VP( signed char, block_max )
	DEFINE_PROPERTY_VP( signed char, ptr )
	DEFINE_PROPERTY_V( int, delta_elems )
	DEFINE_PROPERTY_SP( CvMemStorage, storage )
	DEFINE_PROPERTY_SP( CvSeqBlock, free_blocks )
	DEFINE_PROPERTY_SP( CvSeqBlock, first )
	DEFINE_PROPERTY_S( CvPoint, origin )
};

// #define CV_CONTOUR_FIELDS()  \
//     CV_SEQUENCE_FIELDS()     \
//     CvRect rect;             \
//     int color;               \
//     int reserved[3];
// Unsupport : CV_CONTOUR_FIELDS

// typedef struct CvContour
// {
//     CV_CONTOUR_FIELDS()
// }
// CvContour;
DEFINE_STRUCT( CvContour )
{STRUCT_BASIC( CvContour )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvSeq, h_prev )
	DEFINE_PROPERTY_SP( CvSeq, h_next )
	DEFINE_PROPERTY_SP( CvSeq, v_prev )
	DEFINE_PROPERTY_SP( CvSeq, v_next )
	DEFINE_PROPERTY_V( int, total )
	DEFINE_PROPERTY_V( int, elem_size )
	DEFINE_PROPERTY_VP( signed char, block_max )
	DEFINE_PROPERTY_VP( signed char, ptr )
	DEFINE_PROPERTY_V( int, delta_elems )
	DEFINE_PROPERTY_SP( CvMemStorage, storage )
	DEFINE_PROPERTY_SP( CvSeqBlock, free_blocks )
	DEFINE_PROPERTY_SP( CvSeqBlock, first )
	DEFINE_PROPERTY_S( CvRect, rect )
	DEFINE_PROPERTY_V( int, color )
	DEFINE_PROPERTY_VA( int, reserved, 3 )
};

// typedef CvContour CvPoint2DSeq;
// Unsupport : CvPoint2DSeq

/****************************************************************************************\
*                                    Sequence types                                      *
\****************************************************************************************/

// #define CV_SEQ_MAGIC_VAL             0x42990000
#pragma push_macro( "CV_SEQ_MAGIC_VAL" )
#undef CV_SEQ_MAGIC_VAL
static const int CV_SEQ_MAGIC_VAL
#pragma pop_macro( "CV_SEQ_MAGIC_VAL" )
	= CV_SEQ_MAGIC_VAL;

// #define CV_IS_SEQ(seq) \
//     ((seq) != NULL && (((CvSeq*)(seq))->flags & CV_MAGIC_MASK) == CV_SEQ_MAGIC_VAL)
// Unsupport : CV_IS_SEQ

// #define CV_SET_MAGIC_VAL             0x42980000
#pragma push_macro( "CV_SET_MAGIC_VAL" )
#undef CV_SET_MAGIC_VAL
static const int CV_SET_MAGIC_VAL
#pragma pop_macro( "CV_SET_MAGIC_VAL" )
	= CV_SET_MAGIC_VAL;
// #define CV_IS_SET(set) \
//     ((set) != NULL && (((CvSeq*)(set))->flags & CV_MAGIC_MASK) == CV_SET_MAGIC_VAL)
// Unsupport : CV_IS_SET

// #define CV_SEQ_ELTYPE_BITS           9
#pragma push_macro( "CV_SEQ_ELTYPE_BITS" )
#undef CV_SEQ_ELTYPE_BITS
static const int CV_SEQ_ELTYPE_BITS
#pragma pop_macro( "CV_SEQ_ELTYPE_BITS" )
	= CV_SEQ_ELTYPE_BITS;
// #define CV_SEQ_ELTYPE_MASK           ((1 << CV_SEQ_ELTYPE_BITS) - 1)
#pragma push_macro( "CV_SEQ_ELTYPE_MASK" )
#undef CV_SEQ_ELTYPE_MASK
static const int CV_SEQ_ELTYPE_MASK
#pragma pop_macro( "CV_SEQ_ELTYPE_MASK" )
	= CV_SEQ_ELTYPE_MASK;

// #define CV_SEQ_ELTYPE_POINT          CV_32SC2  /* (x,y) */
#pragma push_macro( "CV_SEQ_ELTYPE_POINT" )
#undef CV_SEQ_ELTYPE_POINT
static const int CV_SEQ_ELTYPE_POINT
#pragma pop_macro( "CV_SEQ_ELTYPE_POINT" )
	= CV_SEQ_ELTYPE_POINT;
// #define CV_SEQ_ELTYPE_CODE           CV_8UC1   /* freeman code: 0..7 */
#pragma push_macro( "CV_SEQ_ELTYPE_CODE" )
#undef CV_SEQ_ELTYPE_CODE
static const int CV_SEQ_ELTYPE_CODE
#pragma pop_macro( "CV_SEQ_ELTYPE_CODE" )
	= CV_SEQ_ELTYPE_CODE;
// #define CV_SEQ_ELTYPE_GENERIC        0
#pragma push_macro( "CV_SEQ_ELTYPE_GENERIC" )
#undef CV_SEQ_ELTYPE_GENERIC
static const int CV_SEQ_ELTYPE_GENERIC
#pragma pop_macro( "CV_SEQ_ELTYPE_GENERIC" )
	= CV_SEQ_ELTYPE_GENERIC;
// #define CV_SEQ_ELTYPE_PTR            CV_USRTYPE1
#pragma push_macro( "CV_SEQ_ELTYPE_PTR" )
#undef CV_SEQ_ELTYPE_PTR
static const int CV_SEQ_ELTYPE_PTR
#pragma pop_macro( "CV_SEQ_ELTYPE_PTR" )
	= CV_SEQ_ELTYPE_PTR;
// #define CV_SEQ_ELTYPE_PPOINT         CV_SEQ_ELTYPE_PTR  /* &(x,y) */
#pragma push_macro( "CV_SEQ_ELTYPE_PPOINT" )
#undef CV_SEQ_ELTYPE_PPOINT
static const int CV_SEQ_ELTYPE_PPOINT
#pragma pop_macro( "CV_SEQ_ELTYPE_PPOINT" )
	= CV_SEQ_ELTYPE_PPOINT;
// #define CV_SEQ_ELTYPE_INDEX          CV_32SC1  /* #(x,y) */
#pragma push_macro( "CV_SEQ_ELTYPE_INDEX" )
#undef CV_SEQ_ELTYPE_INDEX
static const int CV_SEQ_ELTYPE_INDEX
#pragma pop_macro( "CV_SEQ_ELTYPE_INDEX" )
	= CV_SEQ_ELTYPE_INDEX;
// #define CV_SEQ_ELTYPE_GRAPH_EDGE     0  /* &next_o, &next_d, &vtx_o, &vtx_d */
#pragma push_macro( "CV_SEQ_ELTYPE_GRAPH_EDGE" )
#undef CV_SEQ_ELTYPE_GRAPH_EDGE
static const int CV_SEQ_ELTYPE_GRAPH_EDGE
#pragma pop_macro( "CV_SEQ_ELTYPE_GRAPH_EDGE" )
	= CV_SEQ_ELTYPE_GRAPH_EDGE;
// #define CV_SEQ_ELTYPE_GRAPH_VERTEX   0  /* first_edge, &(x,y) */
#pragma push_macro( "CV_SEQ_ELTYPE_GRAPH_VERTEX" )
#undef CV_SEQ_ELTYPE_GRAPH_VERTEX
static const int CV_SEQ_ELTYPE_GRAPH_VERTEX
#pragma pop_macro( "CV_SEQ_ELTYPE_GRAPH_VERTEX" )
	= CV_SEQ_ELTYPE_GRAPH_VERTEX;
// #define CV_SEQ_ELTYPE_TRIAN_ATR      0  /* vertex of the binary tree   */
#pragma push_macro( "CV_SEQ_ELTYPE_TRIAN_ATR" )
#undef CV_SEQ_ELTYPE_TRIAN_ATR
static const int CV_SEQ_ELTYPE_TRIAN_ATR
#pragma pop_macro( "CV_SEQ_ELTYPE_TRIAN_ATR" )
	= CV_SEQ_ELTYPE_TRIAN_ATR;
// #define CV_SEQ_ELTYPE_CONNECTED_COMP 0  /* connected component  */
#pragma push_macro( "CV_SEQ_ELTYPE_CONNECTED_COMP" )
#undef CV_SEQ_ELTYPE_CONNECTED_COMP
static const int CV_SEQ_ELTYPE_CONNECTED_COMP
#pragma pop_macro( "CV_SEQ_ELTYPE_CONNECTED_COMP" )
	= CV_SEQ_ELTYPE_CONNECTED_COMP;
// #define CV_SEQ_ELTYPE_POINT3D        CV_32FC3  /* (x,y,z)  */
#pragma push_macro( "CV_SEQ_ELTYPE_POINT3D" )
#undef CV_SEQ_ELTYPE_POINT3D
static const int CV_SEQ_ELTYPE_POINT3D
#pragma pop_macro( "CV_SEQ_ELTYPE_POINT3D" )
	= CV_SEQ_ELTYPE_POINT3D;

// #define CV_SEQ_KIND_BITS        3
#pragma push_macro( "CV_SEQ_KIND_BITS" )
#undef CV_SEQ_KIND_BITS
static const int CV_SEQ_KIND_BITS
#pragma pop_macro( "CV_SEQ_KIND_BITS" )
	= CV_SEQ_KIND_BITS;
// #define CV_SEQ_KIND_MASK        (((1 << CV_SEQ_KIND_BITS) - 1)<<CV_SEQ_ELTYPE_BITS)
#pragma push_macro( "CV_SEQ_KIND_MASK" )
#undef CV_SEQ_KIND_MASK
static const int CV_SEQ_KIND_MASK
#pragma pop_macro( "CV_SEQ_KIND_MASK" )
	= CV_SEQ_KIND_MASK;

/* types of sequences */
// #define CV_SEQ_KIND_GENERIC     (0 << CV_SEQ_ELTYPE_BITS)
#pragma push_macro( "CV_SEQ_KIND_GENERIC" )
#undef CV_SEQ_KIND_GENERIC
static const int CV_SEQ_KIND_GENERIC
#pragma pop_macro( "CV_SEQ_KIND_GENERIC" )
	= CV_SEQ_KIND_GENERIC;
// #define CV_SEQ_KIND_CURVE       (1 << CV_SEQ_ELTYPE_BITS)
#pragma push_macro( "CV_SEQ_KIND_CURVE" )
#undef CV_SEQ_KIND_CURVE
static const int CV_SEQ_KIND_CURVE
#pragma pop_macro( "CV_SEQ_KIND_CURVE" )
	= CV_SEQ_KIND_CURVE;
// #define CV_SEQ_KIND_BIN_TREE    (2 << CV_SEQ_ELTYPE_BITS)
#pragma push_macro( "CV_SEQ_KIND_BIN_TREE" )
#undef CV_SEQ_KIND_BIN_TREE
static const int CV_SEQ_KIND_BIN_TREE
#pragma pop_macro( "CV_SEQ_KIND_BIN_TREE" )
	= CV_SEQ_KIND_BIN_TREE;

/* types of sparse sequences (sets) */
// #define CV_SEQ_KIND_GRAPH       (3 << CV_SEQ_ELTYPE_BITS)
#pragma push_macro( "CV_SEQ_KIND_GRAPH" )
#undef CV_SEQ_KIND_GRAPH
static const int CV_SEQ_KIND_GRAPH
#pragma pop_macro( "CV_SEQ_KIND_GRAPH" )
	= CV_SEQ_KIND_GRAPH;
// #define CV_SEQ_KIND_SUBDIV2D    (4 << CV_SEQ_ELTYPE_BITS)
#pragma push_macro( "CV_SEQ_KIND_SUBDIV2D" )
#undef CV_SEQ_KIND_SUBDIV2D
static const int CV_SEQ_KIND_SUBDIV2D
#pragma pop_macro( "CV_SEQ_KIND_SUBDIV2D" )
	= CV_SEQ_KIND_SUBDIV2D;

// #define CV_SEQ_FLAG_SHIFT       (CV_SEQ_KIND_BITS + CV_SEQ_ELTYPE_BITS)
#pragma push_macro( "CV_SEQ_FLAG_SHIFT" )
#undef CV_SEQ_FLAG_SHIFT
static const int CV_SEQ_FLAG_SHIFT
#pragma pop_macro( "CV_SEQ_FLAG_SHIFT" )
	= CV_SEQ_FLAG_SHIFT;

/* flags for curves */
// #define CV_SEQ_FLAG_CLOSED     (1 << CV_SEQ_FLAG_SHIFT)
#pragma push_macro( "CV_SEQ_FLAG_CLOSED" )
#undef CV_SEQ_FLAG_CLOSED
static const int CV_SEQ_FLAG_CLOSED
#pragma pop_macro( "CV_SEQ_FLAG_CLOSED" )
	= CV_SEQ_FLAG_CLOSED;
// #define CV_SEQ_FLAG_SIMPLE     (2 << CV_SEQ_FLAG_SHIFT)
#pragma push_macro( "CV_SEQ_FLAG_SIMPLE" )
#undef CV_SEQ_FLAG_SIMPLE
static const int CV_SEQ_FLAG_SIMPLE
#pragma pop_macro( "CV_SEQ_FLAG_SIMPLE" )
	= CV_SEQ_FLAG_SIMPLE;
// #define CV_SEQ_FLAG_CONVEX     (4 << CV_SEQ_FLAG_SHIFT)
#pragma push_macro( "CV_SEQ_FLAG_CONVEX" )
#undef CV_SEQ_FLAG_CONVEX
static const int CV_SEQ_FLAG_CONVEX
#pragma pop_macro( "CV_SEQ_FLAG_CONVEX" )
	= CV_SEQ_FLAG_CONVEX;
// #define CV_SEQ_FLAG_HOLE       (8 << CV_SEQ_FLAG_SHIFT)
#pragma push_macro( "CV_SEQ_FLAG_HOLE" )
#undef CV_SEQ_FLAG_HOLE
static const int CV_SEQ_FLAG_HOLE
#pragma pop_macro( "CV_SEQ_FLAG_HOLE" )
	= CV_SEQ_FLAG_HOLE;

/* flags for graphs */
// #define CV_GRAPH_FLAG_ORIENTED (1 << CV_SEQ_FLAG_SHIFT)
#pragma push_macro( "CV_GRAPH_FLAG_ORIENTED" )
#undef CV_GRAPH_FLAG_ORIENTED
static const int CV_GRAPH_FLAG_ORIENTED
#pragma pop_macro( "CV_GRAPH_FLAG_ORIENTED" )
	= CV_GRAPH_FLAG_ORIENTED;

// #define CV_GRAPH               CV_SEQ_KIND_GRAPH
#pragma push_macro( "CV_GRAPH" )
#undef CV_GRAPH
static const int CV_GRAPH
#pragma pop_macro( "CV_GRAPH" )
	= CV_GRAPH;
// #define CV_ORIENTED_GRAPH      (CV_SEQ_KIND_GRAPH|CV_GRAPH_FLAG_ORIENTED)
#pragma push_macro( "CV_ORIENTED_GRAPH" )
#undef CV_ORIENTED_GRAPH
static const int CV_ORIENTED_GRAPH
#pragma pop_macro( "CV_ORIENTED_GRAPH" )
	= CV_ORIENTED_GRAPH;

/* point sets */
// #define CV_SEQ_POINT_SET       (CV_SEQ_KIND_GENERIC| CV_SEQ_ELTYPE_POINT)
#pragma push_macro( "CV_SEQ_POINT_SET" )
#undef CV_SEQ_POINT_SET
static const int CV_SEQ_POINT_SET
#pragma pop_macro( "CV_SEQ_POINT_SET" )
	= CV_SEQ_POINT_SET;
// #define CV_SEQ_POINT3D_SET     (CV_SEQ_KIND_GENERIC| CV_SEQ_ELTYPE_POINT3D)
#pragma push_macro( "CV_SEQ_POINT3D_SET" )
#undef CV_SEQ_POINT3D_SET
static const int CV_SEQ_POINT3D_SET
#pragma pop_macro( "CV_SEQ_POINT3D_SET" )
	= CV_SEQ_POINT3D_SET;
// #define CV_SEQ_POLYLINE        (CV_SEQ_KIND_CURVE  | CV_SEQ_ELTYPE_POINT)
#pragma push_macro( "CV_SEQ_POLYLINE" )
#undef CV_SEQ_POLYLINE
static const int CV_SEQ_POLYLINE
#pragma pop_macro( "CV_SEQ_POLYLINE" )
	= CV_SEQ_POLYLINE;
// #define CV_SEQ_POLYGON         (CV_SEQ_FLAG_CLOSED | CV_SEQ_POLYLINE )
#pragma push_macro( "CV_SEQ_POLYGON" )
#undef CV_SEQ_POLYGON
static const int CV_SEQ_POLYGON
#pragma pop_macro( "CV_SEQ_POLYGON" )
	= CV_SEQ_POLYGON;
// #define CV_SEQ_CONTOUR         CV_SEQ_POLYGON
#pragma push_macro( "CV_SEQ_CONTOUR" )
#undef CV_SEQ_CONTOUR
static const int CV_SEQ_CONTOUR
#pragma pop_macro( "CV_SEQ_CONTOUR" )
	= CV_SEQ_CONTOUR;
// #define CV_SEQ_SIMPLE_POLYGON  (CV_SEQ_FLAG_SIMPLE | CV_SEQ_POLYGON  )
#pragma push_macro( "CV_SEQ_SIMPLE_POLYGON" )
#undef CV_SEQ_SIMPLE_POLYGON
static const int CV_SEQ_SIMPLE_POLYGON
#pragma pop_macro( "CV_SEQ_SIMPLE_POLYGON" )
	= CV_SEQ_SIMPLE_POLYGON;

/* chain-coded curves */
// #define CV_SEQ_CHAIN           (CV_SEQ_KIND_CURVE  | CV_SEQ_ELTYPE_CODE)
#pragma push_macro( "CV_SEQ_CHAIN" )
#undef CV_SEQ_CHAIN
static const int CV_SEQ_CHAIN
#pragma pop_macro( "CV_SEQ_CHAIN" )
	= CV_SEQ_CHAIN;
// #define CV_SEQ_CHAIN_CONTOUR   (CV_SEQ_FLAG_CLOSED | CV_SEQ_CHAIN)
#pragma push_macro( "CV_SEQ_CHAIN_CONTOUR" )
#undef CV_SEQ_CHAIN_CONTOUR
static const int CV_SEQ_CHAIN_CONTOUR
#pragma pop_macro( "CV_SEQ_CHAIN_CONTOUR" )
	= CV_SEQ_CHAIN_CONTOUR;

/* binary tree for the contour */
// #define CV_SEQ_POLYGON_TREE    (CV_SEQ_KIND_BIN_TREE  | CV_SEQ_ELTYPE_TRIAN_ATR)
#pragma push_macro( "CV_SEQ_POLYGON_TREE" )
#undef CV_SEQ_POLYGON_TREE
static const int CV_SEQ_POLYGON_TREE
#pragma pop_macro( "CV_SEQ_POLYGON_TREE" )
	= CV_SEQ_POLYGON_TREE;

/* sequence of the connected components */
// #define CV_SEQ_CONNECTED_COMP  (CV_SEQ_KIND_GENERIC  | CV_SEQ_ELTYPE_CONNECTED_COMP)
#pragma push_macro( "CV_SEQ_CONNECTED_COMP" )
#undef CV_SEQ_CONNECTED_COMP
static const int CV_SEQ_CONNECTED_COMP
#pragma pop_macro( "CV_SEQ_CONNECTED_COMP" )
	= CV_SEQ_CONNECTED_COMP;

/* sequence of the integer numbers */
// #define CV_SEQ_INDEX           (CV_SEQ_KIND_GENERIC  | CV_SEQ_ELTYPE_INDEX)
#pragma push_macro( "CV_SEQ_INDEX" )
#undef CV_SEQ_INDEX
static const int CV_SEQ_INDEX
#pragma pop_macro( "CV_SEQ_INDEX" )
	= CV_SEQ_INDEX;

// #define CV_SEQ_ELTYPE( seq )   ((seq)->flags & CV_SEQ_ELTYPE_MASK)
// Unsupport : CV_SEQ_ELTYPE
// #define CV_SEQ_KIND( seq )     ((seq)->flags & CV_SEQ_KIND_MASK )
// Unsupport : CV_SEQ_KIND

/* flag checking */
// #define CV_IS_SEQ_INDEX( seq )      ((CV_SEQ_ELTYPE(seq) == CV_SEQ_ELTYPE_INDEX) && \
//                                      (CV_SEQ_KIND(seq) == CV_SEQ_KIND_GENERIC))
// Unsupport : CV_IS_SEQ_INDEX

// #define CV_IS_SEQ_CURVE( seq )      (CV_SEQ_KIND(seq) == CV_SEQ_KIND_CURVE)
// Unsupport : CV_IS_SEQ_CURVE
// #define CV_IS_SEQ_CLOSED( seq )     (((seq)->flags & CV_SEQ_FLAG_CLOSED) != 0)
// Unsupport : CV_IS_SEQ_CLOSED
// #define CV_IS_SEQ_CONVEX( seq )     (((seq)->flags & CV_SEQ_FLAG_CONVEX) != 0)
// Unsupport : CV_IS_SEQ_CONVEX
// #define CV_IS_SEQ_HOLE( seq )       (((seq)->flags & CV_SEQ_FLAG_HOLE) != 0)
// Unsupport : CV_IS_SEQ_HOLE
// #define CV_IS_SEQ_SIMPLE( seq )     ((((seq)->flags & CV_SEQ_FLAG_SIMPLE) != 0) || \
//                                     CV_IS_SEQ_CONVEX(seq))
// Unsupport : CV_IS_SEQ_SIMPLE

/* type checking macros */
// #define CV_IS_SEQ_POINT_SET( seq ) \
//     ((CV_SEQ_ELTYPE(seq) == CV_32SC2 || CV_SEQ_ELTYPE(seq) == CV_32FC2))
// Unsupport : CV_IS_SEQ_POINT_SET

// #define CV_IS_SEQ_POINT_SUBSET( seq ) \
//     (CV_IS_SEQ_INDEX( seq ) || CV_SEQ_ELTYPE(seq) == CV_SEQ_ELTYPE_PPOINT)
// Unsupport : CV_IS_SEQ_POINT_SUBSET

// #define CV_IS_SEQ_POLYLINE( seq )   \
//     (CV_SEQ_KIND(seq) == CV_SEQ_KIND_CURVE && CV_IS_SEQ_POINT_SET(seq))
// Unsupport : CV_IS_SEQ_POLYLINE

// #define CV_IS_SEQ_POLYGON( seq )   \
//     (CV_IS_SEQ_POLYLINE(seq) && CV_IS_SEQ_CLOSED(seq))
// Unsupport : CV_IS_SEQ_POLYGON

// #define CV_IS_SEQ_CHAIN( seq )   \
//     (CV_SEQ_KIND(seq) == CV_SEQ_KIND_CURVE && (seq)->elem_size == 1)
// Unsupport : CV_IS_SEQ_CHAIN

// #define CV_IS_SEQ_CONTOUR( seq )   \
//     (CV_IS_SEQ_CLOSED(seq) && (CV_IS_SEQ_POLYLINE(seq) || CV_IS_SEQ_CHAIN(seq)))
// Unsupport : CV_IS_SEQ_CONTOUR

// #define CV_IS_SEQ_CHAIN_CONTOUR( seq ) \
//     (CV_IS_SEQ_CHAIN( seq ) && CV_IS_SEQ_CLOSED( seq ))
// Unsupport : CV_IS_SEQ_CHAIN_CONTOUR

// #define CV_IS_SEQ_POLYGON_TREE( seq ) \
//     (CV_SEQ_ELTYPE (seq) ==  CV_SEQ_ELTYPE_TRIAN_ATR &&    \
//     CV_SEQ_KIND( seq ) ==  CV_SEQ_KIND_BIN_TREE )
// Unsupport : CV_IS_SEQ_POLYGON_TREE

// #define CV_IS_GRAPH( seq )    \
//     (CV_IS_SET(seq) && CV_SEQ_KIND((CvSet*)(seq)) == CV_SEQ_KIND_GRAPH)
// Unsupport : CV_IS_GRAPH

// #define CV_IS_GRAPH_ORIENTED( seq )   \
//     (((seq)->flags & CV_GRAPH_FLAG_ORIENTED) != 0)
// Unsupport : CV_IS_GRAPH_ORIENTED

// #define CV_IS_SUBDIV2D( seq )  \
//     (CV_IS_SET(seq) && CV_SEQ_KIND((CvSet*)(seq)) == CV_SEQ_KIND_SUBDIV2D)
// Unsupport : CV_IS_SUBDIV2D

/****************************************************************************************/
/*                            Sequence writer & reader                                  */
/****************************************************************************************/

// #define CV_SEQ_WRITER_FIELDS()                                     \
//     int          header_size;                                      \
//     CvSeq*       seq;        /* the sequence written */            \
//     CvSeqBlock*  block;      /* current block */                   \
//     schar*       ptr;        /* pointer to free space */           \
//     schar*       block_min;  /* pointer to the beginning of block*/\
//     schar*       block_max;  /* pointer to the end of block */
// Unsupport : CV_SEQ_WRITER_FIELDS

// typedef struct CvSeqWriter
// {
//     CV_SEQ_WRITER_FIELDS()
// }
// CvSeqWriter;
DEFINE_STRUCT( CvSeqWriter )
{STRUCT_BASIC( CvSeqWriter )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvSeq, seq )
	DEFINE_PROPERTY_SP( CvSeqBlock, block )
	DEFINE_PROPERTY_VP( signed char, ptr )
	DEFINE_PROPERTY_VP( signed char, block_min )
	DEFINE_PROPERTY_VP( signed char, block_max )
};


// #define CV_SEQ_READER_FIELDS()                                      \
//     int          header_size;                                       \
//     CvSeq*       seq;        /* sequence, beign read */             \
//     CvSeqBlock*  block;      /* current block */                    \
//     schar*       ptr;        /* pointer to element be read next */  \
//     schar*       block_min;  /* pointer to the beginning of block */\
//     schar*       block_max;  /* pointer to the end of block */      \
//     int          delta_index;/* = seq->first->start_index   */      \
//     schar*       prev_elem;  /* pointer to previous element */
// Unsupport : CV_SEQ_READER_FIELDS


// typedef struct CvSeqReader
// {
//     CV_SEQ_READER_FIELDS()
// }
// CvSeqReader;
DEFINE_STRUCT( CvSeqReader )
{STRUCT_BASIC( CvSeqReader )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvSeq, seq )
	DEFINE_PROPERTY_SP( CvSeqBlock, block )
	DEFINE_PROPERTY_VP( signed char, ptr )
	DEFINE_PROPERTY_VP( signed char, block_min )
	DEFINE_PROPERTY_VP( signed char, block_max )
	DEFINE_PROPERTY_V( int, delta_index )
	DEFINE_PROPERTY_VP( signed char, prev_elem )
};

/****************************************************************************************/
/*                                Operations on sequences                               */
/****************************************************************************************/

// #define  CV_SEQ_ELEM( seq, elem_type, index )                    \
// /* assert gives some guarantee that <seq> parameter is valid */  \
// (   assert(sizeof((seq)->first[0]) == sizeof(CvSeqBlock) &&      \
//     (seq)->elem_size == sizeof(elem_type)),                      \
//     (elem_type*)((seq)->first && (unsigned)index <               \
//     (unsigned)((seq)->first->count) ?                            \
//     (seq)->first->data + (index) * sizeof(elem_type) :           \
//     cvGetSeqElem( (CvSeq*)(seq), (index) )))
// Unsupport : CV_SEQ_ELEM
// #define CV_GET_SEQ_ELEM( elem_type, seq, index ) CV_SEQ_ELEM( (seq), elem_type, (index) )
// Unsupport : CV_GET_SEQ_ELEM

/* Add element to sequence: */
// #define CV_WRITE_SEQ_ELEM_VAR( elem_ptr, writer )     \
// {                                                     \
//     if( (writer).ptr >= (writer).block_max )          \
//     {                                                 \
//         cvCreateSeqBlock( &writer);                   \
//     }                                                 \
//     memcpy((writer).ptr, elem_ptr, (writer).seq->elem_size);\
//     (writer).ptr += (writer).seq->elem_size;          \
// }
// Unsupport : CV_WRITE_SEQ_ELEM_VAR

// #define CV_WRITE_SEQ_ELEM( elem, writer )             \
// {                                                     \
//     assert( (writer).seq->elem_size == sizeof(elem)); \
//     if( (writer).ptr >= (writer).block_max )          \
//     {                                                 \
//         cvCreateSeqBlock( &writer);                   \
//     }                                                 \
//     assert( (writer).ptr <= (writer).block_max - sizeof(elem));\
//     memcpy((writer).ptr, &(elem), sizeof(elem));      \
//     (writer).ptr += sizeof(elem);                     \
// }
// Unsupport : CV_WRITE_SEQ_ELEM


/* Move reader position forward: */
// #define CV_NEXT_SEQ_ELEM( elem_size, reader )                 \
// {                                                             \
//     if( ((reader).ptr += (elem_size)) >= (reader).block_max ) \
//     {                                                         \
//         cvChangeSeqBlock( &(reader), 1 );                     \
//     }                                                         \
// }
#pragma push_macro( "CV_NEXT_SEQ_ELEM" )
#undef CV_NEXT_SEQ_ELEM
static void CV_NEXT_SEQ_ELEM( int elem_size, MNAME(CvSeqReader)^ reader )
#pragma pop_macro( "CV_NEXT_SEQ_ELEM" )
{
	reader->ptr += elem_size;
	if( reader->ptr.ToInt32() >= reader->block_max.ToInt32() )
	{
		cvChangeSeqBlock( reader->Address, 1 );
	}
}


/* Move reader position backward: */
// #define CV_PREV_SEQ_ELEM( elem_size, reader )                \
// {                                                            \
//     if( ((reader).ptr -= (elem_size)) < (reader).block_min ) \
//     {                                                        \
//         cvChangeSeqBlock( &(reader), -1 );                   \
//     }                                                        \
// }
#pragma push_macro( "CV_PREV_SEQ_ELEM" )
#undef CV_PREV_SEQ_ELEM
static void CV_PREV_SEQ_ELEM( int elem_size, MNAME(CvSeqReader)^ reader )
#pragma pop_macro( "CV_PREV_SEQ_ELEM" )
{
	reader->ptr -= elem_size;
	if( reader->ptr.ToInt32() >= reader->block_min.ToInt32() )
	{
		cvChangeSeqBlock( reader->Address, -1 );
	}
}

/* Read element and move read position forward: */
// #define CV_READ_SEQ_ELEM( elem, reader )                       \
// {                                                              \
//     assert( (reader).seq->elem_size == sizeof(elem));          \
//     memcpy( &(elem), (reader).ptr, sizeof((elem)));            \
//     CV_NEXT_SEQ_ELEM( sizeof(elem), reader )                   \
// }
// Unsupport : CV_READ_SEQ_ELEM

/* Read element and move read position backward: */
// #define CV_REV_READ_SEQ_ELEM( elem, reader )                     \
// {                                                                \
//     assert( (reader).seq->elem_size == sizeof(elem));            \
//     memcpy(&(elem), (reader).ptr, sizeof((elem)));               \
//     CV_PREV_SEQ_ELEM( sizeof(elem), reader )                     \
// }
// Unsupport : CV_REV_READ_SEQ_ELEM


// #define CV_READ_CHAIN_POINT( _pt, reader )                              \
// {                                                                       \
//     (_pt) = (reader).pt;                                                \
//     if( (reader).ptr )                                                  \
//     {                                                                   \
//         CV_READ_SEQ_ELEM( (reader).code, (reader));                     \
//         assert( ((reader).code & ~7) == 0 );                            \
//         (reader).pt.x += (reader).deltas[(int)(reader).code][0];        \
//         (reader).pt.y += (reader).deltas[(int)(reader).code][1];        \
//     }                                                                   \
// }
// Unsupport : CV_READ_CHAIN_POINT

// #define CV_CURRENT_POINT( reader )  (*((CvPoint*)((reader).ptr)))
// Unsupport : CV_CURRENT_POINT
// #define CV_PREV_POINT( reader )     (*((CvPoint*)((reader).prev_elem)))
// Unsupport : CV_PREV_POINT

// #define CV_READ_EDGE( pt1, pt2, reader )               \
// {                                                      \
//     assert( sizeof(pt1) == sizeof(CvPoint) &&          \
//             sizeof(pt2) == sizeof(CvPoint) &&          \
//             reader.seq->elem_size == sizeof(CvPoint)); \
//     (pt1) = CV_PREV_POINT( reader );                   \
//     (pt2) = CV_CURRENT_POINT( reader );                \
//     (reader).prev_elem = (reader).ptr;                 \
//     CV_NEXT_SEQ_ELEM( sizeof(CvPoint), (reader));      \
// }
// Unsupport : CV_READ_EDGE

/************ Graph macros ************/

/* Return next graph edge for given vertex: */
// #define  CV_NEXT_GRAPH_EDGE( edge, vertex )                              \
//      (assert((edge)->vtx[0] == (vertex) || (edge)->vtx[1] == (vertex)),  \
//       (edge)->next[(edge)->vtx[1] == (vertex)])
// Unsupport : CV_NEXT_GRAPH_EDGE



/****************************************************************************************\
*             Data structures for persistence (a.k.a serialization) functionality        *
\****************************************************************************************/

/* "black box" file storage */
// typedef struct CvFileStorage CvFileStorage;
DEFINE_HANDLE( CvFileStorage )

/* Storage flags: */
// #define CV_STORAGE_READ          0
#pragma push_macro( "CV_STORAGE_READ" )
#undef CV_STORAGE_READ
static const int CV_STORAGE_READ
#pragma pop_macro( "CV_STORAGE_READ" )
	= CV_STORAGE_READ;
// #define CV_STORAGE_WRITE         1
#pragma push_macro( "CV_STORAGE_WRITE" )
#undef CV_STORAGE_WRITE
static const int CV_STORAGE_WRITE
#pragma pop_macro( "CV_STORAGE_WRITE" )
	= CV_STORAGE_WRITE;
// #define CV_STORAGE_WRITE_TEXT    CV_STORAGE_WRITE
#pragma push_macro( "CV_STORAGE_WRITE_TEXT" )
#undef CV_STORAGE_WRITE_TEXT
static const int CV_STORAGE_WRITE_TEXT
#pragma pop_macro( "CV_STORAGE_WRITE_TEXT" )
	= CV_STORAGE_WRITE_TEXT;
// #define CV_STORAGE_WRITE_BINARY  CV_STORAGE_WRITE
#pragma push_macro( "CV_STORAGE_WRITE_BINARY" )
#undef CV_STORAGE_WRITE_BINARY
static const int CV_STORAGE_WRITE_BINARY
#pragma pop_macro( "CV_STORAGE_WRITE_BINARY" )
	= CV_STORAGE_WRITE_BINARY;
// #define CV_STORAGE_APPEND        2
#pragma push_macro( "CV_STORAGE_APPEND" )
#undef CV_STORAGE_APPEND
static const int CV_STORAGE_APPEND
#pragma pop_macro( "CV_STORAGE_APPEND" )
	= CV_STORAGE_APPEND;

/* List of attributes: */
// typedef struct CvAttrList
// {
//     const char** attr;         /* NULL-terminated array of (attribute_name,attribute_value) pairs. */
//     struct CvAttrList* next;   /* Pointer to next chunk of the attributes list.                    */
// }
// CvAttrList;
DEFINE_STRUCT( CvAttrList )
{STRUCT_BASIC( CvAttrList )
	DEFINE_PROPERTY_PC( const char**, attr )
	DEFINE_PROPERTY_SP( CvAttrList, next )
DEFINE_SETUP_CONSTRUCTOR( CvAttrList, cvAttrList, 2( TP(const,attr), SP(CvAttrList,next) ) )
DEFINE_SETUP_CONSTRUCTOR( CvAttrList, cvAttrList, 1( TP(const,attr) ) )
};

// CV_INLINE CvAttrList cvAttrList( const char** attr CV_DEFAULT(NULL),
//                                  CvAttrList* next CV_DEFAULT(NULL) )
// {
//     CvAttrList l;
//     l.attr = attr;
//     l.next = next;
// 
//     return l;
// }
DEFINE_FUNCTION_ALIAS( S(CvAttrList), cvAttrList, cvAttrList_, 2( TP(const,attr), SP(CvAttrList,next) ) ) 
DEFINE_FUNCTION_ALIAS( S(CvAttrList), cvAttrList, cvAttrList_, 1( TP(const,attr) ) ) 

// struct CvTypeInfo;

// #define CV_NODE_NONE        0
#pragma push_macro( "CV_NODE_NONE" )
#undef CV_NODE_NONE
static const int CV_NODE_NONE
#pragma pop_macro( "CV_NODE_NONE" )
	= CV_NODE_NONE;
// #define CV_NODE_INT         1
#pragma push_macro( "CV_NODE_INT" )
#undef CV_NODE_INT
static const int CV_NODE_INT
#pragma pop_macro( "CV_NODE_INT" )
	= CV_NODE_INT;
// #define CV_NODE_INTEGER     CV_NODE_INT
#pragma push_macro( "CV_NODE_INTEGER" )
#undef CV_NODE_INTEGER
static const int CV_NODE_INTEGER
#pragma pop_macro( "CV_NODE_INTEGER" )
	= CV_NODE_INTEGER;
// #define CV_NODE_REAL        2
#pragma push_macro( "CV_NODE_REAL" )
#undef CV_NODE_REAL
static const int CV_NODE_REAL
#pragma pop_macro( "CV_NODE_REAL" )
	= CV_NODE_REAL;
// #define CV_NODE_FLOAT       CV_NODE_REAL
#pragma push_macro( "CV_NODE_FLOAT" )
#undef CV_NODE_FLOAT
static const int CV_NODE_FLOAT
#pragma pop_macro( "CV_NODE_FLOAT" )
	= CV_NODE_FLOAT;
// #define CV_NODE_STR         3
#pragma push_macro( "CV_NODE_STR" )
#undef CV_NODE_STR
static const int CV_NODE_STR
#pragma pop_macro( "CV_NODE_STR" )
	= CV_NODE_STR;
// #define CV_NODE_STRING      CV_NODE_STR
#pragma push_macro( "CV_NODE_STRING" )
#undef CV_NODE_STRING
static const int CV_NODE_STRING
#pragma pop_macro( "CV_NODE_STRING" )
	= CV_NODE_STRING;
// #define CV_NODE_REF         4 /* not used */
#pragma push_macro( "CV_NODE_REF" )
#undef CV_NODE_REF
static const int CV_NODE_REF
#pragma pop_macro( "CV_NODE_REF" )
	= CV_NODE_REF;
// #define CV_NODE_SEQ         5
#pragma push_macro( "CV_NODE_SEQ" )
#undef CV_NODE_SEQ
static const int CV_NODE_SEQ
#pragma pop_macro( "CV_NODE_SEQ" )
	= CV_NODE_SEQ;
// #define CV_NODE_MAP         6
#pragma push_macro( "CV_NODE_MAP" )
#undef CV_NODE_MAP
static const int CV_NODE_MAP
#pragma pop_macro( "CV_NODE_MAP" )
	= CV_NODE_MAP;
// #define CV_NODE_TYPE_MASK   7
#pragma push_macro( "CV_NODE_TYPE_MASK" )
#undef CV_NODE_TYPE_MASK
static const int CV_NODE_TYPE_MASK
#pragma pop_macro( "CV_NODE_TYPE_MASK" )
	= CV_NODE_TYPE_MASK;

// #define CV_NODE_TYPE(flags)  ((flags) & CV_NODE_TYPE_MASK)
// Unsupport : CV_NODE_TYPE

/* file node flags */
// #define CV_NODE_FLOW        8 /* Used only for writing structures in YAML format. */
#pragma push_macro( "CV_NODE_FLOW" )
#undef CV_NODE_FLOW
static const int CV_NODE_FLOW
#pragma pop_macro( "CV_NODE_FLOW" )
	= CV_NODE_FLOW;
// #define CV_NODE_USER        16
#pragma push_macro( "CV_NODE_USER" )
#undef CV_NODE_USER
static const int CV_NODE_USER
#pragma pop_macro( "CV_NODE_USER" )
	= CV_NODE_USER;
// #define CV_NODE_EMPTY       32
#pragma push_macro( "CV_NODE_EMPTY" )
#undef CV_NODE_EMPTY
static const int CV_NODE_EMPTY
#pragma pop_macro( "CV_NODE_EMPTY" )
	= CV_NODE_EMPTY;
// #define CV_NODE_NAMED       64
#pragma push_macro( "CV_NODE_NAMED" )
#undef CV_NODE_NAMED
static const int CV_NODE_NAMED
#pragma pop_macro( "CV_NODE_NAMED" )
	= CV_NODE_NAMED;

// #define CV_NODE_IS_INT(flags)        (CV_NODE_TYPE(flags) == CV_NODE_INT)
// Unsupport : CV_NODE_IS_INT
// #define CV_NODE_IS_REAL(flags)       (CV_NODE_TYPE(flags) == CV_NODE_REAL)
// Unsupport : CV_NODE_IS_REAL
// #define CV_NODE_IS_STRING(flags)     (CV_NODE_TYPE(flags) == CV_NODE_STRING)
// Unsupport : CV_NODE_IS_STRING
// #define CV_NODE_IS_SEQ(flags)        (CV_NODE_TYPE(flags) == CV_NODE_SEQ)
// Unsupport : CV_NODE_IS_SEQ
// #define CV_NODE_IS_MAP(flags)        (CV_NODE_TYPE(flags) == CV_NODE_MAP)
// Unsupport : CV_NODE_IS_MAP
// #define CV_NODE_IS_COLLECTION(flags) (CV_NODE_TYPE(flags) >= CV_NODE_SEQ)
// Unsupport : CV_NODE_IS_COLLECTION
// #define CV_NODE_IS_FLOW(flags)       (((flags) & CV_NODE_FLOW) != 0)
// Unsupport : CV_NODE_IS_FLOW
// #define CV_NODE_IS_EMPTY(flags)      (((flags) & CV_NODE_EMPTY) != 0)
// Unsupport : CV_NODE_IS_EMPTY
// #define CV_NODE_IS_USER(flags)       (((flags) & CV_NODE_USER) != 0)
// Unsupport : CV_NODE_IS_USER
// #define CV_NODE_HAS_NAME(flags)      (((flags) & CV_NODE_NAMED) != 0)
// Unsupport : CV_NODE_HAS_NAME

// #define CV_NODE_SEQ_SIMPLE 256
#pragma push_macro( "CV_NODE_SEQ_SIMPLE" )
#undef CV_NODE_SEQ_SIMPLE
static const int CV_NODE_SEQ_SIMPLE
#pragma pop_macro( "CV_NODE_SEQ_SIMPLE" )
	= CV_NODE_SEQ_SIMPLE;
// #define CV_NODE_SEQ_IS_SIMPLE(seq) (((seq)->flags & CV_NODE_SEQ_SIMPLE) != 0)
// Unsupport : CV_NODE_SEQ_IS_SIMPLE

// typedef struct CvString
// {
//     int len;
//     char* ptr;
// }
// CvString;
DEFINE_STRUCT( CvString )
{STRUCT_BASIC( CvString )
	DEFINE_PROPERTY_V( int, len )
	DEFINE_PROPERTY_VP( char, ptr )
};

/* All the keys (names) of elements in the readed file storage
   are stored in the hash to speed up the lookup operations: */
// typedef struct CvStringHashNode
// {
//     unsigned hashval;
//     CvString str;
//     struct CvStringHashNode* next;
// }
// CvStringHashNode;
DEFINE_STRUCT( CvStringHashNode )
{STRUCT_BASIC( CvStringHashNode )
	DEFINE_PROPERTY_V( unsigned, hashval )
	DEFINE_PROPERTY_S( CvString, str )
	DEFINE_PROPERTY_SP( CvStringHashNode, next )
};

// typedef struct CvGenericHash CvFileNodeHash;
DEFINE_HANDLE( CvFileNodeHash )

/* Basic element of the file storage - scalar or collection: */
// typedef struct CvFileNode
// {
//     int tag;
//     struct CvTypeInfo* info; /* type information
//             (only for user-defined object, for others it is 0) */
//     union
//     {
//         double f; /* scalar floating-point number */
//         int i;    /* scalar integer number */
//         CvString str; /* text string */
//         CvSeq* seq; /* sequence (ordered collection of file nodes) */
//         CvFileNodeHash* map; /* map (collection of named file nodes) */
//     } data;
// }
// CvFileNode;
DEFINE_STRUCT_PROTOTYPE( CvTypeInfo )
DEFINE_STRUCT( CvFileNode )
{STRUCT_BASIC( CvFileNode )
	DEFINE_PROPERTY_V( int, tag )
	DEFINE_PROPERTY_SP( CvTypeInfo, info )
DEFINE_PROPERTY_P_CORE( , this->BasePtr->data.seq, this->BasePtr->data.seq, UNAME(CvSeq)*, data )
};

////#ifdef __cplusplus
////extern "C" {
////#endif
// typedef int (CV_CDECL *CvIsInstanceFunc)( const void* struct_ptr );
DEFINE_CALLBACK( V(int), CvIsInstanceFunc, 1( P(const void*,struct_ptr) ) ) 
// typedef void (CV_CDECL *CvReleaseFunc)( void** struct_dblptr );
DEFINE_CALLBACK( N(void), CvReleaseFunc, 1( P(void**,struct_dblptr) ) ) 
// typedef void* (CV_CDECL *CvReadFunc)( CvFileStorage* storage, CvFileNode* node );
DEFINE_CALLBACK( P(void*), CvReadFunc, 2( SP(CvFileStorage,storage), SP(CvFileNode,node) ) ) 
// typedef void (CV_CDECL *CvWriteFunc)( CvFileStorage* storage, const char* name,
//                                       const void* struct_ptr, CvAttrList attributes );
DEFINE_CALLBACK( N(void), CvWriteFunc, 4( SP(CvFileStorage,storage), T(const,name), P(const void*,struct_ptr), S(CvAttrList,attributes) ) ) 
// typedef void* (CV_CDECL *CvCloneFunc)( const void* struct_ptr );
DEFINE_CALLBACK( P(void*), CvCloneFunc, 1( P(const void*,struct_ptr) ) ) 
////#ifdef __cplusplus
////}
////#endif

// typedef struct CvTypeInfo
// {
//     int flags;
//     int header_size;
//     struct CvTypeInfo* prev;
//     struct CvTypeInfo* next;
//     const char* type_name;
//     CvIsInstanceFunc is_instance;
//     CvReleaseFunc release;
//     CvReadFunc read;
//     CvWriteFunc write;
//     CvCloneFunc clone;
// }
// CvTypeInfo;
DEFINE_STRUCT( CvTypeInfo )
{STRUCT_BASIC( CvTypeInfo )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvTypeInfo, prev )
	DEFINE_PROPERTY_SP( CvTypeInfo, next )
	DEFINE_PROPERTY_T( type_name )
	DEFINE_PROPERTY_F( CvIsInstanceFunc, is_instance )
	DEFINE_PROPERTY_F( CvReleaseFunc, release )
	DEFINE_PROPERTY_F( CvReadFunc, read )
	DEFINE_PROPERTY_F( CvWriteFunc, write )
	DEFINE_PROPERTY_F( CvCloneFunc, clone )
};


/**** System data types ******/

// typedef struct CvPluginFuncInfo
// {
//     void** func_addr;
//     void* default_func_addr;
//     const char* func_names;
//     int search_modules;
//     int loaded_from;
// }
// CvPluginFuncInfo;
DEFINE_STRUCT( CvPluginFuncInfo )
{STRUCT_BASIC( CvPluginFuncInfo )
	DEFINE_PROPERTY_P( void**, func_addr )
	DEFINE_PROPERTY_P( void*, default_func_addr )
	DEFINE_PROPERTY_T( func_names )
	DEFINE_PROPERTY_V( int, search_modules )
	DEFINE_PROPERTY_V( int, loaded_from )
};

// typedef struct CvModuleInfo
// {
//     struct CvModuleInfo* next;
//     const char* name;
//     const char* version;
//     CvPluginFuncInfo* func_tab;
// }
// CvModuleInfo;
DEFINE_STRUCT( CvModuleInfo )
{STRUCT_BASIC( CvModuleInfo )
	DEFINE_PROPERTY_SP( CvModuleInfo, next )
	DEFINE_PROPERTY_T( name )
	DEFINE_PROPERTY_T( version )
	DEFINE_PROPERTY_SP( CvPluginFuncInfo, func_tab )
};

////#endif /*_CXCORE_TYPES_H_*/

/* End of file. */
