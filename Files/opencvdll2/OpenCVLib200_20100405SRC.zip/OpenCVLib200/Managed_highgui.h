/*M///////////////////////////////////////////////////////////////////////////////////////
//
//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
//
//  By downloading, copying, installing or using the software you agree to this license.
//  If you do not agree to this license, do not download, install,
//  copy or use the software.
//
//
//                        Intel License Agreement
//                For Open Source Computer Vision Library
//
// Copyright (C) 2000, Intel Corporation, all rights reserved.
// Third party copyrights are property of their respective owners.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistribution's of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//   * Redistribution's in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//   * The name of Intel Corporation may not be used to endorse or promote products
//     derived from this software without specific prior written permission.
//
// This software is provided by the copyright holders and contributors "as is" and
// any express or implied warranties, including, but not limited to, the implied
// warranties of merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the Intel Corporation or contributors be liable for any direct,
// indirect, incidental, special, exemplary, or consequential damages
// (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused
// and on any theory of liability, whether in contract, strict liability,
// or tort (including negligence or otherwise) arising in any way out of
// the use of this software, even if advised of the possibility of such damage.
//
//M*/

////#ifndef _HIGH_GUI_
////#define _HIGH_GUI_
////
////#ifndef SKIP_INCLUDES
////
////  #include "cxcore.h"
////  #if defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64
////    #include <windows.h>
////  #endif
////
////#else // SKIP_INCLUDES
////
////  #if defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64
////    #define CV_CDECL __cdecl
////    #define CV_STDCALL __stdcall
////  #else
////    #define CV_CDECL
////    #define CV_STDCALL
////  #endif
////
////  #ifndef CV_EXTERN_C
////    #ifdef __cplusplus
////      #define CV_EXTERN_C extern "C"
////      #define CV_DEFAULT(val) = val
////    #else
////      #define CV_EXTERN_C
////      #define CV_DEFAULT(val)
////    #endif
////  #endif
////
////  #ifndef CV_EXTERN_C_FUNCPTR
////    #ifdef __cplusplus
////      #define CV_EXTERN_C_FUNCPTR(x) extern "C" { typedef x; }
////    #else
////      #define CV_EXTERN_C_FUNCPTR(x) typedef x
////    #endif
////  #endif
////
////  #ifndef CV_INLINE
////    #if defined __cplusplus
////      #define CV_INLINE inline
////    #elif (defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64) && !defined __GNUC__
////      #define CV_INLINE __inline
////    #else
////      #define CV_INLINE static
////    #endif
////  #endif /* CV_INLINE */
////
////  #if (defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64) && defined CVAPI_EXPORTS
////    #define CV_EXPORTS __declspec(dllexport)
////  #else
////    #define CV_EXPORTS
////  #endif
////
////  #ifndef CVAPI
////    #define CVAPI(rettype) CV_EXTERN_C CV_EXPORTS rettype CV_CDECL
////  #endif
////
////#endif // SKIP_INCLUDES
////
////#if defined(_CH_)
////  #pragma package <chopencv>
////  #include <chdl.h>
////  LOAD_CHDL(highgui)
////#endif
////
////#ifdef __cplusplus
////  extern "C" {
////#endif /* __cplusplus */

/****************************************************************************************\
*                                  Basic GUI functions                                   *
\****************************************************************************************/

/* this function is used to set some external parameters in case of X Window */
// CVAPI(int) cvInitSystem( int argc, char** argv );
DEFINE_FUNCTION( V(int), cvInitSystem, 2( V(int,argc), P(char**,argv) ) ) 

// CVAPI(int) cvStartWindowThread();

// #define CV_WINDOW_AUTOSIZE  1
#pragma push_macro( "CV_WINDOW_AUTOSIZE" )
#undef CV_WINDOW_AUTOSIZE
static const int CV_WINDOW_AUTOSIZE
#pragma pop_macro( "CV_WINDOW_AUTOSIZE" )
	= CV_WINDOW_AUTOSIZE;
/* create window */
// CVAPI(int) cvNamedWindow( const char* name, int flags CV_DEFAULT(CV_WINDOW_AUTOSIZE) );
DEFINE_FUNCTION( V(int), cvNamedWindow, 2( T(const,name), V(int,flags) ) ) 
DEFINE_FUNCTION( V(int), cvNamedWindow, 1( T(const,name) ) ) 

/* display image within window (highgui windows remember their content) */
// CVAPI(void) cvShowImage( const char* name, const CvArr* image );
DEFINE_FUNCTION( N(void), cvShowImage, 2( T(const,name), MP(UMemory,CvArr,image) ) ) 

/* resize/move window */
// CVAPI(void) cvResizeWindow( const char* name, int width, int height );
DEFINE_FUNCTION( N(void), cvResizeWindow, 3( T(const,name), V(int,width), V(int,height) ) ) 
// CVAPI(void) cvMoveWindow( const char* name, int x, int y );
DEFINE_FUNCTION( N(void), cvMoveWindow, 3( T(const,name), V(int,x), V(int,y) ) ) 


/* destroy window and all the trackers associated with it */
// CVAPI(void) cvDestroyWindow( const char* name );
DEFINE_FUNCTION( N(void), cvDestroyWindow, 1( T(const,name) ) ) 

// CVAPI(void) cvDestroyAllWindows(void);
DEFINE_FUNCTION( N(void), cvDestroyAllWindows, 0() ) 

/* get native window handle (HWND in case of Win32 and Widget in case of X Window) */
// CVAPI(void*) cvGetWindowHandle( const char* name );
DEFINE_FUNCTION( P(void*), cvGetWindowHandle, 1( T(const,name) ) ) 

/* get name of highgui window given its native handle */
// CVAPI(const char*) cvGetWindowName( void* window_handle );
DEFINE_FUNCTION( T(const char), cvGetWindowName, 1( P(void*,window_handle) ) ) 


// typedef void (CV_CDECL *CvTrackbarCallback)(int pos);
DEFINE_CALLBACK( N(void), CvTrackbarCallback, 1( V(int,pos) ) ) 

/* create trackbar and display it on top of given window, set callback */
// CVAPI(int) cvCreateTrackbar( const char* trackbar_name, const char* window_name,
//                              int* value, int count, CvTrackbarCallback on_change);
DEFINE_FUNCTION( V(int), cvCreateTrackbar, 5( T(const,trackbar_name), T(const,window_name), VP(int,value), V(int,count), F(CvTrackbarCallback,on_change) ) ) 
DEFINE_FUNCTION( V(int), cvCreateTrackbar, 5( T(const,trackbar_name), T(const,window_name), P(int*,value), V(int,count), F(CvTrackbarCallback,on_change) ) ) 

// typedef void (CV_CDECL *CvTrackbarCallback2)(int pos, void* userdata);
DEFINE_CALLBACK( N(void), CvTrackbarCallback2, 2( V(int,pos), P(void*,userdata) ) ) 

// CVAPI(int) cvCreateTrackbar2( const char* trackbar_name, const char* window_name,
//                               int* value, int count, CvTrackbarCallback2 on_change,
//                               void* userdata CV_DEFAULT(0));
DEFINE_FUNCTION( V(int), cvCreateTrackbar2, 6( T(const,trackbar_name), T(const,window_name), VP(int,value), V(int,count), F(CvTrackbarCallback2,on_change), P(void*,userdata) ) ) 
DEFINE_FUNCTION( V(int), cvCreateTrackbar2, 6( T(const,trackbar_name), T(const,window_name), P(int*,value), V(int,count), F(CvTrackbarCallback2,on_change), P(void*,userdata) ) ) 
DEFINE_FUNCTION( V(int), cvCreateTrackbar2, 5( T(const,trackbar_name), T(const,window_name), VP(int,value), V(int,count), F(CvTrackbarCallback2,on_change) ) ) 
DEFINE_FUNCTION( V(int), cvCreateTrackbar2, 5( T(const,trackbar_name), T(const,window_name), P(int*,value), V(int,count), F(CvTrackbarCallback2,on_change) ) ) 

/* retrieve or set trackbar position */
// CVAPI(int) cvGetTrackbarPos( const char* trackbar_name, const char* window_name );
DEFINE_FUNCTION( V(int), cvGetTrackbarPos, 2( T(const,trackbar_name), T(const,window_name) ) ) 
// CVAPI(void) cvSetTrackbarPos( const char* trackbar_name, const char* window_name, int pos );
DEFINE_FUNCTION( N(void), cvSetTrackbarPos, 3( T(const,trackbar_name), T(const,window_name), V(int,pos) ) ) 

// #define CV_EVENT_MOUSEMOVE      0
#pragma push_macro( "CV_EVENT_MOUSEMOVE" )
#undef CV_EVENT_MOUSEMOVE
static const int CV_EVENT_MOUSEMOVE
#pragma pop_macro( "CV_EVENT_MOUSEMOVE" )
	= CV_EVENT_MOUSEMOVE;
// #define CV_EVENT_LBUTTONDOWN    1
#pragma push_macro( "CV_EVENT_LBUTTONDOWN" )
#undef CV_EVENT_LBUTTONDOWN
static const int CV_EVENT_LBUTTONDOWN
#pragma pop_macro( "CV_EVENT_LBUTTONDOWN" )
	= CV_EVENT_LBUTTONDOWN;
// #define CV_EVENT_RBUTTONDOWN    2
#pragma push_macro( "CV_EVENT_RBUTTONDOWN" )
#undef CV_EVENT_RBUTTONDOWN
static const int CV_EVENT_RBUTTONDOWN
#pragma pop_macro( "CV_EVENT_RBUTTONDOWN" )
	= CV_EVENT_RBUTTONDOWN;
// #define CV_EVENT_MBUTTONDOWN    3
#pragma push_macro( "CV_EVENT_MBUTTONDOWN" )
#undef CV_EVENT_MBUTTONDOWN
static const int CV_EVENT_MBUTTONDOWN
#pragma pop_macro( "CV_EVENT_MBUTTONDOWN" )
	= CV_EVENT_MBUTTONDOWN;
// #define CV_EVENT_LBUTTONUP      4
#pragma push_macro( "CV_EVENT_LBUTTONUP" )
#undef CV_EVENT_LBUTTONUP
static const int CV_EVENT_LBUTTONUP
#pragma pop_macro( "CV_EVENT_LBUTTONUP" )
	= CV_EVENT_LBUTTONUP;
// #define CV_EVENT_RBUTTONUP      5
#pragma push_macro( "CV_EVENT_RBUTTONUP" )
#undef CV_EVENT_RBUTTONUP
static const int CV_EVENT_RBUTTONUP
#pragma pop_macro( "CV_EVENT_RBUTTONUP" )
	= CV_EVENT_RBUTTONUP;
// #define CV_EVENT_MBUTTONUP      6
#pragma push_macro( "CV_EVENT_MBUTTONUP" )
#undef CV_EVENT_MBUTTONUP
static const int CV_EVENT_MBUTTONUP
#pragma pop_macro( "CV_EVENT_MBUTTONUP" )
	= CV_EVENT_MBUTTONUP;
// #define CV_EVENT_LBUTTONDBLCLK  7
#pragma push_macro( "CV_EVENT_LBUTTONDBLCLK" )
#undef CV_EVENT_LBUTTONDBLCLK
static const int CV_EVENT_LBUTTONDBLCLK
#pragma pop_macro( "CV_EVENT_LBUTTONDBLCLK" )
	= CV_EVENT_LBUTTONDBLCLK;
// #define CV_EVENT_RBUTTONDBLCLK  8
#pragma push_macro( "CV_EVENT_RBUTTONDBLCLK" )
#undef CV_EVENT_RBUTTONDBLCLK
static const int CV_EVENT_RBUTTONDBLCLK
#pragma pop_macro( "CV_EVENT_RBUTTONDBLCLK" )
	= CV_EVENT_RBUTTONDBLCLK;
// #define CV_EVENT_MBUTTONDBLCLK  9
#pragma push_macro( "CV_EVENT_MBUTTONDBLCLK" )
#undef CV_EVENT_MBUTTONDBLCLK
static const int CV_EVENT_MBUTTONDBLCLK
#pragma pop_macro( "CV_EVENT_MBUTTONDBLCLK" )
	= CV_EVENT_MBUTTONDBLCLK;

// #define CV_EVENT_FLAG_LBUTTON   1
#pragma push_macro( "CV_EVENT_FLAG_LBUTTON" )
#undef CV_EVENT_FLAG_LBUTTON
static const int CV_EVENT_FLAG_LBUTTON
#pragma pop_macro( "CV_EVENT_FLAG_LBUTTON" )
	= CV_EVENT_FLAG_LBUTTON;
// #define CV_EVENT_FLAG_RBUTTON   2
#pragma push_macro( "CV_EVENT_FLAG_RBUTTON" )
#undef CV_EVENT_FLAG_RBUTTON
static const int CV_EVENT_FLAG_RBUTTON
#pragma pop_macro( "CV_EVENT_FLAG_RBUTTON" )
	= CV_EVENT_FLAG_RBUTTON;
// #define CV_EVENT_FLAG_MBUTTON   4
#pragma push_macro( "CV_EVENT_FLAG_MBUTTON" )
#undef CV_EVENT_FLAG_MBUTTON
static const int CV_EVENT_FLAG_MBUTTON
#pragma pop_macro( "CV_EVENT_FLAG_MBUTTON" )
	= CV_EVENT_FLAG_MBUTTON;
// #define CV_EVENT_FLAG_CTRLKEY   8
#pragma push_macro( "CV_EVENT_FLAG_CTRLKEY" )
#undef CV_EVENT_FLAG_CTRLKEY
static const int CV_EVENT_FLAG_CTRLKEY
#pragma pop_macro( "CV_EVENT_FLAG_CTRLKEY" )
	= CV_EVENT_FLAG_CTRLKEY;
// #define CV_EVENT_FLAG_SHIFTKEY  16
#pragma push_macro( "CV_EVENT_FLAG_SHIFTKEY" )
#undef CV_EVENT_FLAG_SHIFTKEY
static const int CV_EVENT_FLAG_SHIFTKEY
#pragma pop_macro( "CV_EVENT_FLAG_SHIFTKEY" )
	= CV_EVENT_FLAG_SHIFTKEY;
// #define CV_EVENT_FLAG_ALTKEY    32
#pragma push_macro( "CV_EVENT_FLAG_ALTKEY" )
#undef CV_EVENT_FLAG_ALTKEY
static const int CV_EVENT_FLAG_ALTKEY
#pragma pop_macro( "CV_EVENT_FLAG_ALTKEY" )
	= CV_EVENT_FLAG_ALTKEY;

// typedef void (CV_CDECL *CvMouseCallback )(int event, int x, int y, int flags, void* param);
DEFINE_CALLBACK( N(void), CvMouseCallback, 5( V(int,event), V(int,x), V(int,y), V(int,flags), P(void*,param) ) ) 

/* assign callback for mouse events */
// CVAPI(void) cvSetMouseCallback( const char* window_name, CvMouseCallback on_mouse,
//                                 void* param CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvSetMouseCallback, 3( T(const,window_name), F(CvMouseCallback,on_mouse), P(void*,param) ) ) 
DEFINE_FUNCTION( N(void), cvSetMouseCallback, 2( T(const,window_name), F(CvMouseCallback,on_mouse) ) ) 

/* 8bit, color or not */
// #define CV_LOAD_IMAGE_UNCHANGED  -1
#pragma push_macro( "CV_LOAD_IMAGE_UNCHANGED" )
#undef CV_LOAD_IMAGE_UNCHANGED
static const int CV_LOAD_IMAGE_UNCHANGED
#pragma pop_macro( "CV_LOAD_IMAGE_UNCHANGED" )
	= CV_LOAD_IMAGE_UNCHANGED;
/* 8bit, gray */
// #define CV_LOAD_IMAGE_GRAYSCALE   0
#pragma push_macro( "CV_LOAD_IMAGE_GRAYSCALE" )
#undef CV_LOAD_IMAGE_GRAYSCALE
static const int CV_LOAD_IMAGE_GRAYSCALE
#pragma pop_macro( "CV_LOAD_IMAGE_GRAYSCALE" )
	= CV_LOAD_IMAGE_GRAYSCALE;
/* ?, color */
// #define CV_LOAD_IMAGE_COLOR       1
#pragma push_macro( "CV_LOAD_IMAGE_COLOR" )
#undef CV_LOAD_IMAGE_COLOR
static const int CV_LOAD_IMAGE_COLOR
#pragma pop_macro( "CV_LOAD_IMAGE_COLOR" )
	= CV_LOAD_IMAGE_COLOR;
/* any depth, ? */
// #define CV_LOAD_IMAGE_ANYDEPTH    2
#pragma push_macro( "CV_LOAD_IMAGE_ANYDEPTH" )
#undef CV_LOAD_IMAGE_ANYDEPTH
static const int CV_LOAD_IMAGE_ANYDEPTH
#pragma pop_macro( "CV_LOAD_IMAGE_ANYDEPTH" )
	= CV_LOAD_IMAGE_ANYDEPTH;
/* ?, any color */
// #define CV_LOAD_IMAGE_ANYCOLOR    4
#pragma push_macro( "CV_LOAD_IMAGE_ANYCOLOR" )
#undef CV_LOAD_IMAGE_ANYCOLOR
static const int CV_LOAD_IMAGE_ANYCOLOR
#pragma pop_macro( "CV_LOAD_IMAGE_ANYCOLOR" )
	= CV_LOAD_IMAGE_ANYCOLOR;

/* load image from file
  iscolor can be a combination of above flags where CV_LOAD_IMAGE_UNCHANGED
  overrides the other flags
  using CV_LOAD_IMAGE_ANYCOLOR alone is equivalent to CV_LOAD_IMAGE_UNCHANGED
  unless CV_LOAD_IMAGE_ANYDEPTH is specified images are converted to 8bit
*/
// CVAPI(IplImage*) cvLoadImage( const char* filename, int iscolor CV_DEFAULT(CV_LOAD_IMAGE_COLOR));
DEFINE_FUNCTION( SP(IplImage), cvLoadImage, 2( T(const,filename), V(int,iscolor) ) ) 
DEFINE_FUNCTION( SP(IplImage), cvLoadImage, 1( T(const,filename) ) ) 
// CVAPI(CvMat*) cvLoadImageM( const char* filename, int iscolor CV_DEFAULT(CV_LOAD_IMAGE_COLOR));
DEFINE_FUNCTION( SP(CvMat), cvLoadImageM, 2( T(const,filename), V(int,iscolor) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvLoadImageM, 1( T(const,filename) ) ) 

// #define CV_IMWRITE_JPEG_QUALITY 1
#pragma push_macro( "CV_IMWRITE_JPEG_QUALITY" )
#undef CV_IMWRITE_JPEG_QUALITY
static const int CV_IMWRITE_JPEG_QUALITY
#pragma pop_macro( "CV_IMWRITE_JPEG_QUALITY" )
	= CV_IMWRITE_JPEG_QUALITY;
// #define CV_IMWRITE_PNG_COMPRESSION 16
#pragma push_macro( "CV_IMWRITE_PNG_COMPRESSION" )
#undef CV_IMWRITE_PNG_COMPRESSION
static const int CV_IMWRITE_PNG_COMPRESSION
#pragma pop_macro( "CV_IMWRITE_PNG_COMPRESSION" )
	= CV_IMWRITE_PNG_COMPRESSION;
// #define CV_IMWRITE_PXM_BINARY 32
#pragma push_macro( "CV_IMWRITE_PXM_BINARY" )
#undef CV_IMWRITE_PXM_BINARY
static const int CV_IMWRITE_PXM_BINARY
#pragma pop_macro( "CV_IMWRITE_PXM_BINARY" )
	= CV_IMWRITE_PXM_BINARY;

/* save image to file */
// CVAPI(int) cvSaveImage( const char* filename, const CvArr* image,
//                         const int* params CV_DEFAULT(0) );
DEFINE_FUNCTION( V(int), cvSaveImage, 3( T(const,filename), MP(UMemory,CvArr,image), VP(int,params) ) ) 
DEFINE_FUNCTION( V(int), cvSaveImage, 3( T(const,filename), MP(UMemory,CvArr,image), P(const int*,params) ) ) 
DEFINE_FUNCTION( V(int), cvSaveImage, 2( T(const,filename), MP(UMemory,CvArr,image) ) ) 

/* decode image stored in the buffer */
// CVAPI(IplImage*) cvDecodeImage( const CvMat* buf, int iscolor CV_DEFAULT(CV_LOAD_IMAGE_COLOR));
DEFINE_FUNCTION( SP(IplImage), cvDecodeImage, 2( SP(CvMat,buf), V(int,iscolor) ) ) 
DEFINE_FUNCTION( SP(IplImage), cvDecodeImage, 1( SP(CvMat,buf) ) ) 
// CVAPI(CvMat*) cvDecodeImageM( const CvMat* buf, int iscolor CV_DEFAULT(CV_LOAD_IMAGE_COLOR));
DEFINE_FUNCTION( SP(CvMat), cvDecodeImageM, 2( SP(CvMat,buf), V(int,iscolor) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvDecodeImageM, 1( SP(CvMat,buf) ) ) 

/* encode image and store the result as a byte vector (single-row 8uC1 matrix) */
// CVAPI(CvMat*) cvEncodeImage( const char* ext, const CvArr* image,
//                              const int* params CV_DEFAULT(0) );
DEFINE_FUNCTION( SP(CvMat), cvEncodeImage, 3( T(const,ext), MP(UMemory,CvArr,image), VP(int,params) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvEncodeImage, 3( T(const,ext), MP(UMemory,CvArr,image), P(const int*,params) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvEncodeImage, 2( T(const,ext), MP(UMemory,CvArr,image) ) ) 

// #define CV_CVTIMG_FLIP      1
#pragma push_macro( "CV_CVTIMG_FLIP" )
#undef CV_CVTIMG_FLIP
static const int CV_CVTIMG_FLIP
#pragma pop_macro( "CV_CVTIMG_FLIP" )
	= CV_CVTIMG_FLIP;
// #define CV_CVTIMG_SWAP_RB   2
#pragma push_macro( "CV_CVTIMG_SWAP_RB" )
#undef CV_CVTIMG_SWAP_RB
static const int CV_CVTIMG_SWAP_RB
#pragma pop_macro( "CV_CVTIMG_SWAP_RB" )
	= CV_CVTIMG_SWAP_RB;
/* utility function: convert one image to another with optional vertical flip */
// CVAPI(void) cvConvertImage( const CvArr* src, CvArr* dst, int flags CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvConvertImage, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvConvertImage, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* wait for key event infinitely (delay<=0) or for "delay" milliseconds */
// CVAPI(int) cvWaitKey(int delay CV_DEFAULT(0));
DEFINE_FUNCTION( V(int), cvWaitKey, 1( V(int,delay) ) ) 


/****************************************************************************************\
*                         Working with Video Files and Cameras                           *
\****************************************************************************************/

/* "black box" capture structure */
// typedef struct CvCapture CvCapture;
DEFINE_HANDLE( CvCapture )

/* start capturing frames from video file */
// CVAPI(CvCapture*) cvCreateFileCapture( const char* filename );
DEFINE_FUNCTION( SP(CvCapture), cvCreateFileCapture, 1( T(const,filename) ) ) 

// #define CV_CAP_ANY      0     // autodetect
#pragma push_macro( "CV_CAP_ANY" )
#undef CV_CAP_ANY
static const int CV_CAP_ANY
#pragma pop_macro( "CV_CAP_ANY" )
	= CV_CAP_ANY;

// #define CV_CAP_MIL      100   // MIL proprietary drivers
#pragma push_macro( "CV_CAP_MIL" )
#undef CV_CAP_MIL
static const int CV_CAP_MIL
#pragma pop_macro( "CV_CAP_MIL" )
	= CV_CAP_MIL;

// #define CV_CAP_VFW      200   // platform native
#pragma push_macro( "CV_CAP_VFW" )
#undef CV_CAP_VFW
static const int CV_CAP_VFW
#pragma pop_macro( "CV_CAP_VFW" )
	= CV_CAP_VFW;
// #define CV_CAP_V4L      200
#pragma push_macro( "CV_CAP_V4L" )
#undef CV_CAP_V4L
static const int CV_CAP_V4L
#pragma pop_macro( "CV_CAP_V4L" )
	= CV_CAP_V4L;
// #define CV_CAP_V4L2     200
#pragma push_macro( "CV_CAP_V4L2" )
#undef CV_CAP_V4L2
static const int CV_CAP_V4L2
#pragma pop_macro( "CV_CAP_V4L2" )
	= CV_CAP_V4L2;

// #define CV_CAP_FIREWARE 300   // IEEE 1394 drivers
#pragma push_macro( "CV_CAP_FIREWARE" )
#undef CV_CAP_FIREWARE
static const int CV_CAP_FIREWARE
#pragma pop_macro( "CV_CAP_FIREWARE" )
	= CV_CAP_FIREWARE;
// #define CV_CAP_FIREWIRE 300
#pragma push_macro( "CV_CAP_FIREWIRE" )
#undef CV_CAP_FIREWIRE
static const int CV_CAP_FIREWIRE
#pragma pop_macro( "CV_CAP_FIREWIRE" )
	= CV_CAP_FIREWIRE;
// #define CV_CAP_IEEE1394 300
#pragma push_macro( "CV_CAP_IEEE1394" )
#undef CV_CAP_IEEE1394
static const int CV_CAP_IEEE1394
#pragma pop_macro( "CV_CAP_IEEE1394" )
	= CV_CAP_IEEE1394;
// #define CV_CAP_DC1394   300
#pragma push_macro( "CV_CAP_DC1394" )
#undef CV_CAP_DC1394
static const int CV_CAP_DC1394
#pragma pop_macro( "CV_CAP_DC1394" )
	= CV_CAP_DC1394;
// #define CV_CAP_CMU1394  300
#pragma push_macro( "CV_CAP_CMU1394" )
#undef CV_CAP_CMU1394
static const int CV_CAP_CMU1394
#pragma pop_macro( "CV_CAP_CMU1394" )
	= CV_CAP_CMU1394;

// #define CV_CAP_STEREO   400   // TYZX proprietary drivers
#pragma push_macro( "CV_CAP_STEREO" )
#undef CV_CAP_STEREO
static const int CV_CAP_STEREO
#pragma pop_macro( "CV_CAP_STEREO" )
	= CV_CAP_STEREO;
// #define CV_CAP_TYZX     400
#pragma push_macro( "CV_CAP_TYZX" )
#undef CV_CAP_TYZX
static const int CV_CAP_TYZX
#pragma pop_macro( "CV_CAP_TYZX" )
	= CV_CAP_TYZX;
// #define CV_TYZX_LEFT    400
#pragma push_macro( "CV_TYZX_LEFT" )
#undef CV_TYZX_LEFT
static const int CV_TYZX_LEFT
#pragma pop_macro( "CV_TYZX_LEFT" )
	= CV_TYZX_LEFT;
// #define CV_TYZX_RIGHT   401
#pragma push_macro( "CV_TYZX_RIGHT" )
#undef CV_TYZX_RIGHT
static const int CV_TYZX_RIGHT
#pragma pop_macro( "CV_TYZX_RIGHT" )
	= CV_TYZX_RIGHT;
// #define CV_TYZX_COLOR   402
#pragma push_macro( "CV_TYZX_COLOR" )
#undef CV_TYZX_COLOR
static const int CV_TYZX_COLOR
#pragma pop_macro( "CV_TYZX_COLOR" )
	= CV_TYZX_COLOR;
// #define CV_TYZX_Z       403
#pragma push_macro( "CV_TYZX_Z" )
#undef CV_TYZX_Z
static const int CV_TYZX_Z
#pragma pop_macro( "CV_TYZX_Z" )
	= CV_TYZX_Z;

// #define CV_CAP_QT       500   // QuickTime
#pragma push_macro( "CV_CAP_QT" )
#undef CV_CAP_QT
static const int CV_CAP_QT
#pragma pop_macro( "CV_CAP_QT" )
	= CV_CAP_QT;

// #define CV_CAP_UNICAP   600   // Unicap drivers
#pragma push_macro( "CV_CAP_UNICAP" )
#undef CV_CAP_UNICAP
static const int CV_CAP_UNICAP
#pragma pop_macro( "CV_CAP_UNICAP" )
	= CV_CAP_UNICAP;

// #define CV_CAP_DSHOW    700   // DirectShow (via videoInput)
#pragma push_macro( "CV_CAP_DSHOW" )
#undef CV_CAP_DSHOW
static const int CV_CAP_DSHOW
#pragma pop_macro( "CV_CAP_DSHOW" )
	= CV_CAP_DSHOW;

/* start capturing frames from camera: index = camera_index + domain_offset (CV_CAP_*) */
// CVAPI(CvCapture*) cvCreateCameraCapture( int index );
DEFINE_FUNCTION( SP(CvCapture), cvCreateCameraCapture, 1( V(int,index) ) ) 

/* grab a frame, return 1 on success, 0 on fail.
  this function is thought to be fast               */
// CVAPI(int) cvGrabFrame( CvCapture* capture );
DEFINE_FUNCTION( V(int), cvGrabFrame, 1( SP(CvCapture,capture) ) ) 

/* get the frame grabbed with cvGrabFrame(..)
  This function may apply some frame processing like
  frame decompression, flipping etc.
  !!!DO NOT RELEASE or MODIFY the retrieved frame!!! */
// CVAPI(IplImage*) cvRetrieveFrame( CvCapture* capture, int streamIdx CV_DEFAULT(0) );
DEFINE_FUNCTION( SP(IplImage), cvRetrieveFrame, 2( SP(CvCapture,capture), V(int,streamIdx) ) ) 
DEFINE_FUNCTION( SP(IplImage), cvRetrieveFrame, 1( SP(CvCapture,capture) ) ) 

/* Just a combination of cvGrabFrame and cvRetrieveFrame
   !!!DO NOT RELEASE or MODIFY the retrieved frame!!!      */
// CVAPI(IplImage*) cvQueryFrame( CvCapture* capture );
DEFINE_FUNCTION( SP(IplImage), cvQueryFrame, 1( SP(CvCapture,capture) ) ) 

/* stop capturing/reading and free resources */
// CVAPI(void) cvReleaseCapture( CvCapture** capture );
DEFINE_FUNCTION( N(void), cvReleaseCapture, 1( SPP(CvCapture,capture) ) ) 

// #define CV_CAP_PROP_POS_MSEC       0
#pragma push_macro( "CV_CAP_PROP_POS_MSEC" )
#undef CV_CAP_PROP_POS_MSEC
static const int CV_CAP_PROP_POS_MSEC
#pragma pop_macro( "CV_CAP_PROP_POS_MSEC" )
	= CV_CAP_PROP_POS_MSEC;
// #define CV_CAP_PROP_POS_FRAMES     1
#pragma push_macro( "CV_CAP_PROP_POS_FRAMES" )
#undef CV_CAP_PROP_POS_FRAMES
static const int CV_CAP_PROP_POS_FRAMES
#pragma pop_macro( "CV_CAP_PROP_POS_FRAMES" )
	= CV_CAP_PROP_POS_FRAMES;
// #define CV_CAP_PROP_POS_AVI_RATIO  2
#pragma push_macro( "CV_CAP_PROP_POS_AVI_RATIO" )
#undef CV_CAP_PROP_POS_AVI_RATIO
static const int CV_CAP_PROP_POS_AVI_RATIO
#pragma pop_macro( "CV_CAP_PROP_POS_AVI_RATIO" )
	= CV_CAP_PROP_POS_AVI_RATIO;
// #define CV_CAP_PROP_FRAME_WIDTH    3
#pragma push_macro( "CV_CAP_PROP_FRAME_WIDTH" )
#undef CV_CAP_PROP_FRAME_WIDTH
static const int CV_CAP_PROP_FRAME_WIDTH
#pragma pop_macro( "CV_CAP_PROP_FRAME_WIDTH" )
	= CV_CAP_PROP_FRAME_WIDTH;
// #define CV_CAP_PROP_FRAME_HEIGHT   4
#pragma push_macro( "CV_CAP_PROP_FRAME_HEIGHT" )
#undef CV_CAP_PROP_FRAME_HEIGHT
static const int CV_CAP_PROP_FRAME_HEIGHT
#pragma pop_macro( "CV_CAP_PROP_FRAME_HEIGHT" )
	= CV_CAP_PROP_FRAME_HEIGHT;
// #define CV_CAP_PROP_FPS            5
#pragma push_macro( "CV_CAP_PROP_FPS" )
#undef CV_CAP_PROP_FPS
static const int CV_CAP_PROP_FPS
#pragma pop_macro( "CV_CAP_PROP_FPS" )
	= CV_CAP_PROP_FPS;
// #define CV_CAP_PROP_FOURCC         6
#pragma push_macro( "CV_CAP_PROP_FOURCC" )
#undef CV_CAP_PROP_FOURCC
static const int CV_CAP_PROP_FOURCC
#pragma pop_macro( "CV_CAP_PROP_FOURCC" )
	= CV_CAP_PROP_FOURCC;
// #define CV_CAP_PROP_FRAME_COUNT    7
#pragma push_macro( "CV_CAP_PROP_FRAME_COUNT" )
#undef CV_CAP_PROP_FRAME_COUNT
static const int CV_CAP_PROP_FRAME_COUNT
#pragma pop_macro( "CV_CAP_PROP_FRAME_COUNT" )
	= CV_CAP_PROP_FRAME_COUNT;
// #define CV_CAP_PROP_FORMAT         8
#pragma push_macro( "CV_CAP_PROP_FORMAT" )
#undef CV_CAP_PROP_FORMAT
static const int CV_CAP_PROP_FORMAT
#pragma pop_macro( "CV_CAP_PROP_FORMAT" )
	= CV_CAP_PROP_FORMAT;
// #define CV_CAP_PROP_MODE           9
#pragma push_macro( "CV_CAP_PROP_MODE" )
#undef CV_CAP_PROP_MODE
static const int CV_CAP_PROP_MODE
#pragma pop_macro( "CV_CAP_PROP_MODE" )
	= CV_CAP_PROP_MODE;
// #define CV_CAP_PROP_BRIGHTNESS    10
#pragma push_macro( "CV_CAP_PROP_BRIGHTNESS" )
#undef CV_CAP_PROP_BRIGHTNESS
static const int CV_CAP_PROP_BRIGHTNESS
#pragma pop_macro( "CV_CAP_PROP_BRIGHTNESS" )
	= CV_CAP_PROP_BRIGHTNESS;
// #define CV_CAP_PROP_CONTRAST      11
#pragma push_macro( "CV_CAP_PROP_CONTRAST" )
#undef CV_CAP_PROP_CONTRAST
static const int CV_CAP_PROP_CONTRAST
#pragma pop_macro( "CV_CAP_PROP_CONTRAST" )
	= CV_CAP_PROP_CONTRAST;
// #define CV_CAP_PROP_SATURATION    12
#pragma push_macro( "CV_CAP_PROP_SATURATION" )
#undef CV_CAP_PROP_SATURATION
static const int CV_CAP_PROP_SATURATION
#pragma pop_macro( "CV_CAP_PROP_SATURATION" )
	= CV_CAP_PROP_SATURATION;
// #define CV_CAP_PROP_HUE           13
#pragma push_macro( "CV_CAP_PROP_HUE" )
#undef CV_CAP_PROP_HUE
static const int CV_CAP_PROP_HUE
#pragma pop_macro( "CV_CAP_PROP_HUE" )
	= CV_CAP_PROP_HUE;
// #define CV_CAP_PROP_GAIN          14
#pragma push_macro( "CV_CAP_PROP_GAIN" )
#undef CV_CAP_PROP_GAIN
static const int CV_CAP_PROP_GAIN
#pragma pop_macro( "CV_CAP_PROP_GAIN" )
	= CV_CAP_PROP_GAIN;
// #define CV_CAP_PROP_EXPOSURE      15
#pragma push_macro( "CV_CAP_PROP_EXPOSURE" )
#undef CV_CAP_PROP_EXPOSURE
static const int CV_CAP_PROP_EXPOSURE
#pragma pop_macro( "CV_CAP_PROP_EXPOSURE" )
	= CV_CAP_PROP_EXPOSURE;
// #define CV_CAP_PROP_CONVERT_RGB   16
#pragma push_macro( "CV_CAP_PROP_CONVERT_RGB" )
#undef CV_CAP_PROP_CONVERT_RGB
static const int CV_CAP_PROP_CONVERT_RGB
#pragma pop_macro( "CV_CAP_PROP_CONVERT_RGB" )
	= CV_CAP_PROP_CONVERT_RGB;
// #define CV_CAP_PROP_WHITE_BALANCE 17
#pragma push_macro( "CV_CAP_PROP_WHITE_BALANCE" )
#undef CV_CAP_PROP_WHITE_BALANCE
static const int CV_CAP_PROP_WHITE_BALANCE
#pragma pop_macro( "CV_CAP_PROP_WHITE_BALANCE" )
	= CV_CAP_PROP_WHITE_BALANCE;
// #define CV_CAP_PROP_RECTIFICATION 18
#pragma push_macro( "CV_CAP_PROP_RECTIFICATION" )
#undef CV_CAP_PROP_RECTIFICATION
static const int CV_CAP_PROP_RECTIFICATION
#pragma pop_macro( "CV_CAP_PROP_RECTIFICATION" )
	= CV_CAP_PROP_RECTIFICATION;

/* retrieve or set capture properties */
// CVAPI(double) cvGetCaptureProperty( CvCapture* capture, int property_id );
DEFINE_FUNCTION( V(double), cvGetCaptureProperty, 2( SP(CvCapture,capture), V(int,property_id) ) ) 
// CVAPI(int)    cvSetCaptureProperty( CvCapture* capture, int property_id, double value );
DEFINE_FUNCTION( V(int), cvSetCaptureProperty, 3( SP(CvCapture,capture), V(int,property_id), V(double,value) ) ) 

// Return the type of the capturer (eg, CV_CAP_V4W, CV_CAP_UNICAP), which is unknown if created with CV_CAP_ANY
// CVAPI(int)    cvGetCaptureDomain( CvCapture* capture);  
DEFINE_FUNCTION( V(int), cvGetCaptureDomain, 1( SP(CvCapture,capture) ) ) 

/* "black box" video file writer structure */
// typedef struct CvVideoWriter CvVideoWriter;
DEFINE_HANDLE( CvVideoWriter )

////#ifndef SWIG
// #define CV_FOURCC(c1,c2,c3,c4)  \
//     (((c1)&255) + (((c2)&255)<<8) + (((c3)&255)<<16) + (((c4)&255)<<24))
// Unsupport : CV_FOURCC
////#else
////  // Prototype for CV_FOURCC so that swig can generate wrapper without mixing up the define
////  int CV_FOURCC(char c1, char c2, char c3, char c4);
////#endif

// #define CV_FOURCC_PROMPT -1  /* Open Codec Selection Dialog (Windows only) */
#pragma push_macro( "CV_FOURCC_PROMPT" )
#undef CV_FOURCC_PROMPT
static const int CV_FOURCC_PROMPT
#pragma pop_macro( "CV_FOURCC_PROMPT" )
	= CV_FOURCC_PROMPT;
// #define CV_FOURCC_DEFAULT CV_FOURCC('I', 'Y', 'U', 'V') /* Use default codec for specified filename (Linux only) */
// Unsupport : CV_FOURCC_DEFAULT

/* initialize video file writer */
// CVAPI(CvVideoWriter*) cvCreateVideoWriter( const char* filename, int fourcc,
//                                            double fps, CvSize frame_size,
//                                            int is_color CV_DEFAULT(1));
DEFINE_FUNCTION( SP(CvVideoWriter), cvCreateVideoWriter, 5( T(const,filename), V(int,fourcc), V(double,fps), S(CvSize,frame_size), V(int,is_color) ) ) 
DEFINE_FUNCTION( SP(CvVideoWriter), cvCreateVideoWriter, 4( T(const,filename), V(int,fourcc), V(double,fps), S(CvSize,frame_size) ) ) 

//CVAPI(CvVideoWriter*) cvCreateImageSequenceWriter( const char* filename,
//                                                   int is_color CV_DEFAULT(1));

/* write frame to video file */
// CVAPI(int) cvWriteFrame( CvVideoWriter* writer, const IplImage* image );
DEFINE_FUNCTION( V(int), cvWriteFrame, 2( SP(CvVideoWriter,writer), SP(IplImage,image) ) ) 

/* close video file writer */
// CVAPI(void) cvReleaseVideoWriter( CvVideoWriter** writer );
DEFINE_FUNCTION( N(void), cvReleaseVideoWriter, 1( SPP(CvVideoWriter,writer) ) ) 

/****************************************************************************************\
*                              Obsolete functions/synonyms                               *
\****************************************************************************************/

////#ifndef HIGHGUI_NO_BACKWARD_COMPATIBILITY
////    #define HIGHGUI_BACKWARD_COMPATIBILITY
////#endif

////#ifdef HIGHGUI_BACKWARD_COMPATIBILITY

// #define cvCaptureFromFile cvCreateFileCapture
#pragma push_macro( "cvCaptureFromFile" )
#undef cvCaptureFromFile
DEFINE_FUNCTION_ALIAS( SP(CvCapture), cvCreateFileCapture, cvCaptureFromFile, 1( T(const,filename) ) ) 
#pragma pop_macro( "cvCaptureFromFile" )
// #define cvCaptureFromCAM cvCreateCameraCapture
#pragma push_macro( "cvCaptureFromCAM" )
#undef cvCaptureFromCAM
DEFINE_FUNCTION_ALIAS( SP(CvCapture), cvCreateCameraCapture, cvCaptureFromCAM, 1( V(int,index) ) ) 
#pragma pop_macro( "cvCaptureFromCAM" )
// #define cvCaptureFromAVI cvCaptureFromFile
#pragma push_macro( "cvCaptureFromAVI" )
#undef cvCaptureFromAVI
DEFINE_FUNCTION_ALIAS( SP(CvCapture), cvCreateFileCapture, cvCaptureFromAVI, 1( T(const,filename) ) ) 
#pragma pop_macro( "cvCaptureFromAVI" )
// #define cvCreateAVIWriter cvCreateVideoWriter
#pragma push_macro( "cvCreateAVIWriter" )
#undef cvCreateAVIWriter
DEFINE_FUNCTION_ALIAS( SP(CvVideoWriter), cvCreateVideoWriter, cvCreateAVIWriter, 5( T(const,filename), V(int,fourcc), V(double,fps), S(CvSize,frame_size), V(int,is_color) ) ) 
DEFINE_FUNCTION_ALIAS( SP(CvVideoWriter), cvCreateVideoWriter, cvCreateAVIWriter, 4( T(const,filename), V(int,fourcc), V(double,fps), S(CvSize,frame_size) ) ) 
#pragma pop_macro( "cvCreateAVIWriter" )
// #define cvWriteToAVI cvWriteFrame
#pragma push_macro( "cvWriteToAVI" )
#undef cvWriteToAVI
DEFINE_FUNCTION_ALIAS( V(int), cvWriteFrame, cvWriteToAVI, 2( SP(CvVideoWriter,writer), SP(IplImage,image) ) ) 
#pragma pop_macro( "cvWriteToAVI" )
// #define cvAddSearchPath(path)
// Unsupport : cvAddSearchPath
// #define cvvInitSystem cvInitSystem
#pragma push_macro( "cvvInitSystem" )
#undef cvvInitSystem
DEFINE_FUNCTION_ALIAS( V(int), cvInitSystem, cvvInitSystem, 2( V(int,argc), P(char**,argv) ) ) 
#pragma pop_macro( "cvvInitSystem" )
// #define cvvNamedWindow cvNamedWindow
#pragma push_macro( "cvvNamedWindow" )
#undef cvvNamedWindow
DEFINE_FUNCTION_ALIAS( V(int), cvNamedWindow, cvvNamedWindow, 2( T(const,name), V(int,flags) ) ) 
DEFINE_FUNCTION_ALIAS( V(int), cvNamedWindow, cvvNamedWindow, 1( T(const,name) ) ) 
#pragma pop_macro( "cvvNamedWindow" )
// #define cvvShowImage cvShowImage
#pragma push_macro( "cvvShowImage" )
#undef cvvShowImage
DEFINE_FUNCTION_ALIAS( N(void), cvShowImage, cvvShowImage, 2( T(const,name), MP(UMemory,CvArr,image) ) ) 
#pragma pop_macro( "cvvShowImage" )
// #define cvvResizeWindow cvResizeWindow
#pragma push_macro( "cvvResizeWindow" )
#undef cvvResizeWindow
DEFINE_FUNCTION_ALIAS( N(void), cvResizeWindow, cvvResizeWindow, 3( T(const,name), V(int,width), V(int,height) ) ) 
#pragma pop_macro( "cvvResizeWindow" )
// #define cvvDestroyWindow cvDestroyWindow
#pragma push_macro( "cvvDestroyWindow" )
#undef cvvDestroyWindow
DEFINE_FUNCTION_ALIAS( N(void), cvDestroyWindow, cvvDestroyWindow, 1( T(const,name) ) ) 
#pragma pop_macro( "cvvDestroyWindow" )
// #define cvvCreateTrackbar cvCreateTrackbar
#pragma push_macro( "cvvCreateTrackbar" )
#undef cvvCreateTrackbar
DEFINE_FUNCTION_ALIAS( V(int), cvCreateTrackbar, cvvCreateTrackbar, 5( T(const,trackbar_name), T(const,window_name), VP(int,value), V(int,count), F(CvTrackbarCallback,on_change) ) ) 
DEFINE_FUNCTION_ALIAS( V(int), cvCreateTrackbar, cvvCreateTrackbar, 5( T(const,trackbar_name), T(const,window_name), P(int*,value), V(int,count), F(CvTrackbarCallback,on_change) ) ) 
#pragma pop_macro( "cvvCreateTrackbar" )
// #define cvvLoadImage(name) cvLoadImage((name),1)
// Unsupport : cvvLoadImage
// #define cvvSaveImage cvSaveImage
#pragma push_macro( "cvvSaveImage" )
#undef cvvSaveImage
DEFINE_FUNCTION_ALIAS( V(int), cvSaveImage, cvvSaveImage, 3( T(const,filename), MP(UMemory,CvArr,image), VP(int,params) ) ) 
DEFINE_FUNCTION_ALIAS( V(int), cvSaveImage, cvvSaveImage, 3( T(const,filename), MP(UMemory,CvArr,image), P(const int*,params) ) ) 
DEFINE_FUNCTION_ALIAS( V(int), cvSaveImage, cvvSaveImage, 2( T(const,filename), MP(UMemory,CvArr,image) ) ) 
#pragma pop_macro( "cvvSaveImage" )
// #define cvvAddSearchPath cvAddSearchPath
// Unsupport : cvvAddSearchPath
// #define cvvWaitKey(name) cvWaitKey(0)
// Unsupport : cvvWaitKey
// #define cvvWaitKeyEx(name,delay) cvWaitKey(delay)
// Unsupport : cvvWaitKeyEx
// #define cvvConvertImage cvConvertImage
#pragma push_macro( "cvvConvertImage" )
#undef cvvConvertImage
DEFINE_FUNCTION_ALIAS( N(void), cvConvertImage, cvvConvertImage, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,flags) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvConvertImage, cvvConvertImage, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
#pragma pop_macro( "cvvConvertImage" )
// #define HG_AUTOSIZE CV_WINDOW_AUTOSIZE
#pragma push_macro( "HG_AUTOSIZE" )
#undef HG_AUTOSIZE
static const int HG_AUTOSIZE
#pragma pop_macro( "HG_AUTOSIZE" )
	= HG_AUTOSIZE;
// #define set_preprocess_func cvSetPreprocessFuncWin32
// Unsupport : set_preprocess_func
// #define set_postprocess_func cvSetPostprocessFuncWin32
// Unsupport : set_postprocess_func

////#if defined WIN32 || defined _WIN32

// typedef int (CV_CDECL * CvWin32WindowCallback)(HWND, UINT, WPARAM, LPARAM, int*);
DEFINE_CALLBACK( V(int), CvWin32WindowCallback, 5( P(IntPtr,), V(unsigned int,), V(unsigned int,), V(long,), VP(int,) ) ) 
// CVAPI(void) cvSetPreprocessFuncWin32( CvWin32WindowCallback on_preprocess );
DEFINE_FUNCTION( N(void), cvSetPreprocessFuncWin32, 1( F(CvWin32WindowCallback,on_preprocess) ) ) 
// CVAPI(void) cvSetPostprocessFuncWin32( CvWin32WindowCallback on_postprocess );
DEFINE_FUNCTION( N(void), cvSetPostprocessFuncWin32, 1( F(CvWin32WindowCallback,on_postprocess) ) ) 

// CV_INLINE int iplWidth( const IplImage* img );
DEFINE_FUNCTION( V(int), iplWidth, 1( SP(IplImage,img) ) ) 
// CV_INLINE int iplWidth( const IplImage* img )
// {
//     return !img ? 0 : !img->roi ? img->width : img->roi->width;
// }

// CV_INLINE int iplHeight( const IplImage* img );
DEFINE_FUNCTION( V(int), iplHeight, 1( SP(IplImage,img) ) ) 
// CV_INLINE int iplHeight( const IplImage* img )
// {
//     return !img ? 0 : !img->roi ? img->height : img->roi->height;
// }

////#endif

////#endif /* obsolete functions */

/* For use with Win32 */
////#if defined WIN32 || defined _WIN32

// CV_INLINE RECT NormalizeRect( RECT r );
// Unsupport(prototype)
// CV_INLINE RECT NormalizeRect( RECT r )
// {
//     int t;
// 
//     if( r.left > r.right )
//     {
//         t = r.left;
//         r.left = r.right;
//         r.right = t;
//     }
// 
//     if( r.top > r.bottom )
//     {
//         t = r.top;
//         r.top = r.bottom;
//         r.bottom = t;
//     }
// 
//     return r;
// }
// Unsupport

// CV_INLINE CvRect RectToCvRect( RECT sr );
// Unsupport(prototype)
// CV_INLINE CvRect RectToCvRect( RECT sr )
// {
//     sr = NormalizeRect( sr );
//     return cvRect( sr.left, sr.top, sr.right - sr.left, sr.bottom - sr.top );
// }
// Unsupport

// CV_INLINE RECT CvRectToRect( CvRect sr );
// Unsupport(prototype)
// CV_INLINE RECT CvRectToRect( CvRect sr )
// {
//     RECT dr;
//     dr.left = sr.x;
//     dr.top = sr.y;
//     dr.right = sr.x + sr.width;
//     dr.bottom = sr.y + sr.height;
// 
//     return dr;
// }
// Unsupport

// CV_INLINE IplROI RectToROI( RECT r );
// Unsupport(prototype)
// CV_INLINE IplROI RectToROI( RECT r )
// {
//     IplROI roi;
//     r = NormalizeRect( r );
//     roi.xOffset = r.left;
//     roi.yOffset = r.top;
//     roi.width = r.right - r.left;
//     roi.height = r.bottom - r.top;
//     roi.coi = 0;
// 
//     return roi;
// }
// Unsupport

////#endif /* WIN32 */

////#ifdef __cplusplus
////}  /* end of extern "C" */
////#endif /* __cplusplus */


////#if defined __cplusplus && !defined CV_NO_CVV_IMAGE
////
/////* CvvImage class definition */
////class CV_EXPORTS CvvImage
////{
////public:
////    CvvImage();
////    virtual ~CvvImage();
////
////    /* Create image (BGR or grayscale) */
////    virtual bool  Create( int width, int height, int bits_per_pixel, int image_origin = 0 );
////
////    /* Load image from specified file */
////    virtual bool  Load( const char* filename, int desired_color = 1 );
////
////    /* Load rectangle from the file */
////    virtual bool  LoadRect( const char* filename,
////                            int desired_color, CvRect r );
////
////#if defined WIN32 || defined _WIN32
////    virtual bool  LoadRect( const char* filename,
////                            int desired_color, RECT r )
////    {
////        return LoadRect( filename, desired_color,
////                         cvRect( r.left, r.top, r.right - r.left, r.bottom - r.top ));
////    }
////#endif
////
////    /* Save entire image to specified file. */
////    virtual bool  Save( const char* filename );
////
////    /* Get copy of input image ROI */
////    virtual void  CopyOf( CvvImage& image, int desired_color = -1 );
////    virtual void  CopyOf( IplImage* img, int desired_color = -1 );
////
////    IplImage* GetImage() { return m_img; };
////    virtual void  Destroy(void);
////
////    /* width and height of ROI */
////    int Width() { return !m_img ? 0 : !m_img->roi ? m_img->width : m_img->roi->width; };
////    int Height() { return !m_img ? 0 : !m_img->roi ? m_img->height : m_img->roi->height;};
////    int Bpp() { return m_img ? (m_img->depth & 255)*m_img->nChannels : 0; };
////
////    virtual void  Fill( int color );
////
////    /* draw to highgui window */
////    virtual void  Show( const char* window );
////
////#if defined WIN32 || defined _WIN32
////    /* draw part of image to the specified DC */
////    virtual void  Show( HDC dc, int x, int y, int width, int height,
////                        int from_x = 0, int from_y = 0 );
////    /* draw the current image ROI to the specified rectangle of the destination DC */
////    virtual void  DrawToHDC( HDC hDCDst, RECT* pDstRect );
////#endif
////
////protected:
////
////    IplImage*  m_img;
////};
////
////typedef CvvImage CImage;
////
////
////#endif /* __cplusplus */
////
////
/////****************************************************************************************\
////*                                    New interface                                       *
////\****************************************************************************************/
////
////#include "highgui.hpp"
////
////#endif /* _HIGH_GUI_ */
