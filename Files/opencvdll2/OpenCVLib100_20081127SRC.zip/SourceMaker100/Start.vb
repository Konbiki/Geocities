﻿Option Explicit On
Option Strict On

' OpenCV Version 1.0 用
'
' このプログラムは、OpenCVLib100のソースコードを生成する為のものです。
' デバッグ環境下で実行されることを想定しています。
' 

Imports System.IO

Module Start

    Public Sub Main()
        Trace.Listeners.Add(New TextWriterTraceListener(System.Console.Out))

        Debug.Print("---- Program Start ---- {0}", Now)

        'ルートフォルダ取得
        Dim apppath As New DirectoryInfo(My.Application.Info.DirectoryPath)
        Dim rootpath As String = apppath.Parent.Parent.Parent.FullName

        '変換
        Dim cc As New OpenCVConverter
        cc.SourcePath = rootpath + "\cvsrc100\"     '読込先
        cc.OutputPath = rootpath + "\OpenCVLib100\" '出力先
        cc.ConvertDataName = "SourceMaker.ConvertData.txt"
        cc.ReportOpen(cc.OutputPath + "report.txt")
        cc.ConvertAll()
        cc.ReportClose()

        Debug.Print("---- Program End ---- {0}", Now)

    End Sub

End Module

