/*M///////////////////////////////////////////////////////////////////////////////////////
//
//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
//
//  By downloading, copying, installing or using the software you agree to this license.
//  If you do not agree to this license, do not download, install,
//  copy or use the software.
//
//
//                        Intel License Agreement
//                For Open Source Computer Vision Library
//
// Copyright (C) 2000, Intel Corporation, all rights reserved.
// Third party copyrights are property of their respective owners.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistribution's of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//   * Redistribution's in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//   * The name of Intel Corporation may not be used to endorse or promote products
//     derived from this software without specific prior written permission.
//
// This software is provided by the copyright holders and contributors "as is" and
// any express or implied warranties, including, but not limited to, the implied
// warranties of merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the Intel Corporation or contributors be liable for any direct,
// indirect, incidental, special, exemplary, or consequential damages
// (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused
// and on any theory of liability, whether in contract, strict liability,
// or tort (including negligence or otherwise) arising in any way out of
// the use of this software, even if advised of the possibility of such damage.
//
//M*/

////#ifndef _CVTYPES_H_
////#define _CVTYPES_H_

////#ifndef SKIP_INCLUDES
////  #include <assert.h>
////  #include <stdlib.h>
////#endif

/* spatial and central moments */
// typedef struct CvMoments
// {
//     double  m00, m10, m01, m20, m11, m02, m30, m21, m12, m03; /* spatial moments */
//     double  mu20, mu11, mu02, mu30, mu21, mu12, mu03; /* central moments */
//     double  inv_sqrt_m00; /* m00 != 0 ? 1/sqrt(m00) : 0 */
// }
// CvMoments;
DEFINE_STRUCT( CvMoments )
{STRUCT_BASIC( CvMoments )
	DEFINE_PROPERTY_V( double, m00 )
	DEFINE_PROPERTY_V( double, m10 )
	DEFINE_PROPERTY_V( double, m01 )
	DEFINE_PROPERTY_V( double, m20 )
	DEFINE_PROPERTY_V( double, m11 )
	DEFINE_PROPERTY_V( double, m02 )
	DEFINE_PROPERTY_V( double, m30 )
	DEFINE_PROPERTY_V( double, m21 )
	DEFINE_PROPERTY_V( double, m12 )
	DEFINE_PROPERTY_V( double, m03 )
	DEFINE_PROPERTY_V( double, mu20 )
	DEFINE_PROPERTY_V( double, mu11 )
	DEFINE_PROPERTY_V( double, mu02 )
	DEFINE_PROPERTY_V( double, mu30 )
	DEFINE_PROPERTY_V( double, mu21 )
	DEFINE_PROPERTY_V( double, mu12 )
	DEFINE_PROPERTY_V( double, mu03 )
	DEFINE_PROPERTY_V( double, inv_sqrt_m00 )
};

/* Hu invariants */
// typedef struct CvHuMoments
// {
//     double hu1, hu2, hu3, hu4, hu5, hu6, hu7; /* Hu invariants */
// }
// CvHuMoments;
DEFINE_STRUCT( CvHuMoments )
{STRUCT_BASIC( CvHuMoments )
	DEFINE_PROPERTY_V( double, hu1 )
	DEFINE_PROPERTY_V( double, hu2 )
	DEFINE_PROPERTY_V( double, hu3 )
	DEFINE_PROPERTY_V( double, hu4 )
	DEFINE_PROPERTY_V( double, hu5 )
	DEFINE_PROPERTY_V( double, hu6 )
	DEFINE_PROPERTY_V( double, hu7 )
};

/**************************** Connected Component  **************************************/

// typedef struct CvConnectedComp
// {
//     double area;    /* area of the connected component  */
//     CvScalar value; /* average color of the connected component */
//     CvRect rect;    /* ROI of the component  */
//     CvSeq* contour; /* optional component boundary
//                       (the contour might have child contours corresponding to the holes)*/
// }
// CvConnectedComp;
DEFINE_STRUCT( CvConnectedComp )
{STRUCT_BASIC( CvConnectedComp )
	DEFINE_PROPERTY_V( double, area )
	DEFINE_PROPERTY_S( CvScalar, value )
	DEFINE_PROPERTY_S( CvRect, rect )
	DEFINE_PROPERTY_SP( CvSeq, contour )
};

/*
Internal structure that is used for sequental retrieving contours from the image.
It supports both hierarchical and plane variants of Suzuki algorithm.
*/
// typedef struct _CvContourScanner* CvContourScanner;
DEFINE_HANDLEP( CvContourScanner )

/* contour retrieval mode */
// #define CV_RETR_EXTERNAL 0
#pragma push_macro( "CV_RETR_EXTERNAL" )
#undef CV_RETR_EXTERNAL
static const int CV_RETR_EXTERNAL
#pragma pop_macro( "CV_RETR_EXTERNAL" )
	= CV_RETR_EXTERNAL;
// #define CV_RETR_LIST     1
#pragma push_macro( "CV_RETR_LIST" )
#undef CV_RETR_LIST
static const int CV_RETR_LIST
#pragma pop_macro( "CV_RETR_LIST" )
	= CV_RETR_LIST;
// #define CV_RETR_CCOMP    2
#pragma push_macro( "CV_RETR_CCOMP" )
#undef CV_RETR_CCOMP
static const int CV_RETR_CCOMP
#pragma pop_macro( "CV_RETR_CCOMP" )
	= CV_RETR_CCOMP;
// #define CV_RETR_TREE     3
#pragma push_macro( "CV_RETR_TREE" )
#undef CV_RETR_TREE
static const int CV_RETR_TREE
#pragma pop_macro( "CV_RETR_TREE" )
	= CV_RETR_TREE;

/* contour approximation method */
// #define CV_CHAIN_CODE               0
#pragma push_macro( "CV_CHAIN_CODE" )
#undef CV_CHAIN_CODE
static const int CV_CHAIN_CODE
#pragma pop_macro( "CV_CHAIN_CODE" )
	= CV_CHAIN_CODE;
// #define CV_CHAIN_APPROX_NONE        1
#pragma push_macro( "CV_CHAIN_APPROX_NONE" )
#undef CV_CHAIN_APPROX_NONE
static const int CV_CHAIN_APPROX_NONE
#pragma pop_macro( "CV_CHAIN_APPROX_NONE" )
	= CV_CHAIN_APPROX_NONE;
// #define CV_CHAIN_APPROX_SIMPLE      2
#pragma push_macro( "CV_CHAIN_APPROX_SIMPLE" )
#undef CV_CHAIN_APPROX_SIMPLE
static const int CV_CHAIN_APPROX_SIMPLE
#pragma pop_macro( "CV_CHAIN_APPROX_SIMPLE" )
	= CV_CHAIN_APPROX_SIMPLE;
// #define CV_CHAIN_APPROX_TC89_L1     3
#pragma push_macro( "CV_CHAIN_APPROX_TC89_L1" )
#undef CV_CHAIN_APPROX_TC89_L1
static const int CV_CHAIN_APPROX_TC89_L1
#pragma pop_macro( "CV_CHAIN_APPROX_TC89_L1" )
	= CV_CHAIN_APPROX_TC89_L1;
// #define CV_CHAIN_APPROX_TC89_KCOS   4
#pragma push_macro( "CV_CHAIN_APPROX_TC89_KCOS" )
#undef CV_CHAIN_APPROX_TC89_KCOS
static const int CV_CHAIN_APPROX_TC89_KCOS
#pragma pop_macro( "CV_CHAIN_APPROX_TC89_KCOS" )
	= CV_CHAIN_APPROX_TC89_KCOS;
// #define CV_LINK_RUNS                5
#pragma push_macro( "CV_LINK_RUNS" )
#undef CV_LINK_RUNS
static const int CV_LINK_RUNS
#pragma pop_macro( "CV_LINK_RUNS" )
	= CV_LINK_RUNS;

/* Freeman chain reader state */
// typedef struct CvChainPtReader
// {
//     CV_SEQ_READER_FIELDS()
//     char      code;
//     CvPoint   pt;
//     char      deltas[8][2];
// }
// CvChainPtReader;
DEFINE_STRUCT( CvChainPtReader )
{STRUCT_BASIC( CvChainPtReader )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvSeq, seq )
	DEFINE_PROPERTY_SP( CvSeqBlock, block )
	DEFINE_PROPERTY_VP( char, ptr )
	DEFINE_PROPERTY_VP( char, block_min )
	DEFINE_PROPERTY_VP( char, block_max )
	DEFINE_PROPERTY_V( int, delta_index )
	DEFINE_PROPERTY_VP( char, prev_elem )
	DEFINE_PROPERTY_V( char, code )
	DEFINE_PROPERTY_S( CvPoint, pt )
	DEFINE_PROPERTY_VA2( char, deltas, 8, 2 )
};

/* initializes 8-element array for fast access to 3x3 neighborhood of a pixel */
// #define  CV_INIT_3X3_DELTAS( deltas, step, nch )            \
//     ((deltas)[0] =  (nch),  (deltas)[1] = -(step) + (nch),  \
//      (deltas)[2] = -(step), (deltas)[3] = -(step) - (nch),  \
//      (deltas)[4] = -(nch),  (deltas)[5] =  (step) - (nch),  \
//      (deltas)[6] =  (step), (deltas)[7] =  (step) + (nch))
// Unsupport : CV_INIT_3X3_DELTAS

/* Contour tree header */
// typedef struct CvContourTree
// {
//     CV_SEQUENCE_FIELDS()
//     CvPoint p1;            /* the first point of the binary tree root segment */
//     CvPoint p2;            /* the last point of the binary tree root segment */
// }
// CvContourTree;
DEFINE_STRUCT( CvContourTree )
{STRUCT_BASIC( CvContourTree )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvSeq, h_prev )
	DEFINE_PROPERTY_SP( CvSeq, h_next )
	DEFINE_PROPERTY_SP( CvSeq, v_prev )
	DEFINE_PROPERTY_SP( CvSeq, v_next )
	DEFINE_PROPERTY_V( int, total )
	DEFINE_PROPERTY_V( int, elem_size )
	DEFINE_PROPERTY_VP( char, block_max )
	DEFINE_PROPERTY_VP( char, ptr )
	DEFINE_PROPERTY_V( int, delta_elems )
	DEFINE_PROPERTY_SP( CvMemStorage, storage )
	DEFINE_PROPERTY_SP( CvSeqBlock, free_blocks )
	DEFINE_PROPERTY_SP( CvSeqBlock, first )
	DEFINE_PROPERTY_S( CvPoint, p1 )
	DEFINE_PROPERTY_S( CvPoint, p2 )
};

/* Finds a sequence of convexity defects of given contour */
// typedef struct CvConvexityDefect
// {
//     CvPoint* start; /* point of the contour where the defect begins */
//     CvPoint* end; /* point of the contour where the defect ends */
//     CvPoint* depth_point; /* the farthest from the convex hull point within the defect */
//     float depth; /* distance between the farthest point and the convex hull */
// }
// CvConvexityDefect;
DEFINE_STRUCT( CvConvexityDefect )
{STRUCT_BASIC( CvConvexityDefect )
	DEFINE_PROPERTY_SP( CvPoint, start )
	DEFINE_PROPERTY_SP( CvPoint, end )
	DEFINE_PROPERTY_SP( CvPoint, depth_point )
	DEFINE_PROPERTY_V( float, depth )
};

/************ Data structures and related enumerations for Planar Subdivisions ************/

// typedef size_t CvSubdiv2DEdge;
// Unsupport : CvSubdiv2DEdge

// #define CV_QUADEDGE2D_FIELDS()     \
//     int flags;                     \
//     struct CvSubdiv2DPoint* pt[4]; \
//     CvSubdiv2DEdge  next[4];
// Unsupport : CV_QUADEDGE2D_FIELDS

// #define CV_SUBDIV2D_POINT_FIELDS()\
//     int            flags;      \
//     CvSubdiv2DEdge first;      \
//     CvPoint2D32f   pt;
// Unsupport : CV_SUBDIV2D_POINT_FIELDS

// #define CV_SUBDIV2D_VIRTUAL_POINT_FLAG (1 << 30)
#pragma push_macro( "CV_SUBDIV2D_VIRTUAL_POINT_FLAG" )
#undef CV_SUBDIV2D_VIRTUAL_POINT_FLAG
static const int CV_SUBDIV2D_VIRTUAL_POINT_FLAG
#pragma pop_macro( "CV_SUBDIV2D_VIRTUAL_POINT_FLAG" )
	= CV_SUBDIV2D_VIRTUAL_POINT_FLAG;

// typedef struct CvQuadEdge2D
// {
//     CV_QUADEDGE2D_FIELDS()
// }
// CvQuadEdge2D;
DEFINE_STRUCT_PROTOTYPE( CvSubdiv2DPoint )
DEFINE_STRUCT( CvQuadEdge2D )
{STRUCT_BASIC( CvQuadEdge2D )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_SPA( CvSubdiv2DPoint, pt, 4 )
	DEFINE_PROPERTY_VA( size_t, next, 4 )
};

// typedef struct CvSubdiv2DPoint
// {
//     CV_SUBDIV2D_POINT_FIELDS()
// }
// CvSubdiv2DPoint;
DEFINE_STRUCT( CvSubdiv2DPoint )
{STRUCT_BASIC( CvSubdiv2DPoint )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( size_t, first )
	DEFINE_PROPERTY_S( CvPoint2D32f, pt )
};

// #define CV_SUBDIV2D_FIELDS()    \
//     CV_GRAPH_FIELDS()           \
//     int  quad_edges;            \
//     int  is_geometry_valid;     \
//     CvSubdiv2DEdge recent_edge; \
//     CvPoint2D32f  topleft;      \
//     CvPoint2D32f  bottomright;
// Unsupport : CV_SUBDIV2D_FIELDS
    
// typedef struct CvSubdiv2D
// {
//     CV_SUBDIV2D_FIELDS()
// }
// CvSubdiv2D;
DEFINE_STRUCT( CvSubdiv2D )
{STRUCT_BASIC( CvSubdiv2D )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( int, header_size )
	DEFINE_PROPERTY_SP( CvSeq, h_prev )
	DEFINE_PROPERTY_SP( CvSeq, h_next )
	DEFINE_PROPERTY_SP( CvSeq, v_prev )
	DEFINE_PROPERTY_SP( CvSeq, v_next )
	DEFINE_PROPERTY_V( int, total )
	DEFINE_PROPERTY_V( int, elem_size )
	DEFINE_PROPERTY_VP( char, block_max )
	DEFINE_PROPERTY_VP( char, ptr )
	DEFINE_PROPERTY_V( int, delta_elems )
	DEFINE_PROPERTY_SP( CvMemStorage, storage )
	DEFINE_PROPERTY_SP( CvSeqBlock, free_blocks )
	DEFINE_PROPERTY_SP( CvSeqBlock, first )
	DEFINE_PROPERTY_SP( CvSetElem, free_elems )
	DEFINE_PROPERTY_V( int, active_count )
	DEFINE_PROPERTY_SP( CvSet, edges )
	DEFINE_PROPERTY_V( int, quad_edges )
	DEFINE_PROPERTY_V( int, is_geometry_valid )
	DEFINE_PROPERTY_V( size_t, recent_edge )
	DEFINE_PROPERTY_S( CvPoint2D32f, topleft )
	DEFINE_PROPERTY_S( CvPoint2D32f, bottomright )
};


// typedef enum CvSubdiv2DPointLocation
// {
//     CV_PTLOC_ERROR = -2,
//     CV_PTLOC_OUTSIDE_RECT = -1,
//     CV_PTLOC_INSIDE = 0,
//     CV_PTLOC_VERTEX = 1,
//     CV_PTLOC_ON_EDGE = 2
// }
// CvSubdiv2DPointLocation;
DEFINE_ENUM( CvSubdiv2DPointLocation )
{
	DEFINE_ENUMDATA( CV_PTLOC_ERROR )
	DEFINE_ENUMDATA( CV_PTLOC_OUTSIDE_RECT )
	DEFINE_ENUMDATA( CV_PTLOC_INSIDE )
	DEFINE_ENUMDATA( CV_PTLOC_VERTEX )
	DEFINE_ENUMDATA( CV_PTLOC_ON_EDGE )
};

// typedef enum CvNextEdgeType
// {
//     CV_NEXT_AROUND_ORG   = 0x00,
//     CV_NEXT_AROUND_DST   = 0x22,
//     CV_PREV_AROUND_ORG   = 0x11,
//     CV_PREV_AROUND_DST   = 0x33,
//     CV_NEXT_AROUND_LEFT  = 0x13,
//     CV_NEXT_AROUND_RIGHT = 0x31,
//     CV_PREV_AROUND_LEFT  = 0x20,
//     CV_PREV_AROUND_RIGHT = 0x02
// }
// CvNextEdgeType;
DEFINE_ENUM( CvNextEdgeType )
{
	DEFINE_ENUMDATA( CV_NEXT_AROUND_ORG )
	DEFINE_ENUMDATA( CV_NEXT_AROUND_DST )
	DEFINE_ENUMDATA( CV_PREV_AROUND_ORG )
	DEFINE_ENUMDATA( CV_PREV_AROUND_DST )
	DEFINE_ENUMDATA( CV_NEXT_AROUND_LEFT )
	DEFINE_ENUMDATA( CV_NEXT_AROUND_RIGHT )
	DEFINE_ENUMDATA( CV_PREV_AROUND_LEFT )
	DEFINE_ENUMDATA( CV_PREV_AROUND_RIGHT )
};

/* get the next edge with the same origin point (counterwise) */
// #define  CV_SUBDIV2D_NEXT_EDGE( edge )  (((CvQuadEdge2D*)((edge) & ~3))->next[(edge)&3])
// Unsupport : CV_SUBDIV2D_NEXT_EDGE


/* Defines for Distance Transform */
// #define CV_DIST_USER    -1  /* User defined distance */
#pragma push_macro( "CV_DIST_USER" )
#undef CV_DIST_USER
static const int CV_DIST_USER
#pragma pop_macro( "CV_DIST_USER" )
	= CV_DIST_USER;
// #define CV_DIST_L1      1   /* distance = |x1-x2| + |y1-y2| */
#pragma push_macro( "CV_DIST_L1" )
#undef CV_DIST_L1
static const int CV_DIST_L1
#pragma pop_macro( "CV_DIST_L1" )
	= CV_DIST_L1;
// #define CV_DIST_L2      2   /* the simple euclidean distance */
#pragma push_macro( "CV_DIST_L2" )
#undef CV_DIST_L2
static const int CV_DIST_L2
#pragma pop_macro( "CV_DIST_L2" )
	= CV_DIST_L2;
// #define CV_DIST_C       3   /* distance = max(|x1-x2|,|y1-y2|) */
#pragma push_macro( "CV_DIST_C" )
#undef CV_DIST_C
static const int CV_DIST_C
#pragma pop_macro( "CV_DIST_C" )
	= CV_DIST_C;
// #define CV_DIST_L12     4   /* L1-L2 metric: distance = 2(sqrt(1+x*x/2) - 1)) */
#pragma push_macro( "CV_DIST_L12" )
#undef CV_DIST_L12
static const int CV_DIST_L12
#pragma pop_macro( "CV_DIST_L12" )
	= CV_DIST_L12;
// #define CV_DIST_FAIR    5   /* distance = c^2(|x|/c-log(1+|x|/c)), c = 1.3998 */
#pragma push_macro( "CV_DIST_FAIR" )
#undef CV_DIST_FAIR
static const int CV_DIST_FAIR
#pragma pop_macro( "CV_DIST_FAIR" )
	= CV_DIST_FAIR;
// #define CV_DIST_WELSCH  6   /* distance = c^2/2(1-exp(-(x/c)^2)), c = 2.9846 */
#pragma push_macro( "CV_DIST_WELSCH" )
#undef CV_DIST_WELSCH
static const int CV_DIST_WELSCH
#pragma pop_macro( "CV_DIST_WELSCH" )
	= CV_DIST_WELSCH;
// #define CV_DIST_HUBER   7   /* distance = |x|<c ? x^2/2 : c(|x|-c/2), c=1.345 */
#pragma push_macro( "CV_DIST_HUBER" )
#undef CV_DIST_HUBER
static const int CV_DIST_HUBER
#pragma pop_macro( "CV_DIST_HUBER" )
	= CV_DIST_HUBER;


/* Filters used in pyramid decomposition */
// typedef enum CvFilter
// {
//     CV_GAUSSIAN_5x5 = 7
// }
// CvFilter;
DEFINE_ENUM( CvFilter )
{
	DEFINE_ENUMDATA( CV_GAUSSIAN_5x5 )
};

/****************************************************************************************/
/*                                    Older definitions                                 */
/****************************************************************************************/

// typedef float*   CvVect32f;
// Unsupport : CvVect32f
// typedef float*   CvMatr32f;
// Unsupport : CvMatr32f
// typedef double*  CvVect64d;
// Unsupport : CvVect64d
// typedef double*  CvMatr64d;
// Unsupport : CvMatr64d

// typedef struct CvMatrix3
// {
//     float m[3][3];
// }
// CvMatrix3;
DEFINE_STRUCT( CvMatrix3 )
{STRUCT_BASIC( CvMatrix3 )
	DEFINE_PROPERTY_VA2( float, m, 3, 3 )
};


////#ifdef __cplusplus
////extern "C" {
////#endif

// typedef float (CV_CDECL * CvDistanceFunction)( const float* a, const float* b, void* user_param );
DEFINE_CALLBACK( V(float), CvDistanceFunction, 3( VP(float,a), VP(float,b), P(void*,user_param) ) ) 

////#ifdef __cplusplus
////}
////#endif

// typedef struct CvConDensation
// {
//     int MP;
//     int DP;
//     float* DynamMatr;       /* Matrix of the linear Dynamics system  */
//     float* State;           /* Vector of State                       */
//     int SamplesNum;         /* Number of the Samples                 */
//     float** flSamples;      /* arr of the Sample Vectors             */
//     float** flNewSamples;   /* temporary array of the Sample Vectors */
//     float* flConfidence;    /* Confidence for each Sample            */
//     float* flCumulative;    /* Cumulative confidence                 */
//     float* Temp;            /* Temporary vector                      */
//     float* RandomSample;    /* RandomVector to update sample set     */
//     struct CvRandState* RandS; /* Array of structures to generate random vectors */
// }
// CvConDensation;
DEFINE_STRUCT_PROTOTYPE( CvRandState )
DEFINE_STRUCT( CvConDensation )
{STRUCT_BASIC( CvConDensation )
	DEFINE_PROPERTY_V( int, MP )
	DEFINE_PROPERTY_V( int, DP )
	DEFINE_PROPERTY_VP( float, DynamMatr )
	DEFINE_PROPERTY_VP( float, State )
	DEFINE_PROPERTY_V( int, SamplesNum )
	DEFINE_PROPERTY_VPP( float, flSamples )
	DEFINE_PROPERTY_VPP( float, flNewSamples )
	DEFINE_PROPERTY_VP( float, flConfidence )
	DEFINE_PROPERTY_VP( float, flCumulative )
	DEFINE_PROPERTY_VP( float, Temp )
	DEFINE_PROPERTY_VP( float, RandomSample )
	DEFINE_PROPERTY_SP( CvRandState, RandS )
};

/*
standard Kalman filter (in G. Welch' and G. Bishop's notation):

  x(k)=A*x(k-1)+B*u(k)+w(k)  p(w)~N(0,Q)
  z(k)=H*x(k)+v(k),   p(v)~N(0,R)
*/
// typedef struct CvKalman
// {
//     int MP;                     /* number of measurement vector dimensions */
//     int DP;                     /* number of state vector dimensions */
//     int CP;                     /* number of control vector dimensions */
// 
//     /* backward compatibility fields */
// ////#if 1
//     float* PosterState;         /* =state_pre->data.fl */
//     float* PriorState;          /* =state_post->data.fl */
//     float* DynamMatr;           /* =transition_matrix->data.fl */
//     float* MeasurementMatr;     /* =measurement_matrix->data.fl */
//     float* MNCovariance;        /* =measurement_noise_cov->data.fl */
//     float* PNCovariance;        /* =process_noise_cov->data.fl */
//     float* KalmGainMatr;        /* =gain->data.fl */
//     float* PriorErrorCovariance;/* =error_cov_pre->data.fl */
//     float* PosterErrorCovariance;/* =error_cov_post->data.fl */
//     float* Temp1;               /* temp1->data.fl */
//     float* Temp2;               /* temp2->data.fl */
// ////#endif
// 
//     CvMat* state_pre;           /* predicted state (x'(k)):
//                                     x(k)=A*x(k-1)+B*u(k) */
//     CvMat* state_post;          /* corrected state (x(k)):
//                                     x(k)=x'(k)+K(k)*(z(k)-H*x'(k)) */
//     CvMat* transition_matrix;   /* state transition matrix (A) */
//     CvMat* control_matrix;      /* control matrix (B)
//                                    (it is not used if there is no control)*/
//     CvMat* measurement_matrix;  /* measurement matrix (H) */
//     CvMat* process_noise_cov;   /* process noise covariance matrix (Q) */
//     CvMat* measurement_noise_cov; /* measurement noise covariance matrix (R) */
//     CvMat* error_cov_pre;       /* priori error estimate covariance matrix (P'(k)):
//                                     P'(k)=A*P(k-1)*At + Q)*/
//     CvMat* gain;                /* Kalman gain matrix (K(k)):
//                                     K(k)=P'(k)*Ht*inv(H*P'(k)*Ht+R)*/
//     CvMat* error_cov_post;      /* posteriori error estimate covariance matrix (P(k)):
//                                     P(k)=(I-K(k)*H)*P'(k) */
//     CvMat* temp1;               /* temporary matrices */
//     CvMat* temp2;
//     CvMat* temp3;
//     CvMat* temp4;
//     CvMat* temp5;
// }
// CvKalman;
DEFINE_STRUCT( CvKalman )
{STRUCT_BASIC( CvKalman )
	DEFINE_PROPERTY_V( int, MP )
	DEFINE_PROPERTY_V( int, DP )
	DEFINE_PROPERTY_V( int, CP )
	DEFINE_PROPERTY_VP( float, PosterState )
	DEFINE_PROPERTY_VP( float, PriorState )
	DEFINE_PROPERTY_VP( float, DynamMatr )
	DEFINE_PROPERTY_VP( float, MeasurementMatr )
	DEFINE_PROPERTY_VP( float, MNCovariance )
	DEFINE_PROPERTY_VP( float, PNCovariance )
	DEFINE_PROPERTY_VP( float, KalmGainMatr )
	DEFINE_PROPERTY_VP( float, PriorErrorCovariance )
	DEFINE_PROPERTY_VP( float, PosterErrorCovariance )
	DEFINE_PROPERTY_VP( float, Temp1 )
	DEFINE_PROPERTY_VP( float, Temp2 )
	DEFINE_PROPERTY_SP( CvMat, state_pre )
	DEFINE_PROPERTY_SP( CvMat, state_post )
	DEFINE_PROPERTY_SP( CvMat, transition_matrix )
	DEFINE_PROPERTY_SP( CvMat, control_matrix )
	DEFINE_PROPERTY_SP( CvMat, measurement_matrix )
	DEFINE_PROPERTY_SP( CvMat, process_noise_cov )
	DEFINE_PROPERTY_SP( CvMat, measurement_noise_cov )
	DEFINE_PROPERTY_SP( CvMat, error_cov_pre )
	DEFINE_PROPERTY_SP( CvMat, gain )
	DEFINE_PROPERTY_SP( CvMat, error_cov_post )
	DEFINE_PROPERTY_SP( CvMat, temp1 )
	DEFINE_PROPERTY_SP( CvMat, temp2 )
	DEFINE_PROPERTY_SP( CvMat, temp3 )
	DEFINE_PROPERTY_SP( CvMat, temp4 )
	DEFINE_PROPERTY_SP( CvMat, temp5 )
};


/*********************** Haar-like Object Detection structures **************************/
// #define CV_HAAR_MAGIC_VAL    0x42500000
#pragma push_macro( "CV_HAAR_MAGIC_VAL" )
#undef CV_HAAR_MAGIC_VAL
static const int CV_HAAR_MAGIC_VAL
#pragma pop_macro( "CV_HAAR_MAGIC_VAL" )
	= CV_HAAR_MAGIC_VAL;
// #define CV_TYPE_NAME_HAAR    "opencv-haar-classifier"
#pragma push_macro( "CV_TYPE_NAME_HAAR" )
#undef CV_TYPE_NAME_HAAR
static const String^ CV_TYPE_NAME_HAAR
#pragma pop_macro( "CV_TYPE_NAME_HAAR" )
	= CV_TYPE_NAME_HAAR;

// #define CV_IS_HAAR_CLASSIFIER( haar )                                                    \
//     ((haar) != NULL &&                                                                   \
//     (((const CvHaarClassifierCascade*)(haar))->flags & CV_MAGIC_MASK)==CV_HAAR_MAGIC_VAL)
// Unsupport : CV_IS_HAAR_CLASSIFIER

// #define CV_HAAR_FEATURE_MAX  3
#pragma push_macro( "CV_HAAR_FEATURE_MAX" )
#undef CV_HAAR_FEATURE_MAX
static const int CV_HAAR_FEATURE_MAX
#pragma pop_macro( "CV_HAAR_FEATURE_MAX" )
	= CV_HAAR_FEATURE_MAX;

// typedef struct CvHaarFeature
// {
//     int  tilted;
//     struct
//     {
//         CvRect r;
//         float weight;
//     } rect[CV_HAAR_FEATURE_MAX];
// }
// CvHaarFeature;
DEFINE_STRUCT( CvHaarFeature_RECT )
{
	CvHaarFeature_RECT( UNAME(CvHaarFeature)* Src, int Index ) : StructBase( Src, 0, false )
	{
		mIndex = Index;
	}

	DEFINE_ACCESSMETHOD( CvHaarFeature )
	DEFINE_PROPERTY_S_CORE( , this->BasePtr->rect[ mIndex ].r, CvRect, r )
	DEFINE_PROPERTY_V_CORE( , this->BasePtr->rect[ mIndex ].weight, float, weight )

private:
	int		mIndex;
};
DEFINE_STRUCT( CvHaarFeature )
{STRUCT_BASIC( CvHaarFeature )
	DEFINE_PROPERTY_V( int, tilted )
DEFINE_PROPERTY_CORE_S( , MNAME(CvHaarFeature_RECT), rect, 1,
	{ /* �������̏��� */
		if( _rect == nullptr ) { _rect = gcnew array<MNAME(CvHaarFeature_RECT)^>( CV_HAAR_FEATURE_MAX ); }
		if( _rect[ Index ] == nullptr ) { _rect[ Index ] = gcnew MNAME(CvHaarFeature_RECT)( this->BasePtr, Index ); }
		return _rect[ Index ];
	},
	{ /* �擾���̏��� */
		return Get_rect( Index );
	},
	{ /* ������̏��� */
		throw gcnew System::NotImplementedException( "�������O�����\���̃f�[�^�ւ̑���̓T�|�[�g����Ă��܂���B" );
	} )
};

// typedef struct CvHaarClassifier
// {
//     int count;
//     CvHaarFeature* haar_feature;
//     float* threshold;
//     int* left;
//     int* right;
//     float* alpha;
// }
// CvHaarClassifier;
DEFINE_STRUCT( CvHaarClassifier )
{STRUCT_BASIC( CvHaarClassifier )
	DEFINE_PROPERTY_V( int, count )
	DEFINE_PROPERTY_SP( CvHaarFeature, haar_feature )
	DEFINE_PROPERTY_VP( float, threshold )
	DEFINE_PROPERTY_VP( int, left )
	DEFINE_PROPERTY_VP( int, right )
	DEFINE_PROPERTY_VP( float, alpha )
};

// typedef struct CvHaarStageClassifier
// {
//     int  count;
//     float threshold;
//     CvHaarClassifier* classifier;
// 
//     int next;
//     int child;
//     int parent;
// }
// CvHaarStageClassifier;
DEFINE_STRUCT( CvHaarStageClassifier )
{STRUCT_BASIC( CvHaarStageClassifier )
	DEFINE_PROPERTY_V( int, count )
	DEFINE_PROPERTY_V( float, threshold )
	DEFINE_PROPERTY_SP( CvHaarClassifier, classifier )
	DEFINE_PROPERTY_V( int, next )
	DEFINE_PROPERTY_V( int, child )
	DEFINE_PROPERTY_V( int, parent )
};

// typedef struct CvHidHaarClassifierCascade CvHidHaarClassifierCascade;
DEFINE_HANDLE( CvHidHaarClassifierCascade )

// typedef struct CvHaarClassifierCascade
// {
//     int  flags;
//     int  count;
//     CvSize orig_window_size;
//     CvSize real_window_size;
//     double scale;
//     CvHaarStageClassifier* stage_classifier;
//     CvHidHaarClassifierCascade* hid_cascade;
// }
// CvHaarClassifierCascade;
DEFINE_STRUCT( CvHaarClassifierCascade )
{STRUCT_BASIC( CvHaarClassifierCascade )
	DEFINE_PROPERTY_V( int, flags )
	DEFINE_PROPERTY_V( int, count )
	DEFINE_PROPERTY_S( CvSize, orig_window_size )
	DEFINE_PROPERTY_S( CvSize, real_window_size )
	DEFINE_PROPERTY_V( double, scale )
	DEFINE_PROPERTY_SP( CvHaarStageClassifier, stage_classifier )
	DEFINE_PROPERTY_SP( CvHidHaarClassifierCascade, hid_cascade )
};

// typedef struct CvAvgComp
// {
//     CvRect rect;
//     int neighbors;
// }
// CvAvgComp;
DEFINE_STRUCT( CvAvgComp )
{STRUCT_BASIC( CvAvgComp )
	DEFINE_PROPERTY_S( CvRect, rect )
	DEFINE_PROPERTY_V( int, neighbors )
};

////#endif /*_CVTYPES_H_*/

/* End of file. */
