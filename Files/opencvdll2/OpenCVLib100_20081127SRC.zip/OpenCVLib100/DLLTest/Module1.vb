﻿Option Explicit On
Option Strict On

Imports ManagedOpenCV

Module Module1

    Sub Main()

        Trace.Listeners.Add(New TextWriterTraceListener(System.Console.Out))

        Debug.Print("CV_VERSION   : {0}", CV_VERSION)
        Debug.Print("Install Path : {0}", GetOpenCVInstallDirectory)

    End Sub

End Module
