/*M///////////////////////////////////////////////////////////////////////////////////////
//
//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
//
//  By downloading, copying, installing or using the software you agree to this license.
//  If you do not agree to this license, do not download, install,
//  copy or use the software.
//
//
//                        Intel License Agreement
//                For Open Source Computer Vision Library
//
// Copyright (C) 2000, Intel Corporation, all rights reserved.
// Third party copyrights are property of their respective owners.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistribution's of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//   * Redistribution's in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//   * The name of Intel Corporation may not be used to endorse or promote products
//     derived from this software without specific prior written permission.
//
// This software is provided by the copyright holders and contributors "as is" and
// any express or implied warranties, including, but not limited to, the implied
// warranties of merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the Intel Corporation or contributors be liable for any direct,
// indirect, incidental, special, exemplary, or consequential damages
// (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused
// and on any theory of liability, whether in contract, strict liability,
// or tort (including negligence or otherwise) arising in any way out of
// the use of this software, even if advised of the possibility of such damage.
//
//M*/

////#ifndef __CVCAM_H__
////#define __CVCAM_H__

////#ifdef __cplusplus
////#define CVCAM_EXTERN_C extern "C" 
////extern "C" {
////#else
////#define CVCAM_EXTERN_C
////#endif /* __cplusplus */


////#ifdef CVCAM_EXPORTS
////#define CVCAM_API CVCAM_EXTERN_C __declspec(dllexport)
////#else
////#define CVCAM_API CVCAM_EXTERN_C
////#endif /* CVCAM_DLLEXPORT */

/* Returns the actual number of currently available cameras */
// CVCAM_API int cvcamGetCamerasCount();

/* get/set the property of the camera. returns 0 if the property is not supported */
// CVCAM_API int cvcamGetProperty(int camera, const char* property, void* value);
DEFINE_FUNCTION( V(int), cvcamGetProperty, 3( V(int,camera), T(const,property), P(void*,value) ) ) 
// CVCAM_API int cvcamSetProperty(int camera, const char* property, void* value);
DEFINE_FUNCTION( V(int), cvcamSetProperty, 3( V(int,camera), T(const,property), P(void*,value) ) ) 

/* gets all property names. the actual number of properties is returned. */
// CVCAM_API int cvcamGetPropertiesList(int camera, const char** properties, int count);
DEFINE_FUNCTION( V(int), cvcamGetPropertiesList, 3( V(int,camera), TP(const,properties), V(int,count) ) ) 

// CVCAM_API int cvcamBuildStereo(void); 
DEFINE_FUNCTION( V(int), cvcamBuildStereo, 0() ) 

/* Prepares the currently enabled cameras for work */
// CVCAM_API int cvcamInit(void);
DEFINE_FUNCTION( V(int), cvcamInit, 0() ) 

/* Start the video */
// CVCAM_API int cvcamStart(void);
DEFINE_FUNCTION( V(int), cvcamStart, 0() ) 

/* Stop the video */
// CVCAM_API int cvcamStop(void);
DEFINE_FUNCTION( V(int), cvcamStop, 0() ) 

/* Pause the video; should be used for preventing data changes during frame reading 
    using "frame" and other properties */
// CVCAM_API int cvcamPause(void);
DEFINE_FUNCTION( V(int), cvcamPause, 0() ) 

/* Resume the video */
// CVCAM_API int cvcamResume(void);
DEFINE_FUNCTION( V(int), cvcamResume, 0() ) 

/* Frees all resources */
// CVCAM_API int cvcamExit(void);
DEFINE_FUNCTION( V(int), cvcamExit, 0() ) 

/*Pops up a camera(s) selection dialog
Return value - number of cameras selected (0,1 or 2);
Argument: an array of selected cameras numbers
NULL if none selected. Should be released with free() when not needed.
if NULL passed, not used.
*/
// CVCAM_API int cvcamSelectCamera(int** out);
DEFINE_FUNCTION( V(int), cvcamSelectCamera, 1( P(int**,out) ) ) 

/*Plays a specified avi file into a specified window
if file is NULL, file browser is opened. if window is 0,
it is created. width and height mean output size's 0 means
those of avi file are used. __cdecl (*callback)(IplImage*) would be
called on every frame. NULL means no callback*/
// CVCAM_API int cvcamPlayAVI(const char* file, 
//                            void* window, 
//                            int width, 
//                            int height,
//                            void* callback); 
DEFINE_FUNCTION( V(int), cvcamPlayAVI, 5( T(const,file), P(void*,window), V(int,width), V(int,height), P(void*,callback) ) ) 


/*Advanced API for dealing with AVI files*/

// typedef unsigned int cvcamAVIFILE;
// Unsupport : cvcamAVIFILE


/*Opens a given file or pops up a dialog if file is NULL
returns a handle to the file opened for success or -1 for failure*/
// CVCAM_API cvcamAVIFILE cvcamAVIOpenFile(char* file);
DEFINE_FUNCTION( V(unsigned int), cvcamAVIOpenFile, 1( VP(char,file) ) ) 
DEFINE_FUNCTION( V(unsigned int), cvcamAVIOpenFile, 1( P(char*,file) ) ) 

/*The next functions just do what they say and return 0
for success, anything other for failure*/

// CVCAM_API int cvcamAVICloseFile(cvcamAVIFILE file);
DEFINE_FUNCTION( V(int), cvcamAVICloseFile, 1( V(unsigned int,file) ) ) 

// CVCAM_API int cvcamAVISetWindow(cvcamAVIFILE file, void* window);
DEFINE_FUNCTION( V(int), cvcamAVISetWindow, 2( V(unsigned int,file), P(void*,window) ) ) 

// CVCAM_API int cvcamAVISetCallback(cvcamAVIFILE file, void* callback);
DEFINE_FUNCTION( V(int), cvcamAVISetCallback, 2( V(unsigned int,file), P(void*,callback) ) ) 

// CVCAM_API int cvcamAVISetSize(cvcamAVIFILE file, int width, int height);
DEFINE_FUNCTION( V(int), cvcamAVISetSize, 3( V(unsigned int,file), V(int,width), V(int,height) ) ) 

// CVCAM_API int cvcamAVIRun(cvcamAVIFILE file);
DEFINE_FUNCTION( V(int), cvcamAVIRun, 1( V(unsigned int,file) ) ) 

// CVCAM_API int cvcamAVIStop(cvcamAVIFILE file);
DEFINE_FUNCTION( V(int), cvcamAVIStop, 1( V(unsigned int,file) ) ) 

// CVCAM_API int cvcamAVIPause(cvcamAVIFILE file);
DEFINE_FUNCTION( V(int), cvcamAVIPause, 1( V(unsigned int,file) ) ) 

// CVCAM_API int cvcamAVIResume(cvcamAVIFILE file);
DEFINE_FUNCTION( V(int), cvcamAVIResume, 1( V(unsigned int,file) ) ) 

// CVCAM_API int cvcamAVIWaitCompletion(cvcamAVIFILE file);
DEFINE_FUNCTION( V(int), cvcamAVIWaitCompletion, 1( V(unsigned int,file) ) ) 

// CVCAM_API int cvcamAVIIsRunning(cvcamAVIFILE file);
DEFINE_FUNCTION( V(int), cvcamAVIIsRunning, 1( V(unsigned int,file) ) ) 

// static const char CVCAM_PROP_ENABLE[] = "enable";
DEFINE_GLOBAL_TR( CVCAM_PROP_ENABLE )
// static const char CVCAM_PROP_RENDER[] = "render";
DEFINE_GLOBAL_TR( CVCAM_PROP_RENDER )
// static const char CVCAM_PROP_WINDOW[] = "window";
DEFINE_GLOBAL_TR( CVCAM_PROP_WINDOW )
// static const char CVCAM_PROP_CALLBACK[] = "callback";
DEFINE_GLOBAL_TR( CVCAM_PROP_CALLBACK )
// static const char CVCAM_DESCRIPTION[] = "description";
DEFINE_GLOBAL_TR( CVCAM_DESCRIPTION )
// static const char CVCAM_VIDEOFORMAT[] = "video_pp";
DEFINE_GLOBAL_TR( CVCAM_VIDEOFORMAT )
// static const char CVCAM_CAMERAPROPS[] = "camera_pp";
DEFINE_GLOBAL_TR( CVCAM_CAMERAPROPS )
// static const char CVCAM_RNDWIDTH[] = "rendering_width";
DEFINE_GLOBAL_TR( CVCAM_RNDWIDTH )
// static const char CVCAM_RNDHEIGHT[] = "rendering_height";
DEFINE_GLOBAL_TR( CVCAM_RNDHEIGHT )
// static const char CVCAM_SRCWIDTH[] = "source_width";
DEFINE_GLOBAL_TR( CVCAM_SRCWIDTH )
// static const char CVCAM_SRCHEIGHT[] = "source_height";
DEFINE_GLOBAL_TR( CVCAM_SRCHEIGHT )
// static const char CVCAM_STEREO_CALLBACK[] = "stereo_callback";
DEFINE_GLOBAL_TR( CVCAM_STEREO_CALLBACK )
// static const char CVCAM_STEREO3_CALLBACK[] = "stereo3_callback";
DEFINE_GLOBAL_TR( CVCAM_STEREO3_CALLBACK )
// static const char CVCAM_STEREO4_CALLBACK[] = "stereo4_callback";
DEFINE_GLOBAL_TR( CVCAM_STEREO4_CALLBACK )
// static const char CVCAM_PROP_SETFORMAT[] = "set_video_format";
DEFINE_GLOBAL_TR( CVCAM_PROP_SETFORMAT )
// static const char CVCAM_PROP_RAW[] = "raw_image";
DEFINE_GLOBAL_TR( CVCAM_PROP_RAW )
// static const char CVCAM_PROP_TIME_FORMAT[] = "time_format";
DEFINE_GLOBAL_TR( CVCAM_PROP_TIME_FORMAT )
// static const char CVCAM_PROP_DURATION[] = "duration";
DEFINE_GLOBAL_TR( CVCAM_PROP_DURATION )
// static const char CVCAM_PROP_POSITION[] = "current_position";
DEFINE_GLOBAL_TR( CVCAM_PROP_POSITION )

// extern const int FRAMES_FORMAT ;
DEFINE_GLOBAL_VR( int, FRAMES_FORMAT )
// extern const int TIME_FORMAT ;
DEFINE_GLOBAL_VR( int, TIME_FORMAT )

// typedef struct
// {
//     char DeviceDescription[100];
//     char device[100];
//     int  channel;
//     char ChannelDescription[100];
//     int  maxwidth;
//     int  maxheight;
//     int  minwidth;
//     int  minheight;
// }CameraDescription;
DEFINE_STRUCT( CameraDescription )
{STRUCT_BASIC( CameraDescription )
	DEFINE_PROPERTY_VA( char, DeviceDescription, 100 )
	DEFINE_PROPERTY_VA( char, device, 100 )
	DEFINE_PROPERTY_V( int, channel )
	DEFINE_PROPERTY_VA( char, ChannelDescription, 100 )
	DEFINE_PROPERTY_V( int, maxwidth )
	DEFINE_PROPERTY_V( int, maxheight )
	DEFINE_PROPERTY_V( int, minwidth )
	DEFINE_PROPERTY_V( int, minheight )
};

// typedef struct
// {
//     int width;
//     int height;
//     double framerate;
// }VidFormat;
DEFINE_STRUCT( VidFormat )
{STRUCT_BASIC( VidFormat )
	DEFINE_PROPERTY_V( int, width )
	DEFINE_PROPERTY_V( int, height )
	DEFINE_PROPERTY_V( double, framerate )
};


// #define CVCAMTRUE  (void*)1
// Unsupport : CVCAMTRUE
// #define CVCAMFALSE (void*)0
// Unsupport : CVCAMFALSE

// typedef int cvcamWindow;
// Unsupport : cvcamWindow


////#ifdef __cplusplus
////}
////#endif /* __cplusplus */

////#endif //__CVCAM_H__

