/*M///////////////////////////////////////////////////////////////////////////////////////
//
//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
//
//  By downloading, copying, installing or using the software you agree to this license.
//  If you do not agree to this license, do not download, install,
//  copy or use the software.
//
//
//                        Intel License Agreement
//                For Open Source Computer Vision Library
//
// Copyright (C) 2000, Intel Corporation, all rights reserved.
// Third party copyrights are property of their respective owners.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistribution's of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//   * Redistribution's in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//   * The name of Intel Corporation may not be used to endorse or promote products
//     derived from this software without specific prior written permission.
//
// This software is provided by the copyright holders and contributors "as is" and
// any express or implied warranties, including, but not limited to, the implied
// warranties of merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the Intel Corporation or contributors be liable for any direct,
// indirect, incidental, special, exemplary, or consequential damages
// (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused
// and on any theory of liability, whether in contract, strict liability,
// or tort (including negligence or otherwise) arising in any way out of
// the use of this software, even if advised of the possibility of such damage.
//
//M*/


////#ifndef _CV_H_
////#define _CV_H_

////#ifdef __IPL_H__
////#define HAVE_IPL
////#endif

////#ifndef SKIP_INCLUDES
////  #if defined(_CH_)
////    #pragma package <chopencv>
////    #include <chdl.h>
////    LOAD_CHDL(cv)
////  #endif
////#endif

////#include "cxcore.h"
////#include "cvtypes.h"

////#ifdef __cplusplus
////extern "C" {
////#endif

/****************************************************************************************\
*                                    Image Processing                                    *
\****************************************************************************************/

/* Copies source 2D array inside of the larger destination array and
   makes a border of the specified type (IPL_BORDER_*) around the copied area. */
// CVAPI(void) cvCopyMakeBorder( const CvArr* src, CvArr* dst, CvPoint offset,
//                               int bordertype, CvScalar value CV_DEFAULT(cvScalarAll(0)));
DEFINE_FUNCTION( N(void), cvCopyMakeBorder, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), S(CvPoint,offset), V(int,bordertype), S(CvScalar,value) ) ) 
DEFINE_FUNCTION( N(void), cvCopyMakeBorder, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), S(CvPoint,offset), V(int,bordertype) ) ) 

// #define CV_BLUR_NO_SCALE 0
#pragma push_macro( "CV_BLUR_NO_SCALE" )
#undef CV_BLUR_NO_SCALE
static const int CV_BLUR_NO_SCALE
#pragma pop_macro( "CV_BLUR_NO_SCALE" )
	= CV_BLUR_NO_SCALE;
// #define CV_BLUR  1
#pragma push_macro( "CV_BLUR" )
#undef CV_BLUR
static const int CV_BLUR
#pragma pop_macro( "CV_BLUR" )
	= CV_BLUR;
// #define CV_GAUSSIAN  2
#pragma push_macro( "CV_GAUSSIAN" )
#undef CV_GAUSSIAN
static const int CV_GAUSSIAN
#pragma pop_macro( "CV_GAUSSIAN" )
	= CV_GAUSSIAN;
// #define CV_MEDIAN 3
#pragma push_macro( "CV_MEDIAN" )
#undef CV_MEDIAN
static const int CV_MEDIAN
#pragma pop_macro( "CV_MEDIAN" )
	= CV_MEDIAN;
// #define CV_BILATERAL 4
#pragma push_macro( "CV_BILATERAL" )
#undef CV_BILATERAL
static const int CV_BILATERAL
#pragma pop_macro( "CV_BILATERAL" )
	= CV_BILATERAL;

/* Smoothes array (removes noise) */
// CVAPI(void) cvSmooth( const CvArr* src, CvArr* dst,
//                       int smoothtype CV_DEFAULT(CV_GAUSSIAN),
//                       int param1 CV_DEFAULT(3),
//                       int param2 CV_DEFAULT(0),
//                       double param3 CV_DEFAULT(0),
//                       double param4 CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvSmooth, 7( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,smoothtype), V(int,param1), V(int,param2), V(double,param3), V(double,param4) ) ) 
DEFINE_FUNCTION( N(void), cvSmooth, 6( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,smoothtype), V(int,param1), V(int,param2), V(double,param3) ) ) 
DEFINE_FUNCTION( N(void), cvSmooth, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,smoothtype), V(int,param1), V(int,param2) ) ) 
DEFINE_FUNCTION( N(void), cvSmooth, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,smoothtype), V(int,param1) ) ) 
DEFINE_FUNCTION( N(void), cvSmooth, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,smoothtype) ) ) 
DEFINE_FUNCTION( N(void), cvSmooth, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* Convolves the image with the kernel */
// CVAPI(void) cvFilter2D( const CvArr* src, CvArr* dst, const CvMat* kernel,
//                         CvPoint anchor CV_DEFAULT(cvPoint(-1,-1)));
DEFINE_FUNCTION( N(void), cvFilter2D, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,kernel), S(CvPoint,anchor) ) ) 
DEFINE_FUNCTION( N(void), cvFilter2D, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,kernel) ) ) 

/* Finds integral image: SUM(X,Y) = sum(x<X,y<Y)I(x,y) */
// CVAPI(void) cvIntegral( const CvArr* image, CvArr* sum,
//                        CvArr* sqsum CV_DEFAULT(NULL),
//                        CvArr* tilted_sum CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvIntegral, 4( MP(UMemory,CvArr,image), MP(UMemory,CvArr,sum), MP(UMemory,CvArr,sqsum), MP(UMemory,CvArr,tilted_sum) ) ) 
DEFINE_FUNCTION( N(void), cvIntegral, 3( MP(UMemory,CvArr,image), MP(UMemory,CvArr,sum), MP(UMemory,CvArr,sqsum) ) ) 
DEFINE_FUNCTION( N(void), cvIntegral, 2( MP(UMemory,CvArr,image), MP(UMemory,CvArr,sum) ) ) 

/*
   Smoothes the input image with gaussian kernel and then down-samples it.
   dst_width = floor(src_width/2)[+1],
   dst_height = floor(src_height/2)[+1]
*/
// CVAPI(void)  cvPyrDown( const CvArr* src, CvArr* dst,
//                         int filter CV_DEFAULT(CV_GAUSSIAN_5x5) );
DEFINE_FUNCTION( N(void), cvPyrDown, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,filter) ) ) 
DEFINE_FUNCTION( N(void), cvPyrDown, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* 
   Up-samples image and smoothes the result with gaussian kernel.
   dst_width = src_width*2,
   dst_height = src_height*2
*/
// CVAPI(void)  cvPyrUp( const CvArr* src, CvArr* dst,
//                       int filter CV_DEFAULT(CV_GAUSSIAN_5x5) );
DEFINE_FUNCTION( N(void), cvPyrUp, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,filter) ) ) 
DEFINE_FUNCTION( N(void), cvPyrUp, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 


/* Builds the whole pyramid at once. Output array of CvMat headers (levels[*])
   is initialized with the headers of subsequent pyramid levels */
/*CVAPI  void  cvCalcPyramid( const CvArr* src, CvArr* container,
                              CvMat* levels, int level_count,
                              int filter CV_DEFAULT(CV_GAUSSIAN_5x5) );*/


/* Splits color or grayscale image into multiple connected components
   of nearly the same color/brightness using modification of Burt algorithm.
   comp with contain a pointer to sequence (CvSeq)
   of connected components (CvConnectedComp) */
// CVAPI(void) cvPyrSegmentation( IplImage* src, IplImage* dst,
//                               CvMemStorage* storage, CvSeq** comp,
//                               int level, double threshold1,
//                               double threshold2 );
DEFINE_FUNCTION( N(void), cvPyrSegmentation, 7( SP(IplImage,src), SP(IplImage,dst), SP(CvMemStorage,storage), SPP(CvSeq,comp), V(int,level), V(double,threshold1), V(double,threshold2) ) ) 

/* Filters image using meanshift algorithm */
// CVAPI(void) cvPyrMeanShiftFiltering( const CvArr* src, CvArr* dst, 
//     double sp, double sr, int max_level CV_DEFAULT(1),
//     CvTermCriteria termcrit CV_DEFAULT(cvTermCriteria(CV_TERMCRIT_ITER+CV_TERMCRIT_EPS,5,1)));
DEFINE_FUNCTION( N(void), cvPyrMeanShiftFiltering, 6( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,sp), V(double,sr), V(int,max_level), S(CvTermCriteria,termcrit) ) ) 
DEFINE_FUNCTION( N(void), cvPyrMeanShiftFiltering, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,sp), V(double,sr), V(int,max_level) ) ) 
DEFINE_FUNCTION( N(void), cvPyrMeanShiftFiltering, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,sp), V(double,sr) ) ) 

/* Segments image using seed "markers" */
// CVAPI(void) cvWatershed( const CvArr* image, CvArr* markers );
DEFINE_FUNCTION( N(void), cvWatershed, 2( MP(UMemory,CvArr,image), MP(UMemory,CvArr,markers) ) ) 

// #define CV_INPAINT_NS      0
#pragma push_macro( "CV_INPAINT_NS" )
#undef CV_INPAINT_NS
static const int CV_INPAINT_NS
#pragma pop_macro( "CV_INPAINT_NS" )
	= CV_INPAINT_NS;
// #define CV_INPAINT_TELEA   1
#pragma push_macro( "CV_INPAINT_TELEA" )
#undef CV_INPAINT_TELEA
static const int CV_INPAINT_TELEA
#pragma pop_macro( "CV_INPAINT_TELEA" )
	= CV_INPAINT_TELEA;

/* Inpaints the selected region in the image */
// CVAPI(void) cvInpaint( const CvArr* src, const CvArr* inpaint_mask,
//                        CvArr* dst, double inpaintRange, int flags );
DEFINE_FUNCTION( N(void), cvInpaint, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,inpaint_mask), MP(UMemory,CvArr,dst), V(double,inpaintRange), V(int,flags) ) ) 

// #define CV_SCHARR -1
#pragma push_macro( "CV_SCHARR" )
#undef CV_SCHARR
static const int CV_SCHARR
#pragma pop_macro( "CV_SCHARR" )
	= CV_SCHARR;
// #define CV_MAX_SOBEL_KSIZE 7
#pragma push_macro( "CV_MAX_SOBEL_KSIZE" )
#undef CV_MAX_SOBEL_KSIZE
static const int CV_MAX_SOBEL_KSIZE
#pragma pop_macro( "CV_MAX_SOBEL_KSIZE" )
	= CV_MAX_SOBEL_KSIZE;

/* Calculates an image derivative using generalized Sobel
   (aperture_size = 1,3,5,7) or Scharr (aperture_size = -1) operator.
   Scharr can be used only for the first dx or dy derivative */
// CVAPI(void) cvSobel( const CvArr* src, CvArr* dst,
//                     int xorder, int yorder,
//                     int aperture_size CV_DEFAULT(3));
DEFINE_FUNCTION( N(void), cvSobel, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,xorder), V(int,yorder), V(int,aperture_size) ) ) 
DEFINE_FUNCTION( N(void), cvSobel, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,xorder), V(int,yorder) ) ) 

/* Calculates the image Laplacian: (d2/dx + d2/dy)I */
// CVAPI(void) cvLaplace( const CvArr* src, CvArr* dst,
//                       int aperture_size CV_DEFAULT(3) );
DEFINE_FUNCTION( N(void), cvLaplace, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,aperture_size) ) ) 
DEFINE_FUNCTION( N(void), cvLaplace, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* Constants for color conversion */
// #define  CV_BGR2BGRA    0
#pragma push_macro( "CV_BGR2BGRA" )
#undef CV_BGR2BGRA
static const int CV_BGR2BGRA
#pragma pop_macro( "CV_BGR2BGRA" )
	= CV_BGR2BGRA;
// #define  CV_RGB2RGBA    CV_BGR2BGRA
#pragma push_macro( "CV_RGB2RGBA" )
#undef CV_RGB2RGBA
static const int CV_RGB2RGBA
#pragma pop_macro( "CV_RGB2RGBA" )
	= CV_RGB2RGBA;

// #define  CV_BGRA2BGR    1
#pragma push_macro( "CV_BGRA2BGR" )
#undef CV_BGRA2BGR
static const int CV_BGRA2BGR
#pragma pop_macro( "CV_BGRA2BGR" )
	= CV_BGRA2BGR;
// #define  CV_RGBA2RGB    CV_BGRA2BGR
#pragma push_macro( "CV_RGBA2RGB" )
#undef CV_RGBA2RGB
static const int CV_RGBA2RGB
#pragma pop_macro( "CV_RGBA2RGB" )
	= CV_RGBA2RGB;

// #define  CV_BGR2RGBA    2
#pragma push_macro( "CV_BGR2RGBA" )
#undef CV_BGR2RGBA
static const int CV_BGR2RGBA
#pragma pop_macro( "CV_BGR2RGBA" )
	= CV_BGR2RGBA;
// #define  CV_RGB2BGRA    CV_BGR2RGBA
#pragma push_macro( "CV_RGB2BGRA" )
#undef CV_RGB2BGRA
static const int CV_RGB2BGRA
#pragma pop_macro( "CV_RGB2BGRA" )
	= CV_RGB2BGRA;

// #define  CV_RGBA2BGR    3
#pragma push_macro( "CV_RGBA2BGR" )
#undef CV_RGBA2BGR
static const int CV_RGBA2BGR
#pragma pop_macro( "CV_RGBA2BGR" )
	= CV_RGBA2BGR;
// #define  CV_BGRA2RGB    CV_RGBA2BGR
#pragma push_macro( "CV_BGRA2RGB" )
#undef CV_BGRA2RGB
static const int CV_BGRA2RGB
#pragma pop_macro( "CV_BGRA2RGB" )
	= CV_BGRA2RGB;

// #define  CV_BGR2RGB     4
#pragma push_macro( "CV_BGR2RGB" )
#undef CV_BGR2RGB
static const int CV_BGR2RGB
#pragma pop_macro( "CV_BGR2RGB" )
	= CV_BGR2RGB;
// #define  CV_RGB2BGR     CV_BGR2RGB
#pragma push_macro( "CV_RGB2BGR" )
#undef CV_RGB2BGR
static const int CV_RGB2BGR
#pragma pop_macro( "CV_RGB2BGR" )
	= CV_RGB2BGR;

// #define  CV_BGRA2RGBA   5
#pragma push_macro( "CV_BGRA2RGBA" )
#undef CV_BGRA2RGBA
static const int CV_BGRA2RGBA
#pragma pop_macro( "CV_BGRA2RGBA" )
	= CV_BGRA2RGBA;
// #define  CV_RGBA2BGRA   CV_BGRA2RGBA
#pragma push_macro( "CV_RGBA2BGRA" )
#undef CV_RGBA2BGRA
static const int CV_RGBA2BGRA
#pragma pop_macro( "CV_RGBA2BGRA" )
	= CV_RGBA2BGRA;

// #define  CV_BGR2GRAY    6
#pragma push_macro( "CV_BGR2GRAY" )
#undef CV_BGR2GRAY
static const int CV_BGR2GRAY
#pragma pop_macro( "CV_BGR2GRAY" )
	= CV_BGR2GRAY;
// #define  CV_RGB2GRAY    7
#pragma push_macro( "CV_RGB2GRAY" )
#undef CV_RGB2GRAY
static const int CV_RGB2GRAY
#pragma pop_macro( "CV_RGB2GRAY" )
	= CV_RGB2GRAY;
// #define  CV_GRAY2BGR    8
#pragma push_macro( "CV_GRAY2BGR" )
#undef CV_GRAY2BGR
static const int CV_GRAY2BGR
#pragma pop_macro( "CV_GRAY2BGR" )
	= CV_GRAY2BGR;
// #define  CV_GRAY2RGB    CV_GRAY2BGR
#pragma push_macro( "CV_GRAY2RGB" )
#undef CV_GRAY2RGB
static const int CV_GRAY2RGB
#pragma pop_macro( "CV_GRAY2RGB" )
	= CV_GRAY2RGB;
// #define  CV_GRAY2BGRA   9
#pragma push_macro( "CV_GRAY2BGRA" )
#undef CV_GRAY2BGRA
static const int CV_GRAY2BGRA
#pragma pop_macro( "CV_GRAY2BGRA" )
	= CV_GRAY2BGRA;
// #define  CV_GRAY2RGBA   CV_GRAY2BGRA
#pragma push_macro( "CV_GRAY2RGBA" )
#undef CV_GRAY2RGBA
static const int CV_GRAY2RGBA
#pragma pop_macro( "CV_GRAY2RGBA" )
	= CV_GRAY2RGBA;
// #define  CV_BGRA2GRAY   10
#pragma push_macro( "CV_BGRA2GRAY" )
#undef CV_BGRA2GRAY
static const int CV_BGRA2GRAY
#pragma pop_macro( "CV_BGRA2GRAY" )
	= CV_BGRA2GRAY;
// #define  CV_RGBA2GRAY   11
#pragma push_macro( "CV_RGBA2GRAY" )
#undef CV_RGBA2GRAY
static const int CV_RGBA2GRAY
#pragma pop_macro( "CV_RGBA2GRAY" )
	= CV_RGBA2GRAY;

// #define  CV_BGR2BGR565  12
#pragma push_macro( "CV_BGR2BGR565" )
#undef CV_BGR2BGR565
static const int CV_BGR2BGR565
#pragma pop_macro( "CV_BGR2BGR565" )
	= CV_BGR2BGR565;
// #define  CV_RGB2BGR565  13
#pragma push_macro( "CV_RGB2BGR565" )
#undef CV_RGB2BGR565
static const int CV_RGB2BGR565
#pragma pop_macro( "CV_RGB2BGR565" )
	= CV_RGB2BGR565;
// #define  CV_BGR5652BGR  14
#pragma push_macro( "CV_BGR5652BGR" )
#undef CV_BGR5652BGR
static const int CV_BGR5652BGR
#pragma pop_macro( "CV_BGR5652BGR" )
	= CV_BGR5652BGR;
// #define  CV_BGR5652RGB  15
#pragma push_macro( "CV_BGR5652RGB" )
#undef CV_BGR5652RGB
static const int CV_BGR5652RGB
#pragma pop_macro( "CV_BGR5652RGB" )
	= CV_BGR5652RGB;
// #define  CV_BGRA2BGR565 16
#pragma push_macro( "CV_BGRA2BGR565" )
#undef CV_BGRA2BGR565
static const int CV_BGRA2BGR565
#pragma pop_macro( "CV_BGRA2BGR565" )
	= CV_BGRA2BGR565;
// #define  CV_RGBA2BGR565 17
#pragma push_macro( "CV_RGBA2BGR565" )
#undef CV_RGBA2BGR565
static const int CV_RGBA2BGR565
#pragma pop_macro( "CV_RGBA2BGR565" )
	= CV_RGBA2BGR565;
// #define  CV_BGR5652BGRA 18
#pragma push_macro( "CV_BGR5652BGRA" )
#undef CV_BGR5652BGRA
static const int CV_BGR5652BGRA
#pragma pop_macro( "CV_BGR5652BGRA" )
	= CV_BGR5652BGRA;
// #define  CV_BGR5652RGBA 19
#pragma push_macro( "CV_BGR5652RGBA" )
#undef CV_BGR5652RGBA
static const int CV_BGR5652RGBA
#pragma pop_macro( "CV_BGR5652RGBA" )
	= CV_BGR5652RGBA;

// #define  CV_GRAY2BGR565 20
#pragma push_macro( "CV_GRAY2BGR565" )
#undef CV_GRAY2BGR565
static const int CV_GRAY2BGR565
#pragma pop_macro( "CV_GRAY2BGR565" )
	= CV_GRAY2BGR565;
// #define  CV_BGR5652GRAY 21
#pragma push_macro( "CV_BGR5652GRAY" )
#undef CV_BGR5652GRAY
static const int CV_BGR5652GRAY
#pragma pop_macro( "CV_BGR5652GRAY" )
	= CV_BGR5652GRAY;

// #define  CV_BGR2BGR555  22
#pragma push_macro( "CV_BGR2BGR555" )
#undef CV_BGR2BGR555
static const int CV_BGR2BGR555
#pragma pop_macro( "CV_BGR2BGR555" )
	= CV_BGR2BGR555;
// #define  CV_RGB2BGR555  23
#pragma push_macro( "CV_RGB2BGR555" )
#undef CV_RGB2BGR555
static const int CV_RGB2BGR555
#pragma pop_macro( "CV_RGB2BGR555" )
	= CV_RGB2BGR555;
// #define  CV_BGR5552BGR  24
#pragma push_macro( "CV_BGR5552BGR" )
#undef CV_BGR5552BGR
static const int CV_BGR5552BGR
#pragma pop_macro( "CV_BGR5552BGR" )
	= CV_BGR5552BGR;
// #define  CV_BGR5552RGB  25
#pragma push_macro( "CV_BGR5552RGB" )
#undef CV_BGR5552RGB
static const int CV_BGR5552RGB
#pragma pop_macro( "CV_BGR5552RGB" )
	= CV_BGR5552RGB;
// #define  CV_BGRA2BGR555 26
#pragma push_macro( "CV_BGRA2BGR555" )
#undef CV_BGRA2BGR555
static const int CV_BGRA2BGR555
#pragma pop_macro( "CV_BGRA2BGR555" )
	= CV_BGRA2BGR555;
// #define  CV_RGBA2BGR555 27
#pragma push_macro( "CV_RGBA2BGR555" )
#undef CV_RGBA2BGR555
static const int CV_RGBA2BGR555
#pragma pop_macro( "CV_RGBA2BGR555" )
	= CV_RGBA2BGR555;
// #define  CV_BGR5552BGRA 28
#pragma push_macro( "CV_BGR5552BGRA" )
#undef CV_BGR5552BGRA
static const int CV_BGR5552BGRA
#pragma pop_macro( "CV_BGR5552BGRA" )
	= CV_BGR5552BGRA;
// #define  CV_BGR5552RGBA 29
#pragma push_macro( "CV_BGR5552RGBA" )
#undef CV_BGR5552RGBA
static const int CV_BGR5552RGBA
#pragma pop_macro( "CV_BGR5552RGBA" )
	= CV_BGR5552RGBA;

// #define  CV_GRAY2BGR555 30
#pragma push_macro( "CV_GRAY2BGR555" )
#undef CV_GRAY2BGR555
static const int CV_GRAY2BGR555
#pragma pop_macro( "CV_GRAY2BGR555" )
	= CV_GRAY2BGR555;
// #define  CV_BGR5552GRAY 31
#pragma push_macro( "CV_BGR5552GRAY" )
#undef CV_BGR5552GRAY
static const int CV_BGR5552GRAY
#pragma pop_macro( "CV_BGR5552GRAY" )
	= CV_BGR5552GRAY;

// #define  CV_BGR2XYZ     32
#pragma push_macro( "CV_BGR2XYZ" )
#undef CV_BGR2XYZ
static const int CV_BGR2XYZ
#pragma pop_macro( "CV_BGR2XYZ" )
	= CV_BGR2XYZ;
// #define  CV_RGB2XYZ     33
#pragma push_macro( "CV_RGB2XYZ" )
#undef CV_RGB2XYZ
static const int CV_RGB2XYZ
#pragma pop_macro( "CV_RGB2XYZ" )
	= CV_RGB2XYZ;
// #define  CV_XYZ2BGR     34
#pragma push_macro( "CV_XYZ2BGR" )
#undef CV_XYZ2BGR
static const int CV_XYZ2BGR
#pragma pop_macro( "CV_XYZ2BGR" )
	= CV_XYZ2BGR;
// #define  CV_XYZ2RGB     35
#pragma push_macro( "CV_XYZ2RGB" )
#undef CV_XYZ2RGB
static const int CV_XYZ2RGB
#pragma pop_macro( "CV_XYZ2RGB" )
	= CV_XYZ2RGB;

// #define  CV_BGR2YCrCb   36
#pragma push_macro( "CV_BGR2YCrCb" )
#undef CV_BGR2YCrCb
static const int CV_BGR2YCrCb
#pragma pop_macro( "CV_BGR2YCrCb" )
	= CV_BGR2YCrCb;
// #define  CV_RGB2YCrCb   37
#pragma push_macro( "CV_RGB2YCrCb" )
#undef CV_RGB2YCrCb
static const int CV_RGB2YCrCb
#pragma pop_macro( "CV_RGB2YCrCb" )
	= CV_RGB2YCrCb;
// #define  CV_YCrCb2BGR   38
#pragma push_macro( "CV_YCrCb2BGR" )
#undef CV_YCrCb2BGR
static const int CV_YCrCb2BGR
#pragma pop_macro( "CV_YCrCb2BGR" )
	= CV_YCrCb2BGR;
// #define  CV_YCrCb2RGB   39
#pragma push_macro( "CV_YCrCb2RGB" )
#undef CV_YCrCb2RGB
static const int CV_YCrCb2RGB
#pragma pop_macro( "CV_YCrCb2RGB" )
	= CV_YCrCb2RGB;

// #define  CV_BGR2HSV     40
#pragma push_macro( "CV_BGR2HSV" )
#undef CV_BGR2HSV
static const int CV_BGR2HSV
#pragma pop_macro( "CV_BGR2HSV" )
	= CV_BGR2HSV;
// #define  CV_RGB2HSV     41
#pragma push_macro( "CV_RGB2HSV" )
#undef CV_RGB2HSV
static const int CV_RGB2HSV
#pragma pop_macro( "CV_RGB2HSV" )
	= CV_RGB2HSV;

// #define  CV_BGR2Lab     44
#pragma push_macro( "CV_BGR2Lab" )
#undef CV_BGR2Lab
static const int CV_BGR2Lab
#pragma pop_macro( "CV_BGR2Lab" )
	= CV_BGR2Lab;
// #define  CV_RGB2Lab     45
#pragma push_macro( "CV_RGB2Lab" )
#undef CV_RGB2Lab
static const int CV_RGB2Lab
#pragma pop_macro( "CV_RGB2Lab" )
	= CV_RGB2Lab;

// #define  CV_BayerBG2BGR 46
#pragma push_macro( "CV_BayerBG2BGR" )
#undef CV_BayerBG2BGR
static const int CV_BayerBG2BGR
#pragma pop_macro( "CV_BayerBG2BGR" )
	= CV_BayerBG2BGR;
// #define  CV_BayerGB2BGR 47
#pragma push_macro( "CV_BayerGB2BGR" )
#undef CV_BayerGB2BGR
static const int CV_BayerGB2BGR
#pragma pop_macro( "CV_BayerGB2BGR" )
	= CV_BayerGB2BGR;
// #define  CV_BayerRG2BGR 48
#pragma push_macro( "CV_BayerRG2BGR" )
#undef CV_BayerRG2BGR
static const int CV_BayerRG2BGR
#pragma pop_macro( "CV_BayerRG2BGR" )
	= CV_BayerRG2BGR;
// #define  CV_BayerGR2BGR 49
#pragma push_macro( "CV_BayerGR2BGR" )
#undef CV_BayerGR2BGR
static const int CV_BayerGR2BGR
#pragma pop_macro( "CV_BayerGR2BGR" )
	= CV_BayerGR2BGR;

// #define  CV_BayerBG2RGB CV_BayerRG2BGR
#pragma push_macro( "CV_BayerBG2RGB" )
#undef CV_BayerBG2RGB
static const int CV_BayerBG2RGB
#pragma pop_macro( "CV_BayerBG2RGB" )
	= CV_BayerBG2RGB;
// #define  CV_BayerGB2RGB CV_BayerGR2BGR
#pragma push_macro( "CV_BayerGB2RGB" )
#undef CV_BayerGB2RGB
static const int CV_BayerGB2RGB
#pragma pop_macro( "CV_BayerGB2RGB" )
	= CV_BayerGB2RGB;
// #define  CV_BayerRG2RGB CV_BayerBG2BGR
#pragma push_macro( "CV_BayerRG2RGB" )
#undef CV_BayerRG2RGB
static const int CV_BayerRG2RGB
#pragma pop_macro( "CV_BayerRG2RGB" )
	= CV_BayerRG2RGB;
// #define  CV_BayerGR2RGB CV_BayerGB2BGR
#pragma push_macro( "CV_BayerGR2RGB" )
#undef CV_BayerGR2RGB
static const int CV_BayerGR2RGB
#pragma pop_macro( "CV_BayerGR2RGB" )
	= CV_BayerGR2RGB;

// #define  CV_BGR2Luv     50
#pragma push_macro( "CV_BGR2Luv" )
#undef CV_BGR2Luv
static const int CV_BGR2Luv
#pragma pop_macro( "CV_BGR2Luv" )
	= CV_BGR2Luv;
// #define  CV_RGB2Luv     51
#pragma push_macro( "CV_RGB2Luv" )
#undef CV_RGB2Luv
static const int CV_RGB2Luv
#pragma pop_macro( "CV_RGB2Luv" )
	= CV_RGB2Luv;
// #define  CV_BGR2HLS     52
#pragma push_macro( "CV_BGR2HLS" )
#undef CV_BGR2HLS
static const int CV_BGR2HLS
#pragma pop_macro( "CV_BGR2HLS" )
	= CV_BGR2HLS;
// #define  CV_RGB2HLS     53
#pragma push_macro( "CV_RGB2HLS" )
#undef CV_RGB2HLS
static const int CV_RGB2HLS
#pragma pop_macro( "CV_RGB2HLS" )
	= CV_RGB2HLS;

// #define  CV_HSV2BGR     54
#pragma push_macro( "CV_HSV2BGR" )
#undef CV_HSV2BGR
static const int CV_HSV2BGR
#pragma pop_macro( "CV_HSV2BGR" )
	= CV_HSV2BGR;
// #define  CV_HSV2RGB     55
#pragma push_macro( "CV_HSV2RGB" )
#undef CV_HSV2RGB
static const int CV_HSV2RGB
#pragma pop_macro( "CV_HSV2RGB" )
	= CV_HSV2RGB;

// #define  CV_Lab2BGR     56
#pragma push_macro( "CV_Lab2BGR" )
#undef CV_Lab2BGR
static const int CV_Lab2BGR
#pragma pop_macro( "CV_Lab2BGR" )
	= CV_Lab2BGR;
// #define  CV_Lab2RGB     57
#pragma push_macro( "CV_Lab2RGB" )
#undef CV_Lab2RGB
static const int CV_Lab2RGB
#pragma pop_macro( "CV_Lab2RGB" )
	= CV_Lab2RGB;
// #define  CV_Luv2BGR     58
#pragma push_macro( "CV_Luv2BGR" )
#undef CV_Luv2BGR
static const int CV_Luv2BGR
#pragma pop_macro( "CV_Luv2BGR" )
	= CV_Luv2BGR;
// #define  CV_Luv2RGB     59
#pragma push_macro( "CV_Luv2RGB" )
#undef CV_Luv2RGB
static const int CV_Luv2RGB
#pragma pop_macro( "CV_Luv2RGB" )
	= CV_Luv2RGB;
// #define  CV_HLS2BGR     60
#pragma push_macro( "CV_HLS2BGR" )
#undef CV_HLS2BGR
static const int CV_HLS2BGR
#pragma pop_macro( "CV_HLS2BGR" )
	= CV_HLS2BGR;
// #define  CV_HLS2RGB     61
#pragma push_macro( "CV_HLS2RGB" )
#undef CV_HLS2RGB
static const int CV_HLS2RGB
#pragma pop_macro( "CV_HLS2RGB" )
	= CV_HLS2RGB;

// #define  CV_COLORCVT_MAX  100
#pragma push_macro( "CV_COLORCVT_MAX" )
#undef CV_COLORCVT_MAX
static const int CV_COLORCVT_MAX
#pragma pop_macro( "CV_COLORCVT_MAX" )
	= CV_COLORCVT_MAX;

/* Converts input array pixels from one color space to another */
// CVAPI(void)  cvCvtColor( const CvArr* src, CvArr* dst, int code );
DEFINE_FUNCTION( N(void), cvCvtColor, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,code) ) ) 

// #define  CV_INTER_NN        0
#pragma push_macro( "CV_INTER_NN" )
#undef CV_INTER_NN
static const int CV_INTER_NN
#pragma pop_macro( "CV_INTER_NN" )
	= CV_INTER_NN;
// #define  CV_INTER_LINEAR    1
#pragma push_macro( "CV_INTER_LINEAR" )
#undef CV_INTER_LINEAR
static const int CV_INTER_LINEAR
#pragma pop_macro( "CV_INTER_LINEAR" )
	= CV_INTER_LINEAR;
// #define  CV_INTER_CUBIC     2
#pragma push_macro( "CV_INTER_CUBIC" )
#undef CV_INTER_CUBIC
static const int CV_INTER_CUBIC
#pragma pop_macro( "CV_INTER_CUBIC" )
	= CV_INTER_CUBIC;
// #define  CV_INTER_AREA      3
#pragma push_macro( "CV_INTER_AREA" )
#undef CV_INTER_AREA
static const int CV_INTER_AREA
#pragma pop_macro( "CV_INTER_AREA" )
	= CV_INTER_AREA;

// #define  CV_WARP_FILL_OUTLIERS 8
#pragma push_macro( "CV_WARP_FILL_OUTLIERS" )
#undef CV_WARP_FILL_OUTLIERS
static const int CV_WARP_FILL_OUTLIERS
#pragma pop_macro( "CV_WARP_FILL_OUTLIERS" )
	= CV_WARP_FILL_OUTLIERS;
// #define  CV_WARP_INVERSE_MAP  16
#pragma push_macro( "CV_WARP_INVERSE_MAP" )
#undef CV_WARP_INVERSE_MAP
static const int CV_WARP_INVERSE_MAP
#pragma pop_macro( "CV_WARP_INVERSE_MAP" )
	= CV_WARP_INVERSE_MAP;

/* Resizes image (input array is resized to fit the destination array) */
// CVAPI(void)  cvResize( const CvArr* src, CvArr* dst,
//                        int interpolation CV_DEFAULT( CV_INTER_LINEAR ));
DEFINE_FUNCTION( N(void), cvResize, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,interpolation) ) ) 
DEFINE_FUNCTION( N(void), cvResize, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* Warps image with affine transform */ 
// CVAPI(void)  cvWarpAffine( const CvArr* src, CvArr* dst, const CvMat* map_matrix,
//                            int flags CV_DEFAULT(CV_INTER_LINEAR+CV_WARP_FILL_OUTLIERS),
//                            CvScalar fillval CV_DEFAULT(cvScalarAll(0)) );
DEFINE_FUNCTION( N(void), cvWarpAffine, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,map_matrix), V(int,flags), S(CvScalar,fillval) ) ) 
DEFINE_FUNCTION( N(void), cvWarpAffine, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,map_matrix), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvWarpAffine, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,map_matrix) ) ) 

/* Computes affine transform matrix for mapping src[i] to dst[i] (i=0,1,2) */
// CVAPI(CvMat*) cvGetAffineTransform( const CvPoint2D32f * src, 
//                                     const CvPoint2D32f * dst, 
//                                     CvMat * map_matrix );
DEFINE_FUNCTION( SP(CvMat), cvGetAffineTransform, 3( SP(CvPoint2D32f,src), SP(CvPoint2D32f,dst), SP(CvMat,map_matrix) ) ) 

/* Computes rotation_matrix matrix */
// CVAPI(CvMat*)  cv2DRotationMatrix( CvPoint2D32f center, double angle,
//                                    double scale, CvMat* map_matrix );
DEFINE_FUNCTION( SP(CvMat), cv2DRotationMatrix, 4( S(CvPoint2D32f,center), V(double,angle), V(double,scale), SP(CvMat,map_matrix) ) ) 

/* Warps image with perspective (projective) transform */
// CVAPI(void)  cvWarpPerspective( const CvArr* src, CvArr* dst, const CvMat* map_matrix,
//                                 int flags CV_DEFAULT(CV_INTER_LINEAR+CV_WARP_FILL_OUTLIERS),
//                                 CvScalar fillval CV_DEFAULT(cvScalarAll(0)) );
DEFINE_FUNCTION( N(void), cvWarpPerspective, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,map_matrix), V(int,flags), S(CvScalar,fillval) ) ) 
DEFINE_FUNCTION( N(void), cvWarpPerspective, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,map_matrix), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvWarpPerspective, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,map_matrix) ) ) 

/* Computes perspective transform matrix for mapping src[i] to dst[i] (i=0,1,2,3) */
// CVAPI(CvMat*) cvGetPerspectiveTransform( const CvPoint2D32f* src,
//                                          const CvPoint2D32f* dst,
//                                          CvMat* map_matrix );
DEFINE_FUNCTION( SP(CvMat), cvGetPerspectiveTransform, 3( SP(CvPoint2D32f,src), SP(CvPoint2D32f,dst), SP(CvMat,map_matrix) ) ) 

/* Performs generic geometric transformation using the specified coordinate maps */
// CVAPI(void)  cvRemap( const CvArr* src, CvArr* dst,
//                       const CvArr* mapx, const CvArr* mapy,
//                       int flags CV_DEFAULT(CV_INTER_LINEAR+CV_WARP_FILL_OUTLIERS),
//                       CvScalar fillval CV_DEFAULT(cvScalarAll(0)) );
DEFINE_FUNCTION( N(void), cvRemap, 6( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mapx), MP(UMemory,CvArr,mapy), V(int,flags), S(CvScalar,fillval) ) ) 
DEFINE_FUNCTION( N(void), cvRemap, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mapx), MP(UMemory,CvArr,mapy), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvRemap, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mapx), MP(UMemory,CvArr,mapy) ) ) 

/* Performs forward or inverse log-polar image transform */
// CVAPI(void)  cvLogPolar( const CvArr* src, CvArr* dst,
//                          CvPoint2D32f center, double M,
//                          int flags CV_DEFAULT(CV_INTER_LINEAR+CV_WARP_FILL_OUTLIERS));
DEFINE_FUNCTION( N(void), cvLogPolar, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), S(CvPoint2D32f,center), V(double,M), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvLogPolar, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), S(CvPoint2D32f,center), V(double,M) ) ) 

// #define  CV_SHAPE_RECT      0
#pragma push_macro( "CV_SHAPE_RECT" )
#undef CV_SHAPE_RECT
static const int CV_SHAPE_RECT
#pragma pop_macro( "CV_SHAPE_RECT" )
	= CV_SHAPE_RECT;
// #define  CV_SHAPE_CROSS     1
#pragma push_macro( "CV_SHAPE_CROSS" )
#undef CV_SHAPE_CROSS
static const int CV_SHAPE_CROSS
#pragma pop_macro( "CV_SHAPE_CROSS" )
	= CV_SHAPE_CROSS;
// #define  CV_SHAPE_ELLIPSE   2
#pragma push_macro( "CV_SHAPE_ELLIPSE" )
#undef CV_SHAPE_ELLIPSE
static const int CV_SHAPE_ELLIPSE
#pragma pop_macro( "CV_SHAPE_ELLIPSE" )
	= CV_SHAPE_ELLIPSE;
// #define  CV_SHAPE_CUSTOM    100
#pragma push_macro( "CV_SHAPE_CUSTOM" )
#undef CV_SHAPE_CUSTOM
static const int CV_SHAPE_CUSTOM
#pragma pop_macro( "CV_SHAPE_CUSTOM" )
	= CV_SHAPE_CUSTOM;

/* creates structuring element used for morphological operations */
// CVAPI(IplConvKernel*)  cvCreateStructuringElementEx(
//             int cols, int  rows, int  anchor_x, int  anchor_y,
//             int shape, int* values CV_DEFAULT(NULL) );
DEFINE_FUNCTION( SP(IplConvKernel), cvCreateStructuringElementEx, 6( V(int,cols), V(int,rows), V(int,anchor_x), V(int,anchor_y), V(int,shape), VP(int,values) ) ) 
DEFINE_FUNCTION( SP(IplConvKernel), cvCreateStructuringElementEx, 6( V(int,cols), V(int,rows), V(int,anchor_x), V(int,anchor_y), V(int,shape), P(int*,values) ) ) 
DEFINE_FUNCTION( SP(IplConvKernel), cvCreateStructuringElementEx, 5( V(int,cols), V(int,rows), V(int,anchor_x), V(int,anchor_y), V(int,shape) ) ) 

/* releases structuring element */
// CVAPI(void)  cvReleaseStructuringElement( IplConvKernel** element );
DEFINE_FUNCTION( N(void), cvReleaseStructuringElement, 1( SPP(IplConvKernel,element) ) ) 

/* erodes input image (applies minimum filter) one or more times.
   If element pointer is NULL, 3x3 rectangular element is used */
// CVAPI(void)  cvErode( const CvArr* src, CvArr* dst,
//                       IplConvKernel* element CV_DEFAULT(NULL),
//                       int iterations CV_DEFAULT(1) );
DEFINE_FUNCTION( N(void), cvErode, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(IplConvKernel,element), V(int,iterations) ) ) 
DEFINE_FUNCTION( N(void), cvErode, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(IplConvKernel,element) ) ) 
DEFINE_FUNCTION( N(void), cvErode, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* dilates input image (applies maximum filter) one or more times.
   If element pointer is NULL, 3x3 rectangular element is used */
// CVAPI(void)  cvDilate( const CvArr* src, CvArr* dst,
//                        IplConvKernel* element CV_DEFAULT(NULL),
//                        int iterations CV_DEFAULT(1) );
DEFINE_FUNCTION( N(void), cvDilate, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(IplConvKernel,element), V(int,iterations) ) ) 
DEFINE_FUNCTION( N(void), cvDilate, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(IplConvKernel,element) ) ) 
DEFINE_FUNCTION( N(void), cvDilate, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

// #define CV_MOP_OPEN         2
#pragma push_macro( "CV_MOP_OPEN" )
#undef CV_MOP_OPEN
static const int CV_MOP_OPEN
#pragma pop_macro( "CV_MOP_OPEN" )
	= CV_MOP_OPEN;
// #define CV_MOP_CLOSE        3
#pragma push_macro( "CV_MOP_CLOSE" )
#undef CV_MOP_CLOSE
static const int CV_MOP_CLOSE
#pragma pop_macro( "CV_MOP_CLOSE" )
	= CV_MOP_CLOSE;
// #define CV_MOP_GRADIENT     4
#pragma push_macro( "CV_MOP_GRADIENT" )
#undef CV_MOP_GRADIENT
static const int CV_MOP_GRADIENT
#pragma pop_macro( "CV_MOP_GRADIENT" )
	= CV_MOP_GRADIENT;
// #define CV_MOP_TOPHAT       5
#pragma push_macro( "CV_MOP_TOPHAT" )
#undef CV_MOP_TOPHAT
static const int CV_MOP_TOPHAT
#pragma pop_macro( "CV_MOP_TOPHAT" )
	= CV_MOP_TOPHAT;
// #define CV_MOP_BLACKHAT     6
#pragma push_macro( "CV_MOP_BLACKHAT" )
#undef CV_MOP_BLACKHAT
static const int CV_MOP_BLACKHAT
#pragma pop_macro( "CV_MOP_BLACKHAT" )
	= CV_MOP_BLACKHAT;

/* Performs complex morphological transformation */
// CVAPI(void)  cvMorphologyEx( const CvArr* src, CvArr* dst,
//                              CvArr* temp, IplConvKernel* element,
//                              int operation, int iterations CV_DEFAULT(1) );
DEFINE_FUNCTION( N(void), cvMorphologyEx, 6( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,temp), SP(IplConvKernel,element), V(int,operation), V(int,iterations) ) ) 
DEFINE_FUNCTION( N(void), cvMorphologyEx, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,temp), SP(IplConvKernel,element), V(int,operation) ) ) 

/* Calculates all spatial and central moments up to the 3rd order */
// CVAPI(void) cvMoments( const CvArr* arr, CvMoments* moments, int binary CV_DEFAULT(0));
DEFINE_FUNCTION_ALIAS( N(void), cvMoments, cvMoments_, 3( MP(UMemory,CvArr,arr), SP(CvMoments,moments), V(int,binary) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvMoments, cvMoments_, 2( MP(UMemory,CvArr,arr), SP(CvMoments,moments) ) ) 

/* Retrieve particular spatial, central or normalized central moments */
// CVAPI(double)  cvGetSpatialMoment( CvMoments* moments, int x_order, int y_order );
DEFINE_FUNCTION( V(double), cvGetSpatialMoment, 3( SP(CvMoments,moments), V(int,x_order), V(int,y_order) ) ) 
// CVAPI(double)  cvGetCentralMoment( CvMoments* moments, int x_order, int y_order );
DEFINE_FUNCTION( V(double), cvGetCentralMoment, 3( SP(CvMoments,moments), V(int,x_order), V(int,y_order) ) ) 
// CVAPI(double)  cvGetNormalizedCentralMoment( CvMoments* moments,
//                                              int x_order, int y_order );
DEFINE_FUNCTION( V(double), cvGetNormalizedCentralMoment, 3( SP(CvMoments,moments), V(int,x_order), V(int,y_order) ) ) 

/* Calculates 7 Hu's invariants from precalculated spatial and central moments */
// CVAPI(void) cvGetHuMoments( CvMoments*  moments, CvHuMoments*  hu_moments );
DEFINE_FUNCTION( N(void), cvGetHuMoments, 2( SP(CvMoments,moments), SP(CvHuMoments,hu_moments) ) ) 

/*********************************** data sampling **************************************/

/* Fetches pixels that belong to the specified line segment and stores them to the buffer.
   Returns the number of retrieved points. */
// CVAPI(int)  cvSampleLine( const CvArr* image, CvPoint pt1, CvPoint pt2, void* buffer,
//                           int connectivity CV_DEFAULT(8));
DEFINE_FUNCTION( V(int), cvSampleLine, 5( MP(UMemory,CvArr,image), S(CvPoint,pt1), S(CvPoint,pt2), P(void*,buffer), V(int,connectivity) ) ) 
DEFINE_FUNCTION( V(int), cvSampleLine, 4( MP(UMemory,CvArr,image), S(CvPoint,pt1), S(CvPoint,pt2), P(void*,buffer) ) ) 

/* Retrieves the rectangular image region with specified center from the input array.
 dst(x,y) <- src(x + center.x - dst_width/2, y + center.y - dst_height/2).
 Values of pixels with fractional coordinates are retrieved using bilinear interpolation*/
// CVAPI(void)  cvGetRectSubPix( const CvArr* src, CvArr* dst, CvPoint2D32f center );
DEFINE_FUNCTION( N(void), cvGetRectSubPix, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), S(CvPoint2D32f,center) ) ) 


/* Retrieves quadrangle from the input array.
    matrixarr = ( a11  a12 | b1 )   dst(x,y) <- src(A[x y]' + b)
                ( a21  a22 | b2 )   (bilinear interpolation is used to retrieve pixels
                                     with fractional coordinates)
*/
// CVAPI(void)  cvGetQuadrangleSubPix( const CvArr* src, CvArr* dst,
//                                     const CvMat* map_matrix );
DEFINE_FUNCTION( N(void), cvGetQuadrangleSubPix, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,map_matrix) ) ) 

/* Methods for comparing two array */
// #define  CV_TM_SQDIFF        0
#pragma push_macro( "CV_TM_SQDIFF" )
#undef CV_TM_SQDIFF
static const int CV_TM_SQDIFF
#pragma pop_macro( "CV_TM_SQDIFF" )
	= CV_TM_SQDIFF;
// #define  CV_TM_SQDIFF_NORMED 1
#pragma push_macro( "CV_TM_SQDIFF_NORMED" )
#undef CV_TM_SQDIFF_NORMED
static const int CV_TM_SQDIFF_NORMED
#pragma pop_macro( "CV_TM_SQDIFF_NORMED" )
	= CV_TM_SQDIFF_NORMED;
// #define  CV_TM_CCORR         2
#pragma push_macro( "CV_TM_CCORR" )
#undef CV_TM_CCORR
static const int CV_TM_CCORR
#pragma pop_macro( "CV_TM_CCORR" )
	= CV_TM_CCORR;
// #define  CV_TM_CCORR_NORMED  3
#pragma push_macro( "CV_TM_CCORR_NORMED" )
#undef CV_TM_CCORR_NORMED
static const int CV_TM_CCORR_NORMED
#pragma pop_macro( "CV_TM_CCORR_NORMED" )
	= CV_TM_CCORR_NORMED;
// #define  CV_TM_CCOEFF        4
#pragma push_macro( "CV_TM_CCOEFF" )
#undef CV_TM_CCOEFF
static const int CV_TM_CCOEFF
#pragma pop_macro( "CV_TM_CCOEFF" )
	= CV_TM_CCOEFF;
// #define  CV_TM_CCOEFF_NORMED 5
#pragma push_macro( "CV_TM_CCOEFF_NORMED" )
#undef CV_TM_CCOEFF_NORMED
static const int CV_TM_CCOEFF_NORMED
#pragma pop_macro( "CV_TM_CCOEFF_NORMED" )
	= CV_TM_CCOEFF_NORMED;

/* Measures similarity between template and overlapped windows in the source image
   and fills the resultant image with the measurements */
// CVAPI(void)  cvMatchTemplate( const CvArr* image, const CvArr* templ,
//                               CvArr* result, int method );
DEFINE_FUNCTION( N(void), cvMatchTemplate, 4( MP(UMemory,CvArr,image), MP(UMemory,CvArr,templ), MP(UMemory,CvArr,result), V(int,method) ) ) 

/* Computes earth mover distance between
   two weighted point sets (called signatures) */
// CVAPI(float)  cvCalcEMD2( const CvArr* signature1,
//                           const CvArr* signature2,
//                           int distance_type,
//                           CvDistanceFunction distance_func CV_DEFAULT(NULL),
//                           const CvArr* cost_matrix CV_DEFAULT(NULL),
//                           CvArr* flow CV_DEFAULT(NULL),
//                           float* lower_bound CV_DEFAULT(NULL),
//                           void* userdata CV_DEFAULT(NULL));
DEFINE_FUNCTION( V(float), cvCalcEMD2, 8( MP(UMemory,CvArr,signature1), MP(UMemory,CvArr,signature2), V(int,distance_type), F(CvDistanceFunction,distance_func), MP(UMemory,CvArr,cost_matrix), MP(UMemory,CvArr,flow), VP(float,lower_bound), P(void*,userdata) ) ) 
DEFINE_FUNCTION( V(float), cvCalcEMD2, 8( MP(UMemory,CvArr,signature1), MP(UMemory,CvArr,signature2), V(int,distance_type), F(CvDistanceFunction,distance_func), MP(UMemory,CvArr,cost_matrix), MP(UMemory,CvArr,flow), P(float*,lower_bound), P(void*,userdata) ) ) 
DEFINE_FUNCTION( V(float), cvCalcEMD2, 7( MP(UMemory,CvArr,signature1), MP(UMemory,CvArr,signature2), V(int,distance_type), F(CvDistanceFunction,distance_func), MP(UMemory,CvArr,cost_matrix), MP(UMemory,CvArr,flow), VP(float,lower_bound) ) ) 
DEFINE_FUNCTION( V(float), cvCalcEMD2, 7( MP(UMemory,CvArr,signature1), MP(UMemory,CvArr,signature2), V(int,distance_type), F(CvDistanceFunction,distance_func), MP(UMemory,CvArr,cost_matrix), MP(UMemory,CvArr,flow), P(float*,lower_bound) ) ) 
DEFINE_FUNCTION( V(float), cvCalcEMD2, 6( MP(UMemory,CvArr,signature1), MP(UMemory,CvArr,signature2), V(int,distance_type), F(CvDistanceFunction,distance_func), MP(UMemory,CvArr,cost_matrix), MP(UMemory,CvArr,flow) ) ) 
DEFINE_FUNCTION( V(float), cvCalcEMD2, 5( MP(UMemory,CvArr,signature1), MP(UMemory,CvArr,signature2), V(int,distance_type), F(CvDistanceFunction,distance_func), MP(UMemory,CvArr,cost_matrix) ) ) 
DEFINE_FUNCTION( V(float), cvCalcEMD2, 4( MP(UMemory,CvArr,signature1), MP(UMemory,CvArr,signature2), V(int,distance_type), F(CvDistanceFunction,distance_func) ) ) 
DEFINE_FUNCTION( V(float), cvCalcEMD2, 3( MP(UMemory,CvArr,signature1), MP(UMemory,CvArr,signature2), V(int,distance_type) ) ) 

/****************************************************************************************\
*                              Contours retrieving                                       *
\****************************************************************************************/

/* Retrieves outer and optionally inner boundaries of white (non-zero) connected
   components in the black (zero) background */
// CVAPI(int)  cvFindContours( CvArr* image, CvMemStorage* storage, CvSeq** first_contour,
//                             int header_size CV_DEFAULT(sizeof(CvContour)),
//                             int mode CV_DEFAULT(CV_RETR_LIST),
//                             int method CV_DEFAULT(CV_CHAIN_APPROX_SIMPLE),
//                             CvPoint offset CV_DEFAULT(cvPoint(0,0)));
DEFINE_FUNCTION( V(int), cvFindContours, 7( MP(UMemory,CvArr,image), SP(CvMemStorage,storage), SPP(CvSeq,first_contour), V(int,header_size), V(int,mode), V(int,method), S(CvPoint,offset) ) ) 
DEFINE_FUNCTION( V(int), cvFindContours, 6( MP(UMemory,CvArr,image), SP(CvMemStorage,storage), SPP(CvSeq,first_contour), V(int,header_size), V(int,mode), V(int,method) ) ) 
DEFINE_FUNCTION( V(int), cvFindContours, 5( MP(UMemory,CvArr,image), SP(CvMemStorage,storage), SPP(CvSeq,first_contour), V(int,header_size), V(int,mode) ) ) 
DEFINE_FUNCTION( V(int), cvFindContours, 4( MP(UMemory,CvArr,image), SP(CvMemStorage,storage), SPP(CvSeq,first_contour), V(int,header_size) ) ) 
DEFINE_FUNCTION( V(int), cvFindContours, 3( MP(UMemory,CvArr,image), SP(CvMemStorage,storage), SPP(CvSeq,first_contour) ) ) 


/* Initalizes contour retrieving process.
   Calls cvStartFindContours.
   Calls cvFindNextContour until null pointer is returned
   or some other condition becomes true.
   Calls cvEndFindContours at the end. */
// CVAPI(CvContourScanner)  cvStartFindContours( CvArr* image, CvMemStorage* storage,
//                             int header_size CV_DEFAULT(sizeof(CvContour)),
//                             int mode CV_DEFAULT(CV_RETR_LIST),
//                             int method CV_DEFAULT(CV_CHAIN_APPROX_SIMPLE),
//                             CvPoint offset CV_DEFAULT(cvPoint(0,0)));
DEFINE_FUNCTION( S(CvContourScanner), cvStartFindContours, 6( MP(UMemory,CvArr,image), SP(CvMemStorage,storage), V(int,header_size), V(int,mode), V(int,method), S(CvPoint,offset) ) ) 
DEFINE_FUNCTION( S(CvContourScanner), cvStartFindContours, 5( MP(UMemory,CvArr,image), SP(CvMemStorage,storage), V(int,header_size), V(int,mode), V(int,method) ) ) 
DEFINE_FUNCTION( S(CvContourScanner), cvStartFindContours, 4( MP(UMemory,CvArr,image), SP(CvMemStorage,storage), V(int,header_size), V(int,mode) ) ) 
DEFINE_FUNCTION( S(CvContourScanner), cvStartFindContours, 3( MP(UMemory,CvArr,image), SP(CvMemStorage,storage), V(int,header_size) ) ) 
DEFINE_FUNCTION( S(CvContourScanner), cvStartFindContours, 2( MP(UMemory,CvArr,image), SP(CvMemStorage,storage) ) ) 

/* Retrieves next contour */
// CVAPI(CvSeq*)  cvFindNextContour( CvContourScanner scanner );
DEFINE_FUNCTION( SP(CvSeq), cvFindNextContour, 1( S(CvContourScanner,scanner) ) ) 


/* Substitutes the last retrieved contour with the new one
   (if the substitutor is null, the last retrieved contour is removed from the tree) */
// CVAPI(void)   cvSubstituteContour( CvContourScanner scanner, CvSeq* new_contour );
DEFINE_FUNCTION( N(void), cvSubstituteContour, 2( S(CvContourScanner,scanner), SP(CvSeq,new_contour) ) ) 


/* Releases contour scanner and returns pointer to the first outer contour */
// CVAPI(CvSeq*)  cvEndFindContours( CvContourScanner* scanner );
DEFINE_FUNCTION( SP(CvSeq), cvEndFindContours, 1( SP(CvContourScanner,scanner) ) ) 

/* Approximates a single Freeman chain or a tree of chains to polygonal curves */
// CVAPI(CvSeq*) cvApproxChains( CvSeq* src_seq, CvMemStorage* storage,
//                             int method CV_DEFAULT(CV_CHAIN_APPROX_SIMPLE),
//                             double parameter CV_DEFAULT(0),
//                             int  minimal_perimeter CV_DEFAULT(0),
//                             int  recursive CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvSeq), cvApproxChains, 6( SP(CvSeq,src_seq), SP(CvMemStorage,storage), V(int,method), V(double,parameter), V(int,minimal_perimeter), V(int,recursive) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvApproxChains, 5( SP(CvSeq,src_seq), SP(CvMemStorage,storage), V(int,method), V(double,parameter), V(int,minimal_perimeter) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvApproxChains, 4( SP(CvSeq,src_seq), SP(CvMemStorage,storage), V(int,method), V(double,parameter) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvApproxChains, 3( SP(CvSeq,src_seq), SP(CvMemStorage,storage), V(int,method) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvApproxChains, 2( SP(CvSeq,src_seq), SP(CvMemStorage,storage) ) ) 


/* Initalizes Freeman chain reader.
   The reader is used to iteratively get coordinates of all the chain points.
   If the Freeman codes should be read as is, a simple sequence reader should be used */
// CVAPI(void) cvStartReadChainPoints( CvChain* chain, CvChainPtReader* reader );
DEFINE_FUNCTION( N(void), cvStartReadChainPoints, 2( SP(CvChain,chain), SP(CvChainPtReader,reader) ) ) 

/* Retrieves the next chain point */
// CVAPI(CvPoint) cvReadChainPoint( CvChainPtReader* reader );
DEFINE_FUNCTION( S(CvPoint), cvReadChainPoint, 1( SP(CvChainPtReader,reader) ) ) 


/****************************************************************************************\
*                                  Motion Analysis                                       *
\****************************************************************************************/

/************************************ optical flow ***************************************/

/* Calculates optical flow for 2 images using classical Lucas & Kanade algorithm */
// CVAPI(void)  cvCalcOpticalFlowLK( const CvArr* prev, const CvArr* curr,
//                                   CvSize win_size, CvArr* velx, CvArr* vely );
DEFINE_FUNCTION( N(void), cvCalcOpticalFlowLK, 5( MP(UMemory,CvArr,prev), MP(UMemory,CvArr,curr), S(CvSize,win_size), MP(UMemory,CvArr,velx), MP(UMemory,CvArr,vely) ) ) 

/* Calculates optical flow for 2 images using block matching algorithm */
// CVAPI(void)  cvCalcOpticalFlowBM( const CvArr* prev, const CvArr* curr,
//                                   CvSize block_size, CvSize shift_size,
//                                   CvSize max_range, int use_previous,
//                                   CvArr* velx, CvArr* vely );
DEFINE_FUNCTION( N(void), cvCalcOpticalFlowBM, 8( MP(UMemory,CvArr,prev), MP(UMemory,CvArr,curr), S(CvSize,block_size), S(CvSize,shift_size), S(CvSize,max_range), V(int,use_previous), MP(UMemory,CvArr,velx), MP(UMemory,CvArr,vely) ) ) 

/* Calculates Optical flow for 2 images using Horn & Schunck algorithm */
// CVAPI(void)  cvCalcOpticalFlowHS( const CvArr* prev, const CvArr* curr,
//                                   int use_previous, CvArr* velx, CvArr* vely,
//                                   double lambda, CvTermCriteria criteria );
DEFINE_FUNCTION( N(void), cvCalcOpticalFlowHS, 7( MP(UMemory,CvArr,prev), MP(UMemory,CvArr,curr), V(int,use_previous), MP(UMemory,CvArr,velx), MP(UMemory,CvArr,vely), V(double,lambda), S(CvTermCriteria,criteria) ) ) 

// #define  CV_LKFLOW_PYR_A_READY       1
#pragma push_macro( "CV_LKFLOW_PYR_A_READY" )
#undef CV_LKFLOW_PYR_A_READY
static const int CV_LKFLOW_PYR_A_READY
#pragma pop_macro( "CV_LKFLOW_PYR_A_READY" )
	= CV_LKFLOW_PYR_A_READY;
// #define  CV_LKFLOW_PYR_B_READY       2
#pragma push_macro( "CV_LKFLOW_PYR_B_READY" )
#undef CV_LKFLOW_PYR_B_READY
static const int CV_LKFLOW_PYR_B_READY
#pragma pop_macro( "CV_LKFLOW_PYR_B_READY" )
	= CV_LKFLOW_PYR_B_READY;
// #define  CV_LKFLOW_INITIAL_GUESSES   4
#pragma push_macro( "CV_LKFLOW_INITIAL_GUESSES" )
#undef CV_LKFLOW_INITIAL_GUESSES
static const int CV_LKFLOW_INITIAL_GUESSES
#pragma pop_macro( "CV_LKFLOW_INITIAL_GUESSES" )
	= CV_LKFLOW_INITIAL_GUESSES;

/* It is Lucas & Kanade method, modified to use pyramids.
   Also it does several iterations to get optical flow for
   every point at every pyramid level.
   Calculates optical flow between two images for certain set of points (i.e.
   it is a "sparse" optical flow, which is opposite to the previous 3 methods) */
// CVAPI(void)  cvCalcOpticalFlowPyrLK( const CvArr*  prev, const CvArr*  curr,
//                                      CvArr*  prev_pyr, CvArr*  curr_pyr,
//                                      const CvPoint2D32f* prev_features,
//                                      CvPoint2D32f* curr_features,
//                                      int       count,
//                                      CvSize    win_size,
//                                      int       level,
//                                      char*     status,
//                                      float*    track_error,
//                                      CvTermCriteria criteria,
//                                      int       flags );
DEFINE_FUNCTION( N(void), cvCalcOpticalFlowPyrLK, 13( MP(UMemory,CvArr,prev), MP(UMemory,CvArr,curr), MP(UMemory,CvArr,prev_pyr), MP(UMemory,CvArr,curr_pyr), SP(CvPoint2D32f,prev_features), SP(CvPoint2D32f,curr_features), V(int,count), S(CvSize,win_size), V(int,level), VP(char,status), VP(float,track_error), S(CvTermCriteria,criteria), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvCalcOpticalFlowPyrLK, 13( MP(UMemory,CvArr,prev), MP(UMemory,CvArr,curr), MP(UMemory,CvArr,prev_pyr), MP(UMemory,CvArr,curr_pyr), SP(CvPoint2D32f,prev_features), SP(CvPoint2D32f,curr_features), V(int,count), S(CvSize,win_size), V(int,level), P(char*,status), VP(float,track_error), S(CvTermCriteria,criteria), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvCalcOpticalFlowPyrLK, 13( MP(UMemory,CvArr,prev), MP(UMemory,CvArr,curr), MP(UMemory,CvArr,prev_pyr), MP(UMemory,CvArr,curr_pyr), SP(CvPoint2D32f,prev_features), SP(CvPoint2D32f,curr_features), V(int,count), S(CvSize,win_size), V(int,level), VP(char,status), P(float*,track_error), S(CvTermCriteria,criteria), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvCalcOpticalFlowPyrLK, 13( MP(UMemory,CvArr,prev), MP(UMemory,CvArr,curr), MP(UMemory,CvArr,prev_pyr), MP(UMemory,CvArr,curr_pyr), SP(CvPoint2D32f,prev_features), SP(CvPoint2D32f,curr_features), V(int,count), S(CvSize,win_size), V(int,level), P(char*,status), P(float*,track_error), S(CvTermCriteria,criteria), V(int,flags) ) ) 


/* Modification of a previous sparse optical flow algorithm to calculate
   affine flow */
/*CVAPI  void  cvCalcAffineFlowPyrLK( const CvArr*  prev, const CvArr*  curr,
                                     CvArr*  prev_pyr, CvArr*  curr_pyr,
                                     CvPoint2D32f* prev_features,
                                     CvPoint2D32f* curr_features,
                                     float*  matrices, int  count,
                                     CvSize  win_size, int  level,
                                     char*  status, float* track_error,
                                     CvTermCriteria criteria, int flags );*/

/********************************* motion templates *************************************/

/****************************************************************************************\
*        All the motion template functions work only with single channel images.         *
*        Silhouette image must have depth IPL_DEPTH_8U or IPL_DEPTH_8S                   *
*        Motion history image must have depth IPL_DEPTH_32F,                             *
*        Gradient mask - IPL_DEPTH_8U or IPL_DEPTH_8S,                                   *
*        Motion orientation image - IPL_DEPTH_32F                                        *
*        Segmentation mask - IPL_DEPTH_32F                                               *
*        All the angles are in degrees, all the times are in milliseconds                *
\****************************************************************************************/

/* Updates motion history image given motion silhouette */
// CVAPI(void)    cvUpdateMotionHistory( const CvArr* silhouette, CvArr* mhi,
//                                       double timestamp, double duration );
DEFINE_FUNCTION( N(void), cvUpdateMotionHistory, 4( MP(UMemory,CvArr,silhouette), MP(UMemory,CvArr,mhi), V(double,timestamp), V(double,duration) ) ) 

/* Calculates gradient of the motion history image and fills
   a mask indicating where the gradient is valid */
// CVAPI(void)    cvCalcMotionGradient( const CvArr* mhi, CvArr* mask, CvArr* orientation,
//                                      double delta1, double delta2,
//                                      int aperture_size CV_DEFAULT(3));
DEFINE_FUNCTION( N(void), cvCalcMotionGradient, 6( MP(UMemory,CvArr,mhi), MP(UMemory,CvArr,mask), MP(UMemory,CvArr,orientation), V(double,delta1), V(double,delta2), V(int,aperture_size) ) ) 
DEFINE_FUNCTION( N(void), cvCalcMotionGradient, 5( MP(UMemory,CvArr,mhi), MP(UMemory,CvArr,mask), MP(UMemory,CvArr,orientation), V(double,delta1), V(double,delta2) ) ) 

/* Calculates average motion direction within a selected motion region 
   (region can be selected by setting ROIs and/or by composing a valid gradient mask
   with the region mask) */
// CVAPI(double)  cvCalcGlobalOrientation( const CvArr* orientation, const CvArr* mask,
//                                         const CvArr* mhi, double timestamp,
//                                         double duration );
DEFINE_FUNCTION( V(double), cvCalcGlobalOrientation, 5( MP(UMemory,CvArr,orientation), MP(UMemory,CvArr,mask), MP(UMemory,CvArr,mhi), V(double,timestamp), V(double,duration) ) ) 

/* Splits a motion history image into a few parts corresponding to separate independent motions
   (e.g. left hand, right hand) */
// CVAPI(CvSeq*)  cvSegmentMotion( const CvArr* mhi, CvArr* seg_mask,
//                                 CvMemStorage* storage,
//                                 double timestamp, double seg_thresh );
DEFINE_FUNCTION( SP(CvSeq), cvSegmentMotion, 5( MP(UMemory,CvArr,mhi), MP(UMemory,CvArr,seg_mask), SP(CvMemStorage,storage), V(double,timestamp), V(double,seg_thresh) ) ) 

/*********************** Background statistics accumulation *****************************/

/* Adds image to accumulator */
// CVAPI(void)  cvAcc( const CvArr* image, CvArr* sum,
//                     const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvAcc, 3( MP(UMemory,CvArr,image), MP(UMemory,CvArr,sum), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvAcc, 2( MP(UMemory,CvArr,image), MP(UMemory,CvArr,sum) ) ) 

/* Adds squared image to accumulator */
// CVAPI(void)  cvSquareAcc( const CvArr* image, CvArr* sqsum,
//                           const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvSquareAcc, 3( MP(UMemory,CvArr,image), MP(UMemory,CvArr,sqsum), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvSquareAcc, 2( MP(UMemory,CvArr,image), MP(UMemory,CvArr,sqsum) ) ) 

/* Adds a product of two images to accumulator */
// CVAPI(void)  cvMultiplyAcc( const CvArr* image1, const CvArr* image2, CvArr* acc,
//                             const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvMultiplyAcc, 4( MP(UMemory,CvArr,image1), MP(UMemory,CvArr,image2), MP(UMemory,CvArr,acc), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvMultiplyAcc, 3( MP(UMemory,CvArr,image1), MP(UMemory,CvArr,image2), MP(UMemory,CvArr,acc) ) ) 

/* Adds image to accumulator with weights: acc = acc*(1-alpha) + image*alpha */
// CVAPI(void)  cvRunningAvg( const CvArr* image, CvArr* acc, double alpha,
//                            const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvRunningAvg, 4( MP(UMemory,CvArr,image), MP(UMemory,CvArr,acc), V(double,alpha), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvRunningAvg, 3( MP(UMemory,CvArr,image), MP(UMemory,CvArr,acc), V(double,alpha) ) ) 


/****************************************************************************************\
*                                       Tracking                                         *
\****************************************************************************************/

/* Implements CAMSHIFT algorithm - determines object position, size and orientation
   from the object histogram back project (extension of meanshift) */
// CVAPI(int)  cvCamShift( const CvArr* prob_image, CvRect  window,
//                        CvTermCriteria criteria, CvConnectedComp* comp,
//                        CvBox2D* box CV_DEFAULT(NULL) );
DEFINE_FUNCTION( V(int), cvCamShift, 5( MP(UMemory,CvArr,prob_image), S(CvRect,window), S(CvTermCriteria,criteria), SP(CvConnectedComp,comp), SP(CvBox2D,box) ) ) 
DEFINE_FUNCTION( V(int), cvCamShift, 4( MP(UMemory,CvArr,prob_image), S(CvRect,window), S(CvTermCriteria,criteria), SP(CvConnectedComp,comp) ) ) 

/* Implements MeanShift algorithm - determines object position
   from the object histogram back project */
// CVAPI(int)  cvMeanShift( const CvArr* prob_image, CvRect  window,
//                         CvTermCriteria criteria, CvConnectedComp* comp );
DEFINE_FUNCTION( V(int), cvMeanShift, 4( MP(UMemory,CvArr,prob_image), S(CvRect,window), S(CvTermCriteria,criteria), SP(CvConnectedComp,comp) ) ) 

/* Creates ConDensation filter state */
// CVAPI(CvConDensation*)  cvCreateConDensation( int dynam_params,
//                                              int measure_params,
//                                              int sample_count );
DEFINE_FUNCTION( SP(CvConDensation), cvCreateConDensation, 3( V(int,dynam_params), V(int,measure_params), V(int,sample_count) ) ) 

/* Releases ConDensation filter state */
// CVAPI(void)  cvReleaseConDensation( CvConDensation** condens );
DEFINE_FUNCTION( N(void), cvReleaseConDensation, 1( SPP(CvConDensation,condens) ) ) 

/* Updates ConDensation filter by time (predict future state of the system) */
// CVAPI(void)  cvConDensUpdateByTime( CvConDensation* condens);
DEFINE_FUNCTION( N(void), cvConDensUpdateByTime, 1( SP(CvConDensation,condens) ) ) 

/* Initializes ConDensation filter samples  */
// CVAPI(void)  cvConDensInitSampleSet( CvConDensation* condens, CvMat* lower_bound, CvMat* upper_bound );
DEFINE_FUNCTION( N(void), cvConDensInitSampleSet, 3( SP(CvConDensation,condens), SP(CvMat,lower_bound), SP(CvMat,upper_bound) ) ) 

/* Creates Kalman filter and sets A, B, Q, R and state to some initial values */
// CVAPI(CvKalman*) cvCreateKalman( int dynam_params, int measure_params,
//                                 int control_params CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvKalman), cvCreateKalman, 3( V(int,dynam_params), V(int,measure_params), V(int,control_params) ) ) 
DEFINE_FUNCTION( SP(CvKalman), cvCreateKalman, 2( V(int,dynam_params), V(int,measure_params) ) ) 

/* Releases Kalman filter state */
// CVAPI(void)  cvReleaseKalman( CvKalman** kalman);
DEFINE_FUNCTION( N(void), cvReleaseKalman, 1( SPP(CvKalman,kalman) ) ) 

/* Updates Kalman filter by time (predicts future state of the system) */
// CVAPI(const CvMat*)  cvKalmanPredict( CvKalman* kalman,
//                                      const CvMat* control CV_DEFAULT(NULL));
DEFINE_FUNCTION( SPC(CvMat), cvKalmanPredict, 2( SP(CvKalman,kalman), SP(CvMat,control) ) ) 
DEFINE_FUNCTION( SPC(CvMat), cvKalmanPredict, 1( SP(CvKalman,kalman) ) ) 

/* Updates Kalman filter by measurement
   (corrects state of the system and internal matrices) */
// CVAPI(const CvMat*)  cvKalmanCorrect( CvKalman* kalman, const CvMat* measurement );
DEFINE_FUNCTION( SPC(CvMat), cvKalmanCorrect, 2( SP(CvKalman,kalman), SP(CvMat,measurement) ) ) 

/****************************************************************************************\
*                              Planar subdivisions                                       *
\****************************************************************************************/

/* Initializes Delaunay triangulation */
// CVAPI(void)  cvInitSubdivDelaunay2D( CvSubdiv2D* subdiv, CvRect rect );
DEFINE_FUNCTION( N(void), cvInitSubdivDelaunay2D, 2( SP(CvSubdiv2D,subdiv), S(CvRect,rect) ) ) 

/* Creates new subdivision */
// CVAPI(CvSubdiv2D*)  cvCreateSubdiv2D( int subdiv_type, int header_size,
//                                       int vtx_size, int quadedge_size,
//                                       CvMemStorage* storage );
DEFINE_FUNCTION( SP(CvSubdiv2D), cvCreateSubdiv2D, 5( V(int,subdiv_type), V(int,header_size), V(int,vtx_size), V(int,quadedge_size), SP(CvMemStorage,storage) ) ) 

/************************* high-level subdivision functions ***************************/

/* Simplified Delaunay diagram creation */
// CV_INLINE  CvSubdiv2D* cvCreateSubdivDelaunay2D( CvRect rect, CvMemStorage* storage )
// {
//     CvSubdiv2D* subdiv = cvCreateSubdiv2D( CV_SEQ_KIND_SUBDIV2D, sizeof(*subdiv),
//                          sizeof(CvSubdiv2DPoint), sizeof(CvQuadEdge2D), storage );
// 
//     cvInitSubdivDelaunay2D( subdiv, rect );
//     return subdiv;
// }
DEFINE_FUNCTION( SP(CvSubdiv2D), cvCreateSubdivDelaunay2D, 2( S(CvRect,rect), SP(CvMemStorage,storage) ) ) 


/* Inserts new point to the Delaunay triangulation */
// CVAPI(CvSubdiv2DPoint*)  cvSubdivDelaunay2DInsert( CvSubdiv2D* subdiv, CvPoint2D32f pt);
DEFINE_FUNCTION( SP(CvSubdiv2DPoint), cvSubdivDelaunay2DInsert, 2( SP(CvSubdiv2D,subdiv), S(CvPoint2D32f,pt) ) ) 

/* Locates a point within the Delaunay triangulation (finds the edge
   the point is left to or belongs to, or the triangulation point the given
   point coinsides with */
// CVAPI(CvSubdiv2DPointLocation)  cvSubdiv2DLocate(
//                                CvSubdiv2D* subdiv, CvPoint2D32f pt,
//                                CvSubdiv2DEdge* edge,
//                                CvSubdiv2DPoint** vertex CV_DEFAULT(NULL) );
DEFINE_FUNCTION( E(CvSubdiv2DPointLocation), cvSubdiv2DLocate, 4( SP(CvSubdiv2D,subdiv), S(CvPoint2D32f,pt), VP(size_t,edge), SPP(CvSubdiv2DPoint,vertex) ) ) 
DEFINE_FUNCTION( E(CvSubdiv2DPointLocation), cvSubdiv2DLocate, 4( SP(CvSubdiv2D,subdiv), S(CvPoint2D32f,pt), P(size_t*,edge), SPP(CvSubdiv2DPoint,vertex) ) ) 
DEFINE_FUNCTION( E(CvSubdiv2DPointLocation), cvSubdiv2DLocate, 3( SP(CvSubdiv2D,subdiv), S(CvPoint2D32f,pt), VP(size_t,edge) ) ) 
DEFINE_FUNCTION( E(CvSubdiv2DPointLocation), cvSubdiv2DLocate, 3( SP(CvSubdiv2D,subdiv), S(CvPoint2D32f,pt), P(size_t*,edge) ) ) 

/* Calculates Voronoi tesselation (i.e. coordinates of Voronoi points) */
// CVAPI(void)  cvCalcSubdivVoronoi2D( CvSubdiv2D* subdiv );
DEFINE_FUNCTION( N(void), cvCalcSubdivVoronoi2D, 1( SP(CvSubdiv2D,subdiv) ) ) 


/* Removes all Voronoi points from the tesselation */
// CVAPI(void)  cvClearSubdivVoronoi2D( CvSubdiv2D* subdiv );
DEFINE_FUNCTION( N(void), cvClearSubdivVoronoi2D, 1( SP(CvSubdiv2D,subdiv) ) ) 


/* Finds the nearest to the given point vertex in subdivision. */
// CVAPI(CvSubdiv2DPoint*) cvFindNearestPoint2D( CvSubdiv2D* subdiv, CvPoint2D32f pt );
DEFINE_FUNCTION( SP(CvSubdiv2DPoint), cvFindNearestPoint2D, 2( SP(CvSubdiv2D,subdiv), S(CvPoint2D32f,pt) ) ) 


/************ Basic quad-edge navigation and operations ************/

// CV_INLINE  CvSubdiv2DEdge  cvSubdiv2DNextEdge( CvSubdiv2DEdge edge )
// {
//     return  CV_SUBDIV2D_NEXT_EDGE(edge);
// }
DEFINE_FUNCTION( V(size_t), cvSubdiv2DNextEdge, 1( V(size_t,edge) ) ) 


// CV_INLINE  CvSubdiv2DEdge  cvSubdiv2DRotateEdge( CvSubdiv2DEdge edge, int rotate )
// {
//     return  (edge & ~3) + ((edge + rotate) & 3);
// }
DEFINE_FUNCTION( V(size_t), cvSubdiv2DRotateEdge, 2( V(size_t,edge), V(int,rotate) ) ) 

// CV_INLINE  CvSubdiv2DEdge  cvSubdiv2DSymEdge( CvSubdiv2DEdge edge )
// {
//     return edge ^ 2;
// }
DEFINE_FUNCTION( V(size_t), cvSubdiv2DSymEdge, 1( V(size_t,edge) ) ) 

// CV_INLINE  CvSubdiv2DEdge  cvSubdiv2DGetEdge( CvSubdiv2DEdge edge, CvNextEdgeType type )
// {
//     CvQuadEdge2D* e = (CvQuadEdge2D*)(edge & ~3);
//     edge = e->next[(edge + (int)type) & 3];
//     return  (edge & ~3) + ((edge + ((int)type >> 4)) & 3);
// }
DEFINE_FUNCTION( V(size_t), cvSubdiv2DGetEdge, 2( V(size_t,edge), E(CvNextEdgeType,type) ) ) 


// CV_INLINE  CvSubdiv2DPoint*  cvSubdiv2DEdgeOrg( CvSubdiv2DEdge edge )
// {
//     CvQuadEdge2D* e = (CvQuadEdge2D*)(edge & ~3);
//     return (CvSubdiv2DPoint*)e->pt[edge & 3];
// }
DEFINE_FUNCTION( SP(CvSubdiv2DPoint), cvSubdiv2DEdgeOrg, 1( V(size_t,edge) ) ) 


// CV_INLINE  CvSubdiv2DPoint*  cvSubdiv2DEdgeDst( CvSubdiv2DEdge edge )
// {
//     CvQuadEdge2D* e = (CvQuadEdge2D*)(edge & ~3);
//     return (CvSubdiv2DPoint*)e->pt[(edge + 2) & 3];
// }
DEFINE_FUNCTION( SP(CvSubdiv2DPoint), cvSubdiv2DEdgeDst, 1( V(size_t,edge) ) ) 


// CV_INLINE  double  cvTriangleArea( CvPoint2D32f a, CvPoint2D32f b, CvPoint2D32f c )
// {
//     return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
// }
DEFINE_FUNCTION( V(double), cvTriangleArea, 3( S(CvPoint2D32f,a), S(CvPoint2D32f,b), S(CvPoint2D32f,c) ) ) 


/****************************************************************************************\
*                            Contour Processing and Shape Analysis                       *
\****************************************************************************************/

// #define CV_POLY_APPROX_DP 0
#pragma push_macro( "CV_POLY_APPROX_DP" )
#undef CV_POLY_APPROX_DP
static const int CV_POLY_APPROX_DP
#pragma pop_macro( "CV_POLY_APPROX_DP" )
	= CV_POLY_APPROX_DP;

/* Approximates a single polygonal curve (contour) or
   a tree of polygonal curves (contours) */
// CVAPI(CvSeq*)  cvApproxPoly( const void* src_seq,
//                              int header_size, CvMemStorage* storage,
//                              int method, double parameter,
//                              int parameter2 CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvSeq), cvApproxPoly, 6( P(const void*,src_seq), V(int,header_size), SP(CvMemStorage,storage), V(int,method), V(double,parameter), V(int,parameter2) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvApproxPoly, 5( P(const void*,src_seq), V(int,header_size), SP(CvMemStorage,storage), V(int,method), V(double,parameter) ) ) 

// #define CV_DOMINANT_IPAN 1
#pragma push_macro( "CV_DOMINANT_IPAN" )
#undef CV_DOMINANT_IPAN
static const int CV_DOMINANT_IPAN
#pragma pop_macro( "CV_DOMINANT_IPAN" )
	= CV_DOMINANT_IPAN;

/* Finds high-curvature points of the contour */
// CVAPI(CvSeq*) cvFindDominantPoints( CvSeq* contour, CvMemStorage* storage,
//                                    int method CV_DEFAULT(CV_DOMINANT_IPAN),
//                                    double parameter1 CV_DEFAULT(0),
//                                    double parameter2 CV_DEFAULT(0),
//                                    double parameter3 CV_DEFAULT(0),
//                                    double parameter4 CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvSeq), cvFindDominantPoints, 7( SP(CvSeq,contour), SP(CvMemStorage,storage), V(int,method), V(double,parameter1), V(double,parameter2), V(double,parameter3), V(double,parameter4) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvFindDominantPoints, 6( SP(CvSeq,contour), SP(CvMemStorage,storage), V(int,method), V(double,parameter1), V(double,parameter2), V(double,parameter3) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvFindDominantPoints, 5( SP(CvSeq,contour), SP(CvMemStorage,storage), V(int,method), V(double,parameter1), V(double,parameter2) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvFindDominantPoints, 4( SP(CvSeq,contour), SP(CvMemStorage,storage), V(int,method), V(double,parameter1) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvFindDominantPoints, 3( SP(CvSeq,contour), SP(CvMemStorage,storage), V(int,method) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvFindDominantPoints, 2( SP(CvSeq,contour), SP(CvMemStorage,storage) ) ) 

/* Calculates perimeter of a contour or length of a part of contour */
// CVAPI(double)  cvArcLength( const void* curve,
//                             CvSlice slice CV_DEFAULT(CV_WHOLE_SEQ),
//                             int is_closed CV_DEFAULT(-1));
DEFINE_FUNCTION( V(double), cvArcLength, 3( P(const void*,curve), S(CvSlice,slice), V(int,is_closed) ) ) 
DEFINE_FUNCTION( V(double), cvArcLength, 2( P(const void*,curve), S(CvSlice,slice) ) ) 
DEFINE_FUNCTION( V(double), cvArcLength, 1( P(const void*,curve) ) ) 
// #define cvContourPerimeter( contour ) cvArcLength( contour, CV_WHOLE_SEQ, 1 )
// Unsupport : cvContourPerimeter

/* Calculates contour boundning rectangle (update=1) or
   just retrieves pre-calculated rectangle (update=0) */
// CVAPI(CvRect)  cvBoundingRect( CvArr* points, int update CV_DEFAULT(0) );
DEFINE_FUNCTION( S(CvRect), cvBoundingRect, 2( MP(UMemory,CvArr,points), V(int,update) ) ) 
DEFINE_FUNCTION( S(CvRect), cvBoundingRect, 1( MP(UMemory,CvArr,points) ) ) 

/* Calculates area of a contour or contour segment */
// CVAPI(double)  cvContourArea( const CvArr* contour,
//                               CvSlice slice CV_DEFAULT(CV_WHOLE_SEQ));
DEFINE_FUNCTION( V(double), cvContourArea, 2( MP(UMemory,CvArr,contour), S(CvSlice,slice) ) ) 
DEFINE_FUNCTION( V(double), cvContourArea, 1( MP(UMemory,CvArr,contour) ) ) 

/* Finds minimum area rotated rectangle bounding a set of points */
// CVAPI(CvBox2D)  cvMinAreaRect2( const CvArr* points,
//                                 CvMemStorage* storage CV_DEFAULT(NULL));
DEFINE_FUNCTION( S(CvBox2D), cvMinAreaRect2, 2( MP(UMemory,CvArr,points), SP(CvMemStorage,storage) ) ) 
DEFINE_FUNCTION( S(CvBox2D), cvMinAreaRect2, 1( MP(UMemory,CvArr,points) ) ) 

/* Finds minimum enclosing circle for a set of points */
// CVAPI(int)  cvMinEnclosingCircle( const CvArr* points,
//                                   CvPoint2D32f* center, float* radius );
DEFINE_FUNCTION( V(int), cvMinEnclosingCircle, 3( MP(UMemory,CvArr,points), SP(CvPoint2D32f,center), VP(float,radius) ) ) 
DEFINE_FUNCTION( V(int), cvMinEnclosingCircle, 3( MP(UMemory,CvArr,points), SP(CvPoint2D32f,center), P(float*,radius) ) ) 

// #define CV_CONTOURS_MATCH_I1  1
#pragma push_macro( "CV_CONTOURS_MATCH_I1" )
#undef CV_CONTOURS_MATCH_I1
static const int CV_CONTOURS_MATCH_I1
#pragma pop_macro( "CV_CONTOURS_MATCH_I1" )
	= CV_CONTOURS_MATCH_I1;
// #define CV_CONTOURS_MATCH_I2  2
#pragma push_macro( "CV_CONTOURS_MATCH_I2" )
#undef CV_CONTOURS_MATCH_I2
static const int CV_CONTOURS_MATCH_I2
#pragma pop_macro( "CV_CONTOURS_MATCH_I2" )
	= CV_CONTOURS_MATCH_I2;
// #define CV_CONTOURS_MATCH_I3  3
#pragma push_macro( "CV_CONTOURS_MATCH_I3" )
#undef CV_CONTOURS_MATCH_I3
static const int CV_CONTOURS_MATCH_I3
#pragma pop_macro( "CV_CONTOURS_MATCH_I3" )
	= CV_CONTOURS_MATCH_I3;

/* Compares two contours by matching their moments */
// CVAPI(double)  cvMatchShapes( const void* object1, const void* object2,
//                               int method, double parameter CV_DEFAULT(0));
DEFINE_FUNCTION( V(double), cvMatchShapes, 4( P(const void*,object1), P(const void*,object2), V(int,method), V(double,parameter) ) ) 
DEFINE_FUNCTION( V(double), cvMatchShapes, 3( P(const void*,object1), P(const void*,object2), V(int,method) ) ) 

/* Builds hierarhical representation of a contour */
// CVAPI(CvContourTree*)  cvCreateContourTree( const CvSeq* contour,
//                                             CvMemStorage* storage,
//                                             double threshold );
DEFINE_FUNCTION( SP(CvContourTree), cvCreateContourTree, 3( SP(CvSeq,contour), SP(CvMemStorage,storage), V(double,threshold) ) ) 

/* Reconstruct (completelly or partially) contour a from contour tree */
// CVAPI(CvSeq*)  cvContourFromContourTree( const CvContourTree* tree,
//                                          CvMemStorage* storage,
//                                          CvTermCriteria criteria );
DEFINE_FUNCTION( SP(CvSeq), cvContourFromContourTree, 3( SP(CvContourTree,tree), SP(CvMemStorage,storage), S(CvTermCriteria,criteria) ) ) 

/* Compares two contour trees */
// #define  CV_CONTOUR_TREES_MATCH_I1  1
#pragma push_macro( "CV_CONTOUR_TREES_MATCH_I1" )
#undef CV_CONTOUR_TREES_MATCH_I1
static const int CV_CONTOUR_TREES_MATCH_I1
#pragma pop_macro( "CV_CONTOUR_TREES_MATCH_I1" )
	= CV_CONTOUR_TREES_MATCH_I1;

// CVAPI(double)  cvMatchContourTrees( const CvContourTree* tree1,
//                                     const CvContourTree* tree2,
//                                     int method, double threshold );
DEFINE_FUNCTION( V(double), cvMatchContourTrees, 4( SP(CvContourTree,tree1), SP(CvContourTree,tree2), V(int,method), V(double,threshold) ) ) 

/* Calculates histogram of a contour */
// CVAPI(void)  cvCalcPGH( const CvSeq* contour, CvHistogram* hist );
DEFINE_FUNCTION( N(void), cvCalcPGH, 2( SP(CvSeq,contour), SP(CvHistogram,hist) ) ) 

// #define CV_CLOCKWISE         1
#pragma push_macro( "CV_CLOCKWISE" )
#undef CV_CLOCKWISE
static const int CV_CLOCKWISE
#pragma pop_macro( "CV_CLOCKWISE" )
	= CV_CLOCKWISE;
// #define CV_COUNTER_CLOCKWISE 2
#pragma push_macro( "CV_COUNTER_CLOCKWISE" )
#undef CV_COUNTER_CLOCKWISE
static const int CV_COUNTER_CLOCKWISE
#pragma pop_macro( "CV_COUNTER_CLOCKWISE" )
	= CV_COUNTER_CLOCKWISE;

/* Calculates exact convex hull of 2d point set */
// CVAPI(CvSeq*) cvConvexHull2( const CvArr* input,
//                              void* hull_storage CV_DEFAULT(NULL),
//                              int orientation CV_DEFAULT(CV_CLOCKWISE),
//                              int return_points CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvSeq), cvConvexHull2, 4( MP(UMemory,CvArr,input), P(void*,hull_storage), V(int,orientation), V(int,return_points) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvConvexHull2, 3( MP(UMemory,CvArr,input), P(void*,hull_storage), V(int,orientation) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvConvexHull2, 2( MP(UMemory,CvArr,input), P(void*,hull_storage) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvConvexHull2, 1( MP(UMemory,CvArr,input) ) ) 

/* Checks whether the contour is convex or not (returns 1 if convex, 0 if not) */
// CVAPI(int)  cvCheckContourConvexity( const CvArr* contour );
DEFINE_FUNCTION( V(int), cvCheckContourConvexity, 1( MP(UMemory,CvArr,contour) ) ) 

/* Finds convexity defects for the contour */
// CVAPI(CvSeq*)  cvConvexityDefects( const CvArr* contour, const CvArr* convexhull,
//                                    CvMemStorage* storage CV_DEFAULT(NULL));
DEFINE_FUNCTION( SP(CvSeq), cvConvexityDefects, 3( MP(UMemory,CvArr,contour), MP(UMemory,CvArr,convexhull), SP(CvMemStorage,storage) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvConvexityDefects, 2( MP(UMemory,CvArr,contour), MP(UMemory,CvArr,convexhull) ) ) 

/* Fits ellipse into a set of 2d points */
// CVAPI(CvBox2D) cvFitEllipse2( const CvArr* points );
DEFINE_FUNCTION( S(CvBox2D), cvFitEllipse2, 1( MP(UMemory,CvArr,points) ) ) 

/* Finds minimum rectangle containing two given rectangles */
// CVAPI(CvRect)  cvMaxRect( const CvRect* rect1, const CvRect* rect2 );
DEFINE_FUNCTION( S(CvRect), cvMaxRect, 2( SP(CvRect,rect1), SP(CvRect,rect2) ) ) 

/* Finds coordinates of the box vertices */
// CVAPI(void) cvBoxPoints( CvBox2D box, CvPoint2D32f pt[4] );
DEFINE_FUNCTION( N(void), cvBoxPoints, 2( S(CvBox2D,box), SA(CvPoint2D32f,pt,4) ) ) 

/* Initializes sequence header for a matrix (column or row vector) of points -
   a wrapper for cvMakeSeqHeaderForArray (it does not initialize bounding rectangle!!!) */
// CVAPI(CvSeq*) cvPointSeqFromMat( int seq_kind, const CvArr* mat,
//                                  CvContour* contour_header,
//                                  CvSeqBlock* block );
DEFINE_FUNCTION( SP(CvSeq), cvPointSeqFromMat, 4( V(int,seq_kind), MP(UMemory,CvArr,mat), SP(CvContour,contour_header), SP(CvSeqBlock,block) ) ) 

/* Checks whether the point is inside polygon, outside, on an edge (at a vertex).
   Returns positive, negative or zero value, correspondingly.
   Optionally, measures a signed distance between
   the point and the nearest polygon edge (measure_dist=1) */
// CVAPI(double) cvPointPolygonTest( const CvArr* contour,
//                                   CvPoint2D32f pt, int measure_dist );
DEFINE_FUNCTION( V(double), cvPointPolygonTest, 3( MP(UMemory,CvArr,contour), S(CvPoint2D32f,pt), V(int,measure_dist) ) ) 

/****************************************************************************************\
*                                  Histogram functions                                   *
\****************************************************************************************/

/* Creates new histogram */
// CVAPI(CvHistogram*)  cvCreateHist( int dims, int* sizes, int type,
//                                    float** ranges CV_DEFAULT(NULL),
//                                    int uniform CV_DEFAULT(1));
DEFINE_FUNCTION( SP(CvHistogram), cvCreateHist, 5( V(int,dims), VP(int,sizes), V(int,type), P(float**,ranges), V(int,uniform) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvCreateHist, 5( V(int,dims), P(int*,sizes), V(int,type), P(float**,ranges), V(int,uniform) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvCreateHist, 4( V(int,dims), VP(int,sizes), V(int,type), P(float**,ranges) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvCreateHist, 4( V(int,dims), P(int*,sizes), V(int,type), P(float**,ranges) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvCreateHist, 3( V(int,dims), VP(int,sizes), V(int,type) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvCreateHist, 3( V(int,dims), P(int*,sizes), V(int,type) ) ) 

/* Assignes histogram bin ranges */
// CVAPI(void)  cvSetHistBinRanges( CvHistogram* hist, float** ranges,
//                                 int uniform CV_DEFAULT(1));
DEFINE_FUNCTION( N(void), cvSetHistBinRanges, 3( SP(CvHistogram,hist), P(float**,ranges), V(int,uniform) ) ) 
DEFINE_FUNCTION( N(void), cvSetHistBinRanges, 2( SP(CvHistogram,hist), P(float**,ranges) ) ) 

/* Creates histogram header for array */
// CVAPI(CvHistogram*)  cvMakeHistHeaderForArray(
//                             int  dims, int* sizes, CvHistogram* hist,
//                             float* data, float** ranges CV_DEFAULT(NULL),
//                             int uniform CV_DEFAULT(1));
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 6( V(int,dims), VP(int,sizes), SP(CvHistogram,hist), VP(float,data), P(float**,ranges), V(int,uniform) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 6( V(int,dims), P(int*,sizes), SP(CvHistogram,hist), VP(float,data), P(float**,ranges), V(int,uniform) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 6( V(int,dims), VP(int,sizes), SP(CvHistogram,hist), P(float*,data), P(float**,ranges), V(int,uniform) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 6( V(int,dims), P(int*,sizes), SP(CvHistogram,hist), P(float*,data), P(float**,ranges), V(int,uniform) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 5( V(int,dims), VP(int,sizes), SP(CvHistogram,hist), VP(float,data), P(float**,ranges) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 5( V(int,dims), P(int*,sizes), SP(CvHistogram,hist), VP(float,data), P(float**,ranges) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 5( V(int,dims), VP(int,sizes), SP(CvHistogram,hist), P(float*,data), P(float**,ranges) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 5( V(int,dims), P(int*,sizes), SP(CvHistogram,hist), P(float*,data), P(float**,ranges) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 4( V(int,dims), VP(int,sizes), SP(CvHistogram,hist), VP(float,data) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 4( V(int,dims), P(int*,sizes), SP(CvHistogram,hist), VP(float,data) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 4( V(int,dims), VP(int,sizes), SP(CvHistogram,hist), P(float*,data) ) ) 
DEFINE_FUNCTION( SP(CvHistogram), cvMakeHistHeaderForArray, 4( V(int,dims), P(int*,sizes), SP(CvHistogram,hist), P(float*,data) ) ) 

/* Releases histogram */
// CVAPI(void)  cvReleaseHist( CvHistogram** hist );
DEFINE_FUNCTION( N(void), cvReleaseHist, 1( SPP(CvHistogram,hist) ) ) 

/* Clears all the histogram bins */
// CVAPI(void)  cvClearHist( CvHistogram* hist );
DEFINE_FUNCTION( N(void), cvClearHist, 1( SP(CvHistogram,hist) ) ) 

/* Finds indices and values of minimum and maximum histogram bins */
// CVAPI(void)  cvGetMinMaxHistValue( const CvHistogram* hist,
//                                    float* min_value, float* max_value,
//                                    int* min_idx CV_DEFAULT(NULL),
//                                    int* max_idx CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), VP(float,min_value), VP(float,max_value), VP(int,min_idx), VP(int,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), P(float*,min_value), VP(float,max_value), VP(int,min_idx), VP(int,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), VP(float,min_value), P(float*,max_value), VP(int,min_idx), VP(int,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), P(float*,min_value), P(float*,max_value), VP(int,min_idx), VP(int,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), VP(float,min_value), VP(float,max_value), P(int*,min_idx), VP(int,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), P(float*,min_value), VP(float,max_value), P(int*,min_idx), VP(int,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), VP(float,min_value), P(float*,max_value), P(int*,min_idx), VP(int,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), P(float*,min_value), P(float*,max_value), P(int*,min_idx), VP(int,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), VP(float,min_value), VP(float,max_value), VP(int,min_idx), P(int*,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), P(float*,min_value), VP(float,max_value), VP(int,min_idx), P(int*,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), VP(float,min_value), P(float*,max_value), VP(int,min_idx), P(int*,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), P(float*,min_value), P(float*,max_value), VP(int,min_idx), P(int*,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), VP(float,min_value), VP(float,max_value), P(int*,min_idx), P(int*,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), P(float*,min_value), VP(float,max_value), P(int*,min_idx), P(int*,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), VP(float,min_value), P(float*,max_value), P(int*,min_idx), P(int*,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 5( SP(CvHistogram,hist), P(float*,min_value), P(float*,max_value), P(int*,min_idx), P(int*,max_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 4( SP(CvHistogram,hist), VP(float,min_value), VP(float,max_value), VP(int,min_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 4( SP(CvHistogram,hist), P(float*,min_value), VP(float,max_value), VP(int,min_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 4( SP(CvHistogram,hist), VP(float,min_value), P(float*,max_value), VP(int,min_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 4( SP(CvHistogram,hist), P(float*,min_value), P(float*,max_value), VP(int,min_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 4( SP(CvHistogram,hist), VP(float,min_value), VP(float,max_value), P(int*,min_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 4( SP(CvHistogram,hist), P(float*,min_value), VP(float,max_value), P(int*,min_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 4( SP(CvHistogram,hist), VP(float,min_value), P(float*,max_value), P(int*,min_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 4( SP(CvHistogram,hist), P(float*,min_value), P(float*,max_value), P(int*,min_idx) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 3( SP(CvHistogram,hist), VP(float,min_value), VP(float,max_value) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 3( SP(CvHistogram,hist), P(float*,min_value), VP(float,max_value) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 3( SP(CvHistogram,hist), VP(float,min_value), P(float*,max_value) ) ) 
DEFINE_FUNCTION( N(void), cvGetMinMaxHistValue, 3( SP(CvHistogram,hist), P(float*,min_value), P(float*,max_value) ) ) 


/* Normalizes histogram by dividing all bins by sum of the bins, multiplied by <factor>.
   After that sum of histogram bins is equal to <factor> */
// CVAPI(void)  cvNormalizeHist( CvHistogram* hist, double factor );
DEFINE_FUNCTION( N(void), cvNormalizeHist, 2( SP(CvHistogram,hist), V(double,factor) ) ) 


/* Clear all histogram bins that are below the threshold */
// CVAPI(void)  cvThreshHist( CvHistogram* hist, double threshold );
DEFINE_FUNCTION( N(void), cvThreshHist, 2( SP(CvHistogram,hist), V(double,threshold) ) ) 

// #define CV_COMP_CORREL        0
#pragma push_macro( "CV_COMP_CORREL" )
#undef CV_COMP_CORREL
static const int CV_COMP_CORREL
#pragma pop_macro( "CV_COMP_CORREL" )
	= CV_COMP_CORREL;
// #define CV_COMP_CHISQR        1
#pragma push_macro( "CV_COMP_CHISQR" )
#undef CV_COMP_CHISQR
static const int CV_COMP_CHISQR
#pragma pop_macro( "CV_COMP_CHISQR" )
	= CV_COMP_CHISQR;
// #define CV_COMP_INTERSECT     2
#pragma push_macro( "CV_COMP_INTERSECT" )
#undef CV_COMP_INTERSECT
static const int CV_COMP_INTERSECT
#pragma pop_macro( "CV_COMP_INTERSECT" )
	= CV_COMP_INTERSECT;
// #define CV_COMP_BHATTACHARYYA 3
#pragma push_macro( "CV_COMP_BHATTACHARYYA" )
#undef CV_COMP_BHATTACHARYYA
static const int CV_COMP_BHATTACHARYYA
#pragma pop_macro( "CV_COMP_BHATTACHARYYA" )
	= CV_COMP_BHATTACHARYYA;

/* Compares two histogram */
// CVAPI(double)  cvCompareHist( const CvHistogram* hist1,
//                               const CvHistogram* hist2,
//                               int method);
DEFINE_FUNCTION( V(double), cvCompareHist, 3( SP(CvHistogram,hist1), SP(CvHistogram,hist2), V(int,method) ) ) 

/* Copies one histogram to another. Destination histogram is created if
   the destination pointer is NULL */
// CVAPI(void)  cvCopyHist( const CvHistogram* src, CvHistogram** dst );
DEFINE_FUNCTION( N(void), cvCopyHist, 2( SP(CvHistogram,src), SPP(CvHistogram,dst) ) ) 


/* Calculates bayesian probabilistic histograms
   (each or src and dst is an array of <number> histograms */
// CVAPI(void)  cvCalcBayesianProb( CvHistogram** src, int number,
//                                 CvHistogram** dst);
DEFINE_FUNCTION( N(void), cvCalcBayesianProb, 3( SPP(CvHistogram,src), V(int,number), SPP(CvHistogram,dst) ) ) 

/* Calculates array histogram */
// CVAPI(void)  cvCalcArrHist( CvArr** arr, CvHistogram* hist,
//                             int accumulate CV_DEFAULT(0),
//                             const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvCalcArrHist, 4( MPA(UMemory,UNAME(CvArr),arr), SP(CvHistogram,hist), V(int,accumulate), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvCalcArrHist, 3( MPA(UMemory,UNAME(CvArr),arr), SP(CvHistogram,hist), V(int,accumulate) ) ) 
DEFINE_FUNCTION( N(void), cvCalcArrHist, 2( MPA(UMemory,UNAME(CvArr),arr), SP(CvHistogram,hist) ) ) 

// CV_INLINE  void  cvCalcHist( IplImage** image, CvHistogram* hist,
//                              int accumulate CV_DEFAULT(0),
//                              const CvArr* mask CV_DEFAULT(NULL) )
// {
//     cvCalcArrHist( (CvArr**)image, hist, accumulate, mask );
// }
DEFINE_FUNCTION( N(void), cvCalcHist, 4( SPP(IplImage,image), SP(CvHistogram,hist), V(int,accumulate), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvCalcHist, 3( SPP(IplImage,image), SP(CvHistogram,hist), V(int,accumulate) ) ) 
DEFINE_FUNCTION( N(void), cvCalcHist, 2( SPP(IplImage,image), SP(CvHistogram,hist) ) ) 

/* Calculates back project */
// CVAPI(void)  cvCalcArrBackProject( CvArr** image, CvArr* dst,
//                                    const CvHistogram* hist );
DEFINE_FUNCTION( N(void), cvCalcArrBackProject, 3( MPA(UMemory,UNAME(CvArr),image), MP(UMemory,CvArr,dst), SP(CvHistogram,hist) ) ) 
// #define  cvCalcBackProject(image, dst, hist) cvCalcArrBackProject((CvArr**)image, dst, hist)
// Unsupport : cvCalcBackProject


/* Does some sort of template matching but compares histograms of
   template and each window location */
// CVAPI(void)  cvCalcArrBackProjectPatch( CvArr** image, CvArr* dst, CvSize range,
//                                         CvHistogram* hist, int method,
//                                         double factor );
DEFINE_FUNCTION( N(void), cvCalcArrBackProjectPatch, 6( MPA(UMemory,UNAME(CvArr),image), MP(UMemory,CvArr,dst), S(CvSize,range), SP(CvHistogram,hist), V(int,method), V(double,factor) ) ) 
// #define  cvCalcBackProjectPatch( image, dst, range, hist, method, factor ) \
//      cvCalcArrBackProjectPatch( (CvArr**)image, dst, range, hist, method, factor )
// Unsupport : cvCalcBackProjectPatch


/* calculates probabilistic density (divides one histogram by another) */
// CVAPI(void)  cvCalcProbDensity( const CvHistogram* hist1, const CvHistogram* hist2,
//                                 CvHistogram* dst_hist, double scale CV_DEFAULT(255) );
DEFINE_FUNCTION( N(void), cvCalcProbDensity, 4( SP(CvHistogram,hist1), SP(CvHistogram,hist2), SP(CvHistogram,dst_hist), V(double,scale) ) ) 
DEFINE_FUNCTION( N(void), cvCalcProbDensity, 3( SP(CvHistogram,hist1), SP(CvHistogram,hist2), SP(CvHistogram,dst_hist) ) ) 

/* equalizes histogram of 8-bit single-channel image */
// CVAPI(void)  cvEqualizeHist( const CvArr* src, CvArr* dst );
DEFINE_FUNCTION( N(void), cvEqualizeHist, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 


// #define  CV_VALUE  1
#pragma push_macro( "CV_VALUE" )
#undef CV_VALUE
static const int CV_VALUE
#pragma pop_macro( "CV_VALUE" )
	= CV_VALUE;
// #define  CV_ARRAY  2
#pragma push_macro( "CV_ARRAY" )
#undef CV_ARRAY
static const int CV_ARRAY
#pragma pop_macro( "CV_ARRAY" )
	= CV_ARRAY;
/* Updates active contour in order to minimize its cummulative
   (internal and external) energy. */
// CVAPI(void)  cvSnakeImage( const IplImage* image, CvPoint* points,
//                            int  length, float* alpha,
//                            float* beta, float* gamma,
//                            int coeff_usage, CvSize  win,
//                            CvTermCriteria criteria, int calc_gradient CV_DEFAULT(1));
DEFINE_FUNCTION( N(void), cvSnakeImage, 10( SP(IplImage,image), SP(CvPoint,points), V(int,length), VP(float,alpha), VP(float,beta), VP(float,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria), V(int,calc_gradient) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 10( SP(IplImage,image), SP(CvPoint,points), V(int,length), P(float*,alpha), VP(float,beta), VP(float,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria), V(int,calc_gradient) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 10( SP(IplImage,image), SP(CvPoint,points), V(int,length), VP(float,alpha), P(float*,beta), VP(float,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria), V(int,calc_gradient) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 10( SP(IplImage,image), SP(CvPoint,points), V(int,length), P(float*,alpha), P(float*,beta), VP(float,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria), V(int,calc_gradient) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 10( SP(IplImage,image), SP(CvPoint,points), V(int,length), VP(float,alpha), VP(float,beta), P(float*,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria), V(int,calc_gradient) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 10( SP(IplImage,image), SP(CvPoint,points), V(int,length), P(float*,alpha), VP(float,beta), P(float*,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria), V(int,calc_gradient) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 10( SP(IplImage,image), SP(CvPoint,points), V(int,length), VP(float,alpha), P(float*,beta), P(float*,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria), V(int,calc_gradient) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 10( SP(IplImage,image), SP(CvPoint,points), V(int,length), P(float*,alpha), P(float*,beta), P(float*,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria), V(int,calc_gradient) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 9( SP(IplImage,image), SP(CvPoint,points), V(int,length), VP(float,alpha), VP(float,beta), VP(float,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 9( SP(IplImage,image), SP(CvPoint,points), V(int,length), P(float*,alpha), VP(float,beta), VP(float,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 9( SP(IplImage,image), SP(CvPoint,points), V(int,length), VP(float,alpha), P(float*,beta), VP(float,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 9( SP(IplImage,image), SP(CvPoint,points), V(int,length), P(float*,alpha), P(float*,beta), VP(float,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 9( SP(IplImage,image), SP(CvPoint,points), V(int,length), VP(float,alpha), VP(float,beta), P(float*,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 9( SP(IplImage,image), SP(CvPoint,points), V(int,length), P(float*,alpha), VP(float,beta), P(float*,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 9( SP(IplImage,image), SP(CvPoint,points), V(int,length), VP(float,alpha), P(float*,beta), P(float*,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria) ) ) 
DEFINE_FUNCTION( N(void), cvSnakeImage, 9( SP(IplImage,image), SP(CvPoint,points), V(int,length), P(float*,alpha), P(float*,beta), P(float*,gamma), V(int,coeff_usage), S(CvSize,win), S(CvTermCriteria,criteria) ) ) 

/* Calculates the cooficients of the homography matrix */
// CVAPI(void)  cvCalcImageHomography( float* line, CvPoint3D32f* center,
//                                     float* intrinsic, float* homography );
DEFINE_FUNCTION( N(void), cvCalcImageHomography, 4( VP(float,line), SP(CvPoint3D32f,center), VP(float,intrinsic), VP(float,homography) ) ) 
DEFINE_FUNCTION( N(void), cvCalcImageHomography, 4( P(float*,line), SP(CvPoint3D32f,center), VP(float,intrinsic), VP(float,homography) ) ) 
DEFINE_FUNCTION( N(void), cvCalcImageHomography, 4( VP(float,line), SP(CvPoint3D32f,center), P(float*,intrinsic), VP(float,homography) ) ) 
DEFINE_FUNCTION( N(void), cvCalcImageHomography, 4( P(float*,line), SP(CvPoint3D32f,center), P(float*,intrinsic), VP(float,homography) ) ) 
DEFINE_FUNCTION( N(void), cvCalcImageHomography, 4( VP(float,line), SP(CvPoint3D32f,center), VP(float,intrinsic), P(float*,homography) ) ) 
DEFINE_FUNCTION( N(void), cvCalcImageHomography, 4( P(float*,line), SP(CvPoint3D32f,center), VP(float,intrinsic), P(float*,homography) ) ) 
DEFINE_FUNCTION( N(void), cvCalcImageHomography, 4( VP(float,line), SP(CvPoint3D32f,center), P(float*,intrinsic), P(float*,homography) ) ) 
DEFINE_FUNCTION( N(void), cvCalcImageHomography, 4( P(float*,line), SP(CvPoint3D32f,center), P(float*,intrinsic), P(float*,homography) ) ) 

// #define CV_DIST_MASK_3   3
#pragma push_macro( "CV_DIST_MASK_3" )
#undef CV_DIST_MASK_3
static const int CV_DIST_MASK_3
#pragma pop_macro( "CV_DIST_MASK_3" )
	= CV_DIST_MASK_3;
// #define CV_DIST_MASK_5   5
#pragma push_macro( "CV_DIST_MASK_5" )
#undef CV_DIST_MASK_5
static const int CV_DIST_MASK_5
#pragma pop_macro( "CV_DIST_MASK_5" )
	= CV_DIST_MASK_5;
// #define CV_DIST_MASK_PRECISE 0
#pragma push_macro( "CV_DIST_MASK_PRECISE" )
#undef CV_DIST_MASK_PRECISE
static const int CV_DIST_MASK_PRECISE
#pragma pop_macro( "CV_DIST_MASK_PRECISE" )
	= CV_DIST_MASK_PRECISE;

/* Applies distance transform to binary image */
// CVAPI(void)  cvDistTransform( const CvArr* src, CvArr* dst,
//                               int distance_type CV_DEFAULT(CV_DIST_L2),
//                               int mask_size CV_DEFAULT(3),
//                               const float* mask CV_DEFAULT(NULL),
//                               CvArr* labels CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvDistTransform, 6( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,distance_type), V(int,mask_size), VP(float,mask), MP(UMemory,CvArr,labels) ) ) 
DEFINE_FUNCTION( N(void), cvDistTransform, 6( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,distance_type), V(int,mask_size), P(const float*,mask), MP(UMemory,CvArr,labels) ) ) 
DEFINE_FUNCTION( N(void), cvDistTransform, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,distance_type), V(int,mask_size), VP(float,mask) ) ) 
DEFINE_FUNCTION( N(void), cvDistTransform, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,distance_type), V(int,mask_size), P(const float*,mask) ) ) 
DEFINE_FUNCTION( N(void), cvDistTransform, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,distance_type), V(int,mask_size) ) ) 
DEFINE_FUNCTION( N(void), cvDistTransform, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,distance_type) ) ) 
DEFINE_FUNCTION( N(void), cvDistTransform, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 


/* Types of thresholding */
// #define CV_THRESH_BINARY      0  /* value = value > threshold ? max_value : 0       */
#pragma push_macro( "CV_THRESH_BINARY" )
#undef CV_THRESH_BINARY
static const int CV_THRESH_BINARY
#pragma pop_macro( "CV_THRESH_BINARY" )
	= CV_THRESH_BINARY;
// #define CV_THRESH_BINARY_INV  1  /* value = value > threshold ? 0 : max_value       */
#pragma push_macro( "CV_THRESH_BINARY_INV" )
#undef CV_THRESH_BINARY_INV
static const int CV_THRESH_BINARY_INV
#pragma pop_macro( "CV_THRESH_BINARY_INV" )
	= CV_THRESH_BINARY_INV;
// #define CV_THRESH_TRUNC       2  /* value = value > threshold ? threshold : value   */
#pragma push_macro( "CV_THRESH_TRUNC" )
#undef CV_THRESH_TRUNC
static const int CV_THRESH_TRUNC
#pragma pop_macro( "CV_THRESH_TRUNC" )
	= CV_THRESH_TRUNC;
// #define CV_THRESH_TOZERO      3  /* value = value > threshold ? value : 0           */
#pragma push_macro( "CV_THRESH_TOZERO" )
#undef CV_THRESH_TOZERO
static const int CV_THRESH_TOZERO
#pragma pop_macro( "CV_THRESH_TOZERO" )
	= CV_THRESH_TOZERO;
// #define CV_THRESH_TOZERO_INV  4  /* value = value > threshold ? 0 : value           */
#pragma push_macro( "CV_THRESH_TOZERO_INV" )
#undef CV_THRESH_TOZERO_INV
static const int CV_THRESH_TOZERO_INV
#pragma pop_macro( "CV_THRESH_TOZERO_INV" )
	= CV_THRESH_TOZERO_INV;
// #define CV_THRESH_MASK        7
#pragma push_macro( "CV_THRESH_MASK" )
#undef CV_THRESH_MASK
static const int CV_THRESH_MASK
#pragma pop_macro( "CV_THRESH_MASK" )
	= CV_THRESH_MASK;

// #define CV_THRESH_OTSU        8  /* use Otsu algorithm to choose the optimal threshold value;
//                                     combine the flag with one of the above CV_THRESH_* values */
#pragma push_macro( "CV_THRESH_OTSU" )
#undef CV_THRESH_OTSU
static const int CV_THRESH_OTSU
#pragma pop_macro( "CV_THRESH_OTSU" )
	= CV_THRESH_OTSU;

/* Applies fixed-level threshold to grayscale image.
   This is a basic operation applied before retrieving contours */
// CVAPI(void)  cvThreshold( const CvArr*  src, CvArr*  dst,
//                           double  threshold, double  max_value,
//                           int threshold_type );
DEFINE_FUNCTION( N(void), cvThreshold, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,threshold), V(double,max_value), V(int,threshold_type) ) ) 

// #define CV_ADAPTIVE_THRESH_MEAN_C  0
#pragma push_macro( "CV_ADAPTIVE_THRESH_MEAN_C" )
#undef CV_ADAPTIVE_THRESH_MEAN_C
static const int CV_ADAPTIVE_THRESH_MEAN_C
#pragma pop_macro( "CV_ADAPTIVE_THRESH_MEAN_C" )
	= CV_ADAPTIVE_THRESH_MEAN_C;
// #define CV_ADAPTIVE_THRESH_GAUSSIAN_C  1
#pragma push_macro( "CV_ADAPTIVE_THRESH_GAUSSIAN_C" )
#undef CV_ADAPTIVE_THRESH_GAUSSIAN_C
static const int CV_ADAPTIVE_THRESH_GAUSSIAN_C
#pragma pop_macro( "CV_ADAPTIVE_THRESH_GAUSSIAN_C" )
	= CV_ADAPTIVE_THRESH_GAUSSIAN_C;

/* Applies adaptive threshold to grayscale image.
   The two parameters for methods CV_ADAPTIVE_THRESH_MEAN_C and
   CV_ADAPTIVE_THRESH_GAUSSIAN_C are:
   neighborhood size (3, 5, 7 etc.),
   and a constant subtracted from mean (...,-3,-2,-1,0,1,2,3,...) */
// CVAPI(void)  cvAdaptiveThreshold( const CvArr* src, CvArr* dst, double max_value,
//                                   int adaptive_method CV_DEFAULT(CV_ADAPTIVE_THRESH_MEAN_C),
//                                   int threshold_type CV_DEFAULT(CV_THRESH_BINARY),
//                                   int block_size CV_DEFAULT(3),
//                                   double param1 CV_DEFAULT(5));
DEFINE_FUNCTION( N(void), cvAdaptiveThreshold, 7( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,max_value), V(int,adaptive_method), V(int,threshold_type), V(int,block_size), V(double,param1) ) ) 
DEFINE_FUNCTION( N(void), cvAdaptiveThreshold, 6( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,max_value), V(int,adaptive_method), V(int,threshold_type), V(int,block_size) ) ) 
DEFINE_FUNCTION( N(void), cvAdaptiveThreshold, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,max_value), V(int,adaptive_method), V(int,threshold_type) ) ) 
DEFINE_FUNCTION( N(void), cvAdaptiveThreshold, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,max_value), V(int,adaptive_method) ) ) 
DEFINE_FUNCTION( N(void), cvAdaptiveThreshold, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,max_value) ) ) 

// #define CV_FLOODFILL_FIXED_RANGE (1 << 16)
#pragma push_macro( "CV_FLOODFILL_FIXED_RANGE" )
#undef CV_FLOODFILL_FIXED_RANGE
static const int CV_FLOODFILL_FIXED_RANGE
#pragma pop_macro( "CV_FLOODFILL_FIXED_RANGE" )
	= CV_FLOODFILL_FIXED_RANGE;
// #define CV_FLOODFILL_MASK_ONLY   (1 << 17)
#pragma push_macro( "CV_FLOODFILL_MASK_ONLY" )
#undef CV_FLOODFILL_MASK_ONLY
static const int CV_FLOODFILL_MASK_ONLY
#pragma pop_macro( "CV_FLOODFILL_MASK_ONLY" )
	= CV_FLOODFILL_MASK_ONLY;

/* Fills the connected component until the color difference gets large enough */
// CVAPI(void)  cvFloodFill( CvArr* image, CvPoint seed_point,
//                           CvScalar new_val, CvScalar lo_diff CV_DEFAULT(cvScalarAll(0)),
//                           CvScalar up_diff CV_DEFAULT(cvScalarAll(0)),
//                           CvConnectedComp* comp CV_DEFAULT(NULL),
//                           int flags CV_DEFAULT(4),
//                           CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvFloodFill, 8( MP(UMemory,CvArr,image), S(CvPoint,seed_point), S(CvScalar,new_val), S(CvScalar,lo_diff), S(CvScalar,up_diff), SP(CvConnectedComp,comp), V(int,flags), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvFloodFill, 7( MP(UMemory,CvArr,image), S(CvPoint,seed_point), S(CvScalar,new_val), S(CvScalar,lo_diff), S(CvScalar,up_diff), SP(CvConnectedComp,comp), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvFloodFill, 6( MP(UMemory,CvArr,image), S(CvPoint,seed_point), S(CvScalar,new_val), S(CvScalar,lo_diff), S(CvScalar,up_diff), SP(CvConnectedComp,comp) ) ) 
DEFINE_FUNCTION( N(void), cvFloodFill, 5( MP(UMemory,CvArr,image), S(CvPoint,seed_point), S(CvScalar,new_val), S(CvScalar,lo_diff), S(CvScalar,up_diff) ) ) 
DEFINE_FUNCTION( N(void), cvFloodFill, 4( MP(UMemory,CvArr,image), S(CvPoint,seed_point), S(CvScalar,new_val), S(CvScalar,lo_diff) ) ) 
DEFINE_FUNCTION( N(void), cvFloodFill, 3( MP(UMemory,CvArr,image), S(CvPoint,seed_point), S(CvScalar,new_val) ) ) 

/****************************************************************************************\
*                                  Feature detection                                     *
\****************************************************************************************/

// #define CV_CANNY_L2_GRADIENT  (1 << 31)
#pragma push_macro( "CV_CANNY_L2_GRADIENT" )
#undef CV_CANNY_L2_GRADIENT
static const int CV_CANNY_L2_GRADIENT
#pragma pop_macro( "CV_CANNY_L2_GRADIENT" )
	= CV_CANNY_L2_GRADIENT;

/* Runs canny edge detector */
// CVAPI(void)  cvCanny( const CvArr* image, CvArr* edges, double threshold1,
//                       double threshold2, int  aperture_size CV_DEFAULT(3) );
DEFINE_FUNCTION( N(void), cvCanny, 5( MP(UMemory,CvArr,image), MP(UMemory,CvArr,edges), V(double,threshold1), V(double,threshold2), V(int,aperture_size) ) ) 
DEFINE_FUNCTION( N(void), cvCanny, 4( MP(UMemory,CvArr,image), MP(UMemory,CvArr,edges), V(double,threshold1), V(double,threshold2) ) ) 

/* Calculates constraint image for corner detection
   Dx^2 * Dyy + Dxx * Dy^2 - 2 * Dx * Dy * Dxy.
   Applying threshold to the result gives coordinates of corners */
// CVAPI(void) cvPreCornerDetect( const CvArr* image, CvArr* corners,
//                               int aperture_size CV_DEFAULT(3) );
DEFINE_FUNCTION( N(void), cvPreCornerDetect, 3( MP(UMemory,CvArr,image), MP(UMemory,CvArr,corners), V(int,aperture_size) ) ) 
DEFINE_FUNCTION( N(void), cvPreCornerDetect, 2( MP(UMemory,CvArr,image), MP(UMemory,CvArr,corners) ) ) 

/* Calculates eigen values and vectors of 2x2
   gradient covariation matrix at every image pixel */
// CVAPI(void)  cvCornerEigenValsAndVecs( const CvArr* image, CvArr* eigenvv,
//                                       int block_size, int aperture_size CV_DEFAULT(3) );
DEFINE_FUNCTION( N(void), cvCornerEigenValsAndVecs, 4( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eigenvv), V(int,block_size), V(int,aperture_size) ) ) 
DEFINE_FUNCTION( N(void), cvCornerEigenValsAndVecs, 3( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eigenvv), V(int,block_size) ) ) 

/* Calculates minimal eigenvalue for 2x2 gradient covariation matrix at
   every image pixel */
// CVAPI(void)  cvCornerMinEigenVal( const CvArr* image, CvArr* eigenval,
//                                  int block_size, int aperture_size CV_DEFAULT(3) );
DEFINE_FUNCTION( N(void), cvCornerMinEigenVal, 4( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eigenval), V(int,block_size), V(int,aperture_size) ) ) 
DEFINE_FUNCTION( N(void), cvCornerMinEigenVal, 3( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eigenval), V(int,block_size) ) ) 

/* Harris corner detector:
   Calculates det(M) - k*(trace(M)^2), where M is 2x2 gradient covariation matrix for each pixel */
// CVAPI(void)  cvCornerHarris( const CvArr* image, CvArr* harris_responce,
//                              int block_size, int aperture_size CV_DEFAULT(3),
//                              double k CV_DEFAULT(0.04) );
DEFINE_FUNCTION( N(void), cvCornerHarris, 5( MP(UMemory,CvArr,image), MP(UMemory,CvArr,harris_responce), V(int,block_size), V(int,aperture_size), V(double,k) ) ) 
DEFINE_FUNCTION( N(void), cvCornerHarris, 4( MP(UMemory,CvArr,image), MP(UMemory,CvArr,harris_responce), V(int,block_size), V(int,aperture_size) ) ) 
DEFINE_FUNCTION( N(void), cvCornerHarris, 3( MP(UMemory,CvArr,image), MP(UMemory,CvArr,harris_responce), V(int,block_size) ) ) 

/* Adjust corner position using some sort of gradient search */
// CVAPI(void)  cvFindCornerSubPix( const CvArr* image, CvPoint2D32f* corners,
//                                  int count, CvSize win, CvSize zero_zone,
//                                  CvTermCriteria  criteria );
DEFINE_FUNCTION( N(void), cvFindCornerSubPix, 6( MP(UMemory,CvArr,image), SP(CvPoint2D32f,corners), V(int,count), S(CvSize,win), S(CvSize,zero_zone), S(CvTermCriteria,criteria) ) ) 

/* Finds a sparse set of points within the selected region
   that seem to be easy to track */
// CVAPI(void)  cvGoodFeaturesToTrack( const CvArr* image, CvArr* eig_image,
//                                    CvArr* temp_image, CvPoint2D32f* corners,
//                                    int* corner_count, double  quality_level,
//                                    double  min_distance,
//                                    const CvArr* mask CV_DEFAULT(NULL),
//                                    int block_size CV_DEFAULT(3),
//                                    int use_harris CV_DEFAULT(0),
//                                    double k CV_DEFAULT(0.04) );
DEFINE_FUNCTION( N(void), cvGoodFeaturesToTrack, 11( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eig_image), MP(UMemory,CvArr,temp_image), SP(CvPoint2D32f,corners), VP(int,corner_count), V(double,quality_level), V(double,min_distance), MP(UMemory,CvArr,mask), V(int,block_size), V(int,use_harris), V(double,k) ) ) 
DEFINE_FUNCTION( N(void), cvGoodFeaturesToTrack, 11( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eig_image), MP(UMemory,CvArr,temp_image), SP(CvPoint2D32f,corners), P(int*,corner_count), V(double,quality_level), V(double,min_distance), MP(UMemory,CvArr,mask), V(int,block_size), V(int,use_harris), V(double,k) ) ) 
DEFINE_FUNCTION( N(void), cvGoodFeaturesToTrack, 10( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eig_image), MP(UMemory,CvArr,temp_image), SP(CvPoint2D32f,corners), VP(int,corner_count), V(double,quality_level), V(double,min_distance), MP(UMemory,CvArr,mask), V(int,block_size), V(int,use_harris) ) ) 
DEFINE_FUNCTION( N(void), cvGoodFeaturesToTrack, 10( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eig_image), MP(UMemory,CvArr,temp_image), SP(CvPoint2D32f,corners), P(int*,corner_count), V(double,quality_level), V(double,min_distance), MP(UMemory,CvArr,mask), V(int,block_size), V(int,use_harris) ) ) 
DEFINE_FUNCTION( N(void), cvGoodFeaturesToTrack, 9( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eig_image), MP(UMemory,CvArr,temp_image), SP(CvPoint2D32f,corners), VP(int,corner_count), V(double,quality_level), V(double,min_distance), MP(UMemory,CvArr,mask), V(int,block_size) ) ) 
DEFINE_FUNCTION( N(void), cvGoodFeaturesToTrack, 9( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eig_image), MP(UMemory,CvArr,temp_image), SP(CvPoint2D32f,corners), P(int*,corner_count), V(double,quality_level), V(double,min_distance), MP(UMemory,CvArr,mask), V(int,block_size) ) ) 
DEFINE_FUNCTION( N(void), cvGoodFeaturesToTrack, 8( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eig_image), MP(UMemory,CvArr,temp_image), SP(CvPoint2D32f,corners), VP(int,corner_count), V(double,quality_level), V(double,min_distance), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvGoodFeaturesToTrack, 8( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eig_image), MP(UMemory,CvArr,temp_image), SP(CvPoint2D32f,corners), P(int*,corner_count), V(double,quality_level), V(double,min_distance), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvGoodFeaturesToTrack, 7( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eig_image), MP(UMemory,CvArr,temp_image), SP(CvPoint2D32f,corners), VP(int,corner_count), V(double,quality_level), V(double,min_distance) ) ) 
DEFINE_FUNCTION( N(void), cvGoodFeaturesToTrack, 7( MP(UMemory,CvArr,image), MP(UMemory,CvArr,eig_image), MP(UMemory,CvArr,temp_image), SP(CvPoint2D32f,corners), P(int*,corner_count), V(double,quality_level), V(double,min_distance) ) ) 

// #define CV_HOUGH_STANDARD 0
#pragma push_macro( "CV_HOUGH_STANDARD" )
#undef CV_HOUGH_STANDARD
static const int CV_HOUGH_STANDARD
#pragma pop_macro( "CV_HOUGH_STANDARD" )
	= CV_HOUGH_STANDARD;
// #define CV_HOUGH_PROBABILISTIC 1
#pragma push_macro( "CV_HOUGH_PROBABILISTIC" )
#undef CV_HOUGH_PROBABILISTIC
static const int CV_HOUGH_PROBABILISTIC
#pragma pop_macro( "CV_HOUGH_PROBABILISTIC" )
	= CV_HOUGH_PROBABILISTIC;
// #define CV_HOUGH_MULTI_SCALE 2
#pragma push_macro( "CV_HOUGH_MULTI_SCALE" )
#undef CV_HOUGH_MULTI_SCALE
static const int CV_HOUGH_MULTI_SCALE
#pragma pop_macro( "CV_HOUGH_MULTI_SCALE" )
	= CV_HOUGH_MULTI_SCALE;
// #define CV_HOUGH_GRADIENT 3
#pragma push_macro( "CV_HOUGH_GRADIENT" )
#undef CV_HOUGH_GRADIENT
static const int CV_HOUGH_GRADIENT
#pragma pop_macro( "CV_HOUGH_GRADIENT" )
	= CV_HOUGH_GRADIENT;

/* Finds lines on binary image using one of several methods.
   line_storage is either memory storage or 1 x <max number of lines> CvMat, its
   number of columns is changed by the function.
   method is one of CV_HOUGH_*;
   rho, theta and threshold are used for each of those methods;
   param1 ~ line length, param2 ~ line gap - for probabilistic,
   param1 ~ srn, param2 ~ stn - for multi-scale */
// CVAPI(CvSeq*)  cvHoughLines2( CvArr* image, void* line_storage, int method, 
//                               double rho, double theta, int threshold,
//                               double param1 CV_DEFAULT(0), double param2 CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvSeq), cvHoughLines2, 8( MP(UMemory,CvArr,image), P(void*,line_storage), V(int,method), V(double,rho), V(double,theta), V(int,threshold), V(double,param1), V(double,param2) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvHoughLines2, 7( MP(UMemory,CvArr,image), P(void*,line_storage), V(int,method), V(double,rho), V(double,theta), V(int,threshold), V(double,param1) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvHoughLines2, 6( MP(UMemory,CvArr,image), P(void*,line_storage), V(int,method), V(double,rho), V(double,theta), V(int,threshold) ) ) 

/* Finds circles in the image */
// CVAPI(CvSeq*) cvHoughCircles( CvArr* image, void* circle_storage,
//                               int method, double dp, double min_dist,
//                               double param1 CV_DEFAULT(100),
//                               double param2 CV_DEFAULT(100),
//                               int min_radius CV_DEFAULT(0),
//                               int max_radius CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvSeq), cvHoughCircles, 9( MP(UMemory,CvArr,image), P(void*,circle_storage), V(int,method), V(double,dp), V(double,min_dist), V(double,param1), V(double,param2), V(int,min_radius), V(int,max_radius) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvHoughCircles, 8( MP(UMemory,CvArr,image), P(void*,circle_storage), V(int,method), V(double,dp), V(double,min_dist), V(double,param1), V(double,param2), V(int,min_radius) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvHoughCircles, 7( MP(UMemory,CvArr,image), P(void*,circle_storage), V(int,method), V(double,dp), V(double,min_dist), V(double,param1), V(double,param2) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvHoughCircles, 6( MP(UMemory,CvArr,image), P(void*,circle_storage), V(int,method), V(double,dp), V(double,min_dist), V(double,param1) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvHoughCircles, 5( MP(UMemory,CvArr,image), P(void*,circle_storage), V(int,method), V(double,dp), V(double,min_dist) ) ) 

/* Fits a line into set of 2d or 3d points in a robust way (M-estimator technique) */
// CVAPI(void)  cvFitLine( const CvArr* points, int dist_type, double param,
//                         double reps, double aeps, float* line );
DEFINE_FUNCTION( N(void), cvFitLine, 6( MP(UMemory,CvArr,points), V(int,dist_type), V(double,param), V(double,reps), V(double,aeps), VP(float,line) ) ) 
DEFINE_FUNCTION( N(void), cvFitLine, 6( MP(UMemory,CvArr,points), V(int,dist_type), V(double,param), V(double,reps), V(double,aeps), P(float*,line) ) ) 

/****************************************************************************************\
*                         Haar-like Object Detection functions                           *
\****************************************************************************************/

/* Loads haar classifier cascade from a directory.
   It is obsolete: convert your cascade to xml and use cvLoad instead */
// CVAPI(CvHaarClassifierCascade*) cvLoadHaarClassifierCascade(
//                     const char* directory, CvSize orig_window_size);
DEFINE_FUNCTION( SP(CvHaarClassifierCascade), cvLoadHaarClassifierCascade, 2( T(const,directory), S(CvSize,orig_window_size) ) ) 

// CVAPI(void) cvReleaseHaarClassifierCascade( CvHaarClassifierCascade** cascade );
DEFINE_FUNCTION( N(void), cvReleaseHaarClassifierCascade, 1( SPP(CvHaarClassifierCascade,cascade) ) ) 

// #define CV_HAAR_DO_CANNY_PRUNING 1
#pragma push_macro( "CV_HAAR_DO_CANNY_PRUNING" )
#undef CV_HAAR_DO_CANNY_PRUNING
static const int CV_HAAR_DO_CANNY_PRUNING
#pragma pop_macro( "CV_HAAR_DO_CANNY_PRUNING" )
	= CV_HAAR_DO_CANNY_PRUNING;
// #define CV_HAAR_SCALE_IMAGE      2
#pragma push_macro( "CV_HAAR_SCALE_IMAGE" )
#undef CV_HAAR_SCALE_IMAGE
static const int CV_HAAR_SCALE_IMAGE
#pragma pop_macro( "CV_HAAR_SCALE_IMAGE" )
	= CV_HAAR_SCALE_IMAGE;

// CVAPI(CvSeq*) cvHaarDetectObjects( const CvArr* image,
//                      CvHaarClassifierCascade* cascade,
//                      CvMemStorage* storage, double scale_factor CV_DEFAULT(1.1),
//                      int min_neighbors CV_DEFAULT(3), int flags CV_DEFAULT(0),
//                      CvSize min_size CV_DEFAULT(cvSize(0,0)));
DEFINE_FUNCTION( SP(CvSeq), cvHaarDetectObjects, 7( MP(UMemory,CvArr,image), SP(CvHaarClassifierCascade,cascade), SP(CvMemStorage,storage), V(double,scale_factor), V(int,min_neighbors), V(int,flags), S(CvSize,min_size) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvHaarDetectObjects, 6( MP(UMemory,CvArr,image), SP(CvHaarClassifierCascade,cascade), SP(CvMemStorage,storage), V(double,scale_factor), V(int,min_neighbors), V(int,flags) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvHaarDetectObjects, 5( MP(UMemory,CvArr,image), SP(CvHaarClassifierCascade,cascade), SP(CvMemStorage,storage), V(double,scale_factor), V(int,min_neighbors) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvHaarDetectObjects, 4( MP(UMemory,CvArr,image), SP(CvHaarClassifierCascade,cascade), SP(CvMemStorage,storage), V(double,scale_factor) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvHaarDetectObjects, 3( MP(UMemory,CvArr,image), SP(CvHaarClassifierCascade,cascade), SP(CvMemStorage,storage) ) ) 

/* sets images for haar classifier cascade */
// CVAPI(void) cvSetImagesForHaarClassifierCascade( CvHaarClassifierCascade* cascade,
//                                                 const CvArr* sum, const CvArr* sqsum,
//                                                 const CvArr* tilted_sum, double scale );
DEFINE_FUNCTION( N(void), cvSetImagesForHaarClassifierCascade, 5( SP(CvHaarClassifierCascade,cascade), MP(UMemory,CvArr,sum), MP(UMemory,CvArr,sqsum), MP(UMemory,CvArr,tilted_sum), V(double,scale) ) ) 

/* runs the cascade on the specified window */
// CVAPI(int) cvRunHaarClassifierCascade( CvHaarClassifierCascade* cascade,
//                                       CvPoint pt, int start_stage CV_DEFAULT(0));
DEFINE_FUNCTION( V(int), cvRunHaarClassifierCascade, 3( SP(CvHaarClassifierCascade,cascade), S(CvPoint,pt), V(int,start_stage) ) ) 
DEFINE_FUNCTION( V(int), cvRunHaarClassifierCascade, 2( SP(CvHaarClassifierCascade,cascade), S(CvPoint,pt) ) ) 

/****************************************************************************************\
*                     Camera Calibration and Rectification functions                     *
\****************************************************************************************/

/* transforms the input image to compensate lens distortion */
// CVAPI(void) cvUndistort2( const CvArr* src, CvArr* dst,
//                           const CvMat* intrinsic_matrix,
//                           const CvMat* distortion_coeffs );
DEFINE_FUNCTION( N(void), cvUndistort2, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs) ) ) 

/* computes transformation map from intrinsic camera parameters
   that can used by cvRemap */
// CVAPI(void) cvInitUndistortMap( const CvMat* intrinsic_matrix,
//                                 const CvMat* distortion_coeffs,
//                                 CvArr* mapx, CvArr* mapy );
DEFINE_FUNCTION( N(void), cvInitUndistortMap, 4( SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), MP(UMemory,CvArr,mapx), MP(UMemory,CvArr,mapy) ) ) 

/* converts rotation vector to rotation matrix or vice versa */
// CVAPI(int) cvRodrigues2( const CvMat* src, CvMat* dst,
//                          CvMat* jacobian CV_DEFAULT(0) );
DEFINE_FUNCTION( V(int), cvRodrigues2, 3( SP(CvMat,src), SP(CvMat,dst), SP(CvMat,jacobian) ) ) 
DEFINE_FUNCTION( V(int), cvRodrigues2, 2( SP(CvMat,src), SP(CvMat,dst) ) ) 

/* finds perspective transformation between the object plane and image (view) plane */
// CVAPI(void) cvFindHomography( const CvMat* src_points,
//                               const CvMat* dst_points,
//                               CvMat* homography );
DEFINE_FUNCTION( N(void), cvFindHomography, 3( SP(CvMat,src_points), SP(CvMat,dst_points), SP(CvMat,homography) ) ) 

/* projects object points to the view plane using
   the specified extrinsic and intrinsic camera parameters */
// CVAPI(void) cvProjectPoints2( const CvMat* object_points, const CvMat* rotation_vector,
//                               const CvMat* translation_vector, const CvMat* intrinsic_matrix,
//                               const CvMat* distortion_coeffs, CvMat* image_points,
//                               CvMat* dpdrot CV_DEFAULT(NULL), CvMat* dpdt CV_DEFAULT(NULL),
//                               CvMat* dpdf CV_DEFAULT(NULL), CvMat* dpdc CV_DEFAULT(NULL),
//                               CvMat* dpddist CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvProjectPoints2, 11( SP(CvMat,object_points), SP(CvMat,rotation_vector), SP(CvMat,translation_vector), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), SP(CvMat,image_points), SP(CvMat,dpdrot), SP(CvMat,dpdt), SP(CvMat,dpdf), SP(CvMat,dpdc), SP(CvMat,dpddist) ) ) 
DEFINE_FUNCTION( N(void), cvProjectPoints2, 10( SP(CvMat,object_points), SP(CvMat,rotation_vector), SP(CvMat,translation_vector), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), SP(CvMat,image_points), SP(CvMat,dpdrot), SP(CvMat,dpdt), SP(CvMat,dpdf), SP(CvMat,dpdc) ) ) 
DEFINE_FUNCTION( N(void), cvProjectPoints2, 9( SP(CvMat,object_points), SP(CvMat,rotation_vector), SP(CvMat,translation_vector), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), SP(CvMat,image_points), SP(CvMat,dpdrot), SP(CvMat,dpdt), SP(CvMat,dpdf) ) ) 
DEFINE_FUNCTION( N(void), cvProjectPoints2, 8( SP(CvMat,object_points), SP(CvMat,rotation_vector), SP(CvMat,translation_vector), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), SP(CvMat,image_points), SP(CvMat,dpdrot), SP(CvMat,dpdt) ) ) 
DEFINE_FUNCTION( N(void), cvProjectPoints2, 7( SP(CvMat,object_points), SP(CvMat,rotation_vector), SP(CvMat,translation_vector), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), SP(CvMat,image_points), SP(CvMat,dpdrot) ) ) 
DEFINE_FUNCTION( N(void), cvProjectPoints2, 6( SP(CvMat,object_points), SP(CvMat,rotation_vector), SP(CvMat,translation_vector), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), SP(CvMat,image_points) ) ) 

/* finds extrinsic camera parameters from
   a few known corresponding point pairs and intrinsic parameters */
// CVAPI(void) cvFindExtrinsicCameraParams2( const CvMat* object_points,
//                                           const CvMat* image_points,
//                                           const CvMat* intrinsic_matrix,
//                                           const CvMat* distortion_coeffs,
//                                           CvMat* rotation_vector,
//                                           CvMat* translation_vector );
DEFINE_FUNCTION( N(void), cvFindExtrinsicCameraParams2, 6( SP(CvMat,object_points), SP(CvMat,image_points), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), SP(CvMat,rotation_vector), SP(CvMat,translation_vector) ) ) 

// #define CV_CALIB_USE_INTRINSIC_GUESS  1
#pragma push_macro( "CV_CALIB_USE_INTRINSIC_GUESS" )
#undef CV_CALIB_USE_INTRINSIC_GUESS
static const int CV_CALIB_USE_INTRINSIC_GUESS
#pragma pop_macro( "CV_CALIB_USE_INTRINSIC_GUESS" )
	= CV_CALIB_USE_INTRINSIC_GUESS;
// #define CV_CALIB_FIX_ASPECT_RATIO     2
#pragma push_macro( "CV_CALIB_FIX_ASPECT_RATIO" )
#undef CV_CALIB_FIX_ASPECT_RATIO
static const int CV_CALIB_FIX_ASPECT_RATIO
#pragma pop_macro( "CV_CALIB_FIX_ASPECT_RATIO" )
	= CV_CALIB_FIX_ASPECT_RATIO;
// #define CV_CALIB_FIX_PRINCIPAL_POINT  4
#pragma push_macro( "CV_CALIB_FIX_PRINCIPAL_POINT" )
#undef CV_CALIB_FIX_PRINCIPAL_POINT
static const int CV_CALIB_FIX_PRINCIPAL_POINT
#pragma pop_macro( "CV_CALIB_FIX_PRINCIPAL_POINT" )
	= CV_CALIB_FIX_PRINCIPAL_POINT;
// #define CV_CALIB_ZERO_TANGENT_DIST    8
#pragma push_macro( "CV_CALIB_ZERO_TANGENT_DIST" )
#undef CV_CALIB_ZERO_TANGENT_DIST
static const int CV_CALIB_ZERO_TANGENT_DIST
#pragma pop_macro( "CV_CALIB_ZERO_TANGENT_DIST" )
	= CV_CALIB_ZERO_TANGENT_DIST;

/* finds intrinsic and extrinsic camera parameters
   from a few views of known calibration pattern */
// CVAPI(void) cvCalibrateCamera2( const CvMat* object_points,
//                                 const CvMat* image_points,
//                                 const CvMat* point_counts,
//                                 CvSize image_size,
//                                 CvMat* intrinsic_matrix,
//                                 CvMat* distortion_coeffs,
//                                 CvMat* rotation_vectors CV_DEFAULT(NULL),
//                                 CvMat* translation_vectors CV_DEFAULT(NULL),
//                                 int flags CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvCalibrateCamera2, 9( SP(CvMat,object_points), SP(CvMat,image_points), SP(CvMat,point_counts), S(CvSize,image_size), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), SP(CvMat,rotation_vectors), SP(CvMat,translation_vectors), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvCalibrateCamera2, 8( SP(CvMat,object_points), SP(CvMat,image_points), SP(CvMat,point_counts), S(CvSize,image_size), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), SP(CvMat,rotation_vectors), SP(CvMat,translation_vectors) ) ) 
DEFINE_FUNCTION( N(void), cvCalibrateCamera2, 7( SP(CvMat,object_points), SP(CvMat,image_points), SP(CvMat,point_counts), S(CvSize,image_size), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs), SP(CvMat,rotation_vectors) ) ) 
DEFINE_FUNCTION( N(void), cvCalibrateCamera2, 6( SP(CvMat,object_points), SP(CvMat,image_points), SP(CvMat,point_counts), S(CvSize,image_size), SP(CvMat,intrinsic_matrix), SP(CvMat,distortion_coeffs) ) ) 

// #define CV_CALIB_CB_ADAPTIVE_THRESH  1
#pragma push_macro( "CV_CALIB_CB_ADAPTIVE_THRESH" )
#undef CV_CALIB_CB_ADAPTIVE_THRESH
static const int CV_CALIB_CB_ADAPTIVE_THRESH
#pragma pop_macro( "CV_CALIB_CB_ADAPTIVE_THRESH" )
	= CV_CALIB_CB_ADAPTIVE_THRESH;
// #define CV_CALIB_CB_NORMALIZE_IMAGE  2
#pragma push_macro( "CV_CALIB_CB_NORMALIZE_IMAGE" )
#undef CV_CALIB_CB_NORMALIZE_IMAGE
static const int CV_CALIB_CB_NORMALIZE_IMAGE
#pragma pop_macro( "CV_CALIB_CB_NORMALIZE_IMAGE" )
	= CV_CALIB_CB_NORMALIZE_IMAGE;
// #define CV_CALIB_CB_FILTER_QUADS     4 
#pragma push_macro( "CV_CALIB_CB_FILTER_QUADS" )
#undef CV_CALIB_CB_FILTER_QUADS
static const int CV_CALIB_CB_FILTER_QUADS
#pragma pop_macro( "CV_CALIB_CB_FILTER_QUADS" )
	= CV_CALIB_CB_FILTER_QUADS;

/* Detects corners on a chessboard calibration pattern */
// CVAPI(int) cvFindChessboardCorners( const void* image, CvSize pattern_size,
//                                     CvPoint2D32f* corners,
//                                     int* corner_count CV_DEFAULT(NULL),
//                                     int flags CV_DEFAULT(CV_CALIB_CB_ADAPTIVE_THRESH) );
DEFINE_FUNCTION( V(int), cvFindChessboardCorners, 5( P(const void*,image), S(CvSize,pattern_size), SP(CvPoint2D32f,corners), VP(int,corner_count), V(int,flags) ) ) 
DEFINE_FUNCTION( V(int), cvFindChessboardCorners, 5( P(const void*,image), S(CvSize,pattern_size), SP(CvPoint2D32f,corners), P(int*,corner_count), V(int,flags) ) ) 
DEFINE_FUNCTION( V(int), cvFindChessboardCorners, 4( P(const void*,image), S(CvSize,pattern_size), SP(CvPoint2D32f,corners), VP(int,corner_count) ) ) 
DEFINE_FUNCTION( V(int), cvFindChessboardCorners, 4( P(const void*,image), S(CvSize,pattern_size), SP(CvPoint2D32f,corners), P(int*,corner_count) ) ) 
DEFINE_FUNCTION( V(int), cvFindChessboardCorners, 3( P(const void*,image), S(CvSize,pattern_size), SP(CvPoint2D32f,corners) ) ) 

/* Draws individual chessboard corners or the whole chessboard detected */
// CVAPI(void) cvDrawChessboardCorners( CvArr* image, CvSize pattern_size,
//                                      CvPoint2D32f* corners,
//                                      int count, int pattern_was_found );
DEFINE_FUNCTION( N(void), cvDrawChessboardCorners, 5( MP(UMemory,CvArr,image), S(CvSize,pattern_size), SP(CvPoint2D32f,corners), V(int,count), V(int,pattern_was_found) ) ) 

// typedef struct CvPOSITObject CvPOSITObject;
DEFINE_HANDLE( CvPOSITObject )

/* Allocates and initializes CvPOSITObject structure before doing cvPOSIT */
// CVAPI(CvPOSITObject*)  cvCreatePOSITObject( CvPoint3D32f* points, int point_count );
DEFINE_FUNCTION( SP(CvPOSITObject), cvCreatePOSITObject, 2( SP(CvPoint3D32f,points), V(int,point_count) ) ) 


/* Runs POSIT (POSe from ITeration) algorithm for determining 3d position of
   an object given its model and projection in a weak-perspective case */
// CVAPI(void)  cvPOSIT(  CvPOSITObject* posit_object, CvPoint2D32f* image_points,
//                        double focal_length, CvTermCriteria criteria,
//                        CvMatr32f rotation_matrix, CvVect32f translation_vector);
DEFINE_FUNCTION( N(void), cvPOSIT, 6( SP(CvPOSITObject,posit_object), SP(CvPoint2D32f,image_points), V(double,focal_length), S(CvTermCriteria,criteria), VP(float,rotation_matrix), VP(float,translation_vector) ) ) 
DEFINE_FUNCTION( N(void), cvPOSIT, 6( SP(CvPOSITObject,posit_object), SP(CvPoint2D32f,image_points), V(double,focal_length), S(CvTermCriteria,criteria), P(float*,rotation_matrix), VP(float,translation_vector) ) ) 
DEFINE_FUNCTION( N(void), cvPOSIT, 6( SP(CvPOSITObject,posit_object), SP(CvPoint2D32f,image_points), V(double,focal_length), S(CvTermCriteria,criteria), VP(float,rotation_matrix), P(float*,translation_vector) ) ) 
DEFINE_FUNCTION( N(void), cvPOSIT, 6( SP(CvPOSITObject,posit_object), SP(CvPoint2D32f,image_points), V(double,focal_length), S(CvTermCriteria,criteria), P(float*,rotation_matrix), P(float*,translation_vector) ) ) 

/* Releases CvPOSITObject structure */
// CVAPI(void)  cvReleasePOSITObject( CvPOSITObject**  posit_object );
DEFINE_FUNCTION( N(void), cvReleasePOSITObject, 1( SPP(CvPOSITObject,posit_object) ) ) 


/****************************************************************************************\
*                                 Epipolar Geometry                                      *
\****************************************************************************************/

// CVAPI(void) cvConvertPointsHomogenious( const CvMat* src, CvMat* dst );
DEFINE_FUNCTION( N(void), cvConvertPointsHomogenious, 2( SP(CvMat,src), SP(CvMat,dst) ) ) 

/* Calculates fundamental matrix given a set of corresponding points */
// #define CV_FM_7POINT 1
#pragma push_macro( "CV_FM_7POINT" )
#undef CV_FM_7POINT
static const int CV_FM_7POINT
#pragma pop_macro( "CV_FM_7POINT" )
	= CV_FM_7POINT;
// #define CV_FM_8POINT 2
#pragma push_macro( "CV_FM_8POINT" )
#undef CV_FM_8POINT
static const int CV_FM_8POINT
#pragma pop_macro( "CV_FM_8POINT" )
	= CV_FM_8POINT;
// #define CV_FM_LMEDS_ONLY  4
#pragma push_macro( "CV_FM_LMEDS_ONLY" )
#undef CV_FM_LMEDS_ONLY
static const int CV_FM_LMEDS_ONLY
#pragma pop_macro( "CV_FM_LMEDS_ONLY" )
	= CV_FM_LMEDS_ONLY;
// #define CV_FM_RANSAC_ONLY 8
#pragma push_macro( "CV_FM_RANSAC_ONLY" )
#undef CV_FM_RANSAC_ONLY
static const int CV_FM_RANSAC_ONLY
#pragma pop_macro( "CV_FM_RANSAC_ONLY" )
	= CV_FM_RANSAC_ONLY;
// #define CV_FM_LMEDS (CV_FM_LMEDS_ONLY + CV_FM_8POINT)
#pragma push_macro( "CV_FM_LMEDS" )
#undef CV_FM_LMEDS
static const int CV_FM_LMEDS
#pragma pop_macro( "CV_FM_LMEDS" )
	= CV_FM_LMEDS;
// #define CV_FM_RANSAC (CV_FM_RANSAC_ONLY + CV_FM_8POINT)
#pragma push_macro( "CV_FM_RANSAC" )
#undef CV_FM_RANSAC
static const int CV_FM_RANSAC
#pragma pop_macro( "CV_FM_RANSAC" )
	= CV_FM_RANSAC;
// CVAPI(int) cvFindFundamentalMat( const CvMat* points1, const CvMat* points2,
//                                  CvMat* fundamental_matrix,
//                                  int method CV_DEFAULT(CV_FM_RANSAC),
//                                  double param1 CV_DEFAULT(1.), double param2 CV_DEFAULT(0.99),
//                                  CvMat* status CV_DEFAULT(NULL) );
DEFINE_FUNCTION( V(int), cvFindFundamentalMat, 7( SP(CvMat,points1), SP(CvMat,points2), SP(CvMat,fundamental_matrix), V(int,method), V(double,param1), V(double,param2), SP(CvMat,status) ) ) 
DEFINE_FUNCTION( V(int), cvFindFundamentalMat, 6( SP(CvMat,points1), SP(CvMat,points2), SP(CvMat,fundamental_matrix), V(int,method), V(double,param1), V(double,param2) ) ) 
DEFINE_FUNCTION( V(int), cvFindFundamentalMat, 5( SP(CvMat,points1), SP(CvMat,points2), SP(CvMat,fundamental_matrix), V(int,method), V(double,param1) ) ) 
DEFINE_FUNCTION( V(int), cvFindFundamentalMat, 4( SP(CvMat,points1), SP(CvMat,points2), SP(CvMat,fundamental_matrix), V(int,method) ) ) 
DEFINE_FUNCTION( V(int), cvFindFundamentalMat, 3( SP(CvMat,points1), SP(CvMat,points2), SP(CvMat,fundamental_matrix) ) ) 

/* For each input point on one of images
   computes parameters of the corresponding
   epipolar line on the other image */
// CVAPI(void) cvComputeCorrespondEpilines( const CvMat* points,
//                                          int which_image,
//                                          const CvMat* fundamental_matrix,
//                                          CvMat* correspondent_lines );
DEFINE_FUNCTION( N(void), cvComputeCorrespondEpilines, 4( SP(CvMat,points), V(int,which_image), SP(CvMat,fundamental_matrix), SP(CvMat,correspondent_lines) ) ) 

////#ifdef __cplusplus
////}
////#endif

////#ifdef __cplusplus
////#include "cv.hpp"
////#endif

/****************************************************************************************\
*                                 Backward compatibility                                 *
\****************************************************************************************/

////#ifndef CV_NO_BACKWARD_COMPATIBILITY
////#include "cvcompat.h"
////#endif

////#endif /*_CV_H_*/
