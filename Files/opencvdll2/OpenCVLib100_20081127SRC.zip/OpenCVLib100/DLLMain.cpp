///////////////////////////////////////////////////////////////
// OpenCVDotNetLib
///////////////////////////////////////////////////////////////


// Windows�v���b�g�t�H�[���֘A�̐錾
#include <windows.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <math.h>

#include <psapi.h>
#include <locale.h>
#include <errno.h>
#include <imagehlp.h>
#pragma comment(lib, "psapi.lib" )
#pragma comment(lib, "imagehlp.lib" )

///////////////////////////////////////////////////////////////

#define UNAME(name)			UnmanagedOpenCV::##name
#define MNAME(name)			name
#include "NativeWrapper.h"

///////////////////////////////////////////////////////////////
// �A���}�l�[�W��
#pragma unmanaged
namespace UnmanagedOpenCV
{

	// OpenCV�֘A�̃w�b�_
	#pragma warning( push )
	#pragma warning( disable : 4819 )
	#include <cv.h>
	#include <highgui.h>
	#pragma warning( pop )

	// �����N���郉�C�u����
	#pragma comment( lib, "cv.lib" )
	#pragma comment( lib, "cxcore.lib" )
	#pragma comment( lib, "cvhaartraining.lib" )
	#pragma comment( lib, "highgui.lib" )

	// LNK4248�΍�
	struct _IplTileInfo {};
	struct CvFileStorage {};
	struct CvGenericHash {};
	struct _CvContourScanner {};
	struct CvHidHaarClassifierCascade {};
	struct CvPOSITObject {};
	struct CvCapture {};
	struct CvVideoWriter {};
	struct CvFeatureTree {};

}

///////////////////////////////////////////////////////////////
// �}�l�[�W��
#pragma managed
public ref class ManagedOpenCV abstract // sealed
{
public:

#include "Managed_cvver.h"
#include "Managed_cxtypes.h"
#include "Managed_cxcore.h"
#include "Managed_cvtypes.h"
#include "Managed_cv.h"
#include "Managed_highgui.h"

#include "Managed_convertwork.h"
#include "Managed_utility.h"

};

