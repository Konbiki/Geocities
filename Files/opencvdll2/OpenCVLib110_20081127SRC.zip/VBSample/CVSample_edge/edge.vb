﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル edge
'・OpenCV付属サンプル edge のVB版です。
'　変数名、関数名及びコメントは元ソースと同一にしています。
'　変更/追加された部分、及び、注意が必要な箇所には日本語のコメントがあります。
'・このサンプルはVBのフォームを使用しません。
'・終了させるには何かキーを押して下さい。
'//////////////////////////////////////////////////////////////


'OpenCVLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Module edge

    Public wndname As String = "Edge"
    Public tbarname As String = "Threshold"
    Public edge_thresh As Integer = 1

    Public image, cedge, gray, edge As IplImage

    ' define a trackbar callback
    Public Sub on_trackbar(ByVal h As Integer)

        cvSmooth(gray, edge, CV_BLUR, 3, 3, 0, 0)
        cvNot(gray, edge)

        ' Run the edge detector on grayscale
        cvCanny(gray, edge, CSng(edge_thresh), CSng(edge_thresh) * 3, 3)

        cvZero(cedge)
        ' copy edge points
        cvCopy(image, cedge, edge)

        cvShowImage(wndname, cedge)
    End Sub
    Public on_trackbar_ptr As New CvTrackbarCallback(AddressOf on_trackbar)

    Sub Main()

        Dim filename As String
        If My.Application.CommandLineArgs.Count = 1 Then
            filename = My.Application.CommandLineArgs(0)
        Else
            filename = GetOpenCVInstallDirectory() + "\samples\c\fruits.jpg"
        End If

        image = cvLoadImage(filename, 1)
        If image Is Nothing Then Exit Sub

        ' Create the output image
        cedge = cvCreateImage(cvSize_(image.width, image.height), IPL_DEPTH_8U, 3)
        'VBでは関数名/構造体などの大文字小文字の区別がく、
        '関数の'cvSize'と構造体の'CvSize'の区別が付かなくなるため
        '関数'cvSize'は'cvSize_'として定義されています。
        '同様に関数名と構造体名がVB上同一になる場合は
        '元の関数名の後に() '_'(アンダーバー)がついて定義されています。
        'なお一部の構造体には初期化を行うコンストラクタを用意しており、
        '例えば cvSize_(10,20) は new CvSize(10,20) とも記述することもできます。

        ' Convert to grayscale
        gray = cvCreateImage(cvSize_(image.width, image.height), IPL_DEPTH_8U, 1)
        edge = cvCreateImage(cvSize_(image.width, image.height), IPL_DEPTH_8U, 1)
        cvCvtColor(image, gray, CV_BGR2GRAY)

        ' Create a window
        cvNamedWindow(wndname, 1)

        ' create a toolbar
        cvCreateTrackbar(tbarname, wndname, edge_thresh, 100, on_trackbar_ptr)
        'cvCreateTrackbarでは第三引数にトラックバーの値を保持する領域のポインタを指定できます。
        'VB上では上記のように整数型変数を指定することで同様の操作が可能ですが、
        '指定した変数がGCによりアクセスできなくならないように注意する必要があります。
        '同様に第五引数のデリゲートも破棄されてしまわないようにして下さい。
        '悪い例） cvCreateTrackbar(tbarname, ... , AddressOf on_trackbar )

        ' Show the image
        on_trackbar(0)

        ' Wait for a key stroke; the same function aranges events processing
        cvWaitKey(0)
        cvReleaseImage(image)
        cvReleaseImage(gray)
        cvReleaseImage(edge)
        cvDestroyWindow(wndname)

    End Sub


End Module
