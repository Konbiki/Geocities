﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル contours
'・OpenCV付属サンプル contours のVB版です。
'　変数名、関数名及びコメントは元ソースと同一にしています。
'　変更/追加された部分、及び、注意が必要な箇所には日本語のコメントがあります。
'・このサンプルはVBのフォームを使用しません。
'・終了させるには何かキーを押して下さい。
'//////////////////////////////////////////////////////////////


'OpenCVLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Imports System.Runtime.InteropServices 'Marshalクラスを使用するため

Module contours

    Public Const w As Integer = 500

    Public levels As Integer = 3
    Public contours As CvSeq = Nothing

    Sub on_trackbar(ByVal pos As Integer)
        Dim cnt_img As IplImage = cvCreateImage(cvSize_(w, w), 8, 3)
        Dim _contours As CvSeq = contours
        Dim _levels = levels - 3
        If _levels <= 0 Then ' get to the nearest face to make it look as more funny
            _contours = _contours.h_next.h_next.h_next
        End If
        cvZero(cnt_img)
        cvDrawContours(cnt_img, _contours, CV_RGB(255, 0, 0), CV_RGB(0, 255, 0), _levels, 3, CV_AA, cvPoint_(0, 0))
        cvShowImage("contours", cnt_img)
        cvReleaseImage(cnt_img)
    End Sub
    Dim on_trackbar_ptr As New CvTrackbarCallback(AddressOf on_trackbar)

    Sub Main()
        Dim i, j As Integer
        Dim storage As CvMemStorage = cvCreateMemStorage(0)
        Dim img As IplImage = cvCreateImage(cvSize_(w, w), 8, 1)

        cvZero(img)

        For i = 0 To 5
            Dim dx As Integer = (i Mod 2) * 250 - 30
            Dim dy As Integer = (i \ 2) * 150
            Dim white As CvScalar = cvRealScalar(255)
            Dim black As CvScalar = cvRealScalar(0)

            If i = 0 Then
                For j = 0 To 10
                    Dim angle As Double = (j + 5) * CV_PI / 21
                    cvLine(img, cvPoint_(cvRound(dx + 100 + j * 10 - 80 * Math.Cos(angle)), _
                        cvRound(dy + 100 - 90 * Math.Sin(angle))), _
                        cvPoint_(cvRound(dx + 100 + j * 10 - 30 * Math.Cos(angle)), _
                        cvRound(dy + 100 - 30 * Math.Sin(angle))), white, 1, 8, 0)
                Next
            End If

            cvEllipse(img, cvPoint_(dx + 150, dy + 100), cvSize_(100, 70), 0, 0, 360, white, -1, 8, 0)
            cvEllipse(img, cvPoint_(dx + 115, dy + 70), cvSize_(30, 20), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, cvPoint_(dx + 185, dy + 70), cvSize_(30, 20), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, cvPoint_(dx + 115, dy + 70), cvSize_(15, 15), 0, 0, 360, white, -1, 8, 0)
            cvEllipse(img, cvPoint_(dx + 185, dy + 70), cvSize_(15, 15), 0, 0, 360, white, -1, 8, 0)
            cvEllipse(img, cvPoint_(dx + 115, dy + 70), cvSize_(5, 5), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, cvPoint_(dx + 185, dy + 70), cvSize_(5, 5), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, cvPoint_(dx + 150, dy + 100), cvSize_(10, 5), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, cvPoint_(dx + 150, dy + 150), cvSize_(40, 10), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, cvPoint_(dx + 27, dy + 100), cvSize_(20, 35), 0, 0, 360, white, -1, 8, 0)
            cvEllipse(img, cvPoint_(dx + 273, dy + 100), cvSize_(20, 35), 0, 0, 360, white, -1, 8, 0)
        Next

        cvNamedWindow("image", 1)
        cvShowImage("image", img)

        cvFindContours(img, storage, contours, CvContour.StructSize, _
                    CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, cvPoint_(0, 0))

        ' comment this out if you do not want approximation
        contours = cvApproxPoly(contours.Address, CvContour.StructSize, storage, CV_POLY_APPROX_DP, 3, 1)

        cvNamedWindow("contours", 1)
        cvCreateTrackbar("levels+3", "contours", levels, 7, on_trackbar_ptr)

        on_trackbar(0)
        cvWaitKey(0)
        cvReleaseMemStorage(storage)
        cvReleaseImage(img)

    End Sub

End Module
