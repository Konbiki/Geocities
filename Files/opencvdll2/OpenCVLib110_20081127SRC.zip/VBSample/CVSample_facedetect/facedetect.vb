﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル facedetect
'・OpenCV付属サンプル facedetect のVB版です。
'　変数名、関数名及びコメントは元ソースと同一にしています。
'　変更/追加された部分、及び、注意が必要な箇所には日本語のコメントがあります。
'・このサンプルはVBのフォームを使用しません。
'・終了させるには何かキーを押して下さい。
'//////////////////////////////////////////////////////////////


'OpenCVLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Module facedetect

    Private storage As CvMemStorage = Nothing
    Private cascade As CvHaarClassifierCascade = Nothing
    Private nested_cascade As CvHaarClassifierCascade = Nothing
    Public use_nested_cascade As Integer = 0

    Public cascade_name As String = GetOpenCVInstallDirectory() + "\data\haarcascades\haarcascade_frontalface_alt.xml"
    Public nested_cascade_name As String = GetOpenCVInstallDirectory() + "\data\haarcascades\haarcascade_eye_tree_eyeglasses.xml"
    Public scale As Double = 1

    Sub Main()
        Dim capture As CvCapture = Nothing
        Dim frame As IplImage, frame_copy As IplImage = Nothing
        Dim image As IplImage = Nothing
        Const scale_opt As String = "--scale="
        Dim scale_opt_len As Integer = scale_opt.Length
        Const cascade_opt As String = "--cascade="
        Dim cascade_opt_len As Integer = cascade_opt.Length
        Const nested_cascade_opt As String = "--nested-cascade"
        Dim nested_cascade_opt_len As Integer = nested_cascade_opt.Length
        Dim i As Integer
        Dim input_name As String = ""

        Dim argc As Integer = My.Application.CommandLineArgs.Count  '煩雑になるため
        For i = 0 To argc - 1
            Dim argvi As String = My.Application.CommandLineArgs(i) '煩雑になるため
            If argvi.StartsWith(cascade_opt) Then
                cascade_name = argvi.Substring(cascade_opt_len)

            ElseIf argvi.StartsWith(nested_cascade_opt) Then
                If argvi(nested_cascade_opt_len) = "="c Then
                    nested_cascade_name = argvi.Substring(nested_cascade_opt_len + 1)
                End If
                nested_cascade = New CvHaarClassifierCascade(cvLoad(nested_cascade_name))
                'cvGetSeqElemは型不明なポインタ(void*)を返しますが、
                'VBではポインタの概念がないのでUPointerデータを返すようになっています。
                'この戻り値を引数に目的の構造体ラッパ(CvHaarClassifierCascade)を生成すると、
                '元々のポインタが示すアドレスを参照する構造体ラッパが生成されます。
                If nested_cascade Is Nothing Then
                    Console.WriteLine("WARNING: Could not load classifier cascade for nested objects")
                End If

            ElseIf argvi.StartsWith(scale_opt) Then
                If (Not Double.TryParse(argvi.Substring(scale_opt_len), scale)) OrElse (scale < 1) Then
                    scale = 1
                End If

            ElseIf argvi.StartsWith("-") Then
                Console.WriteLine("WARNING: Unknown option {0}", argvi)

            Else
                input_name = argvi

            End If
        Next

        cascade = New CvHaarClassifierCascade(cvLoad(cascade_name))

        If cascade.Address.IsNull Then
            '上記のコードではcvLoadの戻り値がNULLでもCvHaarClassifierCascadeは生成されてしまいますので、
            'CvHaarClassifierCascadeラッパのアドレスがNULLでないことで確認します。
            '上記コードはサンプルを出来るだけ変えないようにするためにこのようにしていますが、
            '実際にはcvLoadの戻り値がNULLであるかどうかを確認して下さい。
            Console.WriteLine("ERROR: Could not load classifier cascade")
            Console.WriteLine( _
                "Usage: facedetect [--cascade=""<cascade_path>""]" + vbCrLf + _
                "   [--nested-cascade[=""nested_cascade_path""]]" + vbCrLf + _
                "   [--scale[=<image scale>" + vbCrLf + _
                "   [filename|camera_index]")
            Exit Sub
        End If
        storage = cvCreateMemStorage(0)

        If (input_name = "") OrElse (Char.IsDigit(input_name(0)) And input_name.Length = 1) Then
            capture = cvCaptureFromCAM(If(input_name.Length = 0, 0, Asc(input_name(0)) - Asc("0")))
        ElseIf input_name <> "" Then
            image = cvLoadImage(input_name, 1)
            If image Is Nothing Then
                capture = cvCaptureFromAVI(input_name)
            End If
        Else
            image = cvLoadImage(GetOpenCVInstallDirectory() + "\samples\c\lena.jpg")
        End If

        cvNamedWindow("result", 1)

        If capture IsNot Nothing Then
            Do
                If cvGrabFrame(capture) = 0 Then
                    Exit Do
                End If
                frame = cvRetrieveFrame(capture)
                If frame Is Nothing Then
                    Exit Do
                End If
                If frame_copy Is Nothing Then
                    frame_copy = cvCreateImage(cvSize_(frame.width, frame.height), IPL_DEPTH_8U, frame.nChannels)
                End If
                If frame.origin = IPL_ORIGIN_TL Then
                    cvCopy(frame, frame_copy, Nothing)
                Else
                    cvFlip(frame, frame_copy, Nothing)
                End If

                detect_and_draw(frame_copy)

                If cvWaitKey(10) >= 0 Then
                    GoTo _cleanup
                End If
            Loop

            cvWaitKey(0)
_cleanup:
            cvReleaseImage(frame_copy)
            cvReleaseCapture(capture)

        Else
            If image IsNot Nothing Then
                detect_and_draw(image)
                cvWaitKey(0)
                cvReleaseImage(image)

            ElseIf input_name <> "" Then
                ' assume it is a text file containing the
                ' list of the image filenames to be processed - one per line
                'ファイル入出力関係はVBに合わせて大幅に変更しました。

                Dim fs As New System.IO.FileStream(input_name, IO.FileMode.Open)
                Dim tr As New System.IO.StreamReader(fs)
                Do While Not tr.EndOfStream
                    Dim c As Integer
                    Dim buf As String = tr.ReadLine
                    buf = buf.Trim
                    Console.WriteLine("file {0}", buf)
                    image = cvLoadImage(buf, 1)
                    If image IsNot Nothing Then
                        detect_and_draw(image)
                        c = cvWaitKey(0)
                        If (c = 27) Or (c = Asc("q")) Or (c = Asc("Q")) Then
                            Exit Do
                        End If
                        cvReleaseImage(image)
                    End If
                Loop
                tr.Close()
                fs.Close()
            End If
        End If

        cvDestroyWindow("result")

    End Sub

    Public Sub detect_and_draw(ByVal img As IplImage)

        Dim colors() As CvScalar = _
            { _
                CV_RGB(255, 0, 0), _
                CV_RGB(255, 128, 0), _
                CV_RGB(255, 255, 0), _
                CV_RGB(0, 255, 0), _
                CV_RGB(0, 128, 255), _
                CV_RGB(0, 255, 255), _
                CV_RGB(0, 0, 255), _
                CV_RGB(255, 0, 255) _
            }

        Dim gray As IplImage, small_img As IplImage
        Dim i, j As Integer

        gray = cvCreateImage(cvSize_(img.width, img.height), 8, 1)
        small_img = cvCreateImage(cvSize_(cvRound(img.width / scale), cvRound(img.height / scale)), 8, 1)

        cvCvtColor(img, gray, CV_BGR2GRAY)
        cvResize(gray, small_img, CV_INTER_LINEAR)
        cvEqualizeHist(small_img, small_img)
        cvClearMemStorage(storage)

        If cascade IsNot Nothing Then
            Dim t As Double = CDbl(cvGetTickCount())
            Dim faces As CvSeq = cvHaarDetectObjects(small_img, cascade, storage, _
                                                1.1, 2, 0 _
                                                Or CV_HAAR_DO_CANNY_PRUNING _
                                                , _
                                                cvSize_(30, 30))
            t = CDbl(cvGetTickCount()) - t
            Console.WriteLine("detection time = {0}ms", t / (CDbl(cvGetTickFrequency() * 1000.0)))
            For i = 0 To If(faces IsNot Nothing, faces.total, 0) - 1
                Dim r As CvRect = New CvRect(cvGetSeqElem(faces, i))
                'cvGetSeqElemはポインタ(char*)を返しますが、
                'VBではポインタの概念がないのでUPointerデータを返すようになっています。
                'この戻り値を引数に構造体のインスタンスを生成すると、
                '元々のポインタが示すアドレスを参照する構造体ラッパが生成されます。

                Dim small_img_roi As New CvMat
                Dim nested_objects As CvSeq
                Dim center As New CvPoint
                Dim color As CvScalar = colors(i Mod 8)
                Dim radius As Integer
                center.x = cvRound((r.x + r.width * 0.5) * scale)
                center.y = cvRound((r.y + r.height * 0.5) * scale)
                radius = cvRound((r.width + r.height) * 0.25 * scale)
                cvCircle(img, center, radius, colors(i Mod 8), 3, 8, 0)
                If nested_cascade Is Nothing Then Continue For

                cvGetSubRect(small_img, small_img_roi, r)
                nested_objects = cvHaarDetectObjects(small_img_roi, nested_cascade, storage, _
                                        1.1, 2, 0 _
                                        , _
                                        cvSize_(0, 0))
                For j = 0 To If(nested_objects IsNot Nothing, nested_objects.total, 0)
                    Dim nr As CvRect = New CvRect(cvGetSeqElem(nested_objects, j))
                    center.x = cvRound((r.x + nr.x + nr.width * 0.5) * scale)
                    center.y = cvRound((r.y + nr.y + nr.height * 0.5) * scale)
                    radius = cvRound((nr.width + nr.height) * 0.25 * scale)
                    cvCircle(img, center, radius, color, 3, 8)
                Next
            Next

        End If

        cvShowImage("result", img)
        cvReleaseImage(gray)
        cvReleaseImage(small_img)

    End Sub

End Module
