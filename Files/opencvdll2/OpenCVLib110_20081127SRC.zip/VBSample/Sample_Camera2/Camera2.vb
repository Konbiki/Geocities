﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル Camera2
'・カメラデバイスから画像を取り込み、VBフォーム上に表示します。
'　また画像処理した画像も並べて表示します。
'・このサンプルでは積極的に.Net FrameworkのGUIを使用しています。
'・終了させるにはESCキーを押すか、ウィンドウを閉じてください。
'//////////////////////////////////////////////////////////////


'OpenCVLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Public Class Camera2

    '==========================================================

    Private mCap As CvCapture   'キャプチャハンドル

    '==========================================================

    'フォームがロードされる時の処理です。
    Private Sub Camera2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'カメラからの画像取り込み開始
        StartCapture()

        'フォームの設定
        Me.KeyPreview = True    'キー入力でForm1_KeyDownイベントが発生

    End Sub

    'フォームが閉じられようとしている時の処理です。
    Private Sub Camera2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        'カメラからの画像取り込み終了
        EndCapture()

    End Sub

    'フォームでキーが押された時の処理です。
    Private Sub Camera2_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        'ESCキーが押されたらフォームを閉じる
        If e.KeyCode = Keys.Escape Then Me.Close()

    End Sub

    '==========================================================

    'カメラからの画像取り込みを開始します。
    Private Sub StartCapture()

        'カメラキャプチャの準備
        mCap = cvCreateCameraCapture(0) '0番のカメラを使用
        If mCap Is Nothing Then Throw New Exception("カメラが使用できません。")

        '画像サイズを得る為、１フレーム読み込む
        Dim img As IplImage
        img = cvQueryFrame(mCap)

        '表示用PictureBoxの位置・サイズを調整
        Pic_Src.Location = New Point(0, 0)
        Pic_Src.ClientSize = New Size(img.width, img.height)
        Pic_Out.Location = New Point(Pic_Src.Width, 0)
        Pic_Out.ClientSize = Pic_Src.ClientSize
        Me.ClientSize = New Size(Pic_Src.Width + Pic_Out.Width, Pic_Src.Height)

        '取り込みタイミング用タイマーの開始（以後、定期的にTimer_Snap_Tickが呼び出される）
        Timer_Snap.Interval = 100
        Timer_Snap.Enabled = True

    End Sub

    'カメラからの画像取り込みを終了します。
    Private Sub EndCapture()

        'タイマー終了
        Timer_Snap.Enabled = False

        'キャプチャ開放
        cvReleaseCapture(mCap)

    End Sub

    '取り込みタイミング用タイマーのイベント処理です。
    Private Sub Timer_Snap_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_Snap.Tick

        '状態チェック
        If mCap Is Nothing Then Exit Sub

        '１フレーム取得
        Dim img As IplImage
        img = cvQueryFrame(mCap)

        'ソース画像（左側）への描画
        img.UpdateBitmapImage()
        Pic_Src.Image = img.BitmapImage
        Pic_Src.Refresh()

        '画像処理
        ImageProc(img)

    End Sub

    '==========================================================

    '画像処理
    Private Sub ImageProc(ByVal SrcImg As IplImage)

        'ワーク領域の準備
        Dim sz As New CvSize
        sz.width = SrcImg.width
        sz.height = SrcImg.height
        Static GrayImg As IplImage = Nothing        'グレイスケール用
        Static CannyImg As IplImage = Nothing       '輪郭線抽出用
        If GrayImg Is Nothing Then
            GrayImg = cvCreateImage(sz, IPL_DEPTH_8U, 1)
        End If
        If CannyImg Is Nothing Then
            CannyImg = cvCreateImage(sz, IPL_DEPTH_8U, 1)
            CannyImg.origin = SrcImg.origin
        End If

        '出力画像生成
        cvCvtColor(SrcImg, GrayImg, CV_BGR2GRAY)    'グレイスケール化
        cvCanny(GrayImg, CannyImg, 10, 50, 3)       '輪郭線抽出

        '結果の表示
        CannyImg.UpdateBitmapImage()
        Pic_Out.Image = CannyImg.BitmapImage
        Pic_Out.Refresh()

    End Sub

End Class
