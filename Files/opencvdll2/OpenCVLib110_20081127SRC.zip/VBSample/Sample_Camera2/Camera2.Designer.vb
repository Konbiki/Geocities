﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Camera2
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Pic_Src = New System.Windows.Forms.PictureBox
        Me.Pic_Out = New System.Windows.Forms.PictureBox
        Me.Timer_Snap = New System.Windows.Forms.Timer(Me.components)
        CType(Me.Pic_Src, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_Out, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pic_Src
        '
        Me.Pic_Src.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pic_Src.Location = New System.Drawing.Point(0, 0)
        Me.Pic_Src.Name = "Pic_Src"
        Me.Pic_Src.Size = New System.Drawing.Size(100, 50)
        Me.Pic_Src.TabIndex = 0
        Me.Pic_Src.TabStop = False
        '
        'Pic_Out
        '
        Me.Pic_Out.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pic_Out.Location = New System.Drawing.Point(32, 16)
        Me.Pic_Out.Name = "Pic_Out"
        Me.Pic_Out.Size = New System.Drawing.Size(100, 50)
        Me.Pic_Out.TabIndex = 1
        Me.Pic_Out.TabStop = False
        '
        'Camera2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Controls.Add(Me.Pic_Out)
        Me.Controls.Add(Me.Pic_Src)
        Me.Name = "Camera2"
        Me.Text = "Form1"
        CType(Me.Pic_Src, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_Out, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pic_Src As System.Windows.Forms.PictureBox
    Friend WithEvents Pic_Out As System.Windows.Forms.PictureBox
    Friend WithEvents Timer_Snap As System.Windows.Forms.Timer

End Class
