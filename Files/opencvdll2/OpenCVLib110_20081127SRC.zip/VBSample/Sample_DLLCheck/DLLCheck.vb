﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル LibCheck
'・OpenCVLibを使用した最小限のサンプルです。
'・コンソール上にOpenCVDotNetLibで使用するOpenCVのバージョンを表示します。
'//////////////////////////////////////////////////////////////


'メニュー「プロジェクト」－「参照の追加」－「参照」にて
'「OpenCVLib???.dll」を参照追加することにより
'「ManagedOpenCV」が使用できるようになります。
Imports ManagedOpenCV


Module DLLCheck

    Sub Main()

        'OpenCVバージョン名の表示
        Console.WriteLine("CV_VERSION = '{0}'", CV_VERSION)

        'インストールパスの表示
        Console.WriteLine("OpenCV Install Path = '{0}'", GetOpenCVInstallDirectory())
        '注意：このパスは、ロードされているDLL(cv???.dll)のパスの
        '　　　親の親パスになります。実際にインストールされた位置と異なる場合もあります。

        'キーが押されるまで待機
        Console.WriteLine()
        Console.WriteLine("何かキーを押してください。")
        Console.ReadKey()

    End Sub

End Module
