﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル camshiftdemo
'・OpenCV付属サンプル camshiftdemo のVB版です。
'　変数名、関数名及びコメントは元ソースと同一にしています。
'　変更/追加された部分、及び、注意が必要な箇所には日本語のコメントがあります。
'・このサンプルはVBのフォームを使用しません。
'・終了させるには何かキーを押して下さい。
'//////////////////////////////////////////////////////////////


'OpenCVLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Module camshiftdemo

    Public image, hsv, hue, mask, backproject, histimg As IplImage
    Public hist As CvHistogram

    Public backproject_mode As Integer = 0
    Public select_object As Integer = 0
    Public track_object As Integer = 0
    Public show_hist As Integer = 1
    Public origin As CvPoint
    Public selection As New CvRect
    Public track_window As New CvRect
    Public track_box As New CvBox2D
    Public track_comp As New CvConnectedComp
    Public hdims As Integer = 16
    Public hranges_arr As New UFloatArray(New Single() {0, 180})
    Public hranges As New UAddressArray(1)
    Public vmin As Integer = 10, vmax As Integer = 256, smin As Integer = 30

    Dim huearray(0) As UMemory                  'hueへの参照を格納する配列(cvCalcArrBackProjectで使用)

    Sub on_mouse(ByVal eventid As Integer, ByVal x As Integer, ByVal y As Integer, ByVal flags As Integer, ByVal param As UPointer)

        If image Is Nothing Then
            Return
        End If

        If image.origin <> 0 Then
            y = image.height - y
        End If

        If select_object <> 0 Then
            selection.x = Math.Min(x, origin.x)
            selection.y = Math.Min(y, origin.y)
            selection.width = selection.x + CV_IABS(x - origin.x)
            selection.height = selection.y + CV_IABS(y - origin.y)

            selection.x = MAX(selection.x, 0)
            selection.y = MAX(selection.y, 0)
            selection.width = MIN(selection.width, image.width)
            selection.height = MIN(selection.height, image.height)
            selection.width -= selection.x
            selection.height -= selection.y
        End If

        Select Case eventid
            Case CV_EVENT_LBUTTONDOWN
                origin = cvPoint_(x, y)
                selection = cvRect_(x, y, 0, 0)
                select_object = 1

            Case CV_EVENT_LBUTTONUP
                select_object = 0
                If (selection.width > 0) And (selection.height > 0) Then
                    track_object = -1
                End If

        End Select

    End Sub
    Public on_mouse_ptr As New CvMouseCallback(AddressOf on_mouse) 'on_mouse呼出用のデリゲート

    Public Function hsv2rgb(ByVal hue As Single) As CvScalar
        Dim rgb(2), p, sector As Integer
        Static sector_data(,) As Integer = _
            {{0, 2, 1}, {1, 2, 0}, {1, 0, 2}, {2, 0, 1}, {2, 1, 0}, {0, 1, 2}}
        hue *= 0.0333333351F
        sector = cvFloor(hue)
        p = cvRound(255 * (hue - sector))
        p = p Xor CInt(If((sector And 1) <> 0, 255, 0))

        rgb(sector_data(sector, 0)) = 255
        rgb(sector_data(sector, 1)) = 0
        rgb(sector_data(sector, 2)) = p

        Return cvScalar_(rgb(2), rgb(1), rgb(0), 0)
    End Function

    Sub Main()

        Dim capture As CvCapture = Nothing

        Dim argc As Integer = My.Application.CommandLineArgs.Count
        Dim argv0 As String = If(argc > 0, My.Application.CommandLineArgs(0), "") '見やすくする為
        If (argc = 0) OrElse ((argc = 1) AndAlso (argv0.Length = 1) AndAlso Char.IsDigit(argv0, 0)) Then
            capture = cvCreateCameraCapture(CInt(If(argc = 1, CInt(argv0), 0)))
        Else
            capture = cvCreateFileCapture(My.Application.CommandLineArgs(0))
        End If

        If capture Is Nothing Then
            Console.WriteLine("Could not initialize capturing...")
            Exit Sub
        End If

        Console.WriteLine("Hot keys: " + vbCrLf + _
            vbTab + "ESC - quit the program" + vbCrLf + _
            vbTab + "c - stop the tracking" + vbCrLf + _
            vbTab + "b - switch to/from backprojection view" + vbCrLf + _
            vbTab + "h - show/hide object histogram" + vbCrLf + _
            "To initialize tracking, select the object with mouse")

        cvNamedWindow("Histogram", 1)
        cvNamedWindow("CamShiftDemo", 1)
        cvSetMouseCallback("CamShiftDemo", on_mouse_ptr, UPointer.Null)
        cvCreateTrackbar("Vmin", "CamShiftDemo", vmin, 256, Nothing)
        cvCreateTrackbar("Vmax", "CamShiftDemo", vmax, 256, Nothing)
        cvCreateTrackbar("Smin", "CamShiftDemo", smin, 256, Nothing)

        Do
            Dim frame As IplImage = Nothing
            Dim i, bin_w, c As Integer

            frame = cvQueryFrame(capture)
            If frame Is Nothing Then Exit Do

            If image Is Nothing Then
                ' allocate all the buufers
                image = cvCreateImage(cvGetSize(frame), 8, 3)
                image.origin = frame.origin
                hsv = cvCreateImage(cvGetSize(frame), 8, 3)
                hue = cvCreateImage(cvGetSize(frame), 8, 1)
                huearray(0) = hue
                mask = cvCreateImage(cvGetSize(frame), 8, 1)
                backproject = cvCreateImage(cvGetSize(frame), 8, 1)
                hranges(0) = hranges_arr.Address
                hist = cvCreateHist(1, hdims, CV_HIST_ARRAY, hranges.Address, 1)
                histimg = cvCreateImage(cvSize_(320, 200), 8, 3)
                cvSetZero(histimg)
            End If

            cvCopy(frame, image, Nothing)
            cvCvtColor(image, hsv, CV_BGR2HSV)

            If track_object <> 0 Then

                Dim _vmin As Integer = vmin, _vmax As Integer = vmax

                cvInRangeS(hsv, cvScalar_(0, smin, MIN(_vmin, _vmax), 0), _
                        cvScalar_(180, 256, MAX(_vmin, _vmax), 0), mask)
                cvSplit(hsv, hue, Nothing, Nothing, Nothing)

                If track_object < 0 Then
                    Dim max_val As Single = 0
                    cvSetImageROI(hue, selection)
                    cvSetImageROI(mask, selection)
                    cvCalcHist(hue, hist, 0, mask)
                    cvGetMinMaxHistValue(hist, 0, max_val, 0, 0)
                    cvConvertScale(New UMemory(hist.bins, 0), New UMemory(hist.bins, 0), If(max_val <> 0, 255.0 / max_val, 0), 0)
                    cvResetImageROI(hue)
                    cvResetImageROI(mask)
                    track_window = selection
                    track_object = 1

                    cvSetZero(histimg)
                    bin_w = histimg.width \ hdims
                    For i = 0 To hdims - 1
                        Dim val As Integer = cvRound(cvGetReal1D(New UMemory(hist.bins, 0), i) * histimg.height / 255)
                        Dim color As CvScalar = hsv2rgb(i * 180.0F / hdims)
                        cvRectangle(histimg, cvPoint_(i * bin_w, histimg.height), _
                                     cvPoint_((i + 1) * bin_w, histimg.height - val), _
                                     color, -1, 8, 0)
                    Next
                End If

                cvCalcArrBackProject(huearray, backproject, hist)
                cvAnd(backproject, mask, backproject, Nothing)
                cvCamShift(backproject, track_window, _
                            cvTermCriteria_(CV_TERMCRIT_EPS Or CV_TERMCRIT_ITER, 10, 1), _
                            track_comp, track_box)
                track_window = track_comp.rect

                If backproject_mode <> 0 Then
                    cvCvtColor(backproject, image, CV_GRAY2BGR)
                End If
                If image.origin <> 0 Then
                    track_box.angle = -track_box.angle
                End If
                cvEllipseBox(image, track_box, CV_RGB(255, 0, 0), 4, CV_AA, 0)

            End If

            If (select_object <> 0) And (selection.width > 0) And (selection.height > 0) Then
                cvSetImageROI(image, selection)
                cvXorS(image, cvScalarAll(255), image, Nothing)
                cvResetImageROI(image)
            End If

            cvShowImage("CamShiftDemo", image)
            cvShowImage("Histogram", histimg)

            c = cvWaitKey(10)
            If c = 27 Then Exit Do
            Select Case c
                Case Asc("b")
                    backproject_mode = backproject_mode Xor 1

                Case Asc("c")
                    track_object = 0
                    cvSetZero(histimg)

                Case Asc("h")
                    show_hist = show_hist Xor 1
                    If show_hist = 0 Then
                        cvDestroyWindow("Histogram")
                    Else
                        cvNamedWindow("Histogram", 1)
                    End If

            End Select

        Loop

        cvReleaseCapture(capture)
        cvDestroyWindow("CamShiftDemo")

    End Sub

End Module
