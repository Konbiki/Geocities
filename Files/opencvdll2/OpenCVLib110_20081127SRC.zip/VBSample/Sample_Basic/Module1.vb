﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル Basic
'・OpenCVLibを使う場合の、基本的な操作例になります。
'　機能は特に意味がありません。
'//////////////////////////////////////////////////////////////


'OpenCVLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Imports System.Runtime.InteropServices

Module Module1

    Sub Main()
        'Debug.Printの出力が「出力ウィンドウ」にも表示されるようにします。
        Trace.Listeners.Add(New TextWriterTraceListener(System.Console.Out))

        Sample_Structure()
        Sample_UPointer()
        Sample_UMemory()
        Sample_UArray()
        Sample_CallBack()

        '終了
        Console.WriteLine()
        Console.WriteLine("何かキーを押してください。")
        cvWaitKey(0)

    End Sub

#Region "構造体"

    ''' <summary>
    ''' 構造体に関するコード例です。
    ''' </summary>
    ''' <remarks></remarks>
    Sub Sample_Structure()
        Debug.Print("Sample_Structure()")

        'OpenCVの構造体(CV構造体)は同じ名前のクラスとして定義されています。
        Dim sz As CvSize

        '.Net Frameworkの「構造体」(VBでのStructure)ではなく、
        '「クラス」として定義されていますので、
        '使用する際はインスタンス化が必要です。
        sz = New CvSize

        'CV構造体のメンバはプロパティとして定義されています。
        sz.width = 10
        sz.height = 20
        Debug.Print("1_1 : {0},{1}", sz.width, sz.height)
        Dim color As New CvScalar 'CvScalarのvalメンバなどは配列のようにアクセスできます。
        color.val(0) = 11 : color.val(1) = 22 : color.val(2) = 33
        Debug.Print("1_2 : {0}, {1}, {2}", color.val(0), color.val(1), color.val(2))

        'OpenCVでは構造体名と大文字小文字が違うだけの初期化関数があります。
        'OpenCVLibでは大文字小文字を区別しないVBでも問題が出ないように
        'オリジナルの関数名の後に「_」(アンダーバー)をつけてあります。
        sz = cvSize_(30, 40)
        Debug.Print("2 : {0},{1}", sz.width, sz.height)

        '一部のCV構造体は初期化ができるコンストラクタを追加してあります。
        sz = New CvSize(50, 60)
        Debug.Print("3 : {0},{1}", sz.width, sz.height)

        'c/c++の構造体の代入ではメンバ（全データ）がコピーされますが、
        'VB上では参照情報がコピーされるだけで、データはコピーされません。
        Dim sz1 As New CvSize(100, 200)
        Dim sz2 As New CvSize(300, 400)
        Debug.Print("4_1 : sz1=({0},{1}), sz2=({2},{3})", sz1.width, sz1.height, sz2.width, sz2.height)
        sz1 = sz2           'この様な代入では、sz1とsz2が同じCV構造体を参照します。
        Debug.Print("4_2 : sz1=({0},{1}), sz2=({2},{3})", sz1.width, sz1.height, sz2.width, sz2.height)
        sz1.width = 999     '同じCV構造体を参照していますので、sz1.widthの更新でsz2.widthも更新されます。
        Debug.Print("4_3 : sz1=({0},{1}), sz2=({2},{3})", sz1.width, sz1.height, sz2.width, sz2.height)

        'c/c++の様にデータのコピーを行いたい場合は、CopyFromメソッドを使用してください。
        Dim sz3 As New CvSize(500, 600)
        Dim sz4 As New CvSize(700, 800)
        Debug.Print("5_1 : sz3=({0},{1}), sz4=({2},{3})", sz3.width, sz3.height, sz4.width, sz4.height)
        sz3.CopyFrom(sz4)   'sz4のデータがsz3にコピーされます。
        Debug.Print("5_2 : sz3=({0},{1}), sz4=({2},{3})", sz3.width, sz3.height, sz4.width, sz4.height)
        sz3.width = 999     'sz3とsz4は同じ参照ではないので、sz3の内容を変更してもsz4に影響がありません。
        Debug.Print("5_3 : sz3=({0},{1}), sz4=({2},{3})", sz3.width, sz3.height, sz4.width, sz4.height)
        '（CV構造体のメンバがCV構造体配列の場合は、内部的にCopyFromメソッドが呼び出されます。）

        'アンマネージポインタを引数に生成した場合、
        'そのアドレスを先頭とする領域をラップするインスタンス（ラッパ）となります。
        Dim ptr As IntPtr = Marshal.AllocHGlobal(CvSize.StructSize) 'アンマネージ領域を確保
        Marshal.WriteInt32(ptr, 0, 123) '確保したアンマネージ領域に書き込み
        Marshal.WriteInt32(ptr, 4, 456)
        Debug.Print("6_0 : {0},{1}", Marshal.ReadInt32(ptr, 0), Marshal.ReadInt32(ptr, 4))
        Dim sz5 As New CvSize(ptr)      'ラッパ作成
        Debug.Print("6_1 : {0},{1}", sz5.width, sz5.height) 'ラッパを介してのアンマネージ領域読み込み
        sz5.width = 789                 'ラッパを介してのアンマネージ領域書き込み
        Debug.Print("6_2 : {0},{1}", Marshal.ReadInt32(ptr, 0), Marshal.ReadInt32(ptr, 4))
        Marshal.FreeHGlobal(ptr) 'メモリの開放

        'CV構造体は StructSize という静的メンバを持っており、
        'アンマネージでの構造体サイズを取得することができます。
        Debug.Print("7 : SizeOf(CvSize) = {0}", CvSize.StructSize)

    End Sub

#End Region

#Region "コールバック"

    ''' <summary>
    ''' コールバックに関するコード例です。
    ''' </summary>
    ''' <remarks></remarks>
    Sub Sample_CallBack()
        Debug.Print("Sample_CallBack()")

        '準備
        cvNamedWindow("CallBackTest", CV_WINDOW_AUTOSIZE)   'トラックバーを入れるウィンドウを生成
        Dim img As IplImage = cvCreateImage(cvSize_(320, 240), IPL_DEPTH_8U, 1) 'ダミーの画像
        cvSetZero(img) 'ダミー画像のクリア

        'コールバック関数を渡すときは
        'オリジナルと同じ型名称のデリゲートを生成し渡します。
        '第三引数には自動的に値を更新させる整数型変数を指定します。
        mOnTrackbarChange_ptr = New CvTrackbarCallback(AddressOf OnTrackbarChange)
        mTrackbarValue = 20 '初期値
        cvCreateTrackbar("TrackBar1", "CallBackTest", mTrackbarValue, 100, mOnTrackbarChange_ptr)

        'デリゲートの生存期間には注意して下さい。
        'ローカルに生成したデリゲートでは、
        'その関数を抜けるとデリゲートがGCの対象となり、いつか使用不可となります。
        '使用不可となった状態でトラックバーを動かすと
        '不正なアクセスとなりプログラムが異常終了してしまいます。
        '　例）cvCreateTrackbar("TrackBar1", 略... , AddressOf OnTrackbarChange)
        '　　　上のコードでは、この関数から抜けてからトラックバーを動かした場合、
        '　　　いつか必ず異常終了となります。（すぐにはならないのが怖い）

        '第三引数も宣言内容によってはGCによる影響により不適切な状態になる可能性があります。
        '（アクセスしてはいけない状態となり、
        '　トラックバーを動かすとプログラムが異常終了してしまうこととなります。
        '第三引数はできるだけ使用せず、コールバック関数の引数の使用をお勧めします。

        '第三引数を使用しない場合は、UPointer.Nullを指定して下さい。
        '　cvCreateTrackbar("TrackBar1", "CallBackTest", UPointer.Null, 100, mOnTrackbarChange_ptr)

        'ウィンドウ表示
        '何かキーが押されるまで表示
        cvShowImage("CallBackTest", img)
        cvWaitKey(0)

        '後片付け
        cvDestroyWindow("CallBackTest")

    End Sub

    ''' <summary>
    ''' トラックバーが移動された時に呼び出されるコールバック関数です。
    ''' </summary>
    ''' <param name="Val">トラックバーの現在の値</param>
    ''' <remarks></remarks>
    Sub OnTrackbarChange(ByVal Val As Integer)

        'コールバック関数の引数に現在のトラックバーの値がセットされて呼び出されます。
        'またトラックバーを生成する時の第三引数で指定した変数の値も更新されます。
        '関数の引数Valと生成時の第三引数は同じ値となります。
        Debug.Print("OnTrackbarChange : Val={0}, mTrackbarValue={1}", Val, mTrackbarValue)

    End Sub

    ''' <summary>
    ''' 関数OnTrackbarChangeを呼び出すデリゲートを定義します。
    ''' </summary>
    ''' <remarks>
    ''' 使用中にGCによって破棄されてしまわない様に、
    ''' グローバルな位置で宣言することをお勧めします。
    ''' </remarks>
    Private mOnTrackbarChange_ptr As CvTrackbarCallback

    ''' <summary>
    ''' トラックバーと連携して値が更新される変数です。
    ''' </summary>
    ''' <remarks>
    ''' 使用中にGCによって破棄されてしまわない様に、
    ''' グローバルな位置で宣言することをお勧めします。
    ''' </remarks>
    Private mTrackbarValue As Integer

#End Region

#Region "メモリアクセス"

    ''' <summary>
    ''' UPointer関連のコード例です。
    ''' </summary>
    ''' <remarks></remarks>
    Sub Sample_UPointer()
        Debug.Print("Sample_UPointer()")

        'UPointerはアンマネージのポインタ（アドレス）を保持する構造体です。
        '意味としてはIntPtrと同様になります。
        Dim ptr As UPointer '暑気は 0 (NULL) となります。　
        Debug.Print("1 : ptr = {0}", ptr)   '16進8桁で表示されます。

        'IntPtr型とは相互に変換可能です。
        'またIntPtr型を引数に生成した場合、引数と同じアドレスとなります。
        Dim memptr As IntPtr = Marshal.AllocHGlobal(10)     'アンマネージ領域確保（アドレス取得）
        ptr = memptr    'IntPtr型を代入
        Dim ptr1 As New UPointer(memptr)    'IntPtr型を引数に生成することも可能
        Debug.Print("2_1 : memptr = {0:X08}", memptr.ToInt32)
        Debug.Print("2_2 : ptr    = {0}", ptr)
        Debug.Print("2_3 : ptr1   = {0}", ptr1)

        'IntPtr型と違う点は、加算減算ができることです。
        Debug.Print("3_1 : ptr = {0}", ptr)
        ptr += 10
        Debug.Print("3_2 : ptr = {0}", ptr)
        Debug.Print("3_3 : ptr = {0}", ptr - 10)

    End Sub

    ''' <summary>
    ''' UMemory関連のコード例です。
    ''' </summary>
    ''' <remarks></remarks>
    Sub Sample_UMemory()
        Debug.Print("Sample_UMemory()")

        'UMemoryはアンマネージ領域のメモリを管理するクラスです。
        '全てのCV構造体(クラス)の基底クラスとなっています。

        '生成時は、アンマネージ領域に確保するサイズ情報か、
        '既存アンマネージ領域のポインタ情報が必要になります。
        Dim mem1 As New UMemory(100)                    '100バイトを新規に確保
        Dim mem2 As New UMemory(GetType(Single), 20)    'Single(単精度浮動小数点)で20個分(=4*20=100)を新規に確保

        Dim ptr3 As IntPtr = Marshal.AllocHGlobal(16)   'アンマネージ領域にメモリ確保
        Dim mem3 As New UMemory(ptr3, 16)               '上で確保したメモリをラップする(サイズは省略可)

        '新規にアンマネージ領域を確保した場合、
        'クラスが破棄されるときに自動的にアンマネージ領域も開放されます。
        'クラス破棄時に解放されるかどうかは、MustDeleteプロパティで判定できます。
        Debug.Print("1_1 : mem1.MustDelete = {0}", mem1.MustDelete) 'True     自動的に破棄される
        Debug.Print("1_2 : mem2.MustDelete = {0}", mem2.MustDelete) 'True     自動的に破棄される
        Debug.Print("1_3 : mem3.MustDelete = {0}", mem3.MustDelete) 'False    自動的に破棄されない

        'ラップしている領域（ラップしているメモリ）へは
        '****Valueプロパティ、****Arrayプロパティでアクセスできます。
        Marshal.WriteInt32(ptr3, 0, &H11223344) 'アンマネージ領域に書き込み（テストデータ）
        Marshal.WriteInt32(ptr3, 4, &H55667788)
        Debug.Print("2_1 : mem3.IntValue = {0:X08}", mem3.IntValue) 'Integer読み込み
        Debug.Print("2_2 : mem3.ShortArray[] = {0:X04} {1:X04} {2:X04} {3:X04}", mem3.ShortArray(0), mem3.ShortArray(1), mem3.ShortArray(2), mem3.ShortArray(3)) 'Short読み込み
        mem3.IntArray(1) = &HAABBCCDD 'Integer書き込み（ptr + 4 * 1 の位置に書き込む）
        Debug.Print("2_3 : mem3.ShortArray[] = {0:X04} {1:X04} {2:X04} {3:X04}", mem3.ShortArray(0), mem3.ShortArray(1), mem3.ShortArray(2), mem3.ShortArray(3)) 'Short読み込み
        mem1.IntValue = &H55555555 '整数型として0x55555555を書き込み
        Debug.Print("2_4 : int {0}, float {1}", mem1.IntValue, mem1.FloatValue) '上記領域を整数型、及び、浮動小数点として読み込み

        'ReadTo****Arrayメソッド、及び、WriteFromArrayメソッドで配列に一括読み込み/書き込みが可能です。
        '連続して読み書きするならば、一旦配列に入れてから計算等を行い、
        '最後にまとめて書き込む方がパフォーマンスがアップする可能性があります。
        Dim dat() As Byte = mem3.ReadToByteArray(8) '配列に一括読み込み
        Debug.Print("3_1 : {0:X02} {1:X02} {2:X02} {3:X02} {4:X02} {5:X02} {6:X02} {7:X02}", _
                    mem3.ByteArray(0), mem3.ByteArray(1), mem3.ByteArray(2), mem3.ByteArray(3), _
                    mem3.ByteArray(4), mem3.ByteArray(5), mem3.ByteArray(6), mem3.ByteArray(7))
        Debug.Print("3_2 : {0:X02} {1:X02} {2:X02} {3:X02} {4:X02} {5:X02} {6:X02} {7:X02}", _
                    dat(0), dat(1), dat(2), dat(3), dat(4), dat(5), dat(6), dat(7))
        dat(2) = &HFF
        dat(5) = &HEE
        mem3.WriteFromArray(dat) '配列を一括書き込み
        Debug.Print("3_3 : {0:X02} {1:X02} {2:X02} {3:X02} {4:X02} {5:X02} {6:X02} {7:X02}", _
                    mem3.ByteArray(0), mem3.ByteArray(1), mem3.ByteArray(2), mem3.ByteArray(3), _
                    mem3.ByteArray(4), mem3.ByteArray(5), mem3.ByteArray(6), mem3.ByteArray(7))

        'ラップしているメモリのアドレスはAddressプロパティで取得できます。
        Debug.Print("4_1 : mem1.Address = {0}", mem1.Address)
        Debug.Print("4_2 : mem2.Address = {0}", mem2.Address)
        Debug.Print("4_3 : mem3.Address = {0}, ptr3 = {0:X08}", mem1.Address, ptr3.ToInt32)

        '既存メモリをラップした場合は、アドレスをサイズ単位で進めたり戻したりすることが出来ます。
        Dim mem4 As New UMemory(ptr3, 4) '領域としては16バイト分あるが、一件分のデータサイズ4バイトで生成する
        Debug.Print("mem4.IntValue = {0:X08} : mem3.IntArray(0) = {1:X08} : mem3.IntArray(1) = {2:X08}", mem4.IntValue, mem3.IntArray(0), mem3.IntArray(1))
        mem4.MoveNext() '次へ
        Debug.Print("mem4.IntValue = {0:X08} : mem3.IntArray(0) = {1:X08} : mem3.IntArray(1) = {2:X08}", mem4.IntValue, mem3.IntArray(0), mem3.IntArray(1))
        'MoveNext/MovePrevは既存メモリをラップした場合のみ利用できます。
        '新たにメモリを確保した場合は使用できません。

        '後片付け
        Marshal.FreeHGlobal(ptr3)
        '開放されたアンマネージ領域へはアクセスしてはいけません。
        '下記を実行すると意味のない値が表示され、場合によってはプログラムが異常終了します。
        'Debug.Print("{0}", mem3.IntValue)

    End Sub

    ''' <summary>
    ''' U****Array関連のコード例です。
    ''' </summary>
    ''' <remarks></remarks>
    Sub Sample_UArray()
        Debug.Print("Sample_U****Array()")

        'U****ArrayクラスはUMemoryクラス同様にアンマネージ領域をラップするクラスですが、
        '配列としてのアクセスに特化しています。

        '生成はUMemoryクラスとほぼ同じです。
        Dim arr1 As New UIntArray(5)    '５個のInteger型配列を確保して生成
        Dim ptr2 As IntPtr = Marshal.AllocHGlobal(16)   'メモリ確保
        Dim arr2 As New UIntArray(ptr2)                 '上の領域をラップする様に生成

        '配列を指定した場合、配列の個数分だけメモリを確保しデータをコピーします。
        Dim src() As Integer = {123, 456, 789}  '元になる配列
        Dim arr3 As New UIntArray(src)          '配列データを指定して生成
        Dim arr4 As New UIntArray(New Integer() {1000, 2000, 3000})     '直接データを指定して生成

        'マネージ配列のようにアンマネージにアクセスできます。
        Debug.Print("1_1 : arr3 {0} {1} {2}", arr3(0), arr3(1), arr3(2), arr3(3))
        Debug.Print("1_2 : arr4 {0} {1} {2}", arr4(0), arr4(1), arr4(2), arr4(3))

    End Sub

#End Region

End Module
