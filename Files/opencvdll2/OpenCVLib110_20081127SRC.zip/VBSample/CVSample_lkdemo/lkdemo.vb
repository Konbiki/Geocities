﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル contours
'・OpenCV付属サンプル contours のVB版です。
'　変数名、関数名及びコメントは元ソースと同一にしています。
'　変更/追加された部分、及び、注意が必要な箇所には日本語のコメントがあります。
'・このサンプルはVBのフォームを使用しません。
'・終了させるには何かキーを押して下さい。
'//////////////////////////////////////////////////////////////


'OpenCVLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Module lkdemo

    Public image, grey, prev_grey, pyramid, prev_pyramid, swap_temp As IplImage

    Public win_size As Integer = 10
    Public Const MAX_COUNT As Integer = 500
    Public points()() As CvPoint2D32f = {Nothing, Nothing}, swap_points() As CvPoint2D32f
    Public status As UMemory
    Public count As Integer = 0
    Public need_to_init As Integer = 0
    Public night_mode As Integer = 0
    Public flags As Integer = 0
    Public add_remove_pt As Integer = 0
    Public pt As New CvPoint


    Sub on_mouse(ByVal eventid As Integer, ByVal x As Integer, ByVal y As Integer, ByVal flags As Integer, ByVal param As UPointer)

        If image Is Nothing Then Exit Sub

        If image.origin <> 0 Then
            y = image.height - y
        End If

        If eventid = CV_EVENT_LBUTTONDOWN Then
            pt.CopyFrom(cvPoint_(x, y))
            add_remove_pt = 1
        End If

    End Sub
    Public on_mouse_ptr As New CvMouseCallback(AddressOf on_mouse)

    Sub Main()

        Dim capture As CvCapture = Nothing

        Dim argc As Integer = My.Application.CommandLineArgs.Count
        Dim argv0 As String = If(argc > 0, My.Application.CommandLineArgs(0), "") '見やすくする為
        If (argc = 0) OrElse ((argc = 1) AndAlso (argv0.Length = 1) AndAlso Char.IsDigit(argv0, 0)) Then
            capture = cvCaptureFromCAM(CInt(If(argc = 1, CInt(argv0), 0)))
        Else
            capture = cvCaptureFromAVI(My.Application.CommandLineArgs(0))
        End If

        If capture Is Nothing Then
            Console.WriteLine("Could not initialize capturing...")
            Exit Sub
        End If

        Console.WriteLine("    Welcome to lkdemo, using OpenCV version {0} ({1}.{2}.{3})", _
            CV_VERSION, _
            CV_MAJOR_VERSION, CV_MINOR_VERSION, CV_SUBMINOR_VERSION)

        Console.WriteLine("Hot keys: " + vbCrLf + _
                vbTab + "ESC - quit the program" + vbCrLf + _
                vbTab + "r - auto-initialize tracking" + vbCrLf + _
                vbTab + "c - delete all the points" + vbCrLf + _
                vbTab + "n - switch the ""night"" mode on/off" + vbCrLf + _
                "To add/remove a feature point click it")

        cvNamedWindow("LkDemo", 0)
        cvSetMouseCallback("LkDemo", on_mouse_ptr, Nothing)

        Do
            Dim frame As IplImage = Nothing
            Dim i, k, c As Integer

            frame = cvQueryFrame(capture)
            If frame Is Nothing Then Exit Do

            If image Is Nothing Then
                ' allocate all the buffers
                image = cvCreateImage(cvGetSize(frame), 8, 3)
                image.origin = frame.origin
                grey = cvCreateImage(cvGetSize(frame), 8, 1)
                prev_grey = cvCreateImage(cvGetSize(frame), 8, 1)
                pyramid = cvCreateImage(cvGetSize(frame), 8, 1)
                prev_pyramid = cvCreateImage(cvGetSize(frame), 8, 1)
                points(0) = CvPoint2D32f.CreateNewArray(MAX_COUNT)
                points(1) = CvPoint2D32f.CreateNewArray(MAX_COUNT)
                '構造体のCreateNewArrayメソッドを使うことにより
                '連続した領域に配置された配列を作成することができます。
                status = New UMemory(MAX_COUNT)
                flags = 0
            End If

            cvCopy(frame, image, Nothing)
            cvCvtColor(image, grey, CV_BGR2GRAY)

            If night_mode <> 0 Then
                cvSetZero(image)
            End If

            If need_to_init <> 0 Then
                ' automatic initialization
                Dim eig As IplImage = cvCreateImage(cvGetSize(grey), 32, 1)
                Dim temp As IplImage = cvCreateImage(cvGetSize(grey), 32, 1)
                Dim quality As Double = 0.01
                Dim min_distance As Double = 10

                count = MAX_COUNT
                cvGoodFeaturesToTrack(grey, eig, temp, points(1)(0), count, _
                                       quality, min_distance, Nothing, 3, 0, 0.04)
                cvFindCornerSubPix(grey, points(1)(0), count, _
                    cvSize_(win_size, win_size), cvSize_(-1, -1), _
                    cvTermCriteria_(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03))
                cvReleaseImage(eig)
                cvReleaseImage(temp)

                add_remove_pt = 0

            ElseIf count > 0 Then
                cvCalcOpticalFlowPyrLK(prev_grey, grey, prev_pyramid, pyramid, _
                    points(0)(0), points(1)(0), count, cvSize_(win_size, win_size), 3, status.Address, UPointer.Null, _
                    cvTermCriteria_(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03), flags)
                flags = flags Or CV_LKFLOW_PYR_A_READY
                k = 0
                For i = 0 To count - 1
                    If add_remove_pt <> 0 Then
                        Dim dx As Double = pt.x - points(1)(i).x
                        Dim dy As Double = pt.y - points(1)(i).y

                        If dx * dx + dy * dy <= 25 Then
                            add_remove_pt = 0
                            Continue For
                        End If
                    End If

                    If status.ByteArray(i) = 0 Then Continue For

                    points(1)(k).CopyFrom(points(1)(i))
                    'CreateNewArrayで確保した領域への代入時は
                    '単純な代入ではなくCopyFromメソッドを使用してください。
                    k += 1
                    cvCircle(image, cvPointFrom32f(points(1)(i)), 3, CV_RGB(0, 255, 0), -1, 8, 0)
                Next
                count = k

            End If

            If (add_remove_pt <> 0) And (count < MAX_COUNT) Then
                points(1)(count).CopyFrom(cvPointTo32f(pt))
                'CreateNewArrayで確保した領域への代入時は
                '単純な代入ではなくCopyFromメソッドを使用してください。
                count += 1
                cvFindCornerSubPix(grey, points(1)(count - 1), 1, _
                    cvSize_(win_size, win_size), cvSize_(-1, -1), _
                    cvTermCriteria_(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03))
                add_remove_pt = 0
            End If

            swap_temp = prev_grey : prev_grey = grey : grey = swap_temp
            swap_temp = prev_pyramid : prev_pyramid = pyramid : pyramid = swap_temp
            swap_points = points(0) : points(0) = points(1) : points(1) = swap_points
            need_to_init = 0
            cvShowImage("LkDemo", image)

            c = cvWaitKey(10)
            If c = 27 Then Exit Do
            Select Case c
                Case Asc("r")
                    need_to_init = 1
                Case Asc("c")
                    count = 0
                Case Asc("n")
                    night_mode = night_mode Xor 1
            End Select

        Loop

        cvReleaseCapture(capture)
        cvDestroyWindow("LkDemo")

    End Sub

End Module
