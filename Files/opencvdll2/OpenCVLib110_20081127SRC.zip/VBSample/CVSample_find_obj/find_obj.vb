﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル find_obj
'・OpenCV付属サンプル find_obj のVB版です。
'　変数名、関数名及びコメントは元ソースと同一にしています。
'　変更/追加された部分、及び、注意が必要な箇所には日本語のコメントがあります。
'・このサンプルはOpenCV1.1pre1以降でのみ動作します。
'・元サンプルに比べ速度がだいぶ遅くなります。（3倍以上）
'　高速化する手段はあるのですが、
'　元ソースとの比較が難しくなりますので、そのままとしています。
'　（最も時間のロスが大きいのがVBでのオブジェクトの生成/破棄だと思われますので
'　　オブジェクトを使いまわしするような構造にすれば幾分早くなると思います。）
'・このサンプルはVBのフォームを使用しません。
'・終了させるには何かキーを押して下さい。
'//////////////////////////////////////////////////////////////


'OpenCVLib???.dllを参照設定して下さい。
Imports ManagedOpenCV

Module find_obj

    Public image As IplImage = Nothing


    Function compareSURFDescriptors(ByVal d1 As UFloatArray, ByVal d2 As UFloatArray, ByVal best As Double, ByVal length As Integer) As Double
        '引数d1,d2はsingle型配列の先頭アドレスを示します。
        '配列で受け取ってもよいのですが、
        'ここではサンプルコードを出来るだけ変えないようにするため
        'UFloatArray型(アンマネージ領域にある単精度浮動小数点配列にアクセスする為のクラス）参照で受け取ってます。

        'また下記の様にすることで若干高速化できます。(10-20%ぐらい)
        '大量のアンマネージ領域にあるデータをアクセスする場合、
        '要は毎回アンマネージ領域をアクセスするのではなく、
        'まとめてマネージ領域にコピーしてから使用するほうが効率が良い場合もあるということです。
        'Function compareSURFDescriptors(ByVal d1ptr As UFloatArray, ByVal d2ptr As UFloatArray, ByVal best As Double, ByVal length As Integer) As Double
        'Dim d1() As Single = d1ptr.ReadToFloatArray(length)
        'Dim d2() As Single = d2ptr.ReadToFloatArray(length)

        Dim total_cost As Double = 0
        Debug.Assert((length Mod 4) = 0)
        For i As Integer = 0 To length - 1 Step 4
            Dim t0 As Double = d1(i) - d2(i)
            Dim t1 As Double = d1(i + 1) - d2(i + 1)
            Dim t2 As Double = d1(i + 2) - d2(i + 2)
            Dim t3 As Double = d1(i + 3) - d2(i + 3)
            total_cost += t0 * t0 + t1 * t1 + t2 * t2 + t3 * t3
            If total_cost > best Then
                Exit For
            End If
        Next

        Return total_cost
    End Function

    Function naiveNearestNeighbor(ByVal vec As UFloatArray, ByVal laplacian As Integer, ByVal model_keypoints As CvSeq, ByVal model_descriptors As CvSeq) As Integer
        Dim length As Integer = CInt(model_descriptors.elem_size / System.Runtime.InteropServices.Marshal.SizeOf(GetType(Single)))
        Dim i As Integer, neighbor As Integer = -1
        Dim d As Double, dist1 As Double = 1000000.0, dist2 As Double = 1000000.0 '1000000.0=1e6
        Dim reader As New CvSeqReader, kreader As New CvSeqReader
        cvStartReadSeq(model_keypoints, kreader)
        cvStartReadSeq(model_descriptors, reader)
        For i = 0 To model_descriptors.total - 1
            Dim kp As CvSURFPoint = New CvSURFPoint(kreader.ptr)
            Dim mvec As UFloatArray = New UFloatArray(reader.ptr)
            'reader.ptrはFloat配列の先頭ポインタです。
            'そのままでは直接アクセスできないので
            'アンマネージ配列ラッパUFloatArrayを作成します。
            'サイズ0のUMemory型でもかまいませんが、
            '配列ラッパはデフォルトインデックスプロパティで(普通の配列のように)アクセスできるので
            '可視性がよくなると思います。
            CV_NEXT_SEQ_ELEM(kreader.seq.elem_size, kreader)
            CV_NEXT_SEQ_ELEM(reader.seq.elem_size, reader)
            If laplacian <> kp.laplacian Then
                Continue For
            End If
            d = compareSURFDescriptors(vec, mvec, dist2, length)
            If d < dist1 Then
                dist2 = dist1
                dist1 = d
                neighbor = i
            ElseIf d < dist2 Then
                dist2 = d
            End If
        Next
        If dist1 < 0.6 * dist2 Then
            Return neighbor
        End If
        Return -1
    End Function

    Sub findPairs(ByVal objectKeypoints As CvSeq, ByVal objectDescriptors As CvSeq, _
                   ByVal imageKeypoints As CvSeq, ByVal imageDescriptors As CvSeq, ByRef ptpairs As List(Of Integer))
        Dim i As Integer
        Dim reader As New CvSeqReader, kreader As New CvSeqReader
        cvStartReadSeq(objectKeypoints, kreader)
        cvStartReadSeq(objectDescriptors, reader)
        ptpairs.Clear()

        For i = 0 To objectDescriptors.total - 1
            Dim kp As CvSURFPoint = New CvSURFPoint(kreader.ptr)
            Dim descriptor As UFloatArray = New UFloatArray(reader.ptr)
            CV_NEXT_SEQ_ELEM(kreader.seq.elem_size, kreader)
            CV_NEXT_SEQ_ELEM(reader.seq.elem_size, reader)
            Dim nearest_neighbor As Integer = naiveNearestNeighbor(descriptor, kp.laplacian, imageKeypoints, imageDescriptors)
            If nearest_neighbor >= 0 Then
                ptpairs.Add(i)
                ptpairs.Add(nearest_neighbor)
            End If
        Next

    End Sub

    Function locatePlanarObject(ByVal objectKeypoints As CvSeq, ByVal objectDescriptors As CvSeq, _
                                ByVal imageKeypoints As CvSeq, ByVal imageDescriptors As CvSeq, _
                                ByRef src_corners() As CvPoint, ByVal dst_corners() As CvPoint) As Integer
        Dim h As New UMemory(GetType(Double), 9)
        Dim _h As CvMat = cvMat_(3, 3, CV_64F, h.Address)
        Dim ptpairs As New List(Of Integer)
        Dim pt1() As CvPoint2D32f, pt2() As CvPoint2D32f
        Dim _pt1 As New CvMat, _pt2 As New CvMat
        Dim i, n As Integer

        findPairs(objectKeypoints, objectDescriptors, imageKeypoints, imageDescriptors, ptpairs)
        n = ptpairs.Count \ 2
        If n < 4 Then
            Return 0
        End If

        pt1 = CvPoint2D32f.CreateNewArray(n) '連続領域確保
        pt2 = CvPoint2D32f.CreateNewArray(n) '連続領域確保
        For i = 0 To n - 1
            pt1(i).CopyFrom(New CvSURFPoint(cvGetSeqElem(objectKeypoints, ptpairs(i * 2))).pt)
            pt2(i).CopyFrom(New CvSURFPoint(cvGetSeqElem(imageKeypoints, ptpairs(i * 2 + 1))).pt)
        Next

        _pt1 = cvMat_(1, n, CV_32FC2, pt1(0).Address)
        _pt2 = cvMat_(1, n, CV_32FC2, pt2(0).Address)
        If cvFindHomography(_pt1, _pt2, _h, CV_RANSAC, 5) <> 0 Then
            Return 0
        End If

        For i = 0 To 3
            Dim x As Double = src_corners(i).x, y As Double = src_corners(i).y
            Dim Z As Double = 1.0 / (h.DoubleArray(6) * x + h.DoubleArray(7) * y + h.DoubleArray(8))
            Dim XX As Double = (h.DoubleArray(0) * x + h.DoubleArray(1) * y + h.DoubleArray(2)) * Z
            Dim YY As Double = (h.DoubleArray(3) * x + h.DoubleArray(4) * y + h.DoubleArray(5)) * Z
            dst_corners(i) = cvPoint_(cvRound(XX), cvRound(YY))
        Next

        Return 1
    End Function

    Sub Main()

        Dim argv As System.Collections.ObjectModel.ReadOnlyCollection(Of String) = My.Application.CommandLineArgs
        Dim argc As Integer = argv.Count
        Dim object_filename As String = If(argc = 2, argv(0), GetOpenCVInstallDirectory() + "\samples\c\box.png")
        Dim scene_filename As String = If(argc = 2, argv(1), GetOpenCVInstallDirectory() + "\samples\c\box_in_scene.png")

        Dim storage As CvMemStorage = cvCreateMemStorage(0)

        cvNamedWindow("Object", 1)
        cvNamedWindow("Object Correspond", 1)

        Dim colors() As CvScalar = _
            { _
                CV_RGB(255, 0, 0), _
                CV_RGB(255, 128, 0), _
                CV_RGB(255, 255, 0), _
                CV_RGB(255, 255, 255), _
                CV_RGB(0, 128, 255), _
                CV_RGB(0, 255, 255), _
                CV_RGB(0, 0, 255), _
                CV_RGB(255, 0, 255), _
                CV_RGB(255, 255, 255) _
            }

        Dim obj As IplImage = cvLoadImage(object_filename, CV_LOAD_IMAGE_GRAYSCALE) 'objectは予約語なのでobjに変更してあります。
        Dim image As IplImage = cvLoadImage(scene_filename, CV_LOAD_IMAGE_GRAYSCALE)
        If (obj Is Nothing) OrElse (image Is Nothing) Then
            Console.WriteLine("Can not load {0} and/or {1}" + vbCrLf + "Usage: find_obj [<object_filename> <scene_filename>]", object_filename, scene_filename)
            Exit Sub
        End If
        Dim object_color As IplImage = cvCreateImage(cvGetSize(obj), 8, 3)
        cvCvtColor(obj, object_color, CV_GRAY2BGR)

        Dim objectKeypoints As CvSeq = Nothing, objectDescriptors As CvSeq = Nothing
        Dim imageKeypoints As CvSeq = Nothing, imageDescriptors As CvSeq = Nothing
        Dim i As Integer
        Dim params As CvSURFParams = cvSURFParams_(500, 1)

        Dim tt As Double = CDbl(cvGetTickCount())
        cvExtractSURF(obj, Nothing, objectKeypoints, objectDescriptors, storage, params)
        Console.WriteLine("Object Descriptors: {0}", objectDescriptors.total)
        cvExtractSURF(image, Nothing, imageKeypoints, imageDescriptors, storage, params)
        Console.WriteLine("Image Descriptors: {0}", imageDescriptors.total)
        tt = CDbl(cvGetTickCount()) - tt
        Console.WriteLine("Extraction time = {0}ms", tt / (cvGetTickFrequency() * 1000.0))
        Dim src_corners() As CvPoint = {New CvPoint(0, 0), New CvPoint(obj.width, 0), New CvPoint(obj.width, obj.height), New CvPoint(0, obj.height)}
        Dim dst_corners(3) As CvPoint
        Dim correspond As IplImage = cvCreateImage(cvSize_(image.width, obj.height + image.height), 8, 1)
        cvSetImageROI(correspond, cvRect_(0, 0, obj.width, obj.height))
        cvCopy(obj, correspond)
        cvSetImageROI(correspond, cvRect_(0, obj.height, correspond.width, correspond.height))
        cvCopy(image, correspond)
        cvResetImageROI(correspond)
        If locatePlanarObject(objectKeypoints, objectDescriptors, imageKeypoints, _
            imageDescriptors, src_corners, dst_corners) <> 0 Then
            For i = 0 To 3
                Dim r1 As CvPoint = dst_corners(i Mod 4)
                Dim r2 As CvPoint = dst_corners((i + 1) Mod 4)
                cvLine(correspond, cvPoint_(r1.x, r1.y + obj.height), _
                    cvPoint_(r2.x, r2.y + obj.height), colors(8))
            Next

        End If
        Dim ptpairs As New List(Of Integer)
        findPairs(objectKeypoints, objectDescriptors, imageKeypoints, imageDescriptors, ptpairs)
        For i = 0 To ptpairs.Count - 1 Step 2
            Dim r1 As CvSURFPoint = New CvSURFPoint(cvGetSeqElem(objectKeypoints, ptpairs(i)))
            Dim r2 As CvSURFPoint = New CvSURFPoint(cvGetSeqElem(imageKeypoints, ptpairs(i + 1)))
            cvLine(correspond, cvPointFrom32f(r1.pt), _
                cvPoint_(cvRound(r2.pt.x), cvRound(r2.pt.y + obj.height)), colors(8))
        Next

        cvShowImage("Object Correspond", correspond)
        For i = 0 To objectKeypoints.total - 1
            Dim r As CvSURFPoint = New CvSURFPoint(cvGetSeqElem(objectKeypoints, i))
            Dim center As New CvPoint
            Dim radius As Integer
            center.x = cvRound(r.pt.x)
            center.y = cvRound(r.pt.y)
            radius = cvRound(r.size * 1.2 / 9.0 * 2)
            cvCircle(object_color, center, radius, colors(0), 1, 8, 0)
        Next
        cvShowImage("Object", object_color)

        cvWaitKey(0)

        cvDestroyWindow("Object")
        cvDestroyWindow("Object SURF")
        cvDestroyWindow("Object Correspond")

    End Sub

End Module
