﻿Option Explicit On
Option Strict On

Imports ManagedOpenCV

Module Module1

    Sub Main()

        Trace.Listeners.Add(New TextWriterTraceListener(System.Console.Out))

        Debug.Print("CV_VERSION   : {0}", CV_VERSION)
        Debug.Print("Install Path : {0}", GetOpenCVInstallDirectory)

        Dim mmm As IplImage
        cvNamedWindow("aaa", 1)

        mmm = LoadImageFromResorce("image1.bmp")
        cvShowImage("aaa", mmm)
        cvWaitKey(0)

        mmm = LoadImageFromResorce("image2.bmp", CV_LOAD_IMAGE_GRAYSCALE)
        cvShowImage("aaa", mmm)
        cvWaitKey(0)

    End Sub

End Module
