// typedef struct CvRandState
// {
//     CvRNG     state;    /* RNG state (the current seed and carry)*/
//     int       disttype; /* distribution type */
//     CvScalar  param[2]; /* parameters of RNG */
// }
// CvRandState;
DEFINE_STRUCT( CvRandState )
{STRUCT_BASIC( CvRandState )
	DEFINE_PROPERTY_V( unsigned long long, state )
	DEFINE_PROPERTY_V( int, disttype )
	DEFINE_PROPERTY_SA( CvScalar, param, 2 )
};
