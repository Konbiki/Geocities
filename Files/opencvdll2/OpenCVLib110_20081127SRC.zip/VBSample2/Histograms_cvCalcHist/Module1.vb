﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　ヒストグラムの描画 cvCalcHist
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Sub Main()
        Dim i, j, bin_w As Integer
        Dim hist_size As Integer = 256
        Dim sch As Integer = 0, ch_width As Integer = 260
        Dim max_value As Single = 0
        Dim range_0 As New UFloatArray(New Single() {0.0F, 256.0F})         'Singleの配列
        Dim ranges As New UAddressArray(New UPointer() {range_0.Address})   'Single配列のポインタ配列
        Dim src_img As IplImage, dst_img(3) As IplImage, hist_img As IplImage
        Dim hist As CvHistogram

        '(1)画像を読み込む
        Dim argv1 As String = GetOpenCVInstallDirectory() + "\samples\c\lena.jpg"
        src_img = cvLoadImage(argv1, CV_LOAD_IMAGE_ANYDEPTH Or CV_LOAD_IMAGE_ANYCOLOR)
        'src_img = cvLoadImage(argv1, CV_LOAD_IMAGE_GRAYSCALE)
        If src_img Is Nothing Then Exit Sub

        '(2)入力画像のチャンネル数分の画像領域を確保
        sch = src_img.nChannels
        For i = 0 To sch - 1
            dst_img(i) = cvCreateImage(cvSize_(src_img.width, src_img.height), src_img.depth, 1)
        Next

        '(3)ヒストグラム構造体，ヒストグラム画像領域を確保  
        hist = cvCreateHist(1, hist_size, CV_HIST_ARRAY, ranges.Address, 1)
        hist_img = cvCreateImage(cvSize_(ch_width * sch, 200), 8, 1)
        '(4)入力画像がマルチチャンネルの場合，画像をチャンネル毎に分割  
        If sch = 1 Then
            cvCopy(src_img, dst_img(0), Nothing)
        Else
            cvSplit(src_img, dst_img(0), dst_img(1), dst_img(2), dst_img(3))
        End If

        '(5)ヒストグラム画像をクリア  
        cvSet_(hist_img, cvScalarAll(255), Nothing)
        For i = 0 To sch - 1

            '(6)ヒストグラムを計算して，スケーリング    
            cvCalcHist(dst_img(i), hist, 0, Nothing)
            cvGetMinMaxHistValue(hist, 0, max_value, 0, 0)
            cvScale(New UMemory(hist.bins), New UMemory(hist.bins), CDbl(hist_img.height) / max_value, 0)

            '(7)ヒストグラムの描画    
            bin_w = cvRound(CDbl(ch_width) / hist_size)
            For j = 0 To hist_size - 1
                cvRectangle(hist_img, _
                    cvPoint_(j * bin_w + (i * ch_width), hist_img.height), _
                    cvPoint_((j + 1) * bin_w + (i * ch_width), _
                        hist_img.height - cvRound(cvGetReal1D(New UMemory(hist.bins), j))), cvScalarAll(0), -1, 8, 0)
            Next
        Next

        '(8)ヒストグラム画像を表示，キーが押されたときに終了  
        cvNamedWindow("Image", CV_WINDOW_AUTOSIZE)
        cvShowImage("Image", src_img)
        cvNamedWindow("Histogram", CV_WINDOW_AUTOSIZE)
        cvShowImage("Histogram", hist_img)
        cvWaitKey(0)
        cvDestroyWindow("Histogram")
        cvReleaseImage(src_img)
        cvReleaseImage(hist_img)
        For i = 0 To sch - 1
            cvReleaseImage(dst_img(i))
        Next
        cvReleaseHist(hist)

    End Sub

End Module
