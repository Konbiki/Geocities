﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　画像のアフィン変換（１） cvGetAffineTransform + cvWarpAffine
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Sub Main()

        Dim src_img, dst_img As IplImage
        Dim map_matrix As CvMat
        Dim src_pnt() As CvPoint2D32f = CvPoint2D32f.CreateNewArray(3), _
            dst_pnt() As CvPoint2D32f = CvPoint2D32f.CreateNewArray(3)

        '(1)画像の読み込み，出力用画像領域の確保を行なう
        src_img = cvLoadImage(GetOpenCVInstallDirectory() + "\samples\c\airplane.jpg", CV_LOAD_IMAGE_ANYDEPTH Or CV_LOAD_IMAGE_ANYCOLOR)
        dst_img = cvCloneImage(src_img)

        '(2)三角形の回転前と回転後の対応する頂点をそれぞれセットし  
        '   cvGetAffineTransformを用いてアフィン行列を求める
        src_pnt(0).CopyFrom(cvPoint2D32f_(200.0, 200.0))    '単純な代入では参照情報のコピーのみが行われ、
        src_pnt(1).CopyFrom(cvPoint2D32f_(250.0, 200.0))    'アンマネージ領域にあるデータはコピーされません。
        src_pnt(2).CopyFrom(cvPoint2D32f_(200.0, 100.0))    'データも含めてコピーする場合はCopyFromメソッドを使ってください。
        dst_pnt(0).CopyFrom(cvPoint2D32f_(300.0, 100.0))
        dst_pnt(1).CopyFrom(cvPoint2D32f_(300.0, 50.0))
        dst_pnt(2).CopyFrom(cvPoint2D32f_(200.0, 100.0))
        'dst_pnt(0).CopyFrom(cvPoint2D32f_(300.0, 100.0))    '実験用データ
        'dst_pnt(1).CopyFrom(cvPoint2D32f_(350.0, 60.0))
        'dst_pnt(2).CopyFrom(cvPoint2D32f_(250.0, 80.0))
        map_matrix = cvCreateMat(2, 3, CV_32FC1)
        cvGetAffineTransform(src_pnt(0), dst_pnt(0), map_matrix)

        cvLine(src_img, cvPointFrom32f(src_pnt(0)), cvPointFrom32f(src_pnt(1)), CV_RGB(0, 128, 255)) '青三角
        cvLine(src_img, cvPointFrom32f(src_pnt(1)), cvPointFrom32f(src_pnt(2)), CV_RGB(0, 128, 255))
        cvLine(src_img, cvPointFrom32f(src_pnt(2)), cvPointFrom32f(src_pnt(0)), CV_RGB(0, 128, 255))
        cvLine(src_img, cvPointFrom32f(dst_pnt(0)), cvPointFrom32f(dst_pnt(1)), CV_RGB(255, 128, 0)) '赤三角
        cvLine(src_img, cvPointFrom32f(dst_pnt(1)), cvPointFrom32f(dst_pnt(2)), CV_RGB(255, 128, 0))
        cvLine(src_img, cvPointFrom32f(dst_pnt(2)), cvPointFrom32f(dst_pnt(0)), CV_RGB(255, 128, 0))
        '青三角が赤三角と重なるように変換する為の行列が求まります。
        '（dstの青三角はsrcの赤三角の位置・角度となります。）

        '(3)指定されたアフィン行列により，cvWarpAffineを用いて画像を回転させる  
        cvWarpAffine(src_img, dst_img, map_matrix, CV_INTER_LINEAR + CV_WARP_FILL_OUTLIERS, cvScalarAll(0))

        '(4)結果を表示する  
        cvNamedWindow("src", CV_WINDOW_AUTOSIZE)
        cvNamedWindow("dst", CV_WINDOW_AUTOSIZE)
        cvShowImage("src", src_img)
        cvShowImage("dst", dst_img)
        cvWaitKey(0)
        cvDestroyWindow("src")
        cvDestroyWindow("dst")
        cvReleaseImage(src_img)
        cvReleaseImage(dst_img)
        cvReleaseMat(map_matrix)

    End Sub

End Module
