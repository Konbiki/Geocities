﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　ハフ変換による直線検出 cvHoughLines2
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Sub Main()

        Dim i As Integer
        Dim line As UFloatArray, rho As Single, theta As Single
        Dim a, b, x0, y0 As Double
        Dim src_img_std, src_img_prob, src_img_gray As IplImage
        Dim storage As CvMemStorage
        Dim lines As CvSeq
        Dim point() As CvPoint, pt1 As New CvPoint, pt2 As New CvPoint

        '(1)画像の読み込み
        Dim argv1 As String = GetOpenCVInstallDirectory() + "\samples\c\pic5.png"
        src_img_gray = cvLoadImage(argv1, CV_LOAD_IMAGE_GRAYSCALE)
        src_img_std = cvLoadImage(argv1, CV_LOAD_IMAGE_COLOR)
        src_img_prob = cvCloneImage(src_img_std)

        '(2)ハフ変換のための前処理
        cvCanny(src_img_gray, src_img_gray, 50, 200, 3)
        storage = cvCreateMemStorage(0)

        '(3)標準的ハフ変換による線の検出と検出した線の描画  
        lines = cvHoughLines2(src_img_gray, storage.Address, CV_HOUGH_STANDARD, 1, CV_PI / 180, 50, 0, 0)
        For i = 0 To MIN(lines.total, 100) - 1
            line = New UFloatArray(cvGetSeqElem(lines, i))
            rho = line(0)
            theta = line(1)
            a = Math.Cos(theta)
            b = Math.Sin(theta)
            x0 = a * rho
            y0 = b * rho
            pt1.x = cvRound(x0 + 1000 * (-b))
            pt1.y = cvRound(y0 + 1000 * (a))
            pt2.x = cvRound(x0 - 1000 * (-b))
            pt2.y = cvRound(y0 - 1000 * (a))
            cvLine(src_img_std, pt1, pt2, CV_RGB(255, 0, 0), 3, 8, 0)
        Next

        '(4)確率的ハフ変換による線分の検出と検出した線分の描画
        lines = Nothing
        lines = cvHoughLines2(src_img_gray, storage.Address, CV_HOUGH_PROBABILISTIC, 1, CV_PI / 180, 50, 50, 10)
        For i = 0 To lines.total - 1
            point = CvPoint.GetArray(cvGetSeqElem(lines, i), 2)
            cvLine(src_img_prob, point(0), point(1), CV_RGB(255, 0, 0), 3, 8, 0)
        Next

        '(5)検出結果表示用のウィンドウを確保し表示する  
        cvNamedWindow("Hough_line_standard", CV_WINDOW_AUTOSIZE)
        cvNamedWindow("Hough_line_probalistic", CV_WINDOW_AUTOSIZE)
        cvShowImage("Hough_line_standard", src_img_std)
        cvShowImage("Hough_line_probalistic", src_img_prob)
        cvWaitKey(0)
        cvDestroyWindow("Hough_line_standard")
        cvDestroyWindow("Hough_line_standard")
        cvReleaseImage(src_img_std)
        cvReleaseImage(src_img_prob)
        cvReleaseImage(src_img_gray)
        cvReleaseMemStorage(storage)

    End Sub

End Module
