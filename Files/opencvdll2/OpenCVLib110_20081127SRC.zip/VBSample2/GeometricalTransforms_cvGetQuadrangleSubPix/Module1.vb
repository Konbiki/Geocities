﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　回転移動のためのピクセルサンプリング cvGetQuadrangleSubPix
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Sub Main()

        Dim angle As Integer = 45
        Dim m As New UFloatArray(6) 'ポインタを関数に渡す必要があるため通常の配列ではなくUFloatArrayを使います。
        Dim src_img, dst_img As IplImage
        Dim MM As New CvMat

        '1)画像の読み込み，出力用画像領域の確保を行なう
        src_img = cvLoadImage(GetOpenCVInstallDirectory() + "\samples\c\airplane.jpg", CV_LOAD_IMAGE_ANYDEPTH Or CV_LOAD_IMAGE_ANYCOLOR)
        dst_img = cvCloneImage(src_img)

        '2)回転のための行列（アフィン行列）要素を設定し，CvMat行列Mを初期化する
        m(0) = CSng(Math.Cos(angle * CV_PI / 180.0))
        m(1) = CSng(-Math.Sin(angle * CV_PI / 180.0))
        m(2) = src_img.width * 0.5F
        m(3) = -m(1)
        m(4) = m(0)
        m(5) = src_img.height * 0.5F
        cvInitMatHeader(MM, 2, 3, CV_32FC1, m.Address, CV_AUTOSTEP) 'mのポインタを渡します。

        '(3)指定された回転行列により，GetQuadrangleSubPixを用いて画像全体を回転させる
        cvGetQuadrangleSubPix(src_img, dst_img, MM)

        '(4)結果を表示する  
        cvNamedWindow("src", CV_WINDOW_AUTOSIZE)
        cvNamedWindow("dst", CV_WINDOW_AUTOSIZE)
        cvShowImage("src", src_img)
        cvShowImage("dst", dst_img)
        cvWaitKey(0)
        cvDestroyWindow("src")
        cvDestroyWindow("dst")
        cvReleaseImage(src_img)
        cvReleaseImage(dst_img)

    End Sub

End Module
