﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　コーナーの検出 cvGoodFeaturesToTrack, cvFindCornerSubPix
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Sub Main()

        Dim i As Integer, corner_count As Integer = 150
        Dim dst_img1, dst_img2, src_img_gray As IplImage
        Dim eig_img, temp_img As IplImage
        Dim corners() As CvPoint2D32f

        Dim argv1 As String = GetOpenCVInstallDirectory() + "\samples\c\airplane.jpg"
        dst_img1 = cvLoadImage(argv1)
        dst_img2 = cvCloneImage(dst_img1)
        src_img_gray = cvLoadImage(argv1, CV_LOAD_IMAGE_GRAYSCALE)
        eig_img = cvCreateImage(cvGetSize(src_img_gray), IPL_DEPTH_32F, 1)
        temp_img = cvCreateImage(cvGetSize(src_img_gray), IPL_DEPTH_32F, 1)
        corners = CvPoint2D32f.CreateNewArray(corner_count)

        '(1)cvCornerMinEigenValを利用したコーナー検出  
        cvGoodFeaturesToTrack(src_img_gray, eig_img, temp_img, corners(0), corner_count, 0.1, 15)
        '第四引数はCvPoint2D32f配列の先頭アドレスを指定するので、配列の先頭要素(0)を指定します。
        cvFindCornerSubPix(src_img_gray, corners(0), corner_count, cvSize_(3, 3), cvSize_(-1, -1), cvTermCriteria_(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03))

        '(2)コーナーの描画
        For i = 0 To corner_count - 1
            cvCircle(dst_img1, cvPointFrom32f(corners(i)), 3, CV_RGB(255, 0, 0), 2)
        Next

        '(3)cvCornerHarrisを利用したコーナー検出  
        corner_count = 150
        cvGoodFeaturesToTrack(src_img_gray, eig_img, temp_img, corners(0), corner_count, 0.1, 15, Nothing, 3, 1, 0.01)
        cvFindCornerSubPix(src_img_gray, corners(0), corner_count, cvSize_(3, 3), cvSize_(-1, -1), cvTermCriteria_(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03))

        '(4)コーナーの描画  
        For i = 0 To corner_count - 1
            cvCircle(dst_img2, cvPointFrom32f(corners(i)), 3, CV_RGB(0, 0, 255), 2)
        Next

        '(5)画像の表示  
        cvNamedWindow("EigenVal", CV_WINDOW_AUTOSIZE)
        cvShowImage("EigenVal", dst_img1)
        cvNamedWindow("Harris", CV_WINDOW_AUTOSIZE)
        cvShowImage("Harris", dst_img2)
        cvWaitKey(0)
        cvDestroyWindow("EigenVal")
        cvDestroyWindow("Harris")
        cvReleaseImage(dst_img1)
        cvReleaseImage(dst_img2)
        cvReleaseImage(eig_img)
        cvReleaseImage(temp_img)
        cvReleaseImage(src_img_gray)

    End Sub

End Module
