﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　逆行列を計算する cvInvert
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Sub Main()

        Dim i, j As Integer
        Dim nrow As Integer = 3
        Dim ncol As Integer = 3
        Dim src, dst, mul As CvMat
        Dim det As Double
        Dim rng As ULong = cvRNG_(CInt(Timer))      '乱数の初期化

        '(1) 行列のメモリ確保  
        src = cvCreateMat(nrow, ncol, CV_32FC1)
        dst = cvCreateMat(ncol, nrow, CV_32FC1)
        mul = cvCreateMat(nrow, nrow, CV_32FC1)

        '(2) 行列srcに乱数を代入
        Console.WriteLine("src")
        cvmSet(src, 0, 0, 1)
        For i = 0 To src.rows - 1
            For j = 0 To src.cols - 1
                cvmSet(src, i, j, cvRandReal(rng))
                Console.Write("{0,8:F4}" + vbTab, cvmGet(src, i, j))
            Next
            Console.WriteLine()
        Next

        '(3) 行列srcの逆行列を求めて，行列dstに代入  
        det = cvInvert(src, dst, CV_SVD)

        '(4) 行列srcの行列式を表示  
        Console.WriteLine("det(src)={0}", det)

        '(5) 行列dstの表示
        For i = 0 To dst.rows - 1
            For j = 0 To dst.cols - 1
                Console.Write("{0,8:F4}" + vbTab, cvmGet(dst, i, j))
            Next
            Console.WriteLine()
        Next

        '(6) 行列srcとdstの積を計算して確認
        cvMatMul(src, dst, mul)
        Console.WriteLine("mul")
        For i = 0 To mul.rows - 1
            For j = 0 To mul.cols - 1
                Console.Write("{0,8:F4}" + vbTab, cvmGet(mul, i, j))
            Next
            Console.WriteLine()
        Next

        '((7) 行列のメモリを開放  
        cvReleaseMat(src)
        cvReleaseMat(dst)
        cvReleaseMat(mul)
        Console.ReadLine() 'キー入力待ち

    End Sub

End Module
