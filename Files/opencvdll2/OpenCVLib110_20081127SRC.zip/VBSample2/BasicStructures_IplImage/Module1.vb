﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　ピクセルデータへの直接アクセス IplImage
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Sub Main()
        Dim x, y As Integer
        Dim p(2) As Byte
        Dim img As IplImage

        img = cvLoadImage(GetOpenCVInstallDirectory() + "\samples\c\fruits.jpg", CV_LOAD_IMAGE_COLOR)
        If img Is Nothing Then Exit Sub

        '(1)ピクセルデータ（R,G,B）を順次取得し，変更する
        Dim imagedata As UByteArray = New UByteArray(img.imageData) 'ポインタの示すアドレスからバイトでアクセスする為のクラス
        For y = 0 To img.height - 1
            For x = 0 To img.width - 1
                p(0) = imagedata(img.widthStep * y + x * 3)         'B
                p(1) = imagedata(img.widthStep * y + x * 3 + 1)     'G
                p(2) = imagedata(img.widthStep * y + x * 3 + 2)     'R
                imagedata(img.widthStep * y + x * 3) = CByte(cvRound(p(0) * 0.7 + 10))
                imagedata(img.widthStep * y + x * 3 + 1) = CByte(cvRound(p(1) * 1.0))
                imagedata(img.widthStep * y + x * 3 + 2) = CByte(cvRound(p(2) * 0.0))
            Next
        Next

        cvNamedWindow("Image", CV_WINDOW_AUTOSIZE)
        cvShowImage("Image", img)
        cvWaitKey(0)
        cvDestroyWindow("Image")
        cvReleaseImage(img)

    End Sub

End Module
