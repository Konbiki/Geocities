﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　離散フーリエ変換 cvDFT
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Sub Main()

        Dim src_img As IplImage
        Dim realInput As IplImage
        Dim imaginaryInput As IplImage
        Dim complexInput As IplImage
        Dim image_Re As IplImage
        Dim image_Im As IplImage
        Dim dft_M, dft_N As Integer
        Dim dft_A As CvMat, tmp As New CvMat
        Dim m, MM As Double '名前が衝突するので M => MM に変更します。

        src_img = cvLoadImage(GetOpenCVInstallDirectory() + "\samples\c\lena.jpg", CV_LOAD_IMAGE_GRAYSCALE)
        If src_img Is Nothing Then Exit Sub
        realInput = cvCreateImage(cvGetSize(src_img), IPL_DEPTH_64F, 1)
        imaginaryInput = cvCreateImage(cvGetSize(src_img), IPL_DEPTH_64F, 1)
        complexInput = cvCreateImage(cvGetSize(src_img), IPL_DEPTH_64F, 2)

        '(1)入力画像を実数配列にコピーし，虚数配列とマージして複素数平面を構成  
        cvScale(src_img, realInput, 1.0, 0.0)
        cvZero(imaginaryInput)
        cvMerge(realInput, imaginaryInput, Nothing, Nothing, complexInput)

        '(2)DFT用の最適サイズを計算し，そのサイズで行列を確保する  
        dft_M = cvGetOptimalDFTSize(src_img.height - 1)
        dft_N = cvGetOptimalDFTSize(src_img.width - 1)
        dft_A = cvCreateMat(dft_M, dft_N, CV_64FC2)
        image_Re = cvCreateImage(cvSize_(dft_N, dft_M), IPL_DEPTH_64F, 1)
        image_Im = cvCreateImage(cvSize_(dft_N, dft_M), IPL_DEPTH_64F, 1)

        '(3)複素数平面をdft_Aにコピーし，残りの行列右側部分を0で埋める  
        cvGetSubRect(dft_A, tmp, cvRect_(0, 0, src_img.width, src_img.height))
        cvCopy(complexInput, tmp, Nothing)
        If dft_A.cols > src_img.width Then
            cvGetSubRect(dft_A, tmp, cvRect_(src_img.width, 0, dft_A.cols - src_img.width, src_img.height))
            cvZero(tmp)
        End If

        '(4)離散フーリエ変換を行い，その結果を実数部分と虚数部分に分解  
        cvDFT(dft_A, dft_A, CV_DXT_FORWARD, complexInput.height)
        cvSplit(dft_A, image_Re, image_Im, Nothing, Nothing)

        '(5)スペクトルの振幅を計算 Mag = sqrt(Re^2 + Im^2)  
        cvPow(image_Re, image_Re, 2.0)
        cvPow(image_Im, image_Im, 2.0)
        cvAdd(image_Re, image_Im, image_Re, Nothing)
        cvPow(image_Re, image_Re, 0.5)

        '(6)振幅の対数をとる log(1 + Mag)  
        cvAddS(image_Re, cvScalarAll(1.0), image_Re, Nothing)
        cvLog(image_Re, image_Re)

        '(7)原点（直流成分）が画像の中心にくるように，画像の象限を入れ替える  
        cvShiftDFT(image_Re, image_Re)

        '(8)振幅画像のピクセル値が0.0-1.0に分布するようにスケーリング  
        cvMinMaxLoc(image_Re, m, MM, Nothing, Nothing, Nothing)
        cvScale(image_Re, image_Re, 1.0 / (MM - m), 1.0 * (-m) / (MM - m))
        cvNamedWindow("Image", CV_WINDOW_AUTOSIZE)
        cvShowImage("Image", src_img)
        cvNamedWindow("Magnitude", CV_WINDOW_AUTOSIZE)
        cvShowImage("Magnitude", image_Re)
        cvWaitKey(0)
        cvDestroyWindow("Image")
        cvDestroyWindow("Magnitude")
        cvReleaseImage(src_img)
        cvReleaseImage(realInput)
        cvReleaseImage(imaginaryInput)
        cvReleaseImage(complexInput)
        cvReleaseImage(image_Re)
        cvReleaseImage(image_Im)
        cvReleaseMat(dft_A)

    End Sub

    Sub cvShiftDFT(ByVal src_arr As UMemory, ByVal dst_arr As UMemory)

        Dim tmp As CvMat = Nothing
        Dim q1stub As New CvMat, q2stub As New CvMat
        Dim q3stub As New CvMat, q4stub As New CvMat
        Dim d1stub As New CvMat, d2stub As New CvMat
        Dim d3stub As New CvMat, d4stub As New CvMat
        Dim q1, q2, q3, q4 As CvMat
        Dim d1, d2, d3, d4 As CvMat
        Dim size As CvSize = cvGetSize(src_arr)
        Dim dst_size As CvSize = cvGetSize(dst_arr)
        Dim cx, cy As Integer

        If (dst_size.width <> size.width) Or (dst_size.height <> size.height) Then
            cvError(-209, "cvShiftDFT", "Source and Destination arrays must have equal sizes", "Module1.vb", 102) 'CV_StsUnmatchedSizes = -209
        End If

        '(9)インプレースモード用のテンポラリバッファ  
        If src_arr.Equals(dst_arr) Then
            tmp = cvCreateMat(size.height \ 2, size.width \ 2, cvGetElemType(src_arr))
        End If
        cx = size.width \ 2 '画像中心
        cy = size.height \ 2

        '(10)1〜4象限を表す配列と，そのコピー先  
        q1 = cvGetSubRect(src_arr, q1stub, cvRect_(0, 0, cx, cy))
        q2 = cvGetSubRect(src_arr, q2stub, cvRect_(cx, 0, cx, cy))
        q3 = cvGetSubRect(src_arr, q3stub, cvRect_(cx, cy, cx, cy))
        q4 = cvGetSubRect(src_arr, q4stub, cvRect_(0, cy, cx, cy))
        d1 = cvGetSubRect(src_arr, d1stub, cvRect_(0, 0, cx, cy))
        d2 = cvGetSubRect(src_arr, d2stub, cvRect_(cx, 0, cx, cy))
        d3 = cvGetSubRect(src_arr, d3stub, cvRect_(cx, cy, cx, cy))
        d4 = cvGetSubRect(src_arr, d4stub, cvRect_(0, cy, cx, cy))

        '(11)実際の象限の入れ替え  
        If Not src_arr.Equals(dst_arr) Then
            If Not (((q1.type Xor d1.type) And CV_MAT_TYPE_MASK) = 0) Then 'CV_ARE_TYPES_EQ
                cvError(-205, "cvShiftDFT", "Source and Destination arrays must have the same format", "Module1.vb", 124) 'CV_StsUnmatchedFormats=-205
            End If
            cvCopy(q3, d1, Nothing)
            cvCopy(q4, d2, Nothing)
            cvCopy(q1, d3, Nothing)
            cvCopy(q2, d4, Nothing)
        Else
            'インプレースモード
            cvCopy(q3, tmp, Nothing)
            cvCopy(q1, q3, Nothing)
            cvCopy(tmp, q1, Nothing)
            cvCopy(q4, tmp, Nothing)
            cvCopy(q2, q4, Nothing)
            cvCopy(tmp, q2, Nothing)
        End If

    End Sub

End Module
