﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　クラスタリングによる減色処理 cvKMeans2
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Private Const MAX_CLUSTERS As Integer = 32 'クラスタ数

    Sub Main()

        Dim i, size As Integer
        Dim src_img, dst_img As IplImage
        Dim clusters As CvMat
        Dim points As CvMat
        Dim color As CvMat = cvCreateMat(MAX_CLUSTERS, 1, CV_32FC3)
        Dim count As CvMat = cvCreateMat(MAX_CLUSTERS, 1, CV_32SC1)

        '(1)画像を読み込む  
        src_img = cvLoadImage(GetOpenCVInstallDirectory() + "\samples\c\fruits.jpg")
        If src_img Is Nothing Then Exit Sub
        size = src_img.width * src_img.height
        dst_img = cvCloneImage(src_img)
        clusters = cvCreateMat(size, 1, CV_32SC1)
        points = cvCreateMat(size, 1, CV_32FC3)

        '(2)ピクセルの値を行列へ代入  
        Dim src_img_imagedata As New UByteArray(src_img.imageData)
        '↑src_img.imageDataが示すメモリにアクセスする為のUByteArrayを生成します。
        Dim points_data_fl As New UFloatArray(points.data)
        For i = 0 To size - 1
            points_data_fl(i * 3 + 0) = src_img_imagedata(i * 3 + 0)
            points_data_fl(i * 3 + 1) = src_img_imagedata(i * 3 + 1)
            points_data_fl(i * 3 + 2) = src_img_imagedata(i * 3 + 2)
        Next

        '(3)クラスタリング  
        cvKMeans2(points, MAX_CLUSTERS, clusters, cvTermCriteria_(CV_TERMCRIT_EPS + CV_TERMCRIT_ITER, 10, 1.0))

        '(4)各クラスタの平均値を計算  
        cvSetZero(color)
        cvSetZero(count)
        Dim clusters_data_i As New UIntArray(clusters.data)
        Dim count_data_i As New UIntArray(count.data)
        Dim color_data_fl As New UFloatArray(color.data)
        For i = 0 To size - 1
            Dim idx As Integer = clusters_data_i(i)
            Dim j As Integer = count_data_i(idx) + 1 : count_data_i(idx) += 1
            color_data_fl(idx * 3 + 0) = color_data_fl(idx * 3 + 0) * (j - 1) / j + points_data_fl(i * 3 + 0) / j
            color_data_fl(idx * 3 + 1) = color_data_fl(idx * 3 + 1) * (j - 1) / j + points_data_fl(i * 3 + 1) / j
            color_data_fl(idx * 3 + 2) = color_data_fl(idx * 3 + 2) * (j - 1) / j + points_data_fl(i * 3 + 2) / j
        Next

        '(5)クラスタ毎に色を描画  
        Dim dst_img_imageData As New UByteArray(dst_img.imageData)
        For i = 0 To size - 1
            Dim idx As Integer = clusters_data_i(i)
            dst_img_imageData(i * 3 + 0) = CByte(color_data_fl(idx * 3 + 0))
            dst_img_imageData(i * 3 + 1) = CByte(color_data_fl(idx * 3 + 1))
            dst_img_imageData(i * 3 + 2) = CByte(color_data_fl(idx * 3 + 2))
        Next

        '(6)画像を表示，キーが押されたときに終了  
        cvNamedWindow("src", CV_WINDOW_AUTOSIZE)
        cvShowImage("src", src_img)
        cvNamedWindow("low-color", CV_WINDOW_AUTOSIZE)
        cvShowImage("low-color", dst_img)
        cvWaitKey(0)
        cvDestroyWindow("src")
        cvDestroyWindow("low-color")
        cvReleaseImage(src_img)
        cvReleaseImage(dst_img)
        cvReleaseMat(clusters)
        cvReleaseMat(points)
        cvReleaseMat(color)
        cvReleaseMat(count)

    End Sub

End Module
