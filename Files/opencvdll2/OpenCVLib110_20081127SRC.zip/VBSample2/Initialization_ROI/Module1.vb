﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　部分画像のシャッフル cvSetImageROI, cvResetImageROI
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    '分割数の定義
    Private Const DIVX As Integer = 4
    Private Const DIVY As Integer = 4
    Private Const DIVXY As Integer = DIVX * DIVY

    Sub Main()
        Dim w, h, i, j As Integer
        Dim src_img, dst_img, tmp_img(1) As IplImage
        Dim roi(DIVXY - 1) As CvRect
        Dim rng As ULong = cvRNG_(CInt(Timer))

        '(1)画像を読み込む
        src_img = cvLoadImage(GetOpenCVInstallDirectory() + "\samples\c\fruits.jpg", CV_LOAD_IMAGE_ANYDEPTH Or CV_LOAD_IMAGE_ANYCOLOR)
        If src_img Is Nothing Then Exit Sub
        w = src_img.width - (src_img.width Mod DIVX) + DIVX
        h = src_img.height - (src_img.height Mod DIVY) + DIVY
        dst_img = cvCreateImage(cvSize_(w, h), src_img.depth, src_img.nChannels)
        tmp_img(0) = cvCreateImage(cvSize_(w \ DIVX, h \ DIVY), src_img.depth, src_img.nChannels)
        tmp_img(1) = cvCreateImage(cvSize_(w \ DIVX, h \ DIVY), src_img.depth, src_img.nChannels)
        cvResize(src_img, dst_img)

        '(2)画像を分割するための矩形を設定  
        For i = 0 To DIVX - 1
            For j = 0 To DIVY - 1
                roi(DIVX * j + i) = New CvRect  'インスタンスを生成します。
                roi(DIVX * j + i).x = (w \ DIVX) * i
                roi(DIVX * j + i).y = (h \ DIVY) * j
                roi(DIVX * j + i).width = w \ DIVX
                roi(DIVX * j + i).height = h \ DIVY
            Next
        Next

        '(3)ROIを利用して部分画像を入れ換える  
        For i = 0 To DIVXY * 2 - 1
            Dim p1 As Integer = CInt(cvRandInt(rng) And &H7FFFFFFFL) Mod DIVXY
            Dim p2 As Integer = CInt(cvRandInt(rng) And &H7FFFFFFFL) Mod DIVXY
            cvSetImageROI(dst_img, roi(p1))
            cvCopy(dst_img, tmp_img(0))
            cvSetImageROI(dst_img, roi(p2))
            cvCopy(dst_img, tmp_img(1))
            cvCopy(tmp_img(0), dst_img)
            cvSetImageROI(dst_img, roi(p1))
            cvCopy(tmp_img(1), dst_img)
        Next
        cvResetImageROI(dst_img)
        cvResize(dst_img, src_img)

        '(4)画像の表示  
        cvNamedWindow("Image", CV_WINDOW_AUTOSIZE)
        cvShowImage("Image", src_img)
        cvWaitKey(0)
        cvDestroyWindow("Image")
        cvReleaseImage(src_img)
        cvReleaseImage(dst_img)
        cvReleaseImage(tmp_img(0))
        cvReleaseImage(tmp_img(1))

    End Sub

End Module
