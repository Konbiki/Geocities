﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　ハフ変換による円検出 cvHoughCircles
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Sub Main()

        Dim i As Integer
        Dim p As UFloatArray  'アンマネージデータの読み込み用
        Dim src_img As IplImage, src_img_gray As IplImage
        Dim storage As CvMemStorage
        Dim circles As CvSeq

        '(1)画像の読み込み
        Dim argv1 As String = GetOpenCVInstallDirectory() + "\samples\c\stuff.jpg"
        src_img_gray = cvLoadImage(argv1, CV_LOAD_IMAGE_GRAYSCALE)
        If src_img_gray Is Nothing Then Exit Sub
        src_img = cvLoadImage(argv1, CV_LOAD_IMAGE_COLOR)

        '(2)ハフ変換のための前処理
        cvSmooth(src_img_gray, src_img_gray, CV_GAUSSIAN, 7, 7, 0, 0)
        storage = cvCreateMemStorage(0)

        '(3)ハフ変換による円の検出と検出した円の描画  
        circles = cvHoughCircles(src_img_gray, storage.Address, CV_HOUGH_GRADIENT, 1, 100, 20, 50, 10, MAX(src_img_gray.width, src_img_gray.height))
        For i = 0 To circles.total - 1
            p = New UFloatArray(cvGetSeqElem(circles, i))
            cvCircle(src_img, cvPoint_(cvRound(p(0)), cvRound(p(1))), 3, CV_RGB(0, 255, 0), -1, 8, 0)
            cvCircle(src_img, cvPoint_(cvRound(p(0)), cvRound(p(1))), cvRound(p(2)), CV_RGB(255, 0, 0), 3, 8, 0)
        Next

        '(4)検出結果表示用のウィンドウを確保し表示する  
        cvNamedWindow("circles_gray", 1)
        cvShowImage("circles_gray", src_img_gray)
        cvNamedWindow("circles", 1)
        cvShowImage("circles", src_img)
        cvWaitKey(0)
        cvDestroyWindow("circles")
        cvReleaseImage(src_img)
        cvReleaseImage(src_img_gray)
        cvReleaseMemStorage(storage)

    End Sub

End Module
