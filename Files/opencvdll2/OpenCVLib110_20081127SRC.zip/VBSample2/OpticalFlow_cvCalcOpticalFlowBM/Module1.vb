﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　ヒストグラムの描画 cvCalcHist
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Module1

    Sub Main()
        Dim i, j, dx, dy, rows, cols As Integer
        Dim block_size As Integer = 10
        Dim shift_size As Integer = 1
        Dim velx As CvMat, vely As CvMat
        Dim block As CvSize = cvSize_(block_size, block_size)
        Dim shift As CvSize = cvSize_(shift_size, shift_size)
        Dim max_range As CvSize = cvSize_(50, 50)
        Dim src_img1 As IplImage, src_img2 As IplImage, dst_img As IplImage

        Dim argv1 As String = "tux.bmp"
        Dim argv2 As String = "tux_move.bmp"
        'Dim argv2 As String = "tux_rotate.bmp"
        'Dim argv2 As String = "tux_scale.bmp"
        src_img1 = LoadImageFromResorce(argv1, CV_LOAD_IMAGE_GRAYSCALE)
        src_img2 = LoadImageFromResorce(argv2, CV_LOAD_IMAGE_GRAYSCALE)
        If (src_img1 Is Nothing) Or (src_img2 Is Nothing) Then Exit Sub
        dst_img = LoadImageFromResorce(argv2, CV_LOAD_IMAGE_COLOR)

        '(1)速度ベクトルを格納する構造体の確保  
        rows = CInt(cvCeil(src_img1.height / block_size))
        cols = CInt(cvCeil(src_img1.width / block_size))
        velx = cvCreateMat(rows, cols, CV_32FC1)
        vely = cvCreateMat(rows, cols, CV_32FC1)
        cvSetZero(velx)
        cvSetZero(vely)

        '(2)オプティカルフローの計算  
        cvCalcOpticalFlowBM(src_img1, src_img2, block, shift, max_range, 0, velx, vely)

        '(3)計算されたフローを描画
        For i = 0 To velx.cols - 1      ' CvMat.width  は CvMat.cols と同じ 
            For j = 0 To vely.rows - 1  ' CvMat.height は CvMat.rows と同じ 
                dx = CInt(cvGetReal2D(velx, j, i))
                dy = CInt(cvGetReal2D(vely, j, i))
                cvLine(dst_img, cvPoint_(i * block_size, j * block_size), cvPoint_(i * block_size + dx, j * block_size + dy), CV_RGB(255, 0, 0), 1, CV_AA, 0)
            Next
        Next
        cvNamedWindow("Image", 1)
        cvShowImage("Image", dst_img)
        cvWaitKey(0)
        cvDestroyWindow("Image")
        cvReleaseImage(src_img1)
        cvReleaseImage(src_img2)
        cvReleaseImage(dst_img)
        cvReleaseMat(velx)
        cvReleaseMat(vely)

    End Sub

End Module
