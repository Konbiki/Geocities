﻿Option Explicit On
Option Strict On

Imports System.IO

'--------------------------------------------------------------

''' <summary>
''' Cソースを読み込み定義用の文を取り出すクラスです。
''' </summary>
''' <remarks></remarks>
Public MustInherit Class CSourceReader

    ''' <summary>ソースファイルのファイルストリームを保持します。</summary>
    Protected mSrcFile As FileStream

    ''' <summary>ソースファイル読込時のリーダーを保持します。</summary>
    Protected mSrc As BinaryReader

    ''' <summary>読み込み中の行番号を保持します。</summary>
    Protected mLine As Integer

    ''' <summary>読み込まれた文のリストを保持します。</summary>
    Protected mStatementList As New List(Of CSourceStatement)

    ''' <summary>解析された定義情報のリストを保持します。</summary>
    Protected mDefines As New List(Of CSourceDefineInfo)

    '----------------------------------------------------------

    ''' <summary>
    ''' ソースを読み込み、解析を行います。
    ''' </summary>
    ''' <param name="Filename"></param>
    ''' <remarks></remarks>
    Public Overridable Sub Load(ByVal Filename As String)

        '全ての文を読み込む
        ReadAllStatement(Filename)

        '全ての()や[]を折りたたむ
        Collapse()

        '定義情報の解析と分類
        Parse()

    End Sub

    ''' <summary>
    ''' ソースファイルをオープンします。
    ''' </summary>
    ''' <param name="Filename"></param>
    ''' <remarks></remarks>
    Protected Sub Open(ByVal Filename As String)

        mSrcFile = New FileStream(Filename, FileMode.Open)
        mSrc = New BinaryReader(mSrcFile)
        mLine = 1

    End Sub

    ''' <summary>
    ''' ソースファイルをクローズします。
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub Close()

        If mSrc IsNot Nothing Then
            mSrc.Close()
            mSrc = Nothing
        End If

        If mSrcFile IsNot Nothing Then
            mSrcFile.Close()
            mSrcFile = Nothing
        End If

    End Sub

    ''' <summary>
    ''' ソースを読み込み、文に分解します。
    ''' </summary>
    ''' <param name="Filename"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ReadAllStatement(ByVal Filename As String) As Boolean

        'ファイルオープン
        Open(Filename)

        '読込済み文をクリア
        mStatementList.Clear()

        '全ての文を読み込む
        Dim st As CSourceStatement
        Do
            '次の文を読み込む
            st = ReadStatement()
            If st Is Nothing Then Exit Do

            'リストに追加
            mStatementList.Add(st)

        Loop

        'ファイルクローズ
        Close()

    End Function

    ''' <summary>
    ''' 次の文を読み込みます。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadStatement() As CSourceStatement

        '準備
        Dim ret As New CSourceStatement
        ret.TokenList = New CSourceTokenList

        '初めのトークン読込
        Dim tkn As CSourceToken
        tkn = ReadNextToken()
        If tkn Is Nothing Then Return Nothing 'ファイル終了
        ret.StartLine = mLine
        tkn.HasSpace = False
        ret.TokenList.Add(tkn)

        If tkn.Text = "#" Then
            'プリプロセッサ

            '改行までを読み込む
            Dim cc As Integer
            Dim sp As Boolean
            Do
                '行終端チェック
                sp = SkipSpace(True)
                cc = mSrc.PeekChar()
                If (cc = Asc(vbCr)) Or (cc = Asc(vbLf)) Or (cc < 0) Then
                    Exit Do
                End If

                'トークン読込
                tkn = ReadNextToken()
                tkn.HasSpace = sp
                If tkn Is Nothing Then Exit Do
                ret.TokenList.Add(tkn)
            Loop
        Else
            'その他の文

            '";"が現れるまで、関数の場合はブロック終了まで読み込む。
            Dim lasttkn As New CSourceToken
            Do
                '次のトークン読込
                tkn = ReadNextToken()
                If tkn Is Nothing Then Exit Do

                'トークン毎の処理
                If tkn.Text = ";" Then Exit Do '終了
                If tkn.Text = "{" Then
                    'ブロック文
                    tkn.Text = "{}"
                    tkn.InnerTokenList = ReadBlock()
                End If

                'リストに追加
                ret.TokenList.Add(tkn)

                '関数定義時の終了判断
                If lasttkn.Text = ")" And tkn.Text = "{}" Then Exit Do '関数定義である
                lasttkn = tkn
            Loop

        End If

        '終了
        ret.EndLine = mLine
        Return ret
    End Function

    ''' <summary>
    ''' 文のリストを返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Statements() As List(Of CSourceStatement)
        Get
            Return mStatementList
        End Get
    End Property

    ''' <summary>
    ''' 定義情報リストを返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Defines() As List(Of CSourceDefineInfo)
        Get
            Return mDefines
        End Get
    End Property

    '----------------------------------------------------------

    ''' <summary>
    ''' 次のトークンを読み込みます。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadNextToken() As CSourceToken

        Dim ret As New CSourceToken

        '空白の読み飛ばし
        ret.HasSpace = SkipSpace(False)
        If EOF() Then Return Nothing 'ファイルの狩猟

        '定数トークンのチェック
        Dim cc As Char
        cc = ReadChar()
        If (cc = """"c) Or (cc = "'"c) Then
            '文字、又は、文字列
            ret.Text = ReadQuoteToken(cc)
            Return ret
        End If
        If ("0"c <= cc) And (cc <= "9") Then
            '数値
            ret.Text = ReadNumericToken(cc)
            Return ret
        End If
        If cc = "-"c Then
            Dim cd As Integer = mSrc.PeekChar()
            If (Asc("0") <= cd) And (cd <= Asc("9")) Then
                '数値
                ret.Text = ReadNumericToken(cc)
                Return ret
            End If
        End If

        '一文字トークンのチェック
        ret.Text = cc
        If IsSingleTokenChar(cc) Then Return ret

        Do
            '次の文字をチェック
            If EOF() Then Exit Do
            cc = ChrW(mSrc.PeekChar())

            '終了確認
            If Char.IsWhiteSpace(cc) Then Exit Do '空白及び改行
            If IsSingleTokenChar(cc) Then Exit Do '次の文字が一文字トークン

            ret.Text += ReadChar()
        Loop

        '成功
        Return ret
    End Function

    ''' <summary>
    ''' 空白及びコメントを読み飛ばします。
    ''' </summary>
    ''' <param name="NoSkipCRLF"></param>
    ''' <remarks></remarks>
    Private Function SkipSpace(ByVal NoSkipCRLF As Boolean) As Boolean

        Dim ret As Boolean = False
        Dim cc As Char
        Do
            '一文字読込
            If EOF() Then Exit Do 'ファイル終了
            cc = ChrW(mSrc.PeekChar())

            '改行チェック
            If (cc = vbCr) Or (cc = vbLf) Then
                If NoSkipCRLF Then Exit Do
            End If

            '空白判定
            If Char.IsWhiteSpace(cc) Then
                ret = True '空白あり
                ReadChar()
                Continue Do
            End If
            If cc = "/"c Then
                'コメント読み飛ばし
                ReadChar()
                CheckAndSkipComment()
                Continue Do
            End If
            If cc = "\"c Then
                If EOF() Then Exit Do
                ReadChar()
                Dim cd As Integer
                cd = mSrc.PeekChar()
                If cd = 13 Then
                    ret = True '空白あり
                    ReadChar()
                    cd = mSrc.PeekChar()
                End If
                If cd = 10 Then
                    ret = True '空白あり
                    ReadChar()
                End If
                If (cd = 13) Or (cd = 10) Then
                    Continue Do
                End If
                Throw New Exception("不明なエスケープ")
            End If

            Exit Do
        Loop

        Return ret
    End Function

    ''' <summary>
    ''' ソース位置が終端に達しているかを判断します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function EOF() As Boolean

        If mSrc Is Nothing Then Return True
        If mSrc.PeekChar() < 0 Then Return True

        Return False
    End Function

    ''' <summary>
    ''' 一文字を読み込みます。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadChar() As Char

        '一文字読込
        Dim cc As Char
        cc = mSrc.ReadChar()

        '行カウント
        Static lastcc As Char = Chr(0)
        If cc = vbCr Then
            mLine += 1
        ElseIf cc = vbLf And lastcc <> vbCr Then
            mLine += 1
        End If
        lastcc = cc

        Return cc
    End Function

    ''' <summary>
    ''' '/'の後を調べコメントかどうかを判断し、コメントの場合読み飛ばします。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CheckAndSkipComment()

        ' "/"の次の文字を読込
        If EOF() Then Return 'ファイル終了
        Dim cc As Char
        cc = ReadChar()

        If cc = "*" Then
            'ブロックコメント

            ' "*/"まで読み飛ばし
            Dim lastcc As Char = " "c
            Do
                '一文字読込
                If EOF() Then Exit Do 'ファイル終了
                cc = ReadChar()

                '終了確認
                If cc = "/" Then
                    If lastcc = "*" Then
                        Exit Do 'コメント終了
                    End If
                End If
                lastcc = cc
            Loop

        ElseIf cc = "/" Then
            '行コメント

            '改行まで読み飛ばし
            Dim cd As Integer
            Do
                '一文字読込
                If EOF() Then Exit Do
                cd = mSrc.PeekChar()

                '終了確認
                If cd = Asc("\") Then
                    If mSrc.PeekChar() = 13 Then
                        ReadChar()
                        If mSrc.PeekChar() = 10 Then
                            ReadChar()
                        End If
                    End If
                End If

                If (cd = 13) Or (cd = 10) Then
                    Exit Do '改行文字
                End If
                ReadChar()

            Loop

        End If

    End Sub

    ''' <summary>
    ''' 指定文字が一文字トークンであるかを判断します。
    ''' </summary>
    ''' <param name="cc"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function IsSingleTokenChar(ByVal cc As Char) As Boolean

        Select Case cc
            Case "!"c, """"c, "#"c, "$"c, "%"c, "&"c, "'"c, "("c, ")"c, "-"c, _
                 "="c, "~"c, "^"c, "|"c, "["c, "{"c, "]"c, "}"c, _
                 ";"c, "+"c, ":"c, "*"c, ","c, "<"c, "."c, ">"c, _
                 "/"c, "?"c
                Return True
        End Select

        Return False
    End Function

    ''' <summary>
    ''' 文字定数又は文字列定数を読み込みます。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadQuoteToken(ByVal QuoteChar As Char) As String

        Dim ret As String = ""
        Dim cc As Char
        Dim esc As Boolean = False
        Do
            '一文字読込
            If EOF() Then Exit Do
            cc = ReadChar()

            If esc Then
                'エスケープ中

                ret += "\" + cc
                esc = False

            Else
                '非エスケープ中

                '終了チェック
                If cc = QuoteChar Then Exit Do

                If cc = "\"c Then
                    'エスケープ
                    esc = True
                    Continue Do
                End If

                ret += cc
            End If
        Loop

        Return QuoteChar + ret + QuoteChar
    End Function

    ''' <summary>
    ''' 数値定数を読み込みます。
    ''' </summary>
    ''' <param name="StartChar"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadNumericToken(ByVal StartChar As Char) As String

        Dim ret As String = StartChar
        Dim cc As Char
        Dim isexp As Boolean = False
        Do
            If EOF() Then Exit Do
            cc = ChrW(mSrc.PeekChar())

            '終了確認
            If Char.IsWhiteSpace(cc) Then Exit Do
            If cc = "."c Then
                '小数点
            ElseIf (cc = "e") Or (cc = "E") Then
                isexp = True '指数指定
            ElseIf (cc = "-") Or (cc = "+") Then
                If isexp Then
                    '指数指定中はそのまま
                Else
                    '指数指定中でなければ終了
                    Exit Do
                End If
            ElseIf IsSingleTokenChar(cc) Then
                '一文字トークン
                Exit Do '"."以外の一文字トークンなら終了
            End If

            ReadChar()
            ret += cc
        Loop

        Return ret
    End Function

    ''' <summary>
    ''' 文ブロック{}を読み込みます。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadBlock() As CSourceTokenList

        Dim ret As New CSourceTokenList
        Dim tkn As CSourceToken
        Do
            '次のトークン読込
            tkn = ReadNextToken()
            If tkn Is Nothing Then Exit Do
            If tkn.Text = "}" Then Exit Do

            '文ブロックのネスト処理
            If tkn.Text = "{" Then
                tkn.Text = "{}"
                tkn.InnerTokenList = ReadBlock()
            End If

            'リストに追加
            ret.Add(tkn)
        Loop

        Return ret
    End Function

    '----------------------------------------------------------

    ''' <summary>
    ''' 全ての文の括弧()[]を折りたたみます。
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub Collapse()

        For x As Integer = 0 To mStatementList.Count - 1
            mStatementList(x) = Collapse(mStatementList(x))
        Next

    End Sub

    ''' <summary>
    ''' 指定された文の括弧()[]を折りたたみます。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Function Collapse(ByVal Statement As CSourceStatement) As CSourceStatement

        '新しい文情報の作成
        Dim ret As New CSourceStatement
        ret.StartLine = Statement.StartLine
        ret.EndLine = Statement.EndLine

        'トークンリストの畳み込み
        Statement.TokenList.Rewind()
        ret.TokenList = Collapse(Statement.TokenList, "")

        Return ret
    End Function

    ''' <summary>
    ''' 指定されたトークンリストの括弧()[]を折りたたみます。
    ''' </summary>
    ''' <param name="Tokens"></param>
    ''' <param name="EndText"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Function Collapse(ByVal Tokens As CSourceTokenList, ByVal EndText As String) As CSourceTokenList

        Dim ret As New CSourceTokenList

        Dim tkn As CSourceToken
        Do
            'トークン取得
            tkn = Tokens.Token
            Tokens.MoveNext()

            If tkn Is Nothing Then Exit Do '終わり
            If tkn.Text = EndText Then Exit Do '終わり

            '内部トークンの処理
            If tkn.InnerTokenList IsNot Nothing Then
                tkn.InnerTokenList = Collapse(tkn.InnerTokenList, "")
            End If

            '折りたたみ
            If tkn.Text = "(" Then
                Dim tt As New CSourceToken
                tt.Text = "()"
                tt.HasSpace = tkn.HasSpace
                tt.InnerTokenList = Collapse(Tokens, ")")
                tkn = tt
            End If
            If tkn.Text = "[" Then
                Dim tt As New CSourceToken
                tt.Text = "[]"
                tt.HasSpace = tkn.HasSpace
                tt.InnerTokenList = Collapse(Tokens, "]")
                tkn = tt
            End If

            'リストに追加
            ret.Add(tkn)

            '次へ
        Loop

        Return ret
    End Function

    '----------------------------------------------------------

    ''' <summary>
    ''' 文を解析し、定義種類毎に分類します。
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Sub Parse()

        '定義リストの初期化
        mDefines.Clear()

        '解析準備
        Dim deflist As New List(Of CSourceDefineInfo)
        For Each tp As Type In DefineTypes
            deflist.Add(CType(Activator.CreateInstance(tp), CSourceDefineInfo))
        Next

        '全ての文を解析
        For Each st As CSourceStatement In mStatementList

            'フィルタ処理
            Filter(st)

            '各情報タイプ別に解析を試みる
            For x As Integer = 0 To deflist.Count - 1
                Dim def As CSourceDefineInfo = deflist(x)

                If def.Parse(st) Then
                    '解析成功

                    '定義情報リストに追加
                    def.AddDefine(mDefines)

                    '新しい解析用のインスタンスを生成
                    deflist(x) = CType(Activator.CreateInstance(DefineTypes(x)), CSourceDefineInfo)
                    Exit For
                End If
            Next
        Next

    End Sub

    ''' <summary>
    ''' 文の定義情報を解析する直前のフィルタ処理です。
    ''' 既に読み込まれている定義情報への置き換えなどを行います。
    ''' </summary>
    ''' <param name="Src"></param>
    ''' <remarks>
    ''' 引数の行までの定義情報を使用することが出来ます。
    ''' </remarks>
    Protected Overridable Sub Filter(ByVal Src As CSourceStatement)
        Src.TokenList = Filter(Src.TokenList)
    End Sub

    ''' <summary>
    ''' トークンリストに対してフィルタ処理を行います。
    ''' </summary>
    ''' <param name="TokenList"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected MustOverride Function Filter(ByVal TokenList As CSourceTokenList) As CSourceTokenList

    ''' <summary>
    ''' 解析する定義情報のリストを返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable ReadOnly Property DefineTypes() As List(Of Type)
        Get
            Static lst As List(Of Type) = Nothing

            'リスト作成
            If lst Is Nothing Then
                lst = New List(Of Type)

                '定義を解析するクラスの型を追加する
                '（追加された順に評価される為、追加する順番も重要。変数宣言は型や関数のプロトタイプ宣言も含んでしまう。）

                lst.Add(GetType(CSourceDefineInfoDefineMacro))      'マクロ定義

                lst.Add(GetType(CSourceDefineInfoTypeDef))          '型定義

                lst.Add(GetType(CSourceDefineInfoFunction))         '関数定義/関数プロトタイプ宣言

                lst.Add(GetType(CSourceDefineInfoTypePrototype))    '型のプロトタイプ宣言

                lst.Add(GetType(CSourceDefineInfoVariable))         '変数宣言

                lst.Add(GetType(CSourceDefineInfoUnknown))          '上記以外の不明な文（必ず最後にすること）
            End If

            Return lst
        End Get
    End Property

End Class

'--------------------------------------------------------------
#Region "トークン処理関係"

''' <summary>
''' 文の情報を保持するクラスです。
''' </summary>
''' <remarks></remarks>
Public Class CSourceStatement

    ''' <summary>開始行番号</summary>
    Public StartLine As Integer

    ''' <summary>終了行番号</summary>
    Public EndLine As Integer

    ''' <summary>トークンリスト</summary>
    Public TokenList As CSourceTokenList

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Return String.Format("{0}-{1} : {2}", Me.StartLine, Me.EndLine, Me.TokenList.ToString)
    End Function

    ''' <summary>
    ''' 内部トークンも含めて文字列化します。
    ''' </summary>
    ''' <param name="Level"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Function ToString(ByVal Level As Integer) As String
        Return String.Format("{0}-{1} : {2}", Me.StartLine, Me.EndLine, Me.TokenList.ToString(Level))
    End Function

End Class


''' <summary>
''' トークンのリストクラスです。
''' </summary>
''' <remarks></remarks>
Public Class CSourceTokenList
    Inherits List(Of CSourceToken)

#Region "シーケンシャルアクセス"

    ''' <summary>シーケンシャルアクセス時の現在位置を保持します。</summary>
    Public mIndex As Integer

    ''' <summary>
    ''' シーケンシャルアクセス時の現在トークンを取得/設定します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Token() As CSourceToken
        Get
            If EndOfToken Then Return Nothing
            Return Me(mIndex)
        End Get
        Set(ByVal value As CSourceToken)
            If EndOfToken Then Throw New System.IndexOutOfRangeException
            Me(mIndex) = value
        End Set
    End Property

    ''' <summary>
    ''' シーケンシャルアクセス時の現在トークンのテキストを返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property TokenText() As String
        Get
            If EndOfToken Then Return ""
            Return Me(mIndex).Text
        End Get
    End Property

    ''' <summary>
    ''' シーケンシャルアクセス時に、一つ次のトークンを取得します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property NextToken() As CSourceToken
        Get
            Dim idx As Integer = mIndex + 1
            If (idx < 0) Or (Me.Count <= idx) Then Return Nothing
            Return Me(idx)
        End Get
    End Property

    ''' <summary>
    ''' シーケンシャルアクセス時に、一つ前のトークンを取得します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property PrevToken() As CSourceToken
        Get
            Dim idx As Integer = mIndex - 1
            If (idx < 0) Or (Me.Count <= idx) Then Return Nothing
            Return Me(idx)
        End Get
    End Property

    ''' <summary>
    ''' シーケンシャルアクセスで現在位置を先頭にまき戻します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Rewind()
        mIndex = 0
    End Sub

    ''' <summary>
    ''' シーケンシャルアクセスで現在のトークンを次に進めます。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub MoveNext()
        mIndex += 1
    End Sub

    ''' <summary>
    ''' シーケンシャルアクセスで現在のトークンを前に進めます。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub MovePrev()
        mIndex -= 1
    End Sub

    ''' <summary>
    ''' シーケンシャルアクセスで現在のトークンを指定します。
    ''' </summary>
    ''' <param name="Index"></param>
    ''' <remarks></remarks>
    Public Sub Seek(ByVal Index As Integer)
        mIndex = Index
    End Sub

    ''' <summary>
    ''' シーケンシャルアクセスでの現在のトークンのインデックスを取得/設定します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property TokenIndex() As Integer
        Get
            Return mIndex
        End Get
        Set(ByVal value As Integer)
            mIndex = value
        End Set
    End Property

    ''' <summary>
    ''' シーケンシャルアクセスで終端又は先端にを超えた場合にTrueを返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property EndOfToken() As Boolean
        Get
            Return IsInvalidIndex(mIndex)
        End Get
    End Property

    ''' <summary>
    ''' シーケンシャルアクセス時に現在位置から終わりまでのコピーを返します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function CopyToTheEnd() As CSourceTokenList
        Return Copy(mIndex)
    End Function

#End Region

#Region "リスト操作"

    ''' <summary>
    ''' リストのコピーを作成します。
    ''' </summary>
    ''' <param name="StartIndex"></param>
    ''' <param name="EndIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Copy(ByVal StartIndex As Integer, ByVal EndIndex As Integer) As CSourceTokenList

        Dim ret As New CSourceTokenList
        For x As Integer = StartIndex To EndIndex
            ret.Add(Me(x))
        Next

        Return ret
    End Function

    ''' <summary>
    ''' リストのコピーを作成します。
    ''' </summary>
    ''' <param name="StartIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Copy(ByVal StartIndex As Integer) As CSourceTokenList
        Return Copy(StartIndex, Me.Count - 1)
    End Function

    ''' <summary>
    ''' リストのコピーを作成します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Copy() As CSourceTokenList
        Return Copy(0, Me.Count - 1)
    End Function

    ''' <summary>
    ''' トークンリスト内のトークンを追加します。
    ''' </summary>
    ''' <param name="Tokens"></param>
    ''' <remarks></remarks>
    Public Overloads Sub Add(ByVal Tokens As CSourceTokenList)
        For Each tkn As CSourceToken In Tokens
            Me.Add(tkn)
        Next
    End Sub

    ''' <summary>
    ''' 新しいトークンを作成し追加します。
    ''' </summary>
    ''' <param name="Text"></param>
    ''' <param name="HasSpace"></param>
    ''' <remarks></remarks>
    Public Overloads Sub Add(ByVal Text As String, Optional ByVal HasSpace As Boolean = False)
        Dim tkn As New CSourceToken
        tkn.Text = Text
        tkn.HasSpace = HasSpace
        Me.Add(tkn)
    End Sub

    ''' <summary>
    ''' 各トークン文字列を取得・設定します。
    ''' 範囲外のインデックスが指定された場合、空文字を返します。
    ''' (設定は例外が発生します）
    ''' </summary>
    ''' <value></value>
    ''' <returns>
    ''' </returns>
    ''' <remarks></remarks>
    Public Property Text(ByVal Index As Integer) As String
        Get
            If (Index < 0) Or (Me.Count <= Index) Then Return ""
            Return Me(Index).Text
        End Get
        Set(ByVal value As String)
            Me(Index).Text = value
        End Set
    End Property

    ''' <summary>
    ''' トークンリストをカンマ(,)毎に分割します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function CommaSplit() As List(Of CSourceTokenList)

        Dim ret As New List(Of CSourceTokenList)
        Dim dat As CSourceTokenList = Nothing
        Me.Rewind()
        Dim tkn As CSourceToken
        Do
            tkn = Me.Token
            If tkn Is Nothing Then Exit Do

            If tkn.Text = "," Then
                ret.Add(dat)
                dat = Nothing
            Else
                If dat Is Nothing Then
                    dat = New CSourceTokenList
                End If
                dat.Add(tkn)
            End If

            Me.MoveNext()
        Loop
        If dat IsNot Nothing Then
            ret.Add(dat)
        End If

        Return ret
    End Function

    ''' <summary>
    ''' トークンの値を更新したリストを返します。
    ''' </summary>
    ''' <param name="Dic"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Replace(ByVal Dic As Dictionary(Of String, CSourceTokenList)) As CSourceTokenList
        Dim ret As New CSourceTokenList

        For Each tkn As CSourceToken In Me
            If Dic.ContainsKey(tkn.Text) Then
                '置き換え
                ret.Add(Dic(tkn.Text))
            Else
                'そのまま
                ret.Add(tkn)
            End If
        Next

        Return ret
    End Function

    ''' <summary>
    ''' インデックスが有効かどうかを判断します。
    ''' </summary>
    ''' <param name="Index"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function IsInvalidIndex(ByVal Index As Integer) As Boolean
        Return (Index < 0) Or (Me.Count <= Index)
    End Function

#End Region

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Dim ss As New System.Text.StringBuilder
        For x As Integer = 0 To Me.Count - 1
            ss.AppendFormat("{0}", Me(x).ToString)
        Next
        Return ss.ToString
    End Function

    ''' <summary>
    ''' 内部トークンも含め文字列化します。
    ''' </summary>
    ''' <param name="Level"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Function ToString(ByVal Level As Integer) As String
        Dim ss As New System.Text.StringBuilder
        For x As Integer = 0 To Me.Count - 1
            ss.AppendFormat("{0}", Me(x).ToString(Level))
        Next
        Return ss.ToString
    End Function

    ''' <summary>
    ''' 全てのトークン文字列を連結した文字列を返します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function AllText() As String
        Dim ss As New System.Text.StringBuilder
        For Each tkn As CSourceToken In Me
            If ss.Length > 0 Then ss.Append(" ")
            ss.Append(tkn.Text)
        Next
        Return ss.ToString
    End Function

End Class


''' <summary>
''' トークンクラスです。
''' </summary>
''' <remarks></remarks>
Public Class CSourceToken

    ''' <summary>トークン文字列</summary>
    Public Text As String

    ''' <summary>トークンの前に空白があるか？</summary>
    Public HasSpace As Boolean

    ''' <summary>内部トークンリスト</summary>
    Public InnerTokenList As CSourceTokenList

    ''' <summary>
    ''' トークンが改行である場合Trueを返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property IsCR() As Boolean
        Get
            Return Text = vbCrLf
        End Get
    End Property

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Return "[" + Text + "]"
    End Function

    ''' <summary>
    ''' 内部トークンも含め文字列化します。
    ''' </summary>
    ''' <param name="Level"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Function ToString(ByVal Level As Integer) As String
        Dim ret As String = ""
        If HasSpace Then ret += " "

        If InnerTokenList Is Nothing Then
            ret += Me.ToString()
        ElseIf Level <= 0 Then
            ret += Me.ToString()
        Else
            ret += String.Format("[{0}:{1}]", Text, InnerTokenList.ToString(Level - 1))
        End If

        Return ret
    End Function

    ''' <summary>
    ''' 複製を作成します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Clone() As CSourceToken
        Dim ret As New CSourceToken
        ret.Text = Me.Text
        ret.HasSpace = Me.HasSpace
        ret.InnerTokenList = Me.InnerTokenList.Copy
        Return ret
    End Function

End Class

#End Region

'--------------------------------------------------------------
#Region "型関係"

''' <summary>
''' 引数リストや構造体メンバの定義情報を保持するクラスです。
''' </summary>
''' <remarks></remarks>
Public Class CSourceVarInfo

    ''' <summary>元のトークンリストを保持します。</summary>
    Public TokenList As CSourceTokenList

    ''' <summary>定義形式(struct/union/enum等)を保持します。</summary>
    Public DefineType As String

    ''' <summary>パラメタ/引数名称を保持します。</summary>
    Public Name As String

    ''' <summary>基本型名称を保持します。</summary>
    Public TypeName As String

    ''' <summary>タグ名称を保持します。</summary>
    Public TagName As String

    ''' <summary>次元数のリストを保持します。</summary>
    Public Dimension As New List(Of CSourceTokenList)

    ''' <summary>ポインタレベル(*の数)を保持します。</summary>
    Public PointerLevel As Integer

    ''' <summary>デフォルト値を保持します。Nothingならデフォルト値はありません。</summary>
    Public DefaultValue As CSourceTokenList

    ''' <summary>構造体/共用体などの内部メンバ情報を保持します。</summary>
    Public Member As CSourceVarInfoList

    '--------------------------

    ''' <summary>
    ''' 初期化します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Clear()

        Name = ""
        TypeName = ""
        TagName = ""
        Dimension.Clear()
        PointerLevel = 0
        DefaultValue = Nothing
        Member = Nothing

    End Sub

    ''' <summary>
    ''' 定義を解析します。
    ''' </summary>
    ''' <param name="Tokens"></param>
    ''' <param name="Index"></param>
    ''' <param name="CammaEnd"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function Parse(ByVal Tokens As CSourceTokenList, ByRef Index As Integer, ByVal CammaEnd As Boolean) As CSourceVarInfoList

        Dim sidx As Integer = Index
        Dim ret As New CSourceVarInfoList
        Dim tkn As CSourceToken
        Dim tname As String = ""
        Dim typeok As Boolean = False
        Dim tagname As String = ""
        Dim deftype As String = ""
        Dim mem As CSourceVarInfoList = Nothing
        Do
            'トークン取得
            If Tokens.IsInvalidIndex(Index) Then Exit Do
            tkn = Tokens(Index)

            '型名取得
            Select Case tkn.Text
                Case "static", "extern"
                    'これらは無視

                Case "const"
                    tname += " " + tkn.Text

                Case "void", "char", "short", "int", "long", "float", "double"
                    tname += " " + tkn.Text
                    typeok = True

                Case "unsigned"
                    tname += " " + tkn.Text
                    typeok = True

                Case "struct", "union", "enum"
                    '定義タイプ取得
                    deftype = tkn.Text

                    'タグ名取得
                    tname += " " + tkn.Text
                    Index += 1
                    If Tokens.IsInvalidIndex(Index) Then Stop
                    If Tokens.Text(Index) <> "{}" Then
                        tagname = Tokens.Text(Index)
                        tname += " " + tagname
                        Index += 1
                    End If

                    'メンバ情報の取得
                    If Tokens.Text(Index) = "{}" Then

                        'メンバリスト取得
                        tkn = Tokens(Index)
                        mem = CSourceVarInfoList.Parse(tkn.InnerTokenList, 0, False)

                        '列挙体の場合、名称に修正
                        If deftype = "enum" Then
                            For Each vv As CSourceVarInfo In mem
                                If vv.Name = "" Then
                                    vv.Name = vv.TypeName
                                End If
                                vv.TypeName = ""
                            Next
                        End If

                        '次のトークンへ
                        Index += 1
                    End If

                    Exit Do

                Case Else
                    If typeok Then
                        '既に型名が判明している場合、名前と判断
                    Else
                        'まだ型名が判明していない場合、型名とする
                        tname += " " + tkn.Text
                        Index += 1
                    End If
                    Exit Do

            End Select

            '次のトークンへ
            Index += 1
        Loop
        tname = tname.Trim

        Dim vi As CSourceVarInfo = Nothing
        Do
            '新しい定義情報の生成
            vi = New CSourceVarInfo
            vi.TypeName = tname
            vi.Member = mem
            vi.TagName = tagname
            vi.DefineType = deftype

            'ポインタレベルの取得
            Do
                'トークン取得
                If Tokens.IsInvalidIndex(Index) Then Exit Do
                tkn = Tokens(Index)

                'ポインタレベル加算
                If tkn.Text <> "*" Then Exit Do
                vi.PointerLevel += 1

                '次のトークンへ
                Index += 1
            Loop

            '名称の取得
            If Tokens.IsInvalidIndex(Index) Then Exit Do
            tkn = Tokens(Index)
            If tkn.Text = "()" Then
                '関数タイプの可能性

                If tkn.InnerTokenList Is Nothing Then Stop '構文がおかしい
                If tkn.InnerTokenList.Text(0) <> "*" Then Stop 'サポートしていない構文

                '関数タイプ
                vi.Name = tkn.InnerTokenList.Text(1)
                Index += 1
                vi.DefineType = "function"

            ElseIf tkn.Text = "," Then
                '名前なし

            ElseIf tkn.Text = "=" Then
                '名前なしでデフォルト値指定＝enum

            Else
                '関数タイプ以外の定義
                vi.Name = tkn.Text
                Index += 1
            End If

            '配列/関数呼出/デフォルト値の取得
            Do
                'トークン取得
                If Tokens.IsInvalidIndex(Index) Then Exit Do
                tkn = Tokens(Index)
                If (tkn.Text = ",") Or (tkn.Text = ";") Then Exit Do

                If tkn.Text = "[]" Then
                    '配列

                    '配列情報追加
                    vi.Dimension.Add(tkn.InnerTokenList)

                ElseIf tkn.Text = "=" Then
                    'デフォルト値

                    'デフォルト値の値トークンリストを格納
                    vi.DefaultValue = New CSourceTokenList
                    Index += 1
                    Do
                        'トークン取得
                        If Tokens.IsInvalidIndex(Index) Then Exit Do
                        tkn = Tokens(Index)

                        '終了判定
                        If (tkn.Text = ",") Or (tkn.Text = ";") Then Exit Do

                        'デフォルト値トークンリストへ追加
                        vi.DefaultValue.Add(tkn)

                        '次のトークンへ
                        Index += 1
                    Loop

                    Exit Do

                ElseIf tkn.Text = "()" Then
                    '関数呼出

                    '引数リストの取得
                    vi.Member = CSourceVarInfoList.Parse(tkn.InnerTokenList, 0, True)

                ElseIf (tkn.Text = ",") Or (tkn.Text = ";") Then
                    'メンバ/引数の区切り

                    Exit Do

                ElseIf tkn.Text = "{}" Then
                    '関数定義の区切り

                    Exit Do
                Else
                    '不明な構文

                    'Debug.Print("{0}", Tokens.AllText)
                    'Stop
                    Return Nothing

                End If

                '次のトークンへ
                Index += 1
            Loop

            '定義情報リストに追加
            If vi IsNot Nothing Then
                ret.Add(vi)
                vi = Nothing
            End If

            If Tokens.IsInvalidIndex(Index) Then Exit Do
            If Tokens(Index).Text = "," Then

                'カンマで終了か？
                If CammaEnd Then Exit Do '終了

                '次の定義へ
                Index += 1

            Else
                Exit Do '終了
            End If
        Loop
        If vi IsNot Nothing Then
            ret.Add(vi)
        End If

        '終了
        Return ret
    End Function

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Dim ss As New System.Text.StringBuilder
        ss.AppendFormat("{0} {1}", GetTypeName(), Me.Name)
        If DefaultValue IsNot Nothing Then
            ss.AppendFormat("= {0}", DefaultValue.AllText)
        End If
        Return ss.ToString
    End Function

    ''' <summary>
    ''' 型名を文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetTypeName() As String
        Dim ss As New System.Text.StringBuilder
        ss.AppendFormat("{0}", Me.TypeName)
        ss.Append(New String("*"c, Me.PointerLevel))
        For Each dd As CSourceTokenList In Me.Dimension
            ss.AppendFormat("[{0}]", dd.AllText)
        Next
        Return ss.ToString
    End Function

    ''' <summary>
    ''' 情報をコピーします。
    ''' </summary>
    ''' <param name="Src"></param>
    ''' <remarks></remarks>
    Public Sub CopyFrom(ByVal Src As CSourceVarInfo)
        Me.Name = Src.Name
        Me.TypeName = Src.TypeName
        Me.TagName = Src.TagName
        Me.Dimension = Src.Dimension
        Me.PointerLevel = Src.PointerLevel
        Me.DefaultValue = Src.DefaultValue
        Me.Member = Src.Member
    End Sub

End Class

''' <summary>
''' 引数リストや構造体メンバのリストクラスです。
''' </summary>
''' <remarks></remarks>
Public Class CSourceVarInfoList
    Inherits List(Of CSourceVarInfo)

    ''' <summary>
    ''' 定義リストを解析します。
    ''' </summary>
    ''' <param name="Tokens"></param>
    ''' <param name="Index"></param>
    ''' <param name="CammaEnd"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function Parse(ByVal Tokens As CSourceTokenList, ByRef Index As Integer, ByVal CammaEnd As Boolean) As CSourceVarInfoList

        Dim ret As New CSourceVarInfoList
        Dim tkn As CSourceToken
        Do
            If Tokens.IsInvalidIndex(Index) Then Exit Do
            tkn = Tokens(Index)
            If (tkn.Text = ";") Or (tkn.Text = ",") Then
                '次のトークンへ
                Index += 1
                Continue Do
            End If

            'メンバ一つの取り出しとリストへの追加
            Dim vv As CSourceVarInfoList
            vv = CSourceVarInfo.Parse(Tokens, Index, CammaEnd)
            ret.AddRange(vv)

            '次のトークンへ
            Index += 1
        Loop

        '成功
        Return ret
    End Function

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Dim ss As New System.Text.StringBuilder
        For Each vv As CSourceVarInfo In Me
            ss.AppendLine(vv.ToString)
        Next
        Return ss.ToString
    End Function

End Class

#End Region

'--------------------------------------------------------------
#Region "定義関係"

''' <summary>
''' 定義情報の基底クラスです。
''' </summary>
''' <remarks></remarks>
Public MustInherit Class CSourceDefineInfo

    ''' <summary>解析対象の情報を保持します。</summary>
    Public SourceStatement As CSourceStatement

    ''' <summary>検索用の名称を保持します。</summary>
    Public Name As String

    ''' <summary>コード生成時に使用されるフラグを保持します。</summary>
    Private FlagDic As New Dictionary(Of String, Boolean)

    ''' <summary>変換時に使用する作業用データを保持します。</summary>
    Public ConvertWorkData As Object

    '--------------------------

    ''' <summary>
    ''' 初期化します。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <remarks></remarks>
    Public Sub Initialize(ByVal Statement As CSourceStatement, ByVal Name As String)

        Me.SourceStatement = Statement
        Me.Name = Name

    End Sub

    ''' <summary>
    ''' 初期化します。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <remarks></remarks>
    Public Sub Initialize(ByVal Statement As CSourceStatement)
        Initialize(Statement, "")
    End Sub

    ''' <summary>
    ''' 改正対象文のトークンリストを保持します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property SourceTokens() As CSourceTokenList
        Get
            Return SourceStatement.TokenList
        End Get
    End Property

    ''' <summary>
    ''' 定義情報を解析します。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <returns>解析に成功した場合True、失敗した場合False</returns>
    ''' <remarks></remarks>
    Public MustOverride Function Parse(ByVal Statement As CSourceStatement) As Boolean

    ''' <summary>
    ''' 定義リストに定義を追加します。
    ''' </summary>
    ''' <param name="DefineList"></param>
    ''' <remarks></remarks>
    Public Overridable Sub AddDefine(ByVal DefineList As List(Of CSourceDefineInfo))

        '自分自身を登録
        DefineList.Add(Me)

    End Sub

    '--------------------------

    ''' <summary>
    ''' コード生成自に使用するフラグを取得・設定します。
    ''' </summary>
    ''' <param name="FlagName"></param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable Property Flag(ByVal FlagName As String) As Boolean
        Get
            If Not FlagDic.ContainsKey(FlagName) Then Return False
            Return FlagDic(FlagName)
        End Get
        Set(ByVal value As Boolean)
            FlagDic(FlagName) = value
        End Set
    End Property

End Class

'--------------------------------------------------------------

''' <summary>
''' 解析できなかった文を保持します。
''' </summary>
''' <remarks></remarks>
Public Class CSourceDefineInfoUnknown
    Inherits CSourceDefineInfo

    ''' <summary>
    ''' 文を解析します。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function Parse(ByVal Statement As CSourceStatement) As Boolean

        'トークンリストの保存
        Initialize(Statement, "Unknown")

        '必ず成功
        Return True
    End Function

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Dim ss As New System.Text.StringBuilder
        ss.AppendFormat("Unknown : ")
        ss.AppendFormat("{0}", MyBase.SourceStatement.ToString)
        Return ss.ToString()
    End Function

End Class

'--------------------------------------------------------------

''' <summary>
''' プリプロセッサ文を解析します。
''' </summary>
''' <remarks></remarks>
Public Class CSourceDefineInfoPreprocessor
    Inherits CSourceDefineInfo

    ''' <summary>プリプロセッサタイプを保持します。</summary>
    Public PreprocessorType As String

    '--------------------------

    ''' <summary>
    ''' 文を解析します。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function Parse(ByVal Statement As CSourceStatement) As Boolean

        'チェック
        If Statement.TokenList.Text(0) <> "#" Then Return False
        If Statement.TokenList.Text(1) = "" Then Return False

        '初期化
        Initialize(Statement)

        '解析
        PreprocessorType = SourceTokens.Text(1)
        MyBase.Name = PreprocessorType

        '成功
        Return True
    End Function

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Dim ss As New System.Text.StringBuilder
        ss.AppendFormat("Preprocessor : ")
        ss.AppendFormat("{0}", Name)
        Return ss.ToString()
    End Function

End Class

''' <summary>
''' DEFINEプリプロセッサ文を解析します。
''' </summary>
''' <remarks></remarks>
Public Class CSourceDefineInfoDefineMacro
    Inherits CSourceDefineInfoPreprocessor

    ''' <summary>マクロ名を保持します。</summary>
    Public MacroName As String

    ''' <summary>引数リスト情報を保持します。</summary>
    Public Params As CSourceVarInfoList

    ''' <summary>値のトークンリストを保持します。</summary>
    Public Value As CSourceTokenList

    '--------------------------

    ''' <summary>
    ''' 文を解析します。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function Parse(ByVal Statement As CSourceStatement) As Boolean

        'チェック
        If MyBase.Parse(Statement) = False Then Return False
        If Statement.TokenList.Text(1) <> "define" Then Return False

        '初期化
        Initialize(Statement)
        Params = Nothing
        Value = Nothing

        '解析
        SourceTokens.Rewind()
        SourceTokens.Seek(2)
        MacroName = SourceTokens.TokenText
        SourceTokens.MoveNext()
        If Not SourceTokens.EndOfToken Then

            If (SourceTokens.Token.Text = "()") And (SourceTokens.Token.HasSpace = False) Then
                '引数リストの解析
                ParseParam(SourceTokens.Token.InnerTokenList)
                SourceTokens.MoveNext()
            End If

            If Not SourceTokens.EndOfToken Then
                '値部のコピー
                Value = SourceTokens.CopyToTheEnd()
            End If

        End If
        MyBase.Name = MacroName

        '成功
        Return True
    End Function

    ''' <summary>
    ''' 引数リストを解析します。
    ''' </summary>
    ''' <param name="ParamTokens"></param>
    ''' <remarks></remarks>
    Public Sub ParseParam(ByVal ParamTokens As CSourceTokenList)

        Params = New CSourceVarInfoList

        Dim tkn As CSourceToken
        ParamTokens.Rewind()
        Do
            tkn = ParamTokens.Token
            ParamTokens.MoveNext()
            If tkn Is Nothing Then Exit Do
            If tkn.Text = "," Then Throw New Exception("引数リストの解析に失敗しました。")

            Dim vv As New CSourceVarInfo
            vv.Name = tkn.Text
            Params.Add(vv)

            tkn = ParamTokens.Token
            ParamTokens.MoveNext()
            If tkn IsNot Nothing Then
                If tkn.Text <> "," Then Throw New Exception("引数リストの解析に失敗しました。")
            End If

        Loop

    End Sub

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Dim ss As New System.Text.StringBuilder
        ss.AppendFormat("Macro : ")
        ss.AppendFormat("{0}", Name)
        Return ss.ToString()
    End Function

    '--------------------------

    ''' <summary>
    ''' 展開したトークンリストを返します。
    ''' </summary>
    ''' <param name="MacroParams"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetExpandTokenList(ByVal MacroParams As CSourceTokenList) As CSourceTokenList

        '引数のチェック
        If Me.Params Is Nothing Then
            If MacroParams IsNot Nothing Then Stop '引数がないマクロに引数が指定された
        End If

        '引数の分割
        Dim pp As List(Of CSourceTokenList)
        pp = MacroParams.CommaSplit()
        If Me.Params.Count <> pp.Count Then Stop '引数の数が一致しない

        '引数がない場合、値のコピーを返す
        If Params Is Nothing Then
            Return Me.Value.Copy
        End If

        '展開用辞書の作成
        Dim dic As New Dictionary(Of String, CSourceTokenList)
        For x As Integer = 0 To Params.Count - 1
            dic.Add(Params(x).Name, pp(x))
        Next

        '展開
        Dim ret As CSourceTokenList
        ret = Value.Replace(dic)

        Return ret
    End Function

End Class

'--------------------------------------------------------------

''' <summary>
''' 型定義文を解析します。
''' </summary>
''' <remarks></remarks>
Public Class CSourceDefineInfoTypeDef
    Inherits CSourceDefineInfo

    ''' <summary>全ての型の定義リストを保持します。</summary>
    Public AllDefines As CSourceVarInfoList

    ''' <summary>メインとなる型定義を保持します。</summary>
    Public MainDefine As CSourceVarInfo

    '--------------------------

    ''' <summary>
    ''' 文を解析します。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function Parse(ByVal Statement As CSourceStatement) As Boolean

        'チェック
        If Statement.TokenList.Text(0) <> "typedef" Then Return False

        '初期化
        Initialize(Statement)
        MyBase.Name = ""

        '解析
        AllDefines = CSourceVarInfoList.Parse(SourceTokens, 1, False)
        If AllDefines.Count = 0 Then Stop

        'メイン定義の選出
        For Each vv As CSourceVarInfo In AllDefines
            If (vv.PointerLevel = 0) And (vv.Dimension.Count = 0) Then
                MainDefine = vv
                Exit For
            End If
        Next
        If MainDefine Is Nothing Then
            MainDefine = AllDefines(0)
        End If
        MyBase.Name = MainDefine.Name

        '成功
        Return True
    End Function

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Dim ss As New System.Text.StringBuilder
        ss.AppendFormat("Typedef : ")
        ss.AppendFormat("{0} : ", MainDefine.DefineType)
        ss.AppendFormat("{0}", Name)
        Return ss.ToString()
    End Function

End Class

'--------------------------------------------------------------

''' <summary>
''' 関数定義を解析します。
''' </summary>
''' <remarks></remarks>
Public Class CSourceDefineInfoFunction
    Inherits CSourceDefineInfo

    ''' <summary>関数定義情報を保持します。</summary>
    Public FuncInfo As CSourceVarInfo

    '--------------------------

    ''' <summary>
    ''' 文を解析します。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function Parse(ByVal Statement As CSourceStatement) As Boolean

        'チェック
        Dim lastidx As Integer = Statement.TokenList.Count - 1
        Do
            If (Statement.TokenList.Text(lastidx - 1) = "()") And (Statement.TokenList.Text(lastidx) = "{}") Then Exit Do 'OK
            If (Statement.TokenList.Text(lastidx) = "()") Then Exit Do 'OK
            Return False
        Loop

        '初期化
        Initialize(Statement)

        '解析
        FuncInfo = New CSourceVarInfo
        Dim vv As CSourceVarInfoList
        vv = CSourceVarInfo.Parse(Statement.TokenList, 0, True)
        If vv.Count <> 1 Then Stop '不明な構文：１文で複数の関数定義
        FuncInfo = vv(0)
        MyBase.Name = FuncInfo.Name

        '成功
        Return True
    End Function

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Dim ss As New System.Text.StringBuilder
        ss.AppendFormat("Function : ")
        ss.AppendFormat("{0}", Name)
        Return ss.ToString()
    End Function

End Class

'--------------------------------------------------------------

''' <summary>
''' 構造体のプロトタイプ宣言を解析します。
''' </summary>
''' <remarks></remarks>
Public Class CSourceDefineInfoTypePrototype
    Inherits CSourceDefineInfo

    ''' <summary>プロトタイプ宣言情報を保持します。</summary>
    Public TypeInfo As CSourceVarInfo

    '--------------------------

    ''' <summary>
    ''' 文を解析します。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function Parse(ByVal Statement As CSourceStatement) As Boolean

        'チェック
        If Statement.TokenList.Text(0) <> "struct" Then Return False

        '初期化
        Initialize(Statement)

        '解析
        Dim vv As CSourceVarInfoList
        vv = CSourceVarInfo.Parse(Statement.TokenList, 0, False)
        If vv.Count <> 1 Then Stop '１文で複数のプロトタイプ宣言
        TypeInfo = vv(0)
        MyBase.Name = TypeInfo.TagName

        '成功
        Return True
    End Function

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Dim ss As New System.Text.StringBuilder
        ss.AppendFormat("Prototype : ")
        ss.AppendFormat("{0}", Name)
        Return ss.ToString()
    End Function

End Class

'--------------------------------------------------------------

''' <summary>
''' 変数定義を解析します。
''' </summary>
''' <remarks></remarks>
Public Class CSourceDefineInfoVariable
    Inherits CSourceDefineInfo

    ''' <summary>解析した変数情報リストを保持します。解析時以外はNothingとなります。</summary>
    Public Vars As CSourceVarInfoList

    ''' <summary>変数情報を保持します。</summary>
    Public VarInfo As CSourceVarInfo

    '--------------------------

    ''' <summary>
    ''' 文を解析します。
    ''' </summary>
    ''' <param name="Statement"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function Parse(ByVal Statement As CSourceStatement) As Boolean

        'チェック
        If Statement.TokenList.Text(0) = "#" Then Return False
        Vars = CSourceVarInfo.Parse(Statement.TokenList, 0, False)
        If Vars Is Nothing Then Return False
        If Vars.Count = 0 Then Return False

        '初期化
        Initialize(Statement)

        '解析


        '成功
        Return True
    End Function

    ''' <summary>
    ''' 定義リストに定義を追加します。
    ''' </summary>
    ''' <param name="DefineList"></param>
    ''' <remarks></remarks>
    Public Overrides Sub AddDefine(ByVal DefineList As System.Collections.Generic.List(Of CSourceDefineInfo))

        If Vars Is Nothing Then Exit Sub
        For Each vv As CSourceVarInfo In Vars

            '解析された各変数を個別に登録
            Dim vi As New CSourceDefineInfoVariable
            vi.VarInfo = vv
            vi.Initialize(Me.SourceStatement, vv.Name)
            DefineList.Add(vi)

        Next

    End Sub

    ''' <summary>
    ''' 文字列化します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Dim ss As New System.Text.StringBuilder
        ss.AppendFormat("Variable : ")
        ss.AppendFormat("{0} ", Name)
        Return ss.ToString()
    End Function

End Class

#End Region
