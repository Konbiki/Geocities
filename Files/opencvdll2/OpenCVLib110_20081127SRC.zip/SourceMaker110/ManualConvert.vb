﻿Option Explicit On
Option Strict On

Imports System.IO
Imports System.Reflection

''' <summary>
''' 自動化できない部分/追加する部分/通常とは異なる変換が必要な部分など、
''' 手動で変換を行う部分を管理します。
''' </summary>
''' <remarks></remarks>
Public Class ManualConvertData

    ''' <summary>手動変換データを保持します。</summary>
    Private ConvertDic As New Dictionary(Of String, String)

    '--------------------------

    ''' <summary>
    ''' 手動変換データを読み込みます。
    ''' </summary>
    ''' <param name="ResourceName"></param>
    ''' <remarks></remarks>
    Public Sub ReadConvertData(ByVal ResourceName As String)

        '変換データのクリア
        ConvertDic.Clear()

        'リソースのオープン
        Dim asm As Assembly = Assembly.GetCallingAssembly()
        Dim stm As Stream = asm.GetManifestResourceStream(ResourceName)
        Dim tr As StreamReader = New StreamReader(stm, System.Text.Encoding.GetEncoding("Shift_JIS"))

        '読込
        Dim key As String = ""
        Dim code As String = ""
        Dim ss As String = ""
        Dim tt As String = ""
        Do
            If tr.EndOfStream Then Exit Do
            ss = tr.ReadLine

            If ss.StartsWith("*") Then
                'キーレコード

                '登録
                If (key <> "") And (code <> "") Then ConvertDic.Add(key, code)

                '新たなキー決定
                key = ss.Substring(1).Trim
                code = ""
                tt = ""

            Else
                'コードレコード

                '余分な改行は除外する
                If ss.Trim = "" Then
                    If code <> "" Then
                        tt += ss.Trim + vbCrLf
                    End If
                Else
                    If code <> "" Then code += vbCrLf
                    If tt <> "" Then
                        code += tt
                        tt = ""
                    End If
                    code += ss.TrimEnd
                End If
            End If

        Loop
        If (key <> "") And (code <> "") Then ConvertDic.Add(key, code)

    End Sub

    '--------------------------

    ''' <summary>
    ''' 変換コードを返します。対応するキーの変換コードがない場合、空白を返します。
    ''' </summary>
    ''' <param name="Key"></param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Default Public ReadOnly Property ConvertCode(ByVal Key As String) As String
        Get
            If ConvertDic.ContainsKey(Key) Then
                Return ConvertDic(Key)
            End If

            Return ""
        End Get
    End Property

    ''' <summary>
    ''' 変換データが格納されている辞書を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Dic() As Dictionary(Of String, String)
        Get
            Return ConvertDic
        End Get
    End Property

End Class

