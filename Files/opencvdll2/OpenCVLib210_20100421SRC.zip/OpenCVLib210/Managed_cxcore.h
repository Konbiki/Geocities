/*M///////////////////////////////////////////////////////////////////////////////////////
//
//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
//
//  By downloading, copying, installing or using the software you agree to this license.
//  If you do not agree to this license, do not download, install,
//  copy or use the software.
//
//
//                           License Agreement
//                For Open Source Computer Vision Library
//
// Copyright (C) 2000-2008, Intel Corporation, all rights reserved.
// Copyright (C) 2009, Willow Garage Inc., all rights reserved.
// Third party copyrights are property of their respective owners.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistribution's of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//   * Redistribution's in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//   * The name of the copyright holders may not be used to endorse or promote products
//     derived from this software without specific prior written permission.
//
// This software is provided by the copyright holders and contributors "as is" and
// any express or implied warranties, including, but not limited to, the implied
// warranties of merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the Intel Corporation or contributors be liable for any direct,
// indirect, incidental, special, exemplary, or consequential damages
// (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused
// and on any theory of liability, whether in contract, strict liability,
// or tort (including negligence or otherwise) arising in any way out of
// the use of this software, even if advised of the possibility of such damage.
//
//M*/


////#ifndef __OPENCV_CORE_H__
////#define __OPENCV_CORE_H__
////
////#ifdef __IPL_H__
////#define HAVE_IPL
////#endif
////
////#ifndef SKIP_INCLUDES
////  #if defined HAVE_IPL && !defined __IPL_H__
////    #ifndef _INC_WINDOWS
////        #define CV_PRETEND_WINDOWS
////        #define _INC_WINDOWS
////        typedef struct tagBITMAPINFOHEADER BITMAPINFOHEADER;
////        typedef int BOOL;
////    #endif
////    #if defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64
////      #include "ipl.h"
////    #else
////      #include "ipl/ipl.h"
////    #endif
////    #ifdef CV_PRETEND_WINDOWS
////        #undef _INC_WINDOWS
////    #endif
////  #endif
////#endif // SKIP_INCLUDES
////
////#include "cxtypes.h"
////#include "cxerror.h"
////#include "cvver.h"
////
////#ifdef __cplusplus
////extern "C" {
////#endif

/****************************************************************************************\
*          Array allocation, deallocation, initialization and access to elements         *
\****************************************************************************************/

/* <malloc> wrapper.
   If there is no enough memory, the function
   (as well as other OpenCV functions that call cvAlloc)
   raises an error. */
// CVAPI(void*)  cvAlloc( size_t size );
DEFINE_FUNCTION( P(void*), cvAlloc, 1( V(size_t,size) ) ) 

/* <free> wrapper.
   Here and further all the memory releasing functions
   (that all call cvFree) take double pointer in order to
   to clear pointer to the data after releasing it.
   Passing pointer to NULL pointer is Ok: nothing happens in this case
*/
// CVAPI(void)   cvFree_( void* ptr );
DEFINE_FUNCTION( N(void), cvFree_, 1( P(void*,ptr) ) ) 
// #define cvFree(ptr) (cvFree_(*(ptr)), *(ptr)=0)
// Unsupport : cvFree

/* Allocates and initializes IplImage header */
// CVAPI(IplImage*)  cvCreateImageHeader( CvSize size, int depth, int channels );
DEFINE_FUNCTION( SP(IplImage), cvCreateImageHeader, 3( S(CvSize,size), V(int,depth), V(int,channels) ) ) 

/* Inializes IplImage header */
// CVAPI(IplImage*) cvInitImageHeader( IplImage* image, CvSize size, int depth,
//                                    int channels, int origin CV_DEFAULT(0),
//                                    int align CV_DEFAULT(4));
DEFINE_FUNCTION( SP(IplImage), cvInitImageHeader, 6( SP(IplImage,image), S(CvSize,size), V(int,depth), V(int,channels), V(int,origin), V(int,align) ) ) 
DEFINE_FUNCTION( SP(IplImage), cvInitImageHeader, 5( SP(IplImage,image), S(CvSize,size), V(int,depth), V(int,channels), V(int,origin) ) ) 
DEFINE_FUNCTION( SP(IplImage), cvInitImageHeader, 4( SP(IplImage,image), S(CvSize,size), V(int,depth), V(int,channels) ) ) 

/* Creates IPL image (header and data) */
// CVAPI(IplImage*)  cvCreateImage( CvSize size, int depth, int channels );
DEFINE_FUNCTION( SP(IplImage), cvCreateImage, 3( S(CvSize,size), V(int,depth), V(int,channels) ) ) 

/* Releases (i.e. deallocates) IPL image header */
// CVAPI(void)  cvReleaseImageHeader( IplImage** image );
DEFINE_FUNCTION( N(void), cvReleaseImageHeader, 1( SPP(IplImage,image) ) ) 

/* Releases IPL image header and data */
// CVAPI(void)  cvReleaseImage( IplImage** image );
DEFINE_FUNCTION( N(void), cvReleaseImage, 1( SPP(IplImage,image) ) ) 

/* Creates a copy of IPL image (widthStep may differ) */
// CVAPI(IplImage*) cvCloneImage( const IplImage* image );
DEFINE_FUNCTION( SP(IplImage), cvCloneImage, 1( SP(IplImage,image) ) ) 

/* Sets a Channel Of Interest (only a few functions support COI) -
   use cvCopy to extract the selected channel and/or put it back */
// CVAPI(void)  cvSetImageCOI( IplImage* image, int coi );
DEFINE_FUNCTION( N(void), cvSetImageCOI, 2( SP(IplImage,image), V(int,coi) ) ) 

/* Retrieves image Channel Of Interest */
// CVAPI(int)  cvGetImageCOI( const IplImage* image );
DEFINE_FUNCTION( V(int), cvGetImageCOI, 1( SP(IplImage,image) ) ) 

/* Sets image ROI (region of interest) (COI is not changed) */
// CVAPI(void)  cvSetImageROI( IplImage* image, CvRect rect );
DEFINE_FUNCTION( N(void), cvSetImageROI, 2( SP(IplImage,image), S(CvRect,rect) ) ) 

/* Resets image ROI and COI */
// CVAPI(void)  cvResetImageROI( IplImage* image );
DEFINE_FUNCTION( N(void), cvResetImageROI, 1( SP(IplImage,image) ) ) 

/* Retrieves image ROI */
// CVAPI(CvRect) cvGetImageROI( const IplImage* image );
DEFINE_FUNCTION( S(CvRect), cvGetImageROI, 1( SP(IplImage,image) ) ) 

/* Allocates and initalizes CvMat header */
// CVAPI(CvMat*)  cvCreateMatHeader( int rows, int cols, int type );
DEFINE_FUNCTION( SP(CvMat), cvCreateMatHeader, 3( V(int,rows), V(int,cols), V(int,type) ) ) 

// #define CV_AUTOSTEP  0x7fffffff
#pragma push_macro( "CV_AUTOSTEP" )
#undef CV_AUTOSTEP
static const int CV_AUTOSTEP
#pragma pop_macro( "CV_AUTOSTEP" )
	= CV_AUTOSTEP;

/* Initializes CvMat header */
// CVAPI(CvMat*) cvInitMatHeader( CvMat* mat, int rows, int cols,
//                               int type, void* data CV_DEFAULT(NULL),
//                               int step CV_DEFAULT(CV_AUTOSTEP) );
DEFINE_FUNCTION( SP(CvMat), cvInitMatHeader, 6( SP(CvMat,mat), V(int,rows), V(int,cols), V(int,type), P(void*,data), V(int,step) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvInitMatHeader, 5( SP(CvMat,mat), V(int,rows), V(int,cols), V(int,type), P(void*,data) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvInitMatHeader, 4( SP(CvMat,mat), V(int,rows), V(int,cols), V(int,type) ) ) 

/* Allocates and initializes CvMat header and allocates data */
// CVAPI(CvMat*)  cvCreateMat( int rows, int cols, int type );
DEFINE_FUNCTION( SP(CvMat), cvCreateMat, 3( V(int,rows), V(int,cols), V(int,type) ) ) 

/* Releases CvMat header and deallocates matrix data
   (reference counting is used for data) */
// CVAPI(void)  cvReleaseMat( CvMat** mat );
DEFINE_FUNCTION( N(void), cvReleaseMat, 1( SPP(CvMat,mat) ) ) 

/* Decrements CvMat data reference counter and deallocates the data if
   it reaches 0 */
// CV_INLINE  void  cvDecRefData( CvArr* arr )
// {
//     if( CV_IS_MAT( arr ))
//     {
//         CvMat* mat = (CvMat*)arr;
//         mat->data.ptr = NULL;
//         if( mat->refcount != NULL && --*mat->refcount == 0 )
//             cvFree( &mat->refcount );
//         mat->refcount = NULL;
//     }
//     else if( CV_IS_MATND( arr ))
//     {
//         CvMatND* mat = (CvMatND*)arr;
//         mat->data.ptr = NULL;
//         if( mat->refcount != NULL && --*mat->refcount == 0 )
//             cvFree( &mat->refcount );
//         mat->refcount = NULL;
//     }
// }
DEFINE_FUNCTION( N(void), cvDecRefData, 1( MP(UMemory,CvArr,arr) ) ) 

/* Increments CvMat data reference counter */
// CV_INLINE  int  cvIncRefData( CvArr* arr )
// {
//     int refcount = 0;
//     if( CV_IS_MAT( arr ))
//     {
//         CvMat* mat = (CvMat*)arr;
//         if( mat->refcount != NULL )
//             refcount = ++*mat->refcount;
//     }
//     else if( CV_IS_MATND( arr ))
//     {
//         CvMatND* mat = (CvMatND*)arr;
//         if( mat->refcount != NULL )
//             refcount = ++*mat->refcount;
//     }
//     return refcount;
// }
DEFINE_FUNCTION( V(int), cvIncRefData, 1( MP(UMemory,CvArr,arr) ) ) 


/* Creates an exact copy of the input matrix (except, may be, step value) */
// CVAPI(CvMat*) cvCloneMat( const CvMat* mat );
DEFINE_FUNCTION( SP(CvMat), cvCloneMat, 1( SP(CvMat,mat) ) ) 


/* Makes a new matrix from <rect> subrectangle of input array.
   No data is copied */
// CVAPI(CvMat*) cvGetSubRect( const CvArr* arr, CvMat* submat, CvRect rect );
DEFINE_FUNCTION( SP(CvMat), cvGetSubRect, 3( MP(UMemory,CvArr,arr), SP(CvMat,submat), S(CvRect,rect) ) ) 
// #define cvGetSubArr cvGetSubRect
#pragma push_macro( "cvGetSubArr" )
#undef cvGetSubArr
DEFINE_FUNCTION_ALIAS( SP(CvMat), cvGetSubRect, cvGetSubArr, 3( MP(UMemory,CvArr,arr), SP(CvMat,submat), S(CvRect,rect) ) ) 
#pragma pop_macro( "cvGetSubArr" )

/* Selects row span of the input array: arr(start_row:delta_row:end_row,:)
    (end_row is not included into the span). */
// CVAPI(CvMat*) cvGetRows( const CvArr* arr, CvMat* submat,
//                         int start_row, int end_row,
//                         int delta_row CV_DEFAULT(1));
DEFINE_FUNCTION( SP(CvMat), cvGetRows, 5( MP(UMemory,CvArr,arr), SP(CvMat,submat), V(int,start_row), V(int,end_row), V(int,delta_row) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvGetRows, 4( MP(UMemory,CvArr,arr), SP(CvMat,submat), V(int,start_row), V(int,end_row) ) ) 

// CV_INLINE  CvMat*  cvGetRow( const CvArr* arr, CvMat* submat, int row )
// {
//     return cvGetRows( arr, submat, row, row + 1, 1 );
// }
DEFINE_FUNCTION( SP(CvMat), cvGetRow, 3( MP(UMemory,CvArr,arr), SP(CvMat,submat), V(int,row) ) ) 


/* Selects column span of the input array: arr(:,start_col:end_col)
   (end_col is not included into the span) */
// CVAPI(CvMat*) cvGetCols( const CvArr* arr, CvMat* submat,
//                         int start_col, int end_col );
DEFINE_FUNCTION( SP(CvMat), cvGetCols, 4( MP(UMemory,CvArr,arr), SP(CvMat,submat), V(int,start_col), V(int,end_col) ) ) 

// CV_INLINE  CvMat*  cvGetCol( const CvArr* arr, CvMat* submat, int col )
// {
//     return cvGetCols( arr, submat, col, col + 1 );
// }
DEFINE_FUNCTION( SP(CvMat), cvGetCol, 3( MP(UMemory,CvArr,arr), SP(CvMat,submat), V(int,col) ) ) 

/* Select a diagonal of the input array.
   (diag = 0 means the main diagonal, >0 means a diagonal above the main one,
   <0 - below the main one).
   The diagonal will be represented as a column (nx1 matrix). */
// CVAPI(CvMat*) cvGetDiag( const CvArr* arr, CvMat* submat,
//                             int diag CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvMat), cvGetDiag, 3( MP(UMemory,CvArr,arr), SP(CvMat,submat), V(int,diag) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvGetDiag, 2( MP(UMemory,CvArr,arr), SP(CvMat,submat) ) ) 

/* low-level scalar <-> raw data conversion functions */
// CVAPI(void) cvScalarToRawData( const CvScalar* scalar, void* data, int type,
//                               int extend_to_12 CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvScalarToRawData, 4( SP(CvScalar,scalar), P(void*,data), V(int,type), V(int,extend_to_12) ) ) 
DEFINE_FUNCTION( N(void), cvScalarToRawData, 3( SP(CvScalar,scalar), P(void*,data), V(int,type) ) ) 

// CVAPI(void) cvRawDataToScalar( const void* data, int type, CvScalar* scalar );
DEFINE_FUNCTION( N(void), cvRawDataToScalar, 3( P(const void*,data), V(int,type), SP(CvScalar,scalar) ) ) 

/* Allocates and initializes CvMatND header */
// CVAPI(CvMatND*)  cvCreateMatNDHeader( int dims, const int* sizes, int type );
DEFINE_FUNCTION( SP(CvMatND), cvCreateMatNDHeader, 3( V(int,dims), VP(int,sizes), V(int,type) ) ) 
DEFINE_FUNCTION( SP(CvMatND), cvCreateMatNDHeader, 3( V(int,dims), P(const int*,sizes), V(int,type) ) ) 

/* Allocates and initializes CvMatND header and allocates data */
// CVAPI(CvMatND*)  cvCreateMatND( int dims, const int* sizes, int type );
DEFINE_FUNCTION( SP(CvMatND), cvCreateMatND, 3( V(int,dims), VP(int,sizes), V(int,type) ) ) 
DEFINE_FUNCTION( SP(CvMatND), cvCreateMatND, 3( V(int,dims), P(const int*,sizes), V(int,type) ) ) 

/* Initializes preallocated CvMatND header */
// CVAPI(CvMatND*)  cvInitMatNDHeader( CvMatND* mat, int dims, const int* sizes,
//                                     int type, void* data CV_DEFAULT(NULL) );
DEFINE_FUNCTION( SP(CvMatND), cvInitMatNDHeader, 5( SP(CvMatND,mat), V(int,dims), VP(int,sizes), V(int,type), P(void*,data) ) ) 
DEFINE_FUNCTION( SP(CvMatND), cvInitMatNDHeader, 5( SP(CvMatND,mat), V(int,dims), P(const int*,sizes), V(int,type), P(void*,data) ) ) 
DEFINE_FUNCTION( SP(CvMatND), cvInitMatNDHeader, 4( SP(CvMatND,mat), V(int,dims), VP(int,sizes), V(int,type) ) ) 
DEFINE_FUNCTION( SP(CvMatND), cvInitMatNDHeader, 4( SP(CvMatND,mat), V(int,dims), P(const int*,sizes), V(int,type) ) ) 

/* Releases CvMatND */
// CV_INLINE  void  cvReleaseMatND( CvMatND** mat )
// {
//     cvReleaseMat( (CvMat**)mat );
// }
DEFINE_FUNCTION( N(void), cvReleaseMatND, 1( SPP(CvMatND,mat) ) ) 

/* Creates a copy of CvMatND (except, may be, steps) */
// CVAPI(CvMatND*) cvCloneMatND( const CvMatND* mat );
DEFINE_FUNCTION( SP(CvMatND), cvCloneMatND, 1( SP(CvMatND,mat) ) ) 

/* Allocates and initializes CvSparseMat header and allocates data */
// CVAPI(CvSparseMat*)  cvCreateSparseMat( int dims, const int* sizes, int type );
DEFINE_FUNCTION( SP(CvSparseMat), cvCreateSparseMat, 3( V(int,dims), VP(int,sizes), V(int,type) ) ) 
DEFINE_FUNCTION( SP(CvSparseMat), cvCreateSparseMat, 3( V(int,dims), P(const int*,sizes), V(int,type) ) ) 

/* Releases CvSparseMat */
// CVAPI(void)  cvReleaseSparseMat( CvSparseMat** mat );
DEFINE_FUNCTION( N(void), cvReleaseSparseMat, 1( SPP(CvSparseMat,mat) ) ) 

/* Creates a copy of CvSparseMat (except, may be, zero items) */
// CVAPI(CvSparseMat*) cvCloneSparseMat( const CvSparseMat* mat );
DEFINE_FUNCTION( SP(CvSparseMat), cvCloneSparseMat, 1( SP(CvSparseMat,mat) ) ) 

/* Initializes sparse array iterator
   (returns the first node or NULL if the array is empty) */
// CVAPI(CvSparseNode*) cvInitSparseMatIterator( const CvSparseMat* mat,
//                                               CvSparseMatIterator* mat_iterator );
DEFINE_FUNCTION( SP(CvSparseNode), cvInitSparseMatIterator, 2( SP(CvSparseMat,mat), SP(CvSparseMatIterator,mat_iterator) ) ) 

// returns next sparse array node (or NULL if there is no more nodes)
// CV_INLINE CvSparseNode* cvGetNextSparseNode( CvSparseMatIterator* mat_iterator )
// {
//     if( mat_iterator->node->next )
//         return mat_iterator->node = mat_iterator->node->next;
//     else
//     {
//         int idx;
//         for( idx = ++mat_iterator->curidx; idx < mat_iterator->mat->hashsize; idx++ )
//         {
//             CvSparseNode* node = (CvSparseNode*)mat_iterator->mat->hashtable[idx];
//             if( node )
//             {
//                 mat_iterator->curidx = idx;
//                 return mat_iterator->node = node;
//             }
//         }
//         return NULL;
//     }
// }
DEFINE_FUNCTION( SP(CvSparseNode), cvGetNextSparseNode, 1( SP(CvSparseMatIterator,mat_iterator) ) ) 

/**************** matrix iterator: used for n-ary operations on dense arrays *********/

// #define CV_MAX_ARR 10
#pragma push_macro( "CV_MAX_ARR" )
#undef CV_MAX_ARR
static const int CV_MAX_ARR
#pragma pop_macro( "CV_MAX_ARR" )
	= CV_MAX_ARR;

// typedef struct CvNArrayIterator
// {
//     int count; /* number of arrays */
//     int dims; /* number of dimensions to iterate */
//     CvSize size; /* maximal common linear size: { width = size, height = 1 } */
//     uchar* ptr[CV_MAX_ARR]; /* pointers to the array slices */
//     int stack[CV_MAX_DIM]; /* for internal use */
//     CvMatND* hdr[CV_MAX_ARR]; /* pointers to the headers of the
//                                  matrices that are processed */
// }
// CvNArrayIterator;
DEFINE_STRUCT( CvNArrayIterator )
{STRUCT_BASIC( CvNArrayIterator )
	DEFINE_PROPERTY_V( int, count )
	DEFINE_PROPERTY_V( int, dims )
	DEFINE_PROPERTY_S( CvSize, size )
	DEFINE_PROPERTY_VPA( unsigned char, ptr, CV_MAX_ARR )
	DEFINE_PROPERTY_VA( int, stack, CV_MAX_DIM )
	DEFINE_PROPERTY_SPA( CvMatND, hdr, CV_MAX_ARR )
};

// #define CV_NO_DEPTH_CHECK     1
#pragma push_macro( "CV_NO_DEPTH_CHECK" )
#undef CV_NO_DEPTH_CHECK
static const int CV_NO_DEPTH_CHECK
#pragma pop_macro( "CV_NO_DEPTH_CHECK" )
	= CV_NO_DEPTH_CHECK;
// #define CV_NO_CN_CHECK        2
#pragma push_macro( "CV_NO_CN_CHECK" )
#undef CV_NO_CN_CHECK
static const int CV_NO_CN_CHECK
#pragma pop_macro( "CV_NO_CN_CHECK" )
	= CV_NO_CN_CHECK;
// #define CV_NO_SIZE_CHECK      4
#pragma push_macro( "CV_NO_SIZE_CHECK" )
#undef CV_NO_SIZE_CHECK
static const int CV_NO_SIZE_CHECK
#pragma pop_macro( "CV_NO_SIZE_CHECK" )
	= CV_NO_SIZE_CHECK;

/* initializes iterator that traverses through several arrays simulteneously
   (the function together with cvNextArraySlice is used for
    N-ari element-wise operations) */
// CVAPI(int) cvInitNArrayIterator( int count, CvArr** arrs,
//                                  const CvArr* mask, CvMatND* stubs,
//                                  CvNArrayIterator* array_iterator,
//                                  int flags CV_DEFAULT(0) );
DEFINE_FUNCTION( V(int), cvInitNArrayIterator, 6( V(int,count), MPA(UMemory,UNAME(CvArr),arrs), MP(UMemory,CvArr,mask), SP(CvMatND,stubs), SP(CvNArrayIterator,array_iterator), V(int,flags) ) ) 
DEFINE_FUNCTION( V(int), cvInitNArrayIterator, 5( V(int,count), MPA(UMemory,UNAME(CvArr),arrs), MP(UMemory,CvArr,mask), SP(CvMatND,stubs), SP(CvNArrayIterator,array_iterator) ) ) 

/* returns zero value if iteration is finished, non-zero (slice length) otherwise */
// CVAPI(int) cvNextNArraySlice( CvNArrayIterator* array_iterator );
DEFINE_FUNCTION( V(int), cvNextNArraySlice, 1( SP(CvNArrayIterator,array_iterator) ) ) 


/* Returns type of array elements:
   CV_8UC1 ... CV_64FC4 ... */
// CVAPI(int) cvGetElemType( const CvArr* arr );
DEFINE_FUNCTION( V(int), cvGetElemType, 1( MP(UMemory,CvArr,arr) ) ) 

/* Retrieves number of an array dimensions and
   optionally sizes of the dimensions */
// CVAPI(int) cvGetDims( const CvArr* arr, int* sizes CV_DEFAULT(NULL) );
DEFINE_FUNCTION( V(int), cvGetDims, 2( MP(UMemory,CvArr,arr), VP(int,sizes) ) ) 
DEFINE_FUNCTION( V(int), cvGetDims, 2( MP(UMemory,CvArr,arr), P(int*,sizes) ) ) 
DEFINE_FUNCTION( V(int), cvGetDims, 1( MP(UMemory,CvArr,arr) ) ) 


/* Retrieves size of a particular array dimension.
   For 2d arrays cvGetDimSize(arr,0) returns number of rows (image height)
   and cvGetDimSize(arr,1) returns number of columns (image width) */
// CVAPI(int) cvGetDimSize( const CvArr* arr, int index );
DEFINE_FUNCTION( V(int), cvGetDimSize, 2( MP(UMemory,CvArr,arr), V(int,index) ) ) 


/* ptr = &arr(idx0,idx1,...). All indexes are zero-based,
   the major dimensions go first (e.g. (y,x) for 2D, (z,y,x) for 3D */
// CVAPI(uchar*) cvPtr1D( const CvArr* arr, int idx0, int* type CV_DEFAULT(NULL));
DEFINE_FUNCTION( P(unsigned char*), cvPtr1D, 3( MP(UMemory,CvArr,arr), V(int,idx0), VP(int,type) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtr1D, 3( MP(UMemory,CvArr,arr), V(int,idx0), P(int*,type) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtr1D, 2( MP(UMemory,CvArr,arr), V(int,idx0) ) ) 
// CVAPI(uchar*) cvPtr2D( const CvArr* arr, int idx0, int idx1, int* type CV_DEFAULT(NULL) );
DEFINE_FUNCTION( P(unsigned char*), cvPtr2D, 4( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), VP(int,type) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtr2D, 4( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), P(int*,type) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtr2D, 3( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1) ) ) 
// CVAPI(uchar*) cvPtr3D( const CvArr* arr, int idx0, int idx1, int idx2,
//                       int* type CV_DEFAULT(NULL));
DEFINE_FUNCTION( P(unsigned char*), cvPtr3D, 5( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), V(int,idx2), VP(int,type) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtr3D, 5( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), V(int,idx2), P(int*,type) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtr3D, 4( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), V(int,idx2) ) ) 

/* For CvMat or IplImage number of indices should be 2
   (row index (y) goes first, column index (x) goes next).
   For CvMatND or CvSparseMat number of infices should match number of <dims> and
   indices order should match the array dimension order. */
// CVAPI(uchar*) cvPtrND( const CvArr* arr, const int* idx, int* type CV_DEFAULT(NULL),
//                       int create_node CV_DEFAULT(1),
//                       unsigned* precalc_hashval CV_DEFAULT(NULL));
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 5( MP(UMemory,CvArr,arr), VP(int,idx), VP(int,type), V(int,create_node), VP(unsigned,precalc_hashval) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 5( MP(UMemory,CvArr,arr), P(const int*,idx), VP(int,type), V(int,create_node), VP(unsigned,precalc_hashval) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 5( MP(UMemory,CvArr,arr), VP(int,idx), P(int*,type), V(int,create_node), VP(unsigned,precalc_hashval) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 5( MP(UMemory,CvArr,arr), P(const int*,idx), P(int*,type), V(int,create_node), VP(unsigned,precalc_hashval) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 5( MP(UMemory,CvArr,arr), VP(int,idx), VP(int,type), V(int,create_node), P(unsigned*,precalc_hashval) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 5( MP(UMemory,CvArr,arr), P(const int*,idx), VP(int,type), V(int,create_node), P(unsigned*,precalc_hashval) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 5( MP(UMemory,CvArr,arr), VP(int,idx), P(int*,type), V(int,create_node), P(unsigned*,precalc_hashval) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 5( MP(UMemory,CvArr,arr), P(const int*,idx), P(int*,type), V(int,create_node), P(unsigned*,precalc_hashval) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 4( MP(UMemory,CvArr,arr), VP(int,idx), VP(int,type), V(int,create_node) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 4( MP(UMemory,CvArr,arr), P(const int*,idx), VP(int,type), V(int,create_node) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 4( MP(UMemory,CvArr,arr), VP(int,idx), P(int*,type), V(int,create_node) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 4( MP(UMemory,CvArr,arr), P(const int*,idx), P(int*,type), V(int,create_node) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 3( MP(UMemory,CvArr,arr), VP(int,idx), VP(int,type) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 3( MP(UMemory,CvArr,arr), P(const int*,idx), VP(int,type) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 3( MP(UMemory,CvArr,arr), VP(int,idx), P(int*,type) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 3( MP(UMemory,CvArr,arr), P(const int*,idx), P(int*,type) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 2( MP(UMemory,CvArr,arr), VP(int,idx) ) ) 
DEFINE_FUNCTION( P(unsigned char*), cvPtrND, 2( MP(UMemory,CvArr,arr), P(const int*,idx) ) ) 

/* value = arr(idx0,idx1,...) */
// CVAPI(CvScalar) cvGet1D( const CvArr* arr, int idx0 );
DEFINE_FUNCTION( S(CvScalar), cvGet1D, 2( MP(UMemory,CvArr,arr), V(int,idx0) ) ) 
// CVAPI(CvScalar) cvGet2D( const CvArr* arr, int idx0, int idx1 );
DEFINE_FUNCTION( S(CvScalar), cvGet2D, 3( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1) ) ) 
// CVAPI(CvScalar) cvGet3D( const CvArr* arr, int idx0, int idx1, int idx2 );
DEFINE_FUNCTION( S(CvScalar), cvGet3D, 4( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), V(int,idx2) ) ) 
// CVAPI(CvScalar) cvGetND( const CvArr* arr, const int* idx );
DEFINE_FUNCTION( S(CvScalar), cvGetND, 2( MP(UMemory,CvArr,arr), VP(int,idx) ) ) 
DEFINE_FUNCTION( S(CvScalar), cvGetND, 2( MP(UMemory,CvArr,arr), P(const int*,idx) ) ) 

/* for 1-channel arrays */
// CVAPI(double) cvGetReal1D( const CvArr* arr, int idx0 );
DEFINE_FUNCTION( V(double), cvGetReal1D, 2( MP(UMemory,CvArr,arr), V(int,idx0) ) ) 
// CVAPI(double) cvGetReal2D( const CvArr* arr, int idx0, int idx1 );
DEFINE_FUNCTION( V(double), cvGetReal2D, 3( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1) ) ) 
// CVAPI(double) cvGetReal3D( const CvArr* arr, int idx0, int idx1, int idx2 );
DEFINE_FUNCTION( V(double), cvGetReal3D, 4( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), V(int,idx2) ) ) 
// CVAPI(double) cvGetRealND( const CvArr* arr, const int* idx );
DEFINE_FUNCTION( V(double), cvGetRealND, 2( MP(UMemory,CvArr,arr), VP(int,idx) ) ) 
DEFINE_FUNCTION( V(double), cvGetRealND, 2( MP(UMemory,CvArr,arr), P(const int*,idx) ) ) 

/* arr(idx0,idx1,...) = value */
// CVAPI(void) cvSet1D( CvArr* arr, int idx0, CvScalar value );
DEFINE_FUNCTION( N(void), cvSet1D, 3( MP(UMemory,CvArr,arr), V(int,idx0), S(CvScalar,value) ) ) 
// CVAPI(void) cvSet2D( CvArr* arr, int idx0, int idx1, CvScalar value );
DEFINE_FUNCTION( N(void), cvSet2D, 4( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), S(CvScalar,value) ) ) 
// CVAPI(void) cvSet3D( CvArr* arr, int idx0, int idx1, int idx2, CvScalar value );
DEFINE_FUNCTION( N(void), cvSet3D, 5( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), V(int,idx2), S(CvScalar,value) ) ) 
// CVAPI(void) cvSetND( CvArr* arr, const int* idx, CvScalar value );
DEFINE_FUNCTION( N(void), cvSetND, 3( MP(UMemory,CvArr,arr), VP(int,idx), S(CvScalar,value) ) ) 
DEFINE_FUNCTION( N(void), cvSetND, 3( MP(UMemory,CvArr,arr), P(const int*,idx), S(CvScalar,value) ) ) 

/* for 1-channel arrays */
// CVAPI(void) cvSetReal1D( CvArr* arr, int idx0, double value );
DEFINE_FUNCTION( N(void), cvSetReal1D, 3( MP(UMemory,CvArr,arr), V(int,idx0), V(double,value) ) ) 
// CVAPI(void) cvSetReal2D( CvArr* arr, int idx0, int idx1, double value );
DEFINE_FUNCTION( N(void), cvSetReal2D, 4( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), V(double,value) ) ) 
// CVAPI(void) cvSetReal3D( CvArr* arr, int idx0,
//                         int idx1, int idx2, double value );
DEFINE_FUNCTION( N(void), cvSetReal3D, 5( MP(UMemory,CvArr,arr), V(int,idx0), V(int,idx1), V(int,idx2), V(double,value) ) ) 
// CVAPI(void) cvSetRealND( CvArr* arr, const int* idx, double value );
DEFINE_FUNCTION( N(void), cvSetRealND, 3( MP(UMemory,CvArr,arr), VP(int,idx), V(double,value) ) ) 
DEFINE_FUNCTION( N(void), cvSetRealND, 3( MP(UMemory,CvArr,arr), P(const int*,idx), V(double,value) ) ) 

/* clears element of ND dense array,
   in case of sparse arrays it deletes the specified node */
// CVAPI(void) cvClearND( CvArr* arr, const int* idx );
DEFINE_FUNCTION( N(void), cvClearND, 2( MP(UMemory,CvArr,arr), VP(int,idx) ) ) 
DEFINE_FUNCTION( N(void), cvClearND, 2( MP(UMemory,CvArr,arr), P(const int*,idx) ) ) 

/* Converts CvArr (IplImage or CvMat,...) to CvMat.
   If the last parameter is non-zero, function can
   convert multi(>2)-dimensional array to CvMat as long as
   the last array's dimension is continous. The resultant
   matrix will be have appropriate (a huge) number of rows */
// CVAPI(CvMat*) cvGetMat( const CvArr* arr, CvMat* header,
//                        int* coi CV_DEFAULT(NULL),
//                        int allowND CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvMat), cvGetMat, 4( MP(UMemory,CvArr,arr), SP(CvMat,header), VP(int,coi), V(int,allowND) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvGetMat, 4( MP(UMemory,CvArr,arr), SP(CvMat,header), P(int*,coi), V(int,allowND) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvGetMat, 3( MP(UMemory,CvArr,arr), SP(CvMat,header), VP(int,coi) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvGetMat, 3( MP(UMemory,CvArr,arr), SP(CvMat,header), P(int*,coi) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvGetMat, 2( MP(UMemory,CvArr,arr), SP(CvMat,header) ) ) 

/* Converts CvArr (IplImage or CvMat) to IplImage */
// CVAPI(IplImage*) cvGetImage( const CvArr* arr, IplImage* image_header );
DEFINE_FUNCTION( SP(IplImage), cvGetImage, 2( MP(UMemory,CvArr,arr), SP(IplImage,image_header) ) ) 


/* Changes a shape of multi-dimensional array.
   new_cn == 0 means that number of channels remains unchanged.
   new_dims == 0 means that number and sizes of dimensions remain the same
   (unless they need to be changed to set the new number of channels)
   if new_dims == 1, there is no need to specify new dimension sizes
   The resultant configuration should be achievable w/o data copying.
   If the resultant array is sparse, CvSparseMat header should be passed
   to the function else if the result is 1 or 2 dimensional,
   CvMat header should be passed to the function
   else CvMatND header should be passed */
// CVAPI(CvArr*) cvReshapeMatND( const CvArr* arr,
//                              int sizeof_header, CvArr* header,
//                              int new_cn, int new_dims, int* new_sizes );
DEFINE_FUNCTION( P(CvArr*), cvReshapeMatND, 6( MP(UMemory,CvArr,arr), V(int,sizeof_header), MP(UMemory,CvArr,header), V(int,new_cn), V(int,new_dims), VP(int,new_sizes) ) ) 
DEFINE_FUNCTION( P(CvArr*), cvReshapeMatND, 6( MP(UMemory,CvArr,arr), V(int,sizeof_header), MP(UMemory,CvArr,header), V(int,new_cn), V(int,new_dims), P(int*,new_sizes) ) ) 

// #define cvReshapeND( arr, header, new_cn, new_dims, new_sizes )   \
//       cvReshapeMatND( (arr), sizeof(*(header)), (header),         \
//                       (new_cn), (new_dims), (new_sizes))
// Unsupport : cvReshapeND

// CVAPI(CvMat*) cvReshape( const CvArr* arr, CvMat* header,
//                         int new_cn, int new_rows CV_DEFAULT(0) );
DEFINE_FUNCTION( SP(CvMat), cvReshape, 4( MP(UMemory,CvArr,arr), SP(CvMat,header), V(int,new_cn), V(int,new_rows) ) ) 
DEFINE_FUNCTION( SP(CvMat), cvReshape, 3( MP(UMemory,CvArr,arr), SP(CvMat,header), V(int,new_cn) ) ) 

/* Repeats source 2d array several times in both horizontal and
   vertical direction to fill destination array */
// CVAPI(void) cvRepeat( const CvArr* src, CvArr* dst );
DEFINE_FUNCTION( N(void), cvRepeat, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* Allocates array data */
// CVAPI(void)  cvCreateData( CvArr* arr );
DEFINE_FUNCTION( N(void), cvCreateData, 1( MP(UMemory,CvArr,arr) ) ) 

/* Releases array data */
// CVAPI(void)  cvReleaseData( CvArr* arr );
DEFINE_FUNCTION( N(void), cvReleaseData, 1( MP(UMemory,CvArr,arr) ) ) 

/* Attaches user data to the array header. The step is reffered to
   the pre-last dimension. That is, all the planes of the array
   must be joint (w/o gaps) */
// CVAPI(void)  cvSetData( CvArr* arr, void* data, int step );
DEFINE_FUNCTION( N(void), cvSetData, 3( MP(UMemory,CvArr,arr), P(void*,data), V(int,step) ) ) 

/* Retrieves raw data of CvMat, IplImage or CvMatND.
   In the latter case the function raises an error if
   the array can not be represented as a matrix */
// CVAPI(void) cvGetRawData( const CvArr* arr, uchar** data,
//                          int* step CV_DEFAULT(NULL),
//                          CvSize* roi_size CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvGetRawData, 4( MP(UMemory,CvArr,arr), P(unsigned char**,data), VP(int,step), SP(CvSize,roi_size) ) ) 
DEFINE_FUNCTION( N(void), cvGetRawData, 4( MP(UMemory,CvArr,arr), P(unsigned char**,data), P(int*,step), SP(CvSize,roi_size) ) ) 
DEFINE_FUNCTION( N(void), cvGetRawData, 3( MP(UMemory,CvArr,arr), P(unsigned char**,data), VP(int,step) ) ) 
DEFINE_FUNCTION( N(void), cvGetRawData, 3( MP(UMemory,CvArr,arr), P(unsigned char**,data), P(int*,step) ) ) 
DEFINE_FUNCTION( N(void), cvGetRawData, 2( MP(UMemory,CvArr,arr), P(unsigned char**,data) ) ) 

/* Returns width and height of array in elements */
// CVAPI(CvSize) cvGetSize( const CvArr* arr );
DEFINE_FUNCTION( S(CvSize), cvGetSize, 1( MP(UMemory,CvArr,arr) ) ) 

/* Copies source array to destination array */
// CVAPI(void)  cvCopy( const CvArr* src, CvArr* dst,
//                      const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvCopy, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvCopy, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* Sets all or "masked" elements of input array
   to the same value*/
// CVAPI(void)  cvSet( CvArr* arr, CvScalar value,
//                     const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION_ALIAS( N(void), cvSet, cvSet_, 3( MP(UMemory,CvArr,arr), S(CvScalar,value), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvSet, cvSet_, 2( MP(UMemory,CvArr,arr), S(CvScalar,value) ) ) 

/* Clears all the array elements (sets them to 0) */
// CVAPI(void)  cvSetZero( CvArr* arr );
DEFINE_FUNCTION( N(void), cvSetZero, 1( MP(UMemory,CvArr,arr) ) ) 
// #define cvZero  cvSetZero
#pragma push_macro( "cvZero" )
#undef cvZero
DEFINE_FUNCTION_ALIAS( N(void), cvSetZero, cvZero, 1( MP(UMemory,CvArr,arr) ) ) 
#pragma pop_macro( "cvZero" )


/* Splits a multi-channel array into the set of single-channel arrays or
   extracts particular [color] plane */
// CVAPI(void)  cvSplit( const CvArr* src, CvArr* dst0, CvArr* dst1,
//                       CvArr* dst2, CvArr* dst3 );
DEFINE_FUNCTION( N(void), cvSplit, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst0), MP(UMemory,CvArr,dst1), MP(UMemory,CvArr,dst2), MP(UMemory,CvArr,dst3) ) ) 

/* Merges a set of single-channel arrays into the single multi-channel array
   or inserts one particular [color] plane to the array */
// CVAPI(void)  cvMerge( const CvArr* src0, const CvArr* src1,
//                       const CvArr* src2, const CvArr* src3,
//                       CvArr* dst );
DEFINE_FUNCTION( N(void), cvMerge, 5( MP(UMemory,CvArr,src0), MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,src3), MP(UMemory,CvArr,dst) ) ) 

/* Copies several channels from input arrays to
   certain channels of output arrays */
// CVAPI(void)  cvMixChannels( const CvArr** src, int src_count,
//                             CvArr** dst, int dst_count,
//                             const int* from_to, int pair_count );
DEFINE_FUNCTION( N(void), cvMixChannels, 6( MPA(UMemory,const UNAME(CvArr),src), V(int,src_count), MPA(UMemory,UNAME(CvArr),dst), V(int,dst_count), VP(int,from_to), V(int,pair_count) ) ) 
DEFINE_FUNCTION( N(void), cvMixChannels, 6( MPA(UMemory,const UNAME(CvArr),src), V(int,src_count), MPA(UMemory,UNAME(CvArr),dst), V(int,dst_count), P(const int*,from_to), V(int,pair_count) ) ) 

/* Performs linear transformation on every source array element:
   dst(x,y,c) = scale*src(x,y,c)+shift.
   Arbitrary combination of input and output array depths are allowed
   (number of channels must be the same), thus the function can be used
   for type conversion */
// CVAPI(void)  cvConvertScale( const CvArr* src, CvArr* dst,
//                              double scale CV_DEFAULT(1),
//                              double shift CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvConvertScale, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,scale), V(double,shift) ) ) 
DEFINE_FUNCTION( N(void), cvConvertScale, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,scale) ) ) 
DEFINE_FUNCTION( N(void), cvConvertScale, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
// #define cvCvtScale cvConvertScale
#pragma push_macro( "cvCvtScale" )
#undef cvCvtScale
DEFINE_FUNCTION_ALIAS( N(void), cvConvertScale, cvCvtScale, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,scale), V(double,shift) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvConvertScale, cvCvtScale, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,scale) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvConvertScale, cvCvtScale, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
#pragma pop_macro( "cvCvtScale" )
// #define cvScale  cvConvertScale
#pragma push_macro( "cvScale" )
#undef cvScale
DEFINE_FUNCTION_ALIAS( N(void), cvConvertScale, cvScale, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,scale), V(double,shift) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvConvertScale, cvScale, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,scale) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvConvertScale, cvScale, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
#pragma pop_macro( "cvScale" )
// #define cvConvert( src, dst )  cvConvertScale( (src), (dst), 1, 0 )
// Unsupport : cvConvert


/* Performs linear transformation on every source array element,
   stores absolute value of the result:
   dst(x,y,c) = abs(scale*src(x,y,c)+shift).
   destination array must have 8u type.
   In other cases one may use cvConvertScale + cvAbsDiffS */
// CVAPI(void)  cvConvertScaleAbs( const CvArr* src, CvArr* dst,
//                                 double scale CV_DEFAULT(1),
//                                 double shift CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvConvertScaleAbs, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,scale), V(double,shift) ) ) 
DEFINE_FUNCTION( N(void), cvConvertScaleAbs, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,scale) ) ) 
DEFINE_FUNCTION( N(void), cvConvertScaleAbs, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
// #define cvCvtScaleAbs  cvConvertScaleAbs
#pragma push_macro( "cvCvtScaleAbs" )
#undef cvCvtScaleAbs
DEFINE_FUNCTION_ALIAS( N(void), cvConvertScaleAbs, cvCvtScaleAbs, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,scale), V(double,shift) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvConvertScaleAbs, cvCvtScaleAbs, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,scale) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvConvertScaleAbs, cvCvtScaleAbs, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
#pragma pop_macro( "cvCvtScaleAbs" )


/* checks termination criteria validity and
   sets eps to default_eps (if it is not set),
   max_iter to default_max_iters (if it is not set)
*/
// CVAPI(CvTermCriteria) cvCheckTermCriteria( CvTermCriteria criteria,
//                                            double default_eps,
//                                            int default_max_iters );
DEFINE_FUNCTION( S(CvTermCriteria), cvCheckTermCriteria, 3( S(CvTermCriteria,criteria), V(double,default_eps), V(int,default_max_iters) ) ) 

/****************************************************************************************\
*                   Arithmetic, logic and comparison operations                          *
\****************************************************************************************/

/* dst(mask) = src1(mask) + src2(mask) */
// CVAPI(void)  cvAdd( const CvArr* src1, const CvArr* src2, CvArr* dst,
//                     const CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvAdd, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvAdd, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* dst(mask) = src(mask) + value */
// CVAPI(void)  cvAddS( const CvArr* src, CvScalar value, CvArr* dst,
//                      const CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvAddS, 4( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvAddS, 3( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst) ) ) 

/* dst(mask) = src1(mask) - src2(mask) */
// CVAPI(void)  cvSub( const CvArr* src1, const CvArr* src2, CvArr* dst,
//                     const CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvSub, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvSub, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* dst(mask) = src(mask) - value = src(mask) + (-value) */
// CV_INLINE  void  cvSubS( const CvArr* src, CvScalar value, CvArr* dst,
//                          const CvArr* mask CV_DEFAULT(NULL))
// {
//     cvAddS( src, cvScalar( -value.val[0], -value.val[1], -value.val[2], -value.val[3]),
//             dst, mask );
// }
DEFINE_FUNCTION( N(void), cvSubS, 4( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvSubS, 3( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst) ) ) 

/* dst(mask) = value - src(mask) */
// CVAPI(void)  cvSubRS( const CvArr* src, CvScalar value, CvArr* dst,
//                       const CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvSubRS, 4( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvSubRS, 3( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = src1(idx) * src2(idx) * scale
   (scaled element-wise multiplication of 2 arrays) */
// CVAPI(void)  cvMul( const CvArr* src1, const CvArr* src2,
//                     CvArr* dst, double scale CV_DEFAULT(1) );
DEFINE_FUNCTION( N(void), cvMul, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst), V(double,scale) ) ) 
DEFINE_FUNCTION( N(void), cvMul, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* element-wise division/inversion with scaling:
    dst(idx) = src1(idx) * scale / src2(idx)
    or dst(idx) = scale / src2(idx) if src1 == 0 */
// CVAPI(void)  cvDiv( const CvArr* src1, const CvArr* src2,
//                     CvArr* dst, double scale CV_DEFAULT(1));
DEFINE_FUNCTION( N(void), cvDiv, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst), V(double,scale) ) ) 
DEFINE_FUNCTION( N(void), cvDiv, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* dst = src1 * scale + src2 */
// CVAPI(void)  cvScaleAdd( const CvArr* src1, CvScalar scale,
//                          const CvArr* src2, CvArr* dst );
DEFINE_FUNCTION( N(void), cvScaleAdd, 4( MP(UMemory,CvArr,src1), S(CvScalar,scale), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 
// #define cvAXPY( A, real_scalar, B, C ) cvScaleAdd(A, cvRealScalar(real_scalar), B, C)
// Unsupport : cvAXPY

/* dst = src1 * alpha + src2 * beta + gamma */
// CVAPI(void)  cvAddWeighted( const CvArr* src1, double alpha,
//                             const CvArr* src2, double beta,
//                             double gamma, CvArr* dst );
DEFINE_FUNCTION( N(void), cvAddWeighted, 6( MP(UMemory,CvArr,src1), V(double,alpha), MP(UMemory,CvArr,src2), V(double,beta), V(double,gamma), MP(UMemory,CvArr,dst) ) ) 

/* result = sum_i(src1(i) * src2(i)) (results for all channels are accumulated together) */
// CVAPI(double)  cvDotProduct( const CvArr* src1, const CvArr* src2 );
DEFINE_FUNCTION( V(double), cvDotProduct, 2( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2) ) ) 

/* dst(idx) = src1(idx) & src2(idx) */
// CVAPI(void) cvAnd( const CvArr* src1, const CvArr* src2,
//                   CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvAnd, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvAnd, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = src(idx) & value */
// CVAPI(void) cvAndS( const CvArr* src, CvScalar value,
//                    CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvAndS, 4( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvAndS, 3( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = src1(idx) | src2(idx) */
// CVAPI(void) cvOr( const CvArr* src1, const CvArr* src2,
//                  CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvOr, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvOr, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = src(idx) | value */
// CVAPI(void) cvOrS( const CvArr* src, CvScalar value,
//                   CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvOrS, 4( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvOrS, 3( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = src1(idx) ^ src2(idx) */
// CVAPI(void) cvXor( const CvArr* src1, const CvArr* src2,
//                   CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvXor, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvXor, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = src(idx) ^ value */
// CVAPI(void) cvXorS( const CvArr* src, CvScalar value,
//                    CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvXorS, 4( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvXorS, 3( MP(UMemory,CvArr,src), S(CvScalar,value), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = ~src(idx) */
// CVAPI(void) cvNot( const CvArr* src, CvArr* dst );
DEFINE_FUNCTION( N(void), cvNot, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = lower(idx) <= src(idx) < upper(idx) */
// CVAPI(void) cvInRange( const CvArr* src, const CvArr* lower,
//                       const CvArr* upper, CvArr* dst );
DEFINE_FUNCTION( N(void), cvInRange, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,lower), MP(UMemory,CvArr,upper), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = lower <= src(idx) < upper */
// CVAPI(void) cvInRangeS( const CvArr* src, CvScalar lower,
//                        CvScalar upper, CvArr* dst );
DEFINE_FUNCTION( N(void), cvInRangeS, 4( MP(UMemory,CvArr,src), S(CvScalar,lower), S(CvScalar,upper), MP(UMemory,CvArr,dst) ) ) 

// #define CV_CMP_EQ   0
#pragma push_macro( "CV_CMP_EQ" )
#undef CV_CMP_EQ
static const int CV_CMP_EQ
#pragma pop_macro( "CV_CMP_EQ" )
	= CV_CMP_EQ;
// #define CV_CMP_GT   1
#pragma push_macro( "CV_CMP_GT" )
#undef CV_CMP_GT
static const int CV_CMP_GT
#pragma pop_macro( "CV_CMP_GT" )
	= CV_CMP_GT;
// #define CV_CMP_GE   2
#pragma push_macro( "CV_CMP_GE" )
#undef CV_CMP_GE
static const int CV_CMP_GE
#pragma pop_macro( "CV_CMP_GE" )
	= CV_CMP_GE;
// #define CV_CMP_LT   3
#pragma push_macro( "CV_CMP_LT" )
#undef CV_CMP_LT
static const int CV_CMP_LT
#pragma pop_macro( "CV_CMP_LT" )
	= CV_CMP_LT;
// #define CV_CMP_LE   4
#pragma push_macro( "CV_CMP_LE" )
#undef CV_CMP_LE
static const int CV_CMP_LE
#pragma pop_macro( "CV_CMP_LE" )
	= CV_CMP_LE;
// #define CV_CMP_NE   5
#pragma push_macro( "CV_CMP_NE" )
#undef CV_CMP_NE
static const int CV_CMP_NE
#pragma pop_macro( "CV_CMP_NE" )
	= CV_CMP_NE;

/* The comparison operation support single-channel arrays only.
   Destination image should be 8uC1 or 8sC1 */

/* dst(idx) = src1(idx) _cmp_op_ src2(idx) */
// CVAPI(void) cvCmp( const CvArr* src1, const CvArr* src2, CvArr* dst, int cmp_op );
DEFINE_FUNCTION( N(void), cvCmp, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst), V(int,cmp_op) ) ) 

/* dst(idx) = src1(idx) _cmp_op_ value */
// CVAPI(void) cvCmpS( const CvArr* src, double value, CvArr* dst, int cmp_op );
DEFINE_FUNCTION( N(void), cvCmpS, 4( MP(UMemory,CvArr,src), V(double,value), MP(UMemory,CvArr,dst), V(int,cmp_op) ) ) 

/* dst(idx) = min(src1(idx),src2(idx)) */
// CVAPI(void) cvMin( const CvArr* src1, const CvArr* src2, CvArr* dst );
DEFINE_FUNCTION( N(void), cvMin, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = max(src1(idx),src2(idx)) */
// CVAPI(void) cvMax( const CvArr* src1, const CvArr* src2, CvArr* dst );
DEFINE_FUNCTION( N(void), cvMax, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = min(src(idx),value) */
// CVAPI(void) cvMinS( const CvArr* src, double value, CvArr* dst );
DEFINE_FUNCTION( N(void), cvMinS, 3( MP(UMemory,CvArr,src), V(double,value), MP(UMemory,CvArr,dst) ) ) 

/* dst(idx) = max(src(idx),value) */
// CVAPI(void) cvMaxS( const CvArr* src, double value, CvArr* dst );
DEFINE_FUNCTION( N(void), cvMaxS, 3( MP(UMemory,CvArr,src), V(double,value), MP(UMemory,CvArr,dst) ) ) 

/* dst(x,y,c) = abs(src1(x,y,c) - src2(x,y,c)) */
// CVAPI(void) cvAbsDiff( const CvArr* src1, const CvArr* src2, CvArr* dst );
DEFINE_FUNCTION( N(void), cvAbsDiff, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* dst(x,y,c) = abs(src(x,y,c) - value(c)) */
// CVAPI(void) cvAbsDiffS( const CvArr* src, CvArr* dst, CvScalar value );
DEFINE_FUNCTION( N(void), cvAbsDiffS, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), S(CvScalar,value) ) ) 
// #define cvAbs( src, dst ) cvAbsDiffS( (src), (dst), cvScalarAll(0))
// Unsupport : cvAbs

/****************************************************************************************\
*                                Math operations                                         *
\****************************************************************************************/

/* Does cartesian->polar coordinates conversion.
   Either of output components (magnitude or angle) is optional */
// CVAPI(void)  cvCartToPolar( const CvArr* x, const CvArr* y,
//                             CvArr* magnitude, CvArr* angle CV_DEFAULT(NULL),
//                             int angle_in_degrees CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvCartToPolar, 5( MP(UMemory,CvArr,x), MP(UMemory,CvArr,y), MP(UMemory,CvArr,magnitude), MP(UMemory,CvArr,angle), V(int,angle_in_degrees) ) ) 
DEFINE_FUNCTION( N(void), cvCartToPolar, 4( MP(UMemory,CvArr,x), MP(UMemory,CvArr,y), MP(UMemory,CvArr,magnitude), MP(UMemory,CvArr,angle) ) ) 
DEFINE_FUNCTION( N(void), cvCartToPolar, 3( MP(UMemory,CvArr,x), MP(UMemory,CvArr,y), MP(UMemory,CvArr,magnitude) ) ) 

/* Does polar->cartesian coordinates conversion.
   Either of output components (magnitude or angle) is optional.
   If magnitude is missing it is assumed to be all 1's */
// CVAPI(void)  cvPolarToCart( const CvArr* magnitude, const CvArr* angle,
//                             CvArr* x, CvArr* y,
//                             int angle_in_degrees CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvPolarToCart, 5( MP(UMemory,CvArr,magnitude), MP(UMemory,CvArr,angle), MP(UMemory,CvArr,x), MP(UMemory,CvArr,y), V(int,angle_in_degrees) ) ) 
DEFINE_FUNCTION( N(void), cvPolarToCart, 4( MP(UMemory,CvArr,magnitude), MP(UMemory,CvArr,angle), MP(UMemory,CvArr,x), MP(UMemory,CvArr,y) ) ) 

/* Does powering: dst(idx) = src(idx)^power */
// CVAPI(void)  cvPow( const CvArr* src, CvArr* dst, double power );
DEFINE_FUNCTION( N(void), cvPow, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,power) ) ) 

/* Does exponention: dst(idx) = exp(src(idx)).
   Overflow is not handled yet. Underflow is handled.
   Maximal relative error is ~7e-6 for single-precision input */
// CVAPI(void)  cvExp( const CvArr* src, CvArr* dst );
DEFINE_FUNCTION( N(void), cvExp, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* Calculates natural logarithms: dst(idx) = log(abs(src(idx))).
   Logarithm of 0 gives large negative number(~-700)
   Maximal relative error is ~3e-7 for single-precision output
*/
// CVAPI(void)  cvLog( const CvArr* src, CvArr* dst );
DEFINE_FUNCTION( N(void), cvLog, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/* Fast arctangent calculation */
// CVAPI(float) cvFastArctan( float y, float x );
DEFINE_FUNCTION( V(float), cvFastArctan, 2( V(float,y), V(float,x) ) ) 

/* Fast cubic root calculation */
// CVAPI(float)  cvCbrt( float value );
DEFINE_FUNCTION( V(float), cvCbrt, 1( V(float,value) ) ) 

/* Checks array values for NaNs, Infs or simply for too large numbers
   (if CV_CHECK_RANGE is set). If CV_CHECK_QUIET is set,
   no runtime errors is raised (function returns zero value in case of "bad" values).
   Otherwise cvError is called */
// #define  CV_CHECK_RANGE    1
#pragma push_macro( "CV_CHECK_RANGE" )
#undef CV_CHECK_RANGE
static const int CV_CHECK_RANGE
#pragma pop_macro( "CV_CHECK_RANGE" )
	= CV_CHECK_RANGE;
// #define  CV_CHECK_QUIET    2
#pragma push_macro( "CV_CHECK_QUIET" )
#undef CV_CHECK_QUIET
static const int CV_CHECK_QUIET
#pragma pop_macro( "CV_CHECK_QUIET" )
	= CV_CHECK_QUIET;
// CVAPI(int)  cvCheckArr( const CvArr* arr, int flags CV_DEFAULT(0),
//                         double min_val CV_DEFAULT(0), double max_val CV_DEFAULT(0));
DEFINE_FUNCTION( V(int), cvCheckArr, 4( MP(UMemory,CvArr,arr), V(int,flags), V(double,min_val), V(double,max_val) ) ) 
DEFINE_FUNCTION( V(int), cvCheckArr, 3( MP(UMemory,CvArr,arr), V(int,flags), V(double,min_val) ) ) 
DEFINE_FUNCTION( V(int), cvCheckArr, 2( MP(UMemory,CvArr,arr), V(int,flags) ) ) 
DEFINE_FUNCTION( V(int), cvCheckArr, 1( MP(UMemory,CvArr,arr) ) ) 
// #define cvCheckArray cvCheckArr
#pragma push_macro( "cvCheckArray" )
#undef cvCheckArray
DEFINE_FUNCTION_ALIAS( V(int), cvCheckArr, cvCheckArray, 4( MP(UMemory,CvArr,arr), V(int,flags), V(double,min_val), V(double,max_val) ) ) 
DEFINE_FUNCTION_ALIAS( V(int), cvCheckArr, cvCheckArray, 3( MP(UMemory,CvArr,arr), V(int,flags), V(double,min_val) ) ) 
DEFINE_FUNCTION_ALIAS( V(int), cvCheckArr, cvCheckArray, 2( MP(UMemory,CvArr,arr), V(int,flags) ) ) 
DEFINE_FUNCTION_ALIAS( V(int), cvCheckArr, cvCheckArray, 1( MP(UMemory,CvArr,arr) ) ) 
#pragma pop_macro( "cvCheckArray" )

// #define CV_RAND_UNI      0
#pragma push_macro( "CV_RAND_UNI" )
#undef CV_RAND_UNI
static const int CV_RAND_UNI
#pragma pop_macro( "CV_RAND_UNI" )
	= CV_RAND_UNI;
// #define CV_RAND_NORMAL   1
#pragma push_macro( "CV_RAND_NORMAL" )
#undef CV_RAND_NORMAL
static const int CV_RAND_NORMAL
#pragma pop_macro( "CV_RAND_NORMAL" )
	= CV_RAND_NORMAL;
// CVAPI(void) cvRandArr( CvRNG* rng, CvArr* arr, int dist_type,
//                       CvScalar param1, CvScalar param2 );
DEFINE_FUNCTION( N(void), cvRandArr, 5( VP(unsigned long long,rng), MP(UMemory,CvArr,arr), V(int,dist_type), S(CvScalar,param1), S(CvScalar,param2) ) ) 
DEFINE_FUNCTION( N(void), cvRandArr, 5( P(unsigned long long*,rng), MP(UMemory,CvArr,arr), V(int,dist_type), S(CvScalar,param1), S(CvScalar,param2) ) ) 

// CVAPI(void) cvRandShuffle( CvArr* mat, CvRNG* rng,
//                            double iter_factor CV_DEFAULT(1.));
DEFINE_FUNCTION( N(void), cvRandShuffle, 3( MP(UMemory,CvArr,mat), VP(unsigned long long,rng), V(double,iter_factor) ) ) 
DEFINE_FUNCTION( N(void), cvRandShuffle, 3( MP(UMemory,CvArr,mat), P(unsigned long long*,rng), V(double,iter_factor) ) ) 
DEFINE_FUNCTION( N(void), cvRandShuffle, 2( MP(UMemory,CvArr,mat), VP(unsigned long long,rng) ) ) 
DEFINE_FUNCTION( N(void), cvRandShuffle, 2( MP(UMemory,CvArr,mat), P(unsigned long long*,rng) ) ) 

// #define CV_SORT_EVERY_ROW 0
#pragma push_macro( "CV_SORT_EVERY_ROW" )
#undef CV_SORT_EVERY_ROW
static const int CV_SORT_EVERY_ROW
#pragma pop_macro( "CV_SORT_EVERY_ROW" )
	= CV_SORT_EVERY_ROW;
// #define CV_SORT_EVERY_COLUMN 1
#pragma push_macro( "CV_SORT_EVERY_COLUMN" )
#undef CV_SORT_EVERY_COLUMN
static const int CV_SORT_EVERY_COLUMN
#pragma pop_macro( "CV_SORT_EVERY_COLUMN" )
	= CV_SORT_EVERY_COLUMN;
// #define CV_SORT_ASCENDING 0
#pragma push_macro( "CV_SORT_ASCENDING" )
#undef CV_SORT_ASCENDING
static const int CV_SORT_ASCENDING
#pragma pop_macro( "CV_SORT_ASCENDING" )
	= CV_SORT_ASCENDING;
// #define CV_SORT_DESCENDING 16
#pragma push_macro( "CV_SORT_DESCENDING" )
#undef CV_SORT_DESCENDING
static const int CV_SORT_DESCENDING
#pragma pop_macro( "CV_SORT_DESCENDING" )
	= CV_SORT_DESCENDING;

// CVAPI(void) cvSort( const CvArr* src, CvArr* dst CV_DEFAULT(NULL),
//                     CvArr* idxmat CV_DEFAULT(NULL),
//                     int flags CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvSort, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,idxmat), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvSort, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,idxmat) ) ) 
DEFINE_FUNCTION( N(void), cvSort, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
DEFINE_FUNCTION( N(void), cvSort, 1( MP(UMemory,CvArr,src) ) ) 

/* Finds real roots of a cubic equation */
// CVAPI(int) cvSolveCubic( const CvMat* coeffs, CvMat* roots );
DEFINE_FUNCTION( V(int), cvSolveCubic, 2( SP(CvMat,coeffs), SP(CvMat,roots) ) ) 

/* Finds all real and complex roots of a polynomial equation */
// CVAPI(void) cvSolvePoly(const CvMat* coeffs, CvMat *roots2,
// 			int maxiter CV_DEFAULT(20), int fig CV_DEFAULT(100));
DEFINE_FUNCTION( N(void), cvSolvePoly, 4( SP(CvMat,coeffs), SP(CvMat,roots2), V(int,maxiter), V(int,fig) ) ) 
DEFINE_FUNCTION( N(void), cvSolvePoly, 3( SP(CvMat,coeffs), SP(CvMat,roots2), V(int,maxiter) ) ) 
DEFINE_FUNCTION( N(void), cvSolvePoly, 2( SP(CvMat,coeffs), SP(CvMat,roots2) ) ) 

/****************************************************************************************\
*                                Matrix operations                                       *
\****************************************************************************************/

/* Calculates cross product of two 3d vectors */
// CVAPI(void)  cvCrossProduct( const CvArr* src1, const CvArr* src2, CvArr* dst );
DEFINE_FUNCTION( N(void), cvCrossProduct, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* Matrix transform: dst = A*B + C, C is optional */
// #define cvMatMulAdd( src1, src2, src3, dst ) cvGEMM( (src1), (src2), 1., (src3), 1., (dst), 0 )
#pragma push_macro( "cvMatMulAdd" )
#undef cvMatMulAdd
DEFINE_FUNCTION_CUSTOM( N(void), cvMatMulAdd, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,src3), MP(UMemory,CvArr,dst) ), \
	{ \
		cvGEMM( src1, src2, 1., src3, 1., dst, 0 );
	}, {} )
#pragma pop_macro( "cvMatMulAdd" )
// #define cvMatMul( src1, src2, dst )  cvMatMulAdd( (src1), (src2), NULL, (dst))
#pragma push_macro( "cvMatMul" )
#undef cvMatMul
DEFINE_FUNCTION_CUSTOM( N(void), cvMatMul, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ), \
	{ \
		cvMatMulAdd( src1, src2, nullptr, dst );
	}, {} )
#pragma pop_macro( "cvMatMul" )

// #define CV_GEMM_A_T 1
#pragma push_macro( "CV_GEMM_A_T" )
#undef CV_GEMM_A_T
static const int CV_GEMM_A_T
#pragma pop_macro( "CV_GEMM_A_T" )
	= CV_GEMM_A_T;
// #define CV_GEMM_B_T 2
#pragma push_macro( "CV_GEMM_B_T" )
#undef CV_GEMM_B_T
static const int CV_GEMM_B_T
#pragma pop_macro( "CV_GEMM_B_T" )
	= CV_GEMM_B_T;
// #define CV_GEMM_C_T 4
#pragma push_macro( "CV_GEMM_C_T" )
#undef CV_GEMM_C_T
static const int CV_GEMM_C_T
#pragma pop_macro( "CV_GEMM_C_T" )
	= CV_GEMM_C_T;
/* Extended matrix transform:
   dst = alpha*op(A)*op(B) + beta*op(C), where op(X) is X or X^T */
// CVAPI(void)  cvGEMM( const CvArr* src1, const CvArr* src2, double alpha,
//                      const CvArr* src3, double beta, CvArr* dst,
//                      int tABC CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvGEMM, 7( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), V(double,alpha), MP(UMemory,CvArr,src3), V(double,beta), MP(UMemory,CvArr,dst), V(int,tABC) ) ) 
DEFINE_FUNCTION( N(void), cvGEMM, 6( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), V(double,alpha), MP(UMemory,CvArr,src3), V(double,beta), MP(UMemory,CvArr,dst) ) ) 
// #define cvMatMulAddEx cvGEMM
#pragma push_macro( "cvMatMulAddEx" )
#undef cvMatMulAddEx
DEFINE_FUNCTION_ALIAS( N(void), cvGEMM, cvMatMulAddEx, 7( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), V(double,alpha), MP(UMemory,CvArr,src3), V(double,beta), MP(UMemory,CvArr,dst), V(int,tABC) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvGEMM, cvMatMulAddEx, 6( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), V(double,alpha), MP(UMemory,CvArr,src3), V(double,beta), MP(UMemory,CvArr,dst) ) ) 
#pragma pop_macro( "cvMatMulAddEx" )

/* Transforms each element of source array and stores
   resultant vectors in destination array */
// CVAPI(void)  cvTransform( const CvArr* src, CvArr* dst,
//                           const CvMat* transmat,
//                           const CvMat* shiftvec CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvTransform, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,transmat), SP(CvMat,shiftvec) ) ) 
DEFINE_FUNCTION( N(void), cvTransform, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,transmat) ) ) 
// #define cvMatMulAddS cvTransform
#pragma push_macro( "cvMatMulAddS" )
#undef cvMatMulAddS
DEFINE_FUNCTION_ALIAS( N(void), cvTransform, cvMatMulAddS, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,transmat), SP(CvMat,shiftvec) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvTransform, cvMatMulAddS, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,transmat) ) ) 
#pragma pop_macro( "cvMatMulAddS" )

/* Does perspective transform on every element of input array */
// CVAPI(void)  cvPerspectiveTransform( const CvArr* src, CvArr* dst,
//                                      const CvMat* mat );
DEFINE_FUNCTION( N(void), cvPerspectiveTransform, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), SP(CvMat,mat) ) ) 

/* Calculates (A-delta)*(A-delta)^T (order=0) or (A-delta)^T*(A-delta) (order=1) */
// CVAPI(void) cvMulTransposed( const CvArr* src, CvArr* dst, int order,
//                              const CvArr* delta CV_DEFAULT(NULL),
//                              double scale CV_DEFAULT(1.) );
DEFINE_FUNCTION( N(void), cvMulTransposed, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,order), MP(UMemory,CvArr,delta), V(double,scale) ) ) 
DEFINE_FUNCTION( N(void), cvMulTransposed, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,order), MP(UMemory,CvArr,delta) ) ) 
DEFINE_FUNCTION( N(void), cvMulTransposed, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,order) ) ) 

/* Tranposes matrix. Square matrices can be transposed in-place */
// CVAPI(void)  cvTranspose( const CvArr* src, CvArr* dst );
DEFINE_FUNCTION( N(void), cvTranspose, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
// #define cvT cvTranspose
#pragma push_macro( "cvT" )
#undef cvT
DEFINE_FUNCTION_ALIAS( N(void), cvTranspose, cvT, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
#pragma pop_macro( "cvT" )

/* Completes the symmetric matrix from the lower (LtoR=0) or from the upper (LtoR!=0) part */
// CVAPI(void)  cvCompleteSymm( CvMat* matrix, int LtoR CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvCompleteSymm, 2( SP(CvMat,matrix), V(int,LtoR) ) ) 
DEFINE_FUNCTION( N(void), cvCompleteSymm, 1( SP(CvMat,matrix) ) ) 

/* Mirror array data around horizontal (flip=0),
   vertical (flip=1) or both(flip=-1) axises:
   cvFlip(src) flips images vertically and sequences horizontally (inplace) */
// CVAPI(void)  cvFlip( const CvArr* src, CvArr* dst CV_DEFAULT(NULL),
//                      int flip_mode CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvFlip, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,flip_mode) ) ) 
DEFINE_FUNCTION( N(void), cvFlip, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
DEFINE_FUNCTION( N(void), cvFlip, 1( MP(UMemory,CvArr,src) ) ) 
// #define cvMirror cvFlip
#pragma push_macro( "cvMirror" )
#undef cvMirror
DEFINE_FUNCTION_ALIAS( N(void), cvFlip, cvMirror, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,flip_mode) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvFlip, cvMirror, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvFlip, cvMirror, 1( MP(UMemory,CvArr,src) ) ) 
#pragma pop_macro( "cvMirror" )


// #define CV_SVD_MODIFY_A   1
#pragma push_macro( "CV_SVD_MODIFY_A" )
#undef CV_SVD_MODIFY_A
static const int CV_SVD_MODIFY_A
#pragma pop_macro( "CV_SVD_MODIFY_A" )
	= CV_SVD_MODIFY_A;
// #define CV_SVD_U_T        2
#pragma push_macro( "CV_SVD_U_T" )
#undef CV_SVD_U_T
static const int CV_SVD_U_T
#pragma pop_macro( "CV_SVD_U_T" )
	= CV_SVD_U_T;
// #define CV_SVD_V_T        4
#pragma push_macro( "CV_SVD_V_T" )
#undef CV_SVD_V_T
static const int CV_SVD_V_T
#pragma pop_macro( "CV_SVD_V_T" )
	= CV_SVD_V_T;

/* Performs Singular Value Decomposition of a matrix */
// CVAPI(void)   cvSVD( CvArr* A, CvArr* W, CvArr* U CV_DEFAULT(NULL),
//                      CvArr* V CV_DEFAULT(NULL), int flags CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvSVD, 5( MP(UMemory,CvArr,A), MP(UMemory,CvArr,W), MP(UMemory,CvArr,U), MP(UMemory,CvArr,V), V(int,flags) ) ) 
DEFINE_FUNCTION( N(void), cvSVD, 4( MP(UMemory,CvArr,A), MP(UMemory,CvArr,W), MP(UMemory,CvArr,U), MP(UMemory,CvArr,V) ) ) 
DEFINE_FUNCTION( N(void), cvSVD, 3( MP(UMemory,CvArr,A), MP(UMemory,CvArr,W), MP(UMemory,CvArr,U) ) ) 
DEFINE_FUNCTION( N(void), cvSVD, 2( MP(UMemory,CvArr,A), MP(UMemory,CvArr,W) ) ) 

/* Performs Singular Value Back Substitution (solves A*X = B):
   flags must be the same as in cvSVD */
// CVAPI(void)   cvSVBkSb( const CvArr* W, const CvArr* U,
//                         const CvArr* V, const CvArr* B,
//                         CvArr* X, int flags );
DEFINE_FUNCTION( N(void), cvSVBkSb, 6( MP(UMemory,CvArr,W), MP(UMemory,CvArr,U), MP(UMemory,CvArr,V), MP(UMemory,CvArr,B), MP(UMemory,CvArr,X), V(int,flags) ) ) 

// #define CV_LU  0
#pragma push_macro( "CV_LU" )
#undef CV_LU
static const int CV_LU
#pragma pop_macro( "CV_LU" )
	= CV_LU;
// #define CV_SVD 1
#pragma push_macro( "CV_SVD" )
#undef CV_SVD
static const int CV_SVD
#pragma pop_macro( "CV_SVD" )
	= CV_SVD;
// #define CV_SVD_SYM 2
#pragma push_macro( "CV_SVD_SYM" )
#undef CV_SVD_SYM
static const int CV_SVD_SYM
#pragma pop_macro( "CV_SVD_SYM" )
	= CV_SVD_SYM;
// #define CV_CHOLESKY 3
#pragma push_macro( "CV_CHOLESKY" )
#undef CV_CHOLESKY
static const int CV_CHOLESKY
#pragma pop_macro( "CV_CHOLESKY" )
	= CV_CHOLESKY;
// #define CV_QR  4
#pragma push_macro( "CV_QR" )
#undef CV_QR
static const int CV_QR
#pragma pop_macro( "CV_QR" )
	= CV_QR;
// #define CV_NORMAL 16
#pragma push_macro( "CV_NORMAL" )
#undef CV_NORMAL
static const int CV_NORMAL
#pragma pop_macro( "CV_NORMAL" )
	= CV_NORMAL;

/* Inverts matrix */
// CVAPI(double)  cvInvert( const CvArr* src, CvArr* dst,
//                          int method CV_DEFAULT(CV_LU));
DEFINE_FUNCTION( V(double), cvInvert, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,method) ) ) 
DEFINE_FUNCTION( V(double), cvInvert, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
// #define cvInv cvInvert
#pragma push_macro( "cvInv" )
#undef cvInv
DEFINE_FUNCTION_ALIAS( V(double), cvInvert, cvInv, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,method) ) ) 
DEFINE_FUNCTION_ALIAS( V(double), cvInvert, cvInv, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 
#pragma pop_macro( "cvInv" )

/* Solves linear system (src1)*(dst) = (src2)
   (returns 0 if src1 is a singular and CV_LU method is used) */
// CVAPI(int)  cvSolve( const CvArr* src1, const CvArr* src2, CvArr* dst,
//                      int method CV_DEFAULT(CV_LU));
DEFINE_FUNCTION( V(int), cvSolve, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst), V(int,method) ) ) 
DEFINE_FUNCTION( V(int), cvSolve, 3( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst) ) ) 

/* Calculates determinant of input matrix */
// CVAPI(double) cvDet( const CvArr* mat );
DEFINE_FUNCTION( V(double), cvDet, 1( MP(UMemory,CvArr,mat) ) ) 

/* Calculates trace of the matrix (sum of elements on the main diagonal) */
// CVAPI(CvScalar) cvTrace( const CvArr* mat );
DEFINE_FUNCTION( S(CvScalar), cvTrace, 1( MP(UMemory,CvArr,mat) ) ) 

/* Finds eigen values and vectors of a symmetric matrix */
// CVAPI(void)  cvEigenVV( CvArr* mat, CvArr* evects, CvArr* evals,
//                         double eps CV_DEFAULT(0),
//                         int lowindex CV_DEFAULT(-1),
//                         int highindex CV_DEFAULT(-1));
DEFINE_FUNCTION( N(void), cvEigenVV, 6( MP(UMemory,CvArr,mat), MP(UMemory,CvArr,evects), MP(UMemory,CvArr,evals), V(double,eps), V(int,lowindex), V(int,highindex) ) ) 
DEFINE_FUNCTION( N(void), cvEigenVV, 5( MP(UMemory,CvArr,mat), MP(UMemory,CvArr,evects), MP(UMemory,CvArr,evals), V(double,eps), V(int,lowindex) ) ) 
DEFINE_FUNCTION( N(void), cvEigenVV, 4( MP(UMemory,CvArr,mat), MP(UMemory,CvArr,evects), MP(UMemory,CvArr,evals), V(double,eps) ) ) 
DEFINE_FUNCTION( N(void), cvEigenVV, 3( MP(UMemory,CvArr,mat), MP(UMemory,CvArr,evects), MP(UMemory,CvArr,evals) ) ) 

///* Finds selected eigen values and vectors of a symmetric matrix */
//CVAPI(void)  cvSelectedEigenVV( CvArr* mat, CvArr* evects, CvArr* evals,
//                                int lowindex, int highindex );

/* Makes an identity matrix (mat_ij = i == j) */
// CVAPI(void)  cvSetIdentity( CvArr* mat, CvScalar value CV_DEFAULT(cvRealScalar(1)) );
DEFINE_FUNCTION( N(void), cvSetIdentity, 2( MP(UMemory,CvArr,mat), S(CvScalar,value) ) ) 
DEFINE_FUNCTION( N(void), cvSetIdentity, 1( MP(UMemory,CvArr,mat) ) ) 

/* Fills matrix with given range of numbers */
// CVAPI(CvArr*)  cvRange( CvArr* mat, double start, double end );
DEFINE_FUNCTION( P(CvArr*), cvRange, 3( MP(UMemory,CvArr,mat), V(double,start), V(double,end) ) ) 

/* Calculates covariation matrix for a set of vectors */
/* transpose([v1-avg, v2-avg,...]) * [v1-avg,v2-avg,...] */
// #define CV_COVAR_SCRAMBLED 0
#pragma push_macro( "CV_COVAR_SCRAMBLED" )
#undef CV_COVAR_SCRAMBLED
static const int CV_COVAR_SCRAMBLED
#pragma pop_macro( "CV_COVAR_SCRAMBLED" )
	= CV_COVAR_SCRAMBLED;

/* [v1-avg, v2-avg,...] * transpose([v1-avg,v2-avg,...]) */
// #define CV_COVAR_NORMAL    1
#pragma push_macro( "CV_COVAR_NORMAL" )
#undef CV_COVAR_NORMAL
static const int CV_COVAR_NORMAL
#pragma pop_macro( "CV_COVAR_NORMAL" )
	= CV_COVAR_NORMAL;

/* do not calc average (i.e. mean vector) - use the input vector instead
   (useful for calculating covariance matrix by parts) */
// #define CV_COVAR_USE_AVG   2
#pragma push_macro( "CV_COVAR_USE_AVG" )
#undef CV_COVAR_USE_AVG
static const int CV_COVAR_USE_AVG
#pragma pop_macro( "CV_COVAR_USE_AVG" )
	= CV_COVAR_USE_AVG;

/* scale the covariance matrix coefficients by number of the vectors */
// #define CV_COVAR_SCALE     4
#pragma push_macro( "CV_COVAR_SCALE" )
#undef CV_COVAR_SCALE
static const int CV_COVAR_SCALE
#pragma pop_macro( "CV_COVAR_SCALE" )
	= CV_COVAR_SCALE;

/* all the input vectors are stored in a single matrix, as its rows */
// #define CV_COVAR_ROWS      8
#pragma push_macro( "CV_COVAR_ROWS" )
#undef CV_COVAR_ROWS
static const int CV_COVAR_ROWS
#pragma pop_macro( "CV_COVAR_ROWS" )
	= CV_COVAR_ROWS;

/* all the input vectors are stored in a single matrix, as its columns */
// #define CV_COVAR_COLS     16
#pragma push_macro( "CV_COVAR_COLS" )
#undef CV_COVAR_COLS
static const int CV_COVAR_COLS
#pragma pop_macro( "CV_COVAR_COLS" )
	= CV_COVAR_COLS;

// CVAPI(void)  cvCalcCovarMatrix( const CvArr** vects, int count,
//                                 CvArr* cov_mat, CvArr* avg, int flags );
DEFINE_FUNCTION( N(void), cvCalcCovarMatrix, 5( MPA(UMemory,const UNAME(CvArr),vects), V(int,count), MP(UMemory,CvArr,cov_mat), MP(UMemory,CvArr,avg), V(int,flags) ) ) 

// #define CV_PCA_DATA_AS_ROW 0
#pragma push_macro( "CV_PCA_DATA_AS_ROW" )
#undef CV_PCA_DATA_AS_ROW
static const int CV_PCA_DATA_AS_ROW
#pragma pop_macro( "CV_PCA_DATA_AS_ROW" )
	= CV_PCA_DATA_AS_ROW;
// #define CV_PCA_DATA_AS_COL 1
#pragma push_macro( "CV_PCA_DATA_AS_COL" )
#undef CV_PCA_DATA_AS_COL
static const int CV_PCA_DATA_AS_COL
#pragma pop_macro( "CV_PCA_DATA_AS_COL" )
	= CV_PCA_DATA_AS_COL;
// #define CV_PCA_USE_AVG 2
#pragma push_macro( "CV_PCA_USE_AVG" )
#undef CV_PCA_USE_AVG
static const int CV_PCA_USE_AVG
#pragma pop_macro( "CV_PCA_USE_AVG" )
	= CV_PCA_USE_AVG;
// CVAPI(void)  cvCalcPCA( const CvArr* data, CvArr* mean,
//                         CvArr* eigenvals, CvArr* eigenvects, int flags );
DEFINE_FUNCTION( N(void), cvCalcPCA, 5( MP(UMemory,CvArr,data), MP(UMemory,CvArr,mean), MP(UMemory,CvArr,eigenvals), MP(UMemory,CvArr,eigenvects), V(int,flags) ) ) 

// CVAPI(void)  cvProjectPCA( const CvArr* data, const CvArr* mean,
//                            const CvArr* eigenvects, CvArr* result );
DEFINE_FUNCTION( N(void), cvProjectPCA, 4( MP(UMemory,CvArr,data), MP(UMemory,CvArr,mean), MP(UMemory,CvArr,eigenvects), MP(UMemory,CvArr,result) ) ) 

// CVAPI(void)  cvBackProjectPCA( const CvArr* proj, const CvArr* mean,
//                                const CvArr* eigenvects, CvArr* result );
DEFINE_FUNCTION( N(void), cvBackProjectPCA, 4( MP(UMemory,CvArr,proj), MP(UMemory,CvArr,mean), MP(UMemory,CvArr,eigenvects), MP(UMemory,CvArr,result) ) ) 

/* Calculates Mahalanobis(weighted) distance */
// CVAPI(double)  cvMahalanobis( const CvArr* vec1, const CvArr* vec2, const CvArr* mat );
DEFINE_FUNCTION( V(double), cvMahalanobis, 3( MP(UMemory,CvArr,vec1), MP(UMemory,CvArr,vec2), MP(UMemory,CvArr,mat) ) ) 
// #define cvMahalonobis  cvMahalanobis
#pragma push_macro( "cvMahalonobis" )
#undef cvMahalonobis
DEFINE_FUNCTION_ALIAS( V(double), cvMahalanobis, cvMahalonobis, 3( MP(UMemory,CvArr,vec1), MP(UMemory,CvArr,vec2), MP(UMemory,CvArr,mat) ) ) 
#pragma pop_macro( "cvMahalonobis" )

/****************************************************************************************\
*                                    Array Statistics                                    *
\****************************************************************************************/

/* Finds sum of array elements */
// CVAPI(CvScalar)  cvSum( const CvArr* arr );
DEFINE_FUNCTION( S(CvScalar), cvSum, 1( MP(UMemory,CvArr,arr) ) ) 

/* Calculates number of non-zero pixels */
// CVAPI(int)  cvCountNonZero( const CvArr* arr );
DEFINE_FUNCTION( V(int), cvCountNonZero, 1( MP(UMemory,CvArr,arr) ) ) 

/* Calculates mean value of array elements */
// CVAPI(CvScalar)  cvAvg( const CvArr* arr, const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( S(CvScalar), cvAvg, 2( MP(UMemory,CvArr,arr), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( S(CvScalar), cvAvg, 1( MP(UMemory,CvArr,arr) ) ) 

/* Calculates mean and standard deviation of pixel values */
// CVAPI(void)  cvAvgSdv( const CvArr* arr, CvScalar* mean, CvScalar* std_dev,
//                        const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvAvgSdv, 4( MP(UMemory,CvArr,arr), SP(CvScalar,mean), SP(CvScalar,std_dev), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvAvgSdv, 3( MP(UMemory,CvArr,arr), SP(CvScalar,mean), SP(CvScalar,std_dev) ) ) 

/* Finds global minimum, maximum and their positions */
// CVAPI(void)  cvMinMaxLoc( const CvArr* arr, double* min_val, double* max_val,
//                           CvPoint* min_loc CV_DEFAULT(NULL),
//                           CvPoint* max_loc CV_DEFAULT(NULL),
//                           const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 6( MP(UMemory,CvArr,arr), VP(double,min_val), VP(double,max_val), SP(CvPoint,min_loc), SP(CvPoint,max_loc), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 6( MP(UMemory,CvArr,arr), P(double*,min_val), VP(double,max_val), SP(CvPoint,min_loc), SP(CvPoint,max_loc), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 6( MP(UMemory,CvArr,arr), VP(double,min_val), P(double*,max_val), SP(CvPoint,min_loc), SP(CvPoint,max_loc), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 6( MP(UMemory,CvArr,arr), P(double*,min_val), P(double*,max_val), SP(CvPoint,min_loc), SP(CvPoint,max_loc), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 5( MP(UMemory,CvArr,arr), VP(double,min_val), VP(double,max_val), SP(CvPoint,min_loc), SP(CvPoint,max_loc) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 5( MP(UMemory,CvArr,arr), P(double*,min_val), VP(double,max_val), SP(CvPoint,min_loc), SP(CvPoint,max_loc) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 5( MP(UMemory,CvArr,arr), VP(double,min_val), P(double*,max_val), SP(CvPoint,min_loc), SP(CvPoint,max_loc) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 5( MP(UMemory,CvArr,arr), P(double*,min_val), P(double*,max_val), SP(CvPoint,min_loc), SP(CvPoint,max_loc) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 4( MP(UMemory,CvArr,arr), VP(double,min_val), VP(double,max_val), SP(CvPoint,min_loc) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 4( MP(UMemory,CvArr,arr), P(double*,min_val), VP(double,max_val), SP(CvPoint,min_loc) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 4( MP(UMemory,CvArr,arr), VP(double,min_val), P(double*,max_val), SP(CvPoint,min_loc) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 4( MP(UMemory,CvArr,arr), P(double*,min_val), P(double*,max_val), SP(CvPoint,min_loc) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 3( MP(UMemory,CvArr,arr), VP(double,min_val), VP(double,max_val) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 3( MP(UMemory,CvArr,arr), P(double*,min_val), VP(double,max_val) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 3( MP(UMemory,CvArr,arr), VP(double,min_val), P(double*,max_val) ) ) 
DEFINE_FUNCTION( N(void), cvMinMaxLoc, 3( MP(UMemory,CvArr,arr), P(double*,min_val), P(double*,max_val) ) ) 

/* types of array norm */
// #define CV_C            1
#pragma push_macro( "CV_C" )
#undef CV_C
static const int CV_C
#pragma pop_macro( "CV_C" )
	= CV_C;
// #define CV_L1           2
#pragma push_macro( "CV_L1" )
#undef CV_L1
static const int CV_L1
#pragma pop_macro( "CV_L1" )
	= CV_L1;
// #define CV_L2           4
#pragma push_macro( "CV_L2" )
#undef CV_L2
static const int CV_L2
#pragma pop_macro( "CV_L2" )
	= CV_L2;
// #define CV_NORM_MASK    7
#pragma push_macro( "CV_NORM_MASK" )
#undef CV_NORM_MASK
static const int CV_NORM_MASK
#pragma pop_macro( "CV_NORM_MASK" )
	= CV_NORM_MASK;
// #define CV_RELATIVE     8
#pragma push_macro( "CV_RELATIVE" )
#undef CV_RELATIVE
static const int CV_RELATIVE
#pragma pop_macro( "CV_RELATIVE" )
	= CV_RELATIVE;
// #define CV_DIFF         16
#pragma push_macro( "CV_DIFF" )
#undef CV_DIFF
static const int CV_DIFF
#pragma pop_macro( "CV_DIFF" )
	= CV_DIFF;
// #define CV_MINMAX       32
#pragma push_macro( "CV_MINMAX" )
#undef CV_MINMAX
static const int CV_MINMAX
#pragma pop_macro( "CV_MINMAX" )
	= CV_MINMAX;

// #define CV_DIFF_C       (CV_DIFF | CV_C)
#pragma push_macro( "CV_DIFF_C" )
#undef CV_DIFF_C
static const int CV_DIFF_C
#pragma pop_macro( "CV_DIFF_C" )
	= CV_DIFF_C;
// #define CV_DIFF_L1      (CV_DIFF | CV_L1)
#pragma push_macro( "CV_DIFF_L1" )
#undef CV_DIFF_L1
static const int CV_DIFF_L1
#pragma pop_macro( "CV_DIFF_L1" )
	= CV_DIFF_L1;
// #define CV_DIFF_L2      (CV_DIFF | CV_L2)
#pragma push_macro( "CV_DIFF_L2" )
#undef CV_DIFF_L2
static const int CV_DIFF_L2
#pragma pop_macro( "CV_DIFF_L2" )
	= CV_DIFF_L2;
// #define CV_RELATIVE_C   (CV_RELATIVE | CV_C)
#pragma push_macro( "CV_RELATIVE_C" )
#undef CV_RELATIVE_C
static const int CV_RELATIVE_C
#pragma pop_macro( "CV_RELATIVE_C" )
	= CV_RELATIVE_C;
// #define CV_RELATIVE_L1  (CV_RELATIVE | CV_L1)
#pragma push_macro( "CV_RELATIVE_L1" )
#undef CV_RELATIVE_L1
static const int CV_RELATIVE_L1
#pragma pop_macro( "CV_RELATIVE_L1" )
	= CV_RELATIVE_L1;
// #define CV_RELATIVE_L2  (CV_RELATIVE | CV_L2)
#pragma push_macro( "CV_RELATIVE_L2" )
#undef CV_RELATIVE_L2
static const int CV_RELATIVE_L2
#pragma pop_macro( "CV_RELATIVE_L2" )
	= CV_RELATIVE_L2;

/* Finds norm, difference norm or relative difference norm for an array (or two arrays) */
// CVAPI(double)  cvNorm( const CvArr* arr1, const CvArr* arr2 CV_DEFAULT(NULL),
//                        int norm_type CV_DEFAULT(CV_L2),
//                        const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( V(double), cvNorm, 4( MP(UMemory,CvArr,arr1), MP(UMemory,CvArr,arr2), V(int,norm_type), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( V(double), cvNorm, 3( MP(UMemory,CvArr,arr1), MP(UMemory,CvArr,arr2), V(int,norm_type) ) ) 
DEFINE_FUNCTION( V(double), cvNorm, 2( MP(UMemory,CvArr,arr1), MP(UMemory,CvArr,arr2) ) ) 
DEFINE_FUNCTION( V(double), cvNorm, 1( MP(UMemory,CvArr,arr1) ) ) 

// CVAPI(void)  cvNormalize( const CvArr* src, CvArr* dst,
//                           double a CV_DEFAULT(1.), double b CV_DEFAULT(0.),
//                           int norm_type CV_DEFAULT(CV_L2),
//                           const CvArr* mask CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvNormalize, 6( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,a), V(double,b), V(int,norm_type), MP(UMemory,CvArr,mask) ) ) 
DEFINE_FUNCTION( N(void), cvNormalize, 5( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,a), V(double,b), V(int,norm_type) ) ) 
DEFINE_FUNCTION( N(void), cvNormalize, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,a), V(double,b) ) ) 
DEFINE_FUNCTION( N(void), cvNormalize, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(double,a) ) ) 
DEFINE_FUNCTION( N(void), cvNormalize, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 


// #define CV_REDUCE_SUM 0
#pragma push_macro( "CV_REDUCE_SUM" )
#undef CV_REDUCE_SUM
static const int CV_REDUCE_SUM
#pragma pop_macro( "CV_REDUCE_SUM" )
	= CV_REDUCE_SUM;
// #define CV_REDUCE_AVG 1
#pragma push_macro( "CV_REDUCE_AVG" )
#undef CV_REDUCE_AVG
static const int CV_REDUCE_AVG
#pragma pop_macro( "CV_REDUCE_AVG" )
	= CV_REDUCE_AVG;
// #define CV_REDUCE_MAX 2
#pragma push_macro( "CV_REDUCE_MAX" )
#undef CV_REDUCE_MAX
static const int CV_REDUCE_MAX
#pragma pop_macro( "CV_REDUCE_MAX" )
	= CV_REDUCE_MAX;
// #define CV_REDUCE_MIN 3
#pragma push_macro( "CV_REDUCE_MIN" )
#undef CV_REDUCE_MIN
static const int CV_REDUCE_MIN
#pragma pop_macro( "CV_REDUCE_MIN" )
	= CV_REDUCE_MIN;

// CVAPI(void)  cvReduce( const CvArr* src, CvArr* dst, int dim CV_DEFAULT(-1),
//                        int op CV_DEFAULT(CV_REDUCE_SUM) );
DEFINE_FUNCTION( N(void), cvReduce, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,dim), V(int,op) ) ) 
DEFINE_FUNCTION( N(void), cvReduce, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,dim) ) ) 
DEFINE_FUNCTION( N(void), cvReduce, 2( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst) ) ) 

/****************************************************************************************\
*                      Discrete Linear Transforms and Related Functions                  *
\****************************************************************************************/

// #define CV_DXT_FORWARD  0
#pragma push_macro( "CV_DXT_FORWARD" )
#undef CV_DXT_FORWARD
static const int CV_DXT_FORWARD
#pragma pop_macro( "CV_DXT_FORWARD" )
	= CV_DXT_FORWARD;
// #define CV_DXT_INVERSE  1
#pragma push_macro( "CV_DXT_INVERSE" )
#undef CV_DXT_INVERSE
static const int CV_DXT_INVERSE
#pragma pop_macro( "CV_DXT_INVERSE" )
	= CV_DXT_INVERSE;
// #define CV_DXT_SCALE    2 /* divide result by size of array */
#pragma push_macro( "CV_DXT_SCALE" )
#undef CV_DXT_SCALE
static const int CV_DXT_SCALE
#pragma pop_macro( "CV_DXT_SCALE" )
	= CV_DXT_SCALE;
// #define CV_DXT_INV_SCALE (CV_DXT_INVERSE + CV_DXT_SCALE)
#pragma push_macro( "CV_DXT_INV_SCALE" )
#undef CV_DXT_INV_SCALE
static const int CV_DXT_INV_SCALE
#pragma pop_macro( "CV_DXT_INV_SCALE" )
	= CV_DXT_INV_SCALE;
// #define CV_DXT_INVERSE_SCALE CV_DXT_INV_SCALE
#pragma push_macro( "CV_DXT_INVERSE_SCALE" )
#undef CV_DXT_INVERSE_SCALE
static const int CV_DXT_INVERSE_SCALE
#pragma pop_macro( "CV_DXT_INVERSE_SCALE" )
	= CV_DXT_INVERSE_SCALE;
// #define CV_DXT_ROWS     4 /* transform each row individually */
#pragma push_macro( "CV_DXT_ROWS" )
#undef CV_DXT_ROWS
static const int CV_DXT_ROWS
#pragma pop_macro( "CV_DXT_ROWS" )
	= CV_DXT_ROWS;
// #define CV_DXT_MUL_CONJ 8 /* conjugate the second argument of cvMulSpectrums */
#pragma push_macro( "CV_DXT_MUL_CONJ" )
#undef CV_DXT_MUL_CONJ
static const int CV_DXT_MUL_CONJ
#pragma pop_macro( "CV_DXT_MUL_CONJ" )
	= CV_DXT_MUL_CONJ;

/* Discrete Fourier Transform:
    complex->complex,
    real->ccs (forward),
    ccs->real (inverse) */
// CVAPI(void)  cvDFT( const CvArr* src, CvArr* dst, int flags,
//                     int nonzero_rows CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvDFT, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,flags), V(int,nonzero_rows) ) ) 
DEFINE_FUNCTION( N(void), cvDFT, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,flags) ) ) 
// #define cvFFT cvDFT
#pragma push_macro( "cvFFT" )
#undef cvFFT
DEFINE_FUNCTION_ALIAS( N(void), cvDFT, cvFFT, 4( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,flags), V(int,nonzero_rows) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvDFT, cvFFT, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,flags) ) ) 
#pragma pop_macro( "cvFFT" )

/* Multiply results of DFTs: DFT(X)*DFT(Y) or DFT(X)*conj(DFT(Y)) */
// CVAPI(void)  cvMulSpectrums( const CvArr* src1, const CvArr* src2,
//                              CvArr* dst, int flags );
DEFINE_FUNCTION( N(void), cvMulSpectrums, 4( MP(UMemory,CvArr,src1), MP(UMemory,CvArr,src2), MP(UMemory,CvArr,dst), V(int,flags) ) ) 

/* Finds optimal DFT vector size >= size0 */
// CVAPI(int)  cvGetOptimalDFTSize( int size0 );
DEFINE_FUNCTION( V(int), cvGetOptimalDFTSize, 1( V(int,size0) ) ) 

/* Discrete Cosine Transform */
// CVAPI(void)  cvDCT( const CvArr* src, CvArr* dst, int flags );
DEFINE_FUNCTION( N(void), cvDCT, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), V(int,flags) ) ) 

/****************************************************************************************\
*                              Dynamic data structures                                   *
\****************************************************************************************/

/* Calculates length of sequence slice (with support of negative indices). */
// CVAPI(int) cvSliceLength( CvSlice slice, const CvSeq* seq );
DEFINE_FUNCTION( V(int), cvSliceLength, 2( S(CvSlice,slice), SP(CvSeq,seq) ) ) 


/* Creates new memory storage.
   block_size == 0 means that default,
   somewhat optimal size, is used (currently, it is 64K) */
// CVAPI(CvMemStorage*)  cvCreateMemStorage( int block_size CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvMemStorage), cvCreateMemStorage, 1( V(int,block_size) ) ) 


/* Creates a memory storage that will borrow memory blocks from parent storage */
// CVAPI(CvMemStorage*)  cvCreateChildMemStorage( CvMemStorage* parent );
DEFINE_FUNCTION( SP(CvMemStorage), cvCreateChildMemStorage, 1( SP(CvMemStorage,parent) ) ) 


/* Releases memory storage. All the children of a parent must be released before
   the parent. A child storage returns all the blocks to parent when it is released */
// CVAPI(void)  cvReleaseMemStorage( CvMemStorage** storage );
DEFINE_FUNCTION( N(void), cvReleaseMemStorage, 1( SPP(CvMemStorage,storage) ) ) 


/* Clears memory storage. This is the only way(!!!) (besides cvRestoreMemStoragePos)
   to reuse memory allocated for the storage - cvClearSeq,cvClearSet ...
   do not free any memory.
   A child storage returns all the blocks to the parent when it is cleared */
// CVAPI(void)  cvClearMemStorage( CvMemStorage* storage );
DEFINE_FUNCTION( N(void), cvClearMemStorage, 1( SP(CvMemStorage,storage) ) ) 

/* Remember a storage "free memory" position */
// CVAPI(void)  cvSaveMemStoragePos( const CvMemStorage* storage, CvMemStoragePos* pos );
DEFINE_FUNCTION( N(void), cvSaveMemStoragePos, 2( SP(CvMemStorage,storage), SP(CvMemStoragePos,pos) ) ) 

/* Restore a storage "free memory" position */
// CVAPI(void)  cvRestoreMemStoragePos( CvMemStorage* storage, CvMemStoragePos* pos );
DEFINE_FUNCTION( N(void), cvRestoreMemStoragePos, 2( SP(CvMemStorage,storage), SP(CvMemStoragePos,pos) ) ) 

/* Allocates continuous buffer of the specified size in the storage */
// CVAPI(void*) cvMemStorageAlloc( CvMemStorage* storage, size_t size );
DEFINE_FUNCTION( P(void*), cvMemStorageAlloc, 2( SP(CvMemStorage,storage), V(size_t,size) ) ) 

/* Allocates string in memory storage */
// CVAPI(CvString) cvMemStorageAllocString( CvMemStorage* storage, const char* ptr,
//                                         int len CV_DEFAULT(-1) );
DEFINE_FUNCTION( S(CvString), cvMemStorageAllocString, 3( SP(CvMemStorage,storage), T(const,ptr), V(int,len) ) ) 
DEFINE_FUNCTION( S(CvString), cvMemStorageAllocString, 2( SP(CvMemStorage,storage), T(const,ptr) ) ) 

/* Creates new empty sequence that will reside in the specified storage */
// CVAPI(CvSeq*)  cvCreateSeq( int seq_flags, int header_size,
//                             int elem_size, CvMemStorage* storage );
DEFINE_FUNCTION( SP(CvSeq), cvCreateSeq, 4( V(int,seq_flags), V(int,header_size), V(int,elem_size), SP(CvMemStorage,storage) ) ) 

/* Changes default size (granularity) of sequence blocks.
   The default size is ~1Kbyte */
// CVAPI(void)  cvSetSeqBlockSize( CvSeq* seq, int delta_elems );
DEFINE_FUNCTION( N(void), cvSetSeqBlockSize, 2( SP(CvSeq,seq), V(int,delta_elems) ) ) 


/* Adds new element to the end of sequence. Returns pointer to the element */
// CVAPI(schar*)  cvSeqPush( CvSeq* seq, const void* element CV_DEFAULT(NULL));
DEFINE_FUNCTION( P(signed char*), cvSeqPush, 2( SP(CvSeq,seq), P(const void*,element) ) ) 
DEFINE_FUNCTION( P(signed char*), cvSeqPush, 1( SP(CvSeq,seq) ) ) 


/* Adds new element to the beginning of sequence. Returns pointer to it */
// CVAPI(schar*)  cvSeqPushFront( CvSeq* seq, const void* element CV_DEFAULT(NULL));
DEFINE_FUNCTION( P(signed char*), cvSeqPushFront, 2( SP(CvSeq,seq), P(const void*,element) ) ) 
DEFINE_FUNCTION( P(signed char*), cvSeqPushFront, 1( SP(CvSeq,seq) ) ) 


/* Removes the last element from sequence and optionally saves it */
// CVAPI(void)  cvSeqPop( CvSeq* seq, void* element CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvSeqPop, 2( SP(CvSeq,seq), P(void*,element) ) ) 
DEFINE_FUNCTION( N(void), cvSeqPop, 1( SP(CvSeq,seq) ) ) 


/* Removes the first element from sequence and optioanally saves it */
// CVAPI(void)  cvSeqPopFront( CvSeq* seq, void* element CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvSeqPopFront, 2( SP(CvSeq,seq), P(void*,element) ) ) 
DEFINE_FUNCTION( N(void), cvSeqPopFront, 1( SP(CvSeq,seq) ) ) 


// #define CV_FRONT 1
#pragma push_macro( "CV_FRONT" )
#undef CV_FRONT
static const int CV_FRONT
#pragma pop_macro( "CV_FRONT" )
	= CV_FRONT;
// #define CV_BACK 0
#pragma push_macro( "CV_BACK" )
#undef CV_BACK
static const int CV_BACK
#pragma pop_macro( "CV_BACK" )
	= CV_BACK;
/* Adds several new elements to the end of sequence */
// CVAPI(void)  cvSeqPushMulti( CvSeq* seq, const void* elements,
//                              int count, int in_front CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvSeqPushMulti, 4( SP(CvSeq,seq), P(const void*,elements), V(int,count), V(int,in_front) ) ) 
DEFINE_FUNCTION( N(void), cvSeqPushMulti, 3( SP(CvSeq,seq), P(const void*,elements), V(int,count) ) ) 

/* Removes several elements from the end of sequence and optionally saves them */
// CVAPI(void)  cvSeqPopMulti( CvSeq* seq, void* elements,
//                             int count, int in_front CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvSeqPopMulti, 4( SP(CvSeq,seq), P(void*,elements), V(int,count), V(int,in_front) ) ) 
DEFINE_FUNCTION( N(void), cvSeqPopMulti, 3( SP(CvSeq,seq), P(void*,elements), V(int,count) ) ) 

/* Inserts a new element in the middle of sequence.
   cvSeqInsert(seq,0,elem) == cvSeqPushFront(seq,elem) */
// CVAPI(schar*)  cvSeqInsert( CvSeq* seq, int before_index,
//                             const void* element CV_DEFAULT(NULL));
DEFINE_FUNCTION( P(signed char*), cvSeqInsert, 3( SP(CvSeq,seq), V(int,before_index), P(const void*,element) ) ) 
DEFINE_FUNCTION( P(signed char*), cvSeqInsert, 2( SP(CvSeq,seq), V(int,before_index) ) ) 

/* Removes specified sequence element */
// CVAPI(void)  cvSeqRemove( CvSeq* seq, int index );
DEFINE_FUNCTION( N(void), cvSeqRemove, 2( SP(CvSeq,seq), V(int,index) ) ) 


/* Removes all the elements from the sequence. The freed memory
   can be reused later only by the same sequence unless cvClearMemStorage
   or cvRestoreMemStoragePos is called */
// CVAPI(void)  cvClearSeq( CvSeq* seq );
DEFINE_FUNCTION( N(void), cvClearSeq, 1( SP(CvSeq,seq) ) ) 


/* Retrieves pointer to specified sequence element.
   Negative indices are supported and mean counting from the end
   (e.g -1 means the last sequence element) */
// CVAPI(schar*)  cvGetSeqElem( const CvSeq* seq, int index );
DEFINE_FUNCTION( P(signed char*), cvGetSeqElem, 2( SP(CvSeq,seq), V(int,index) ) ) 

/* Calculates index of the specified sequence element.
   Returns -1 if element does not belong to the sequence */
// CVAPI(int)  cvSeqElemIdx( const CvSeq* seq, const void* element,
//                          CvSeqBlock** block CV_DEFAULT(NULL) );
DEFINE_FUNCTION( V(int), cvSeqElemIdx, 3( SP(CvSeq,seq), P(const void*,element), SPP(CvSeqBlock,block) ) ) 
DEFINE_FUNCTION( V(int), cvSeqElemIdx, 2( SP(CvSeq,seq), P(const void*,element) ) ) 

/* Initializes sequence writer. The new elements will be added to the end of sequence */
// CVAPI(void)  cvStartAppendToSeq( CvSeq* seq, CvSeqWriter* writer );
DEFINE_FUNCTION( N(void), cvStartAppendToSeq, 2( SP(CvSeq,seq), SP(CvSeqWriter,writer) ) ) 


/* Combination of cvCreateSeq and cvStartAppendToSeq */
// CVAPI(void)  cvStartWriteSeq( int seq_flags, int header_size,
//                               int elem_size, CvMemStorage* storage,
//                               CvSeqWriter* writer );
DEFINE_FUNCTION( N(void), cvStartWriteSeq, 5( V(int,seq_flags), V(int,header_size), V(int,elem_size), SP(CvMemStorage,storage), SP(CvSeqWriter,writer) ) ) 

/* Closes sequence writer, updates sequence header and returns pointer
   to the resultant sequence
   (which may be useful if the sequence was created using cvStartWriteSeq))
*/
// CVAPI(CvSeq*)  cvEndWriteSeq( CvSeqWriter* writer );
DEFINE_FUNCTION( SP(CvSeq), cvEndWriteSeq, 1( SP(CvSeqWriter,writer) ) ) 


/* Updates sequence header. May be useful to get access to some of previously
   written elements via cvGetSeqElem or sequence reader */
// CVAPI(void)   cvFlushSeqWriter( CvSeqWriter* writer );
DEFINE_FUNCTION( N(void), cvFlushSeqWriter, 1( SP(CvSeqWriter,writer) ) ) 


/* Initializes sequence reader.
   The sequence can be read in forward or backward direction */
// CVAPI(void) cvStartReadSeq( const CvSeq* seq, CvSeqReader* reader,
//                            int reverse CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvStartReadSeq, 3( SP(CvSeq,seq), SP(CvSeqReader,reader), V(int,reverse) ) ) 
DEFINE_FUNCTION( N(void), cvStartReadSeq, 2( SP(CvSeq,seq), SP(CvSeqReader,reader) ) ) 


/* Returns current sequence reader position (currently observed sequence element) */
// CVAPI(int)  cvGetSeqReaderPos( CvSeqReader* reader );
DEFINE_FUNCTION( V(int), cvGetSeqReaderPos, 1( SP(CvSeqReader,reader) ) ) 


/* Changes sequence reader position. It may seek to an absolute or
   to relative to the current position */
// CVAPI(void)   cvSetSeqReaderPos( CvSeqReader* reader, int index,
//                                  int is_relative CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvSetSeqReaderPos, 3( SP(CvSeqReader,reader), V(int,index), V(int,is_relative) ) ) 
DEFINE_FUNCTION( N(void), cvSetSeqReaderPos, 2( SP(CvSeqReader,reader), V(int,index) ) ) 

/* Copies sequence content to a continuous piece of memory */
// CVAPI(void*)  cvCvtSeqToArray( const CvSeq* seq, void* elements,
//                                CvSlice slice CV_DEFAULT(CV_WHOLE_SEQ) );
DEFINE_FUNCTION( P(void*), cvCvtSeqToArray, 3( SP(CvSeq,seq), P(void*,elements), S(CvSlice,slice) ) ) 
DEFINE_FUNCTION( P(void*), cvCvtSeqToArray, 2( SP(CvSeq,seq), P(void*,elements) ) ) 

/* Creates sequence header for array.
   After that all the operations on sequences that do not alter the content
   can be applied to the resultant sequence */
// CVAPI(CvSeq*) cvMakeSeqHeaderForArray( int seq_type, int header_size,
//                                        int elem_size, void* elements, int total,
//                                        CvSeq* seq, CvSeqBlock* block );
DEFINE_FUNCTION( SP(CvSeq), cvMakeSeqHeaderForArray, 7( V(int,seq_type), V(int,header_size), V(int,elem_size), P(void*,elements), V(int,total), SP(CvSeq,seq), SP(CvSeqBlock,block) ) ) 

/* Extracts sequence slice (with or without copying sequence elements) */
// CVAPI(CvSeq*) cvSeqSlice( const CvSeq* seq, CvSlice slice,
//                          CvMemStorage* storage CV_DEFAULT(NULL),
//                          int copy_data CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvSeq), cvSeqSlice, 4( SP(CvSeq,seq), S(CvSlice,slice), SP(CvMemStorage,storage), V(int,copy_data) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvSeqSlice, 3( SP(CvSeq,seq), S(CvSlice,slice), SP(CvMemStorage,storage) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvSeqSlice, 2( SP(CvSeq,seq), S(CvSlice,slice) ) ) 

// CV_INLINE CvSeq* cvCloneSeq( const CvSeq* seq, CvMemStorage* storage CV_DEFAULT(NULL))
// {
//     return cvSeqSlice( seq, CV_WHOLE_SEQ, storage, 1 );
// }
DEFINE_FUNCTION( SP(CvSeq), cvCloneSeq, 2( SP(CvSeq,seq), SP(CvMemStorage,storage) ) ) 
DEFINE_FUNCTION( SP(CvSeq), cvCloneSeq, 1( SP(CvSeq,seq) ) ) 

/* Removes sequence slice */
// CVAPI(void)  cvSeqRemoveSlice( CvSeq* seq, CvSlice slice );
DEFINE_FUNCTION( N(void), cvSeqRemoveSlice, 2( SP(CvSeq,seq), S(CvSlice,slice) ) ) 

/* Inserts a sequence or array into another sequence */
// CVAPI(void)  cvSeqInsertSlice( CvSeq* seq, int before_index, const CvArr* from_arr );
DEFINE_FUNCTION( N(void), cvSeqInsertSlice, 3( SP(CvSeq,seq), V(int,before_index), MP(UMemory,CvArr,from_arr) ) ) 

/* a < b ? -1 : a > b ? 1 : 0 */
// typedef int (CV_CDECL* CvCmpFunc)(const void* a, const void* b, void* userdata );
DEFINE_CALLBACK( V(int), CvCmpFunc, 3( P(const void*,a), P(const void*,b), P(void*,userdata) ) ) 

/* Sorts sequence in-place given element comparison function */
// CVAPI(void) cvSeqSort( CvSeq* seq, CvCmpFunc func, void* userdata CV_DEFAULT(NULL) );
DEFINE_FUNCTION( N(void), cvSeqSort, 3( SP(CvSeq,seq), F(CvCmpFunc,func), P(void*,userdata) ) ) 
DEFINE_FUNCTION( N(void), cvSeqSort, 2( SP(CvSeq,seq), F(CvCmpFunc,func) ) ) 

/* Finds element in a [sorted] sequence */
// CVAPI(schar*) cvSeqSearch( CvSeq* seq, const void* elem, CvCmpFunc func,
//                            int is_sorted, int* elem_idx,
//                            void* userdata CV_DEFAULT(NULL) );
DEFINE_FUNCTION( P(signed char*), cvSeqSearch, 6( SP(CvSeq,seq), P(const void*,elem), F(CvCmpFunc,func), V(int,is_sorted), VP(int,elem_idx), P(void*,userdata) ) ) 
DEFINE_FUNCTION( P(signed char*), cvSeqSearch, 6( SP(CvSeq,seq), P(const void*,elem), F(CvCmpFunc,func), V(int,is_sorted), P(int*,elem_idx), P(void*,userdata) ) ) 
DEFINE_FUNCTION( P(signed char*), cvSeqSearch, 5( SP(CvSeq,seq), P(const void*,elem), F(CvCmpFunc,func), V(int,is_sorted), VP(int,elem_idx) ) ) 
DEFINE_FUNCTION( P(signed char*), cvSeqSearch, 5( SP(CvSeq,seq), P(const void*,elem), F(CvCmpFunc,func), V(int,is_sorted), P(int*,elem_idx) ) ) 

/* Reverses order of sequence elements in-place */
// CVAPI(void) cvSeqInvert( CvSeq* seq );
DEFINE_FUNCTION( N(void), cvSeqInvert, 1( SP(CvSeq,seq) ) ) 

/* Splits sequence into one or more equivalence classes using the specified criteria */
// CVAPI(int)  cvSeqPartition( const CvSeq* seq, CvMemStorage* storage,
//                             CvSeq** labels, CvCmpFunc is_equal, void* userdata );
DEFINE_FUNCTION( V(int), cvSeqPartition, 5( SP(CvSeq,seq), SP(CvMemStorage,storage), SPP(CvSeq,labels), F(CvCmpFunc,is_equal), P(void*,userdata) ) ) 

/************ Internal sequence functions ************/
// CVAPI(void)  cvChangeSeqBlock( void* reader, int direction );
DEFINE_FUNCTION( N(void), cvChangeSeqBlock, 2( P(void*,reader), V(int,direction) ) ) 
// CVAPI(void)  cvCreateSeqBlock( CvSeqWriter* writer );
DEFINE_FUNCTION( N(void), cvCreateSeqBlock, 1( SP(CvSeqWriter,writer) ) ) 


/* Creates a new set */
// CVAPI(CvSet*)  cvCreateSet( int set_flags, int header_size,
//                             int elem_size, CvMemStorage* storage );
DEFINE_FUNCTION( SP(CvSet), cvCreateSet, 4( V(int,set_flags), V(int,header_size), V(int,elem_size), SP(CvMemStorage,storage) ) ) 

/* Adds new element to the set and returns pointer to it */
// CVAPI(int)  cvSetAdd( CvSet* set_header, CvSetElem* elem CV_DEFAULT(NULL),
//                       CvSetElem** inserted_elem CV_DEFAULT(NULL) );
DEFINE_FUNCTION( V(int), cvSetAdd, 3( SP(CvSet,set_header), SP(CvSetElem,elem), SPP(CvSetElem,inserted_elem) ) ) 
DEFINE_FUNCTION( V(int), cvSetAdd, 2( SP(CvSet,set_header), SP(CvSetElem,elem) ) ) 
DEFINE_FUNCTION( V(int), cvSetAdd, 1( SP(CvSet,set_header) ) ) 

/* Fast variant of cvSetAdd */
// CV_INLINE  CvSetElem* cvSetNew( CvSet* set_header )
// {
//     CvSetElem* elem = set_header->free_elems;
//     if( elem )
//     {
//         set_header->free_elems = elem->next_free;
//         elem->flags = elem->flags & CV_SET_ELEM_IDX_MASK;
//         set_header->active_count++;
//     }
//     else
//         cvSetAdd( set_header, NULL, (CvSetElem**)&elem );
//     return elem;
// }
DEFINE_FUNCTION( SP(CvSetElem), cvSetNew, 1( SP(CvSet,set_header) ) ) 

/* Removes set element given its pointer */
// CV_INLINE  void cvSetRemoveByPtr( CvSet* set_header, void* elem )
// {
//     CvSetElem* _elem = (CvSetElem*)elem;
//     assert( _elem->flags >= 0 /*&& (elem->flags & CV_SET_ELEM_IDX_MASK) < set_header->total*/ );
//     _elem->next_free = set_header->free_elems;
//     _elem->flags = (_elem->flags & CV_SET_ELEM_IDX_MASK) | CV_SET_ELEM_FREE_FLAG;
//     set_header->free_elems = _elem;
//     set_header->active_count--;
// }
DEFINE_FUNCTION( N(void), cvSetRemoveByPtr, 2( SP(CvSet,set_header), P(void*,elem) ) ) 

/* Removes element from the set by its index  */
// CVAPI(void)   cvSetRemove( CvSet* set_header, int index );
DEFINE_FUNCTION( N(void), cvSetRemove, 2( SP(CvSet,set_header), V(int,index) ) ) 

/* Returns a set element by index. If the element doesn't belong to the set,
   NULL is returned */
// CV_INLINE CvSetElem* cvGetSetElem( const CvSet* set_header, int index )
// {
//     CvSetElem* elem = (CvSetElem*)cvGetSeqElem( (CvSeq*)set_header, index );
//     return elem && CV_IS_SET_ELEM( elem ) ? elem : 0;
// }
DEFINE_FUNCTION( SP(CvSetElem), cvGetSetElem, 2( SP(CvSet,set_header), V(int,index) ) ) 

/* Removes all the elements from the set */
// CVAPI(void)  cvClearSet( CvSet* set_header );
DEFINE_FUNCTION( N(void), cvClearSet, 1( SP(CvSet,set_header) ) ) 

/* Creates new graph */
// CVAPI(CvGraph*)  cvCreateGraph( int graph_flags, int header_size,
//                                 int vtx_size, int edge_size,
//                                 CvMemStorage* storage );
DEFINE_FUNCTION( SP(CvGraph), cvCreateGraph, 5( V(int,graph_flags), V(int,header_size), V(int,vtx_size), V(int,edge_size), SP(CvMemStorage,storage) ) ) 

/* Adds new vertex to the graph */
// CVAPI(int)  cvGraphAddVtx( CvGraph* graph, const CvGraphVtx* vtx CV_DEFAULT(NULL),
//                            CvGraphVtx** inserted_vtx CV_DEFAULT(NULL) );
DEFINE_FUNCTION( V(int), cvGraphAddVtx, 3( SP(CvGraph,graph), SP(CvGraphVtx,vtx), SPP(CvGraphVtx,inserted_vtx) ) ) 
DEFINE_FUNCTION( V(int), cvGraphAddVtx, 2( SP(CvGraph,graph), SP(CvGraphVtx,vtx) ) ) 
DEFINE_FUNCTION( V(int), cvGraphAddVtx, 1( SP(CvGraph,graph) ) ) 


/* Removes vertex from the graph together with all incident edges */
// CVAPI(int)  cvGraphRemoveVtx( CvGraph* graph, int index );
DEFINE_FUNCTION( V(int), cvGraphRemoveVtx, 2( SP(CvGraph,graph), V(int,index) ) ) 
// CVAPI(int)  cvGraphRemoveVtxByPtr( CvGraph* graph, CvGraphVtx* vtx );
DEFINE_FUNCTION( V(int), cvGraphRemoveVtxByPtr, 2( SP(CvGraph,graph), SP(CvGraphVtx,vtx) ) ) 


/* Link two vertices specifed by indices or pointers if they
   are not connected or return pointer to already existing edge
   connecting the vertices.
   Functions return 1 if a new edge was created, 0 otherwise */
// CVAPI(int)  cvGraphAddEdge( CvGraph* graph,
//                             int start_idx, int end_idx,
//                             const CvGraphEdge* edge CV_DEFAULT(NULL),
//                             CvGraphEdge** inserted_edge CV_DEFAULT(NULL) );
DEFINE_FUNCTION( V(int), cvGraphAddEdge, 5( SP(CvGraph,graph), V(int,start_idx), V(int,end_idx), SP(CvGraphEdge,edge), SPP(CvGraphEdge,inserted_edge) ) ) 
DEFINE_FUNCTION( V(int), cvGraphAddEdge, 4( SP(CvGraph,graph), V(int,start_idx), V(int,end_idx), SP(CvGraphEdge,edge) ) ) 
DEFINE_FUNCTION( V(int), cvGraphAddEdge, 3( SP(CvGraph,graph), V(int,start_idx), V(int,end_idx) ) ) 

// CVAPI(int)  cvGraphAddEdgeByPtr( CvGraph* graph,
//                                CvGraphVtx* start_vtx, CvGraphVtx* end_vtx,
//                                const CvGraphEdge* edge CV_DEFAULT(NULL),
//                                CvGraphEdge** inserted_edge CV_DEFAULT(NULL) );
DEFINE_FUNCTION( V(int), cvGraphAddEdgeByPtr, 5( SP(CvGraph,graph), SP(CvGraphVtx,start_vtx), SP(CvGraphVtx,end_vtx), SP(CvGraphEdge,edge), SPP(CvGraphEdge,inserted_edge) ) ) 
DEFINE_FUNCTION( V(int), cvGraphAddEdgeByPtr, 4( SP(CvGraph,graph), SP(CvGraphVtx,start_vtx), SP(CvGraphVtx,end_vtx), SP(CvGraphEdge,edge) ) ) 
DEFINE_FUNCTION( V(int), cvGraphAddEdgeByPtr, 3( SP(CvGraph,graph), SP(CvGraphVtx,start_vtx), SP(CvGraphVtx,end_vtx) ) ) 

/* Remove edge connecting two vertices */
// CVAPI(void)  cvGraphRemoveEdge( CvGraph* graph, int start_idx, int end_idx );
DEFINE_FUNCTION( N(void), cvGraphRemoveEdge, 3( SP(CvGraph,graph), V(int,start_idx), V(int,end_idx) ) ) 
// CVAPI(void)  cvGraphRemoveEdgeByPtr( CvGraph* graph, CvGraphVtx* start_vtx,
//                                      CvGraphVtx* end_vtx );
DEFINE_FUNCTION( N(void), cvGraphRemoveEdgeByPtr, 3( SP(CvGraph,graph), SP(CvGraphVtx,start_vtx), SP(CvGraphVtx,end_vtx) ) ) 

/* Find edge connecting two vertices */
// CVAPI(CvGraphEdge*)  cvFindGraphEdge( const CvGraph* graph, int start_idx, int end_idx );
DEFINE_FUNCTION( SP(CvGraphEdge), cvFindGraphEdge, 3( SP(CvGraph,graph), V(int,start_idx), V(int,end_idx) ) ) 
// CVAPI(CvGraphEdge*)  cvFindGraphEdgeByPtr( const CvGraph* graph,
//                                            const CvGraphVtx* start_vtx,
//                                            const CvGraphVtx* end_vtx );
DEFINE_FUNCTION( SP(CvGraphEdge), cvFindGraphEdgeByPtr, 3( SP(CvGraph,graph), SP(CvGraphVtx,start_vtx), SP(CvGraphVtx,end_vtx) ) ) 
// #define cvGraphFindEdge cvFindGraphEdge
#pragma push_macro( "cvGraphFindEdge" )
#undef cvGraphFindEdge
DEFINE_FUNCTION_ALIAS( SP(CvGraphEdge), cvFindGraphEdge, cvGraphFindEdge, 3( SP(CvGraph,graph), V(int,start_idx), V(int,end_idx) ) ) 
#pragma pop_macro( "cvGraphFindEdge" )
// #define cvGraphFindEdgeByPtr cvFindGraphEdgeByPtr
#pragma push_macro( "cvGraphFindEdgeByPtr" )
#undef cvGraphFindEdgeByPtr
DEFINE_FUNCTION_ALIAS( SP(CvGraphEdge), cvFindGraphEdgeByPtr, cvGraphFindEdgeByPtr, 3( SP(CvGraph,graph), SP(CvGraphVtx,start_vtx), SP(CvGraphVtx,end_vtx) ) ) 
#pragma pop_macro( "cvGraphFindEdgeByPtr" )

/* Remove all vertices and edges from the graph */
// CVAPI(void)  cvClearGraph( CvGraph* graph );
DEFINE_FUNCTION( N(void), cvClearGraph, 1( SP(CvGraph,graph) ) ) 


/* Count number of edges incident to the vertex */
// CVAPI(int)  cvGraphVtxDegree( const CvGraph* graph, int vtx_idx );
DEFINE_FUNCTION( V(int), cvGraphVtxDegree, 2( SP(CvGraph,graph), V(int,vtx_idx) ) ) 
// CVAPI(int)  cvGraphVtxDegreeByPtr( const CvGraph* graph, const CvGraphVtx* vtx );
DEFINE_FUNCTION( V(int), cvGraphVtxDegreeByPtr, 2( SP(CvGraph,graph), SP(CvGraphVtx,vtx) ) ) 


/* Retrieves graph vertex by given index */
// #define cvGetGraphVtx( graph, idx ) (CvGraphVtx*)cvGetSetElem((CvSet*)(graph), (idx))
// Unsupport : cvGetGraphVtx

/* Retrieves index of a graph vertex given its pointer */
// #define cvGraphVtxIdx( graph, vtx ) ((vtx)->flags & CV_SET_ELEM_IDX_MASK)
// Unsupport : cvGraphVtxIdx

/* Retrieves index of a graph edge given its pointer */
// #define cvGraphEdgeIdx( graph, edge ) ((edge)->flags & CV_SET_ELEM_IDX_MASK)
// Unsupport : cvGraphEdgeIdx

// #define cvGraphGetVtxCount( graph ) ((graph)->active_count)
// Unsupport : cvGraphGetVtxCount
// #define cvGraphGetEdgeCount( graph ) ((graph)->edges->active_count)
// Unsupport : cvGraphGetEdgeCount

// #define  CV_GRAPH_VERTEX        1
#pragma push_macro( "CV_GRAPH_VERTEX" )
#undef CV_GRAPH_VERTEX
static const int CV_GRAPH_VERTEX
#pragma pop_macro( "CV_GRAPH_VERTEX" )
	= CV_GRAPH_VERTEX;
// #define  CV_GRAPH_TREE_EDGE     2
#pragma push_macro( "CV_GRAPH_TREE_EDGE" )
#undef CV_GRAPH_TREE_EDGE
static const int CV_GRAPH_TREE_EDGE
#pragma pop_macro( "CV_GRAPH_TREE_EDGE" )
	= CV_GRAPH_TREE_EDGE;
// #define  CV_GRAPH_BACK_EDGE     4
#pragma push_macro( "CV_GRAPH_BACK_EDGE" )
#undef CV_GRAPH_BACK_EDGE
static const int CV_GRAPH_BACK_EDGE
#pragma pop_macro( "CV_GRAPH_BACK_EDGE" )
	= CV_GRAPH_BACK_EDGE;
// #define  CV_GRAPH_FORWARD_EDGE  8
#pragma push_macro( "CV_GRAPH_FORWARD_EDGE" )
#undef CV_GRAPH_FORWARD_EDGE
static const int CV_GRAPH_FORWARD_EDGE
#pragma pop_macro( "CV_GRAPH_FORWARD_EDGE" )
	= CV_GRAPH_FORWARD_EDGE;
// #define  CV_GRAPH_CROSS_EDGE    16
#pragma push_macro( "CV_GRAPH_CROSS_EDGE" )
#undef CV_GRAPH_CROSS_EDGE
static const int CV_GRAPH_CROSS_EDGE
#pragma pop_macro( "CV_GRAPH_CROSS_EDGE" )
	= CV_GRAPH_CROSS_EDGE;
// #define  CV_GRAPH_ANY_EDGE      30
#pragma push_macro( "CV_GRAPH_ANY_EDGE" )
#undef CV_GRAPH_ANY_EDGE
static const int CV_GRAPH_ANY_EDGE
#pragma pop_macro( "CV_GRAPH_ANY_EDGE" )
	= CV_GRAPH_ANY_EDGE;
// #define  CV_GRAPH_NEW_TREE      32
#pragma push_macro( "CV_GRAPH_NEW_TREE" )
#undef CV_GRAPH_NEW_TREE
static const int CV_GRAPH_NEW_TREE
#pragma pop_macro( "CV_GRAPH_NEW_TREE" )
	= CV_GRAPH_NEW_TREE;
// #define  CV_GRAPH_BACKTRACKING  64
#pragma push_macro( "CV_GRAPH_BACKTRACKING" )
#undef CV_GRAPH_BACKTRACKING
static const int CV_GRAPH_BACKTRACKING
#pragma pop_macro( "CV_GRAPH_BACKTRACKING" )
	= CV_GRAPH_BACKTRACKING;
// #define  CV_GRAPH_OVER          -1
#pragma push_macro( "CV_GRAPH_OVER" )
#undef CV_GRAPH_OVER
static const int CV_GRAPH_OVER
#pragma pop_macro( "CV_GRAPH_OVER" )
	= CV_GRAPH_OVER;

// #define  CV_GRAPH_ALL_ITEMS    -1
#pragma push_macro( "CV_GRAPH_ALL_ITEMS" )
#undef CV_GRAPH_ALL_ITEMS
static const int CV_GRAPH_ALL_ITEMS
#pragma pop_macro( "CV_GRAPH_ALL_ITEMS" )
	= CV_GRAPH_ALL_ITEMS;

/* flags for graph vertices and edges */
// #define  CV_GRAPH_ITEM_VISITED_FLAG  (1 << 30)
#pragma push_macro( "CV_GRAPH_ITEM_VISITED_FLAG" )
#undef CV_GRAPH_ITEM_VISITED_FLAG
static const int CV_GRAPH_ITEM_VISITED_FLAG
#pragma pop_macro( "CV_GRAPH_ITEM_VISITED_FLAG" )
	= CV_GRAPH_ITEM_VISITED_FLAG;
// #define  CV_IS_GRAPH_VERTEX_VISITED(vtx) \
//     (((CvGraphVtx*)(vtx))->flags & CV_GRAPH_ITEM_VISITED_FLAG)
// Unsupport : CV_IS_GRAPH_VERTEX_VISITED
// #define  CV_IS_GRAPH_EDGE_VISITED(edge) \
//     (((CvGraphEdge*)(edge))->flags & CV_GRAPH_ITEM_VISITED_FLAG)
// Unsupport : CV_IS_GRAPH_EDGE_VISITED
// #define  CV_GRAPH_SEARCH_TREE_NODE_FLAG   (1 << 29)
#pragma push_macro( "CV_GRAPH_SEARCH_TREE_NODE_FLAG" )
#undef CV_GRAPH_SEARCH_TREE_NODE_FLAG
static const int CV_GRAPH_SEARCH_TREE_NODE_FLAG
#pragma pop_macro( "CV_GRAPH_SEARCH_TREE_NODE_FLAG" )
	= CV_GRAPH_SEARCH_TREE_NODE_FLAG;
// #define  CV_GRAPH_FORWARD_EDGE_FLAG       (1 << 28)
#pragma push_macro( "CV_GRAPH_FORWARD_EDGE_FLAG" )
#undef CV_GRAPH_FORWARD_EDGE_FLAG
static const int CV_GRAPH_FORWARD_EDGE_FLAG
#pragma pop_macro( "CV_GRAPH_FORWARD_EDGE_FLAG" )
	= CV_GRAPH_FORWARD_EDGE_FLAG;

// typedef struct CvGraphScanner
// {
//     CvGraphVtx* vtx;       /* current graph vertex (or current edge origin) */
//     CvGraphVtx* dst;       /* current graph edge destination vertex */
//     CvGraphEdge* edge;     /* current edge */
// 
//     CvGraph* graph;        /* the graph */
//     CvSeq*   stack;        /* the graph vertex stack */
//     int      index;        /* the lower bound of certainly visited vertices */
//     int      mask;         /* event mask */
// }
// CvGraphScanner;
DEFINE_STRUCT( CvGraphScanner )
{STRUCT_BASIC( CvGraphScanner )
	DEFINE_PROPERTY_SP( CvGraphVtx, vtx )
	DEFINE_PROPERTY_SP( CvGraphVtx, dst )
	DEFINE_PROPERTY_SP( CvGraphEdge, edge )
	DEFINE_PROPERTY_SP( CvGraph, graph )
	DEFINE_PROPERTY_SP( CvSeq, stack )
	DEFINE_PROPERTY_V( int, index )
	DEFINE_PROPERTY_V( int, mask )
};

/* Creates new graph scanner. */
// CVAPI(CvGraphScanner*)  cvCreateGraphScanner( CvGraph* graph,
//                                              CvGraphVtx* vtx CV_DEFAULT(NULL),
//                                              int mask CV_DEFAULT(CV_GRAPH_ALL_ITEMS));
DEFINE_FUNCTION( SP(CvGraphScanner), cvCreateGraphScanner, 3( SP(CvGraph,graph), SP(CvGraphVtx,vtx), V(int,mask) ) ) 
DEFINE_FUNCTION( SP(CvGraphScanner), cvCreateGraphScanner, 2( SP(CvGraph,graph), SP(CvGraphVtx,vtx) ) ) 
DEFINE_FUNCTION( SP(CvGraphScanner), cvCreateGraphScanner, 1( SP(CvGraph,graph) ) ) 

/* Releases graph scanner. */
// CVAPI(void) cvReleaseGraphScanner( CvGraphScanner** scanner );
DEFINE_FUNCTION( N(void), cvReleaseGraphScanner, 1( SPP(CvGraphScanner,scanner) ) ) 

/* Get next graph element */
// CVAPI(int)  cvNextGraphItem( CvGraphScanner* scanner );
DEFINE_FUNCTION( V(int), cvNextGraphItem, 1( SP(CvGraphScanner,scanner) ) ) 

/* Creates a copy of graph */
// CVAPI(CvGraph*) cvCloneGraph( const CvGraph* graph, CvMemStorage* storage );
DEFINE_FUNCTION( SP(CvGraph), cvCloneGraph, 2( SP(CvGraph,graph), SP(CvMemStorage,storage) ) ) 

/****************************************************************************************\
*                                     Drawing                                            *
\****************************************************************************************/

/****************************************************************************************\
*       Drawing functions work with images/matrices of arbitrary type.                   *
*       For color images the channel order is BGR[A]                                     *
*       Antialiasing is supported only for 8-bit image now.                              *
*       All the functions include parameter color that means rgb value (that may be      *
*       constructed with CV_RGB macro) for color images and brightness                   *
*       for grayscale images.                                                            *
*       If a drawn figure is partially or completely outside of the image, it is clipped.*
\****************************************************************************************/

// #define CV_RGB( r, g, b )  cvScalar( (b), (g), (r), 0 )
#pragma push_macro( "CV_RGB" )
#undef CV_RGB
static CvScalar^ CV_RGB( double r, double g, double b )
#pragma pop_macro( "CV_RGB" )
{
	return cvScalar_( b, g, r, 0 );
}
// #define CV_FILLED -1
#pragma push_macro( "CV_FILLED" )
#undef CV_FILLED
static const int CV_FILLED
#pragma pop_macro( "CV_FILLED" )
	= CV_FILLED;

// #define CV_AA 16
#pragma push_macro( "CV_AA" )
#undef CV_AA
static const int CV_AA
#pragma pop_macro( "CV_AA" )
	= CV_AA;

/* Draws 4-connected, 8-connected or antialiased line segment connecting two points */
// CVAPI(void)  cvLine( CvArr* img, CvPoint pt1, CvPoint pt2,
//                      CvScalar color, int thickness CV_DEFAULT(1),
//                      int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvLine, 7( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvLine, 6( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvLine, 5( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION( N(void), cvLine, 4( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color) ) ) 

/* Draws a rectangle given two opposite corners of the rectangle (pt1 & pt2),
   if thickness<0 (e.g. thickness == CV_FILLED), the filled box is drawn */
// CVAPI(void)  cvRectangle( CvArr* img, CvPoint pt1, CvPoint pt2,
//                           CvScalar color, int thickness CV_DEFAULT(1),
//                           int line_type CV_DEFAULT(8),
//                           int shift CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvRectangle, 7( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvRectangle, 6( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvRectangle, 5( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION( N(void), cvRectangle, 4( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color) ) ) 

/* Draws a rectangle specified by a CvRect structure */
// CVAPI(void)  cvRectangleR( CvArr* img, CvRect r,
//                            CvScalar color, int thickness CV_DEFAULT(1),
//                            int line_type CV_DEFAULT(8),
//                            int shift CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvRectangleR, 6( MP(UMemory,CvArr,img), S(CvRect,r), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvRectangleR, 5( MP(UMemory,CvArr,img), S(CvRect,r), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvRectangleR, 4( MP(UMemory,CvArr,img), S(CvRect,r), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION( N(void), cvRectangleR, 3( MP(UMemory,CvArr,img), S(CvRect,r), S(CvScalar,color) ) ) 
    
    
/* Draws a circle with specified center and radius.
   Thickness works in the same way as with cvRectangle */
// CVAPI(void)  cvCircle( CvArr* img, CvPoint center, int radius,
//                        CvScalar color, int thickness CV_DEFAULT(1),
//                        int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvCircle, 7( MP(UMemory,CvArr,img), S(CvPoint,center), V(int,radius), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvCircle, 6( MP(UMemory,CvArr,img), S(CvPoint,center), V(int,radius), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvCircle, 5( MP(UMemory,CvArr,img), S(CvPoint,center), V(int,radius), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION( N(void), cvCircle, 4( MP(UMemory,CvArr,img), S(CvPoint,center), V(int,radius), S(CvScalar,color) ) ) 

/* Draws ellipse outline, filled ellipse, elliptic arc or filled elliptic sector,
   depending on <thickness>, <start_angle> and <end_angle> parameters. The resultant figure
   is rotated by <angle>. All the angles are in degrees */
// CVAPI(void)  cvEllipse( CvArr* img, CvPoint center, CvSize axes,
//                         double angle, double start_angle, double end_angle,
//                         CvScalar color, int thickness CV_DEFAULT(1),
//                         int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvEllipse, 10( MP(UMemory,CvArr,img), S(CvPoint,center), S(CvSize,axes), V(double,angle), V(double,start_angle), V(double,end_angle), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvEllipse, 9( MP(UMemory,CvArr,img), S(CvPoint,center), S(CvSize,axes), V(double,angle), V(double,start_angle), V(double,end_angle), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvEllipse, 8( MP(UMemory,CvArr,img), S(CvPoint,center), S(CvSize,axes), V(double,angle), V(double,start_angle), V(double,end_angle), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION( N(void), cvEllipse, 7( MP(UMemory,CvArr,img), S(CvPoint,center), S(CvSize,axes), V(double,angle), V(double,start_angle), V(double,end_angle), S(CvScalar,color) ) ) 

// CV_INLINE  void  cvEllipseBox( CvArr* img, CvBox2D box, CvScalar color,
//                                int thickness CV_DEFAULT(1),
//                                int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0) )
// {
//     CvSize axes;
//     axes.width = cvRound(box.size.width*0.5);
//     axes.height = cvRound(box.size.height*0.5);
// 
//     cvEllipse( img, cvPointFrom32f( box.center ), axes, box.angle,
//                0, 360, color, thickness, line_type, shift );
// }
DEFINE_FUNCTION( N(void), cvEllipseBox, 6( MP(UMemory,CvArr,img), S(CvBox2D,box), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvEllipseBox, 5( MP(UMemory,CvArr,img), S(CvBox2D,box), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvEllipseBox, 4( MP(UMemory,CvArr,img), S(CvBox2D,box), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION( N(void), cvEllipseBox, 3( MP(UMemory,CvArr,img), S(CvBox2D,box), S(CvScalar,color) ) ) 

/* Fills convex or monotonous polygon. */
// CVAPI(void)  cvFillConvexPoly( CvArr* img, const CvPoint* pts, int npts, CvScalar color,
//                                int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0));
DEFINE_FUNCTION( N(void), cvFillConvexPoly, 6( MP(UMemory,CvArr,img), SP(CvPoint,pts), V(int,npts), S(CvScalar,color), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvFillConvexPoly, 5( MP(UMemory,CvArr,img), SP(CvPoint,pts), V(int,npts), S(CvScalar,color), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvFillConvexPoly, 4( MP(UMemory,CvArr,img), SP(CvPoint,pts), V(int,npts), S(CvScalar,color) ) ) 

/* Fills an area bounded by one or more arbitrary polygons */
// CVAPI(void)  cvFillPoly( CvArr* img, CvPoint** pts, const int* npts,
//                          int contours, CvScalar color,
//                          int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvFillPoly, 7( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), S(CvScalar,color), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvFillPoly, 7( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), S(CvScalar,color), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvFillPoly, 6( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), S(CvScalar,color), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvFillPoly, 6( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), S(CvScalar,color), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvFillPoly, 5( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), S(CvScalar,color) ) ) 
DEFINE_FUNCTION( N(void), cvFillPoly, 5( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), S(CvScalar,color) ) ) 

/* Draws one or more polygonal curves */
// CVAPI(void)  cvPolyLine( CvArr* img, CvPoint** pts, const int* npts, int contours,
//                          int is_closed, CvScalar color, int thickness CV_DEFAULT(1),
//                          int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvPolyLine, 9( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvPolyLine, 9( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION( N(void), cvPolyLine, 8( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvPolyLine, 8( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvPolyLine, 7( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION( N(void), cvPolyLine, 7( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION( N(void), cvPolyLine, 6( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), V(int,is_closed), S(CvScalar,color) ) ) 
DEFINE_FUNCTION( N(void), cvPolyLine, 6( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), V(int,is_closed), S(CvScalar,color) ) ) 

// #define cvDrawRect cvRectangle
#pragma push_macro( "cvDrawRect" )
#undef cvDrawRect
DEFINE_FUNCTION_ALIAS( N(void), cvRectangle, cvDrawRect, 7( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvRectangle, cvDrawRect, 6( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvRectangle, cvDrawRect, 5( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvRectangle, cvDrawRect, 4( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color) ) ) 
#pragma pop_macro( "cvDrawRect" )
// #define cvDrawLine cvLine
#pragma push_macro( "cvDrawLine" )
#undef cvDrawLine
DEFINE_FUNCTION_ALIAS( N(void), cvLine, cvDrawLine, 7( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvLine, cvDrawLine, 6( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvLine, cvDrawLine, 5( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvLine, cvDrawLine, 4( MP(UMemory,CvArr,img), S(CvPoint,pt1), S(CvPoint,pt2), S(CvScalar,color) ) ) 
#pragma pop_macro( "cvDrawLine" )
// #define cvDrawCircle cvCircle
#pragma push_macro( "cvDrawCircle" )
#undef cvDrawCircle
DEFINE_FUNCTION_ALIAS( N(void), cvCircle, cvDrawCircle, 7( MP(UMemory,CvArr,img), S(CvPoint,center), V(int,radius), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvCircle, cvDrawCircle, 6( MP(UMemory,CvArr,img), S(CvPoint,center), V(int,radius), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvCircle, cvDrawCircle, 5( MP(UMemory,CvArr,img), S(CvPoint,center), V(int,radius), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvCircle, cvDrawCircle, 4( MP(UMemory,CvArr,img), S(CvPoint,center), V(int,radius), S(CvScalar,color) ) ) 
#pragma pop_macro( "cvDrawCircle" )
// #define cvDrawEllipse cvEllipse
#pragma push_macro( "cvDrawEllipse" )
#undef cvDrawEllipse
DEFINE_FUNCTION_ALIAS( N(void), cvEllipse, cvDrawEllipse, 10( MP(UMemory,CvArr,img), S(CvPoint,center), S(CvSize,axes), V(double,angle), V(double,start_angle), V(double,end_angle), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvEllipse, cvDrawEllipse, 9( MP(UMemory,CvArr,img), S(CvPoint,center), S(CvSize,axes), V(double,angle), V(double,start_angle), V(double,end_angle), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvEllipse, cvDrawEllipse, 8( MP(UMemory,CvArr,img), S(CvPoint,center), S(CvSize,axes), V(double,angle), V(double,start_angle), V(double,end_angle), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvEllipse, cvDrawEllipse, 7( MP(UMemory,CvArr,img), S(CvPoint,center), S(CvSize,axes), V(double,angle), V(double,start_angle), V(double,end_angle), S(CvScalar,color) ) ) 
#pragma pop_macro( "cvDrawEllipse" )
// #define cvDrawPolyLine cvPolyLine
#pragma push_macro( "cvDrawPolyLine" )
#undef cvDrawPolyLine
DEFINE_FUNCTION_ALIAS( N(void), cvPolyLine, cvDrawPolyLine, 9( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvPolyLine, cvDrawPolyLine, 9( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness), V(int,line_type), V(int,shift) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvPolyLine, cvDrawPolyLine, 8( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvPolyLine, cvDrawPolyLine, 8( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvPolyLine, cvDrawPolyLine, 7( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvPolyLine, cvDrawPolyLine, 7( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), V(int,is_closed), S(CvScalar,color), V(int,thickness) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvPolyLine, cvDrawPolyLine, 6( MP(UMemory,CvArr,img), SPP(CvPoint,pts), VP(int,npts), V(int,contours), V(int,is_closed), S(CvScalar,color) ) ) 
DEFINE_FUNCTION_ALIAS( N(void), cvPolyLine, cvDrawPolyLine, 6( MP(UMemory,CvArr,img), SPP(CvPoint,pts), P(const int*,npts), V(int,contours), V(int,is_closed), S(CvScalar,color) ) ) 
#pragma pop_macro( "cvDrawPolyLine" )

/* Clips the line segment connecting *pt1 and *pt2
   by the rectangular window
   (0<=x<img_size.width, 0<=y<img_size.height). */
// CVAPI(int) cvClipLine( CvSize img_size, CvPoint* pt1, CvPoint* pt2 );
DEFINE_FUNCTION( V(int), cvClipLine, 3( S(CvSize,img_size), SP(CvPoint,pt1), SP(CvPoint,pt2) ) ) 

/* Initializes line iterator. Initially, line_iterator->ptr will point
   to pt1 (or pt2, see left_to_right description) location in the image.
   Returns the number of pixels on the line between the ending points. */
// CVAPI(int)  cvInitLineIterator( const CvArr* image, CvPoint pt1, CvPoint pt2,
//                                 CvLineIterator* line_iterator,
//                                 int connectivity CV_DEFAULT(8),
//                                 int left_to_right CV_DEFAULT(0));
DEFINE_FUNCTION( V(int), cvInitLineIterator, 6( MP(UMemory,CvArr,image), S(CvPoint,pt1), S(CvPoint,pt2), SP(CvLineIterator,line_iterator), V(int,connectivity), V(int,left_to_right) ) ) 
DEFINE_FUNCTION( V(int), cvInitLineIterator, 5( MP(UMemory,CvArr,image), S(CvPoint,pt1), S(CvPoint,pt2), SP(CvLineIterator,line_iterator), V(int,connectivity) ) ) 
DEFINE_FUNCTION( V(int), cvInitLineIterator, 4( MP(UMemory,CvArr,image), S(CvPoint,pt1), S(CvPoint,pt2), SP(CvLineIterator,line_iterator) ) ) 

/* Moves iterator to the next line point */
// #define CV_NEXT_LINE_POINT( line_iterator )                     \
// {                                                               \
//     int _line_iterator_mask = (line_iterator).err < 0 ? -1 : 0; \
//     (line_iterator).err += (line_iterator).minus_delta +        \
//         ((line_iterator).plus_delta & _line_iterator_mask);     \
//     (line_iterator).ptr += (line_iterator).minus_step +         \
//         ((line_iterator).plus_step & _line_iterator_mask);      \
// }
// Unsupport : CV_NEXT_LINE_POINT


/* basic font types */
// #define CV_FONT_HERSHEY_SIMPLEX         0
#pragma push_macro( "CV_FONT_HERSHEY_SIMPLEX" )
#undef CV_FONT_HERSHEY_SIMPLEX
static const int CV_FONT_HERSHEY_SIMPLEX
#pragma pop_macro( "CV_FONT_HERSHEY_SIMPLEX" )
	= CV_FONT_HERSHEY_SIMPLEX;
// #define CV_FONT_HERSHEY_PLAIN           1
#pragma push_macro( "CV_FONT_HERSHEY_PLAIN" )
#undef CV_FONT_HERSHEY_PLAIN
static const int CV_FONT_HERSHEY_PLAIN
#pragma pop_macro( "CV_FONT_HERSHEY_PLAIN" )
	= CV_FONT_HERSHEY_PLAIN;
// #define CV_FONT_HERSHEY_DUPLEX          2
#pragma push_macro( "CV_FONT_HERSHEY_DUPLEX" )
#undef CV_FONT_HERSHEY_DUPLEX
static const int CV_FONT_HERSHEY_DUPLEX
#pragma pop_macro( "CV_FONT_HERSHEY_DUPLEX" )
	= CV_FONT_HERSHEY_DUPLEX;
// #define CV_FONT_HERSHEY_COMPLEX         3
#pragma push_macro( "CV_FONT_HERSHEY_COMPLEX" )
#undef CV_FONT_HERSHEY_COMPLEX
static const int CV_FONT_HERSHEY_COMPLEX
#pragma pop_macro( "CV_FONT_HERSHEY_COMPLEX" )
	= CV_FONT_HERSHEY_COMPLEX;
// #define CV_FONT_HERSHEY_TRIPLEX         4
#pragma push_macro( "CV_FONT_HERSHEY_TRIPLEX" )
#undef CV_FONT_HERSHEY_TRIPLEX
static const int CV_FONT_HERSHEY_TRIPLEX
#pragma pop_macro( "CV_FONT_HERSHEY_TRIPLEX" )
	= CV_FONT_HERSHEY_TRIPLEX;
// #define CV_FONT_HERSHEY_COMPLEX_SMALL   5
#pragma push_macro( "CV_FONT_HERSHEY_COMPLEX_SMALL" )
#undef CV_FONT_HERSHEY_COMPLEX_SMALL
static const int CV_FONT_HERSHEY_COMPLEX_SMALL
#pragma pop_macro( "CV_FONT_HERSHEY_COMPLEX_SMALL" )
	= CV_FONT_HERSHEY_COMPLEX_SMALL;
// #define CV_FONT_HERSHEY_SCRIPT_SIMPLEX  6
#pragma push_macro( "CV_FONT_HERSHEY_SCRIPT_SIMPLEX" )
#undef CV_FONT_HERSHEY_SCRIPT_SIMPLEX
static const int CV_FONT_HERSHEY_SCRIPT_SIMPLEX
#pragma pop_macro( "CV_FONT_HERSHEY_SCRIPT_SIMPLEX" )
	= CV_FONT_HERSHEY_SCRIPT_SIMPLEX;
// #define CV_FONT_HERSHEY_SCRIPT_COMPLEX  7
#pragma push_macro( "CV_FONT_HERSHEY_SCRIPT_COMPLEX" )
#undef CV_FONT_HERSHEY_SCRIPT_COMPLEX
static const int CV_FONT_HERSHEY_SCRIPT_COMPLEX
#pragma pop_macro( "CV_FONT_HERSHEY_SCRIPT_COMPLEX" )
	= CV_FONT_HERSHEY_SCRIPT_COMPLEX;

/* font flags */
// #define CV_FONT_ITALIC                 16
#pragma push_macro( "CV_FONT_ITALIC" )
#undef CV_FONT_ITALIC
static const int CV_FONT_ITALIC
#pragma pop_macro( "CV_FONT_ITALIC" )
	= CV_FONT_ITALIC;

// #define CV_FONT_VECTOR0    CV_FONT_HERSHEY_SIMPLEX
#pragma push_macro( "CV_FONT_VECTOR0" )
#undef CV_FONT_VECTOR0
static const int CV_FONT_VECTOR0
#pragma pop_macro( "CV_FONT_VECTOR0" )
	= CV_FONT_VECTOR0;

/* Font structure */
// typedef struct CvFont
// {
//     int         font_face; /* =CV_FONT_* */
//     const int*  ascii; /* font data and metrics */
//     const int*  greek;
//     const int*  cyrillic;
//     float       hscale, vscale;
//     float       shear; /* slope coefficient: 0 - normal, >0 - italic */
//     int         thickness; /* letters thickness */
//     float       dx; /* horizontal interval between letters */
//     int         line_type;
// }
// CvFont;
DEFINE_STRUCT( CvFont )
{STRUCT_BASIC( CvFont )
	DEFINE_PROPERTY_V( int, font_face )
	DEFINE_PROPERTY_PC( int*, ascii )
	DEFINE_PROPERTY_PC( int*, greek )
	DEFINE_PROPERTY_PC( int*, cyrillic )
	DEFINE_PROPERTY_V( float, hscale )
	DEFINE_PROPERTY_V( float, vscale )
	DEFINE_PROPERTY_V( float, shear )
	DEFINE_PROPERTY_V( int, thickness )
	DEFINE_PROPERTY_V( float, dx )
	DEFINE_PROPERTY_V( int, line_type )
DEFINE_SETUP_CONSTRUCTOR( CvFont, cvFont, 2( V(double,scale), V(int,thickness) ) )
DEFINE_SETUP_CONSTRUCTOR( CvFont, cvFont, 1( V(double,scale) ) )
};

/* Initializes font structure used further in cvPutText */
// CVAPI(void)  cvInitFont( CvFont* font, int font_face,
//                          double hscale, double vscale,
//                          double shear CV_DEFAULT(0),
//                          int thickness CV_DEFAULT(1),
//                          int line_type CV_DEFAULT(8));
DEFINE_FUNCTION( N(void), cvInitFont, 7( SP(CvFont,font), V(int,font_face), V(double,hscale), V(double,vscale), V(double,shear), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvInitFont, 6( SP(CvFont,font), V(int,font_face), V(double,hscale), V(double,vscale), V(double,shear), V(int,thickness) ) ) 
DEFINE_FUNCTION( N(void), cvInitFont, 5( SP(CvFont,font), V(int,font_face), V(double,hscale), V(double,vscale), V(double,shear) ) ) 
DEFINE_FUNCTION( N(void), cvInitFont, 4( SP(CvFont,font), V(int,font_face), V(double,hscale), V(double,vscale) ) ) 

// CV_INLINE CvFont cvFont( double scale, int thickness CV_DEFAULT(1) )
// {
//     CvFont font;
//     cvInitFont( &font, CV_FONT_HERSHEY_PLAIN, scale, scale, 0, thickness, CV_AA );
//     return font;
// }
DEFINE_FUNCTION_ALIAS( S(CvFont), cvFont, cvFont_, 2( V(double,scale), V(int,thickness) ) ) 
DEFINE_FUNCTION_ALIAS( S(CvFont), cvFont, cvFont_, 1( V(double,scale) ) ) 

/* Renders text stroke with specified font and color at specified location.
   CvFont should be initialized with cvInitFont */
// CVAPI(void)  cvPutText( CvArr* img, const char* text, CvPoint org,
//                         const CvFont* font, CvScalar color );
DEFINE_FUNCTION( N(void), cvPutText, 5( MP(UMemory,CvArr,img), T(const,text), S(CvPoint,org), SP(CvFont,font), S(CvScalar,color) ) ) 

/* Calculates bounding box of text stroke (useful for alignment) */
// CVAPI(void)  cvGetTextSize( const char* text_string, const CvFont* font,
//                             CvSize* text_size, int* baseline );
DEFINE_FUNCTION( N(void), cvGetTextSize, 4( T(const,text_string), SP(CvFont,font), SP(CvSize,text_size), VP(int,baseline) ) ) 
DEFINE_FUNCTION( N(void), cvGetTextSize, 4( T(const,text_string), SP(CvFont,font), SP(CvSize,text_size), P(int*,baseline) ) ) 

/* Unpacks color value, if arrtype is CV_8UC?, <color> is treated as
   packed color value, otherwise the first channels (depending on arrtype)
   of destination scalar are set to the same value = <color> */
// CVAPI(CvScalar)  cvColorToScalar( double packed_color, int arrtype );
DEFINE_FUNCTION( S(CvScalar), cvColorToScalar, 2( V(double,packed_color), V(int,arrtype) ) ) 

/* Returns the polygon points which make up the given ellipse.  The ellipse is define by
   the box of size 'axes' rotated 'angle' around the 'center'.  A partial sweep
   of the ellipse arc can be done by spcifying arc_start and arc_end to be something
   other than 0 and 360, respectively.  The input array 'pts' must be large enough to
   hold the result.  The total number of points stored into 'pts' is returned by this
   function. */
// CVAPI(int) cvEllipse2Poly( CvPoint center, CvSize axes,
//                  int angle, int arc_start, int arc_end, CvPoint * pts, int delta );
DEFINE_FUNCTION( V(int), cvEllipse2Poly, 7( S(CvPoint,center), S(CvSize,axes), V(int,angle), V(int,arc_start), V(int,arc_end), SP(CvPoint,pts), V(int,delta) ) ) 

/* Draws contour outlines or filled interiors on the image */
// CVAPI(void)  cvDrawContours( CvArr *img, CvSeq* contour,
//                              CvScalar external_color, CvScalar hole_color,
//                              int max_level, int thickness CV_DEFAULT(1),
//                              int line_type CV_DEFAULT(8),
//                              CvPoint offset CV_DEFAULT(cvPoint(0,0)));
DEFINE_FUNCTION( N(void), cvDrawContours, 8( MP(UMemory,CvArr,img), SP(CvSeq,contour), S(CvScalar,external_color), S(CvScalar,hole_color), V(int,max_level), V(int,thickness), V(int,line_type), S(CvPoint,offset) ) ) 
DEFINE_FUNCTION( N(void), cvDrawContours, 7( MP(UMemory,CvArr,img), SP(CvSeq,contour), S(CvScalar,external_color), S(CvScalar,hole_color), V(int,max_level), V(int,thickness), V(int,line_type) ) ) 
DEFINE_FUNCTION( N(void), cvDrawContours, 6( MP(UMemory,CvArr,img), SP(CvSeq,contour), S(CvScalar,external_color), S(CvScalar,hole_color), V(int,max_level), V(int,thickness) ) ) 
DEFINE_FUNCTION( N(void), cvDrawContours, 5( MP(UMemory,CvArr,img), SP(CvSeq,contour), S(CvScalar,external_color), S(CvScalar,hole_color), V(int,max_level) ) ) 

/* Does look-up transformation. Elements of the source array
   (that should be 8uC1 or 8sC1) are used as indexes in lutarr 256-element table */
// CVAPI(void) cvLUT( const CvArr* src, CvArr* dst, const CvArr* lut );
DEFINE_FUNCTION( N(void), cvLUT, 3( MP(UMemory,CvArr,src), MP(UMemory,CvArr,dst), MP(UMemory,CvArr,lut) ) ) 


/******************* Iteration through the sequence tree *****************/
// typedef struct CvTreeNodeIterator
// {
//     const void* node;
//     int level;
//     int max_level;
// }
// CvTreeNodeIterator;
DEFINE_STRUCT( CvTreeNodeIterator )
{STRUCT_BASIC( CvTreeNodeIterator )
	DEFINE_PROPERTY_PC( void*, node )
	DEFINE_PROPERTY_V( int, level )
	DEFINE_PROPERTY_V( int, max_level )
};

// CVAPI(void) cvInitTreeNodeIterator( CvTreeNodeIterator* tree_iterator,
//                                    const void* first, int max_level );
DEFINE_FUNCTION( N(void), cvInitTreeNodeIterator, 3( SP(CvTreeNodeIterator,tree_iterator), P(const void*,first), V(int,max_level) ) ) 
// CVAPI(void*) cvNextTreeNode( CvTreeNodeIterator* tree_iterator );
DEFINE_FUNCTION( P(void*), cvNextTreeNode, 1( SP(CvTreeNodeIterator,tree_iterator) ) ) 
// CVAPI(void*) cvPrevTreeNode( CvTreeNodeIterator* tree_iterator );
DEFINE_FUNCTION( P(void*), cvPrevTreeNode, 1( SP(CvTreeNodeIterator,tree_iterator) ) ) 

/* Inserts sequence into tree with specified "parent" sequence.
   If parent is equal to frame (e.g. the most external contour),
   then added contour will have null pointer to parent. */
// CVAPI(void) cvInsertNodeIntoTree( void* node, void* parent, void* frame );
DEFINE_FUNCTION( N(void), cvInsertNodeIntoTree, 3( P(void*,node), P(void*,parent), P(void*,frame) ) ) 

/* Removes contour from tree (together with the contour children). */
// CVAPI(void) cvRemoveNodeFromTree( void* node, void* frame );
DEFINE_FUNCTION( N(void), cvRemoveNodeFromTree, 2( P(void*,node), P(void*,frame) ) ) 

/* Gathers pointers to all the sequences,
   accessible from the <first>, to the single sequence */
// CVAPI(CvSeq*) cvTreeToNodeSeq( const void* first, int header_size,
//                               CvMemStorage* storage );
DEFINE_FUNCTION( SP(CvSeq), cvTreeToNodeSeq, 3( P(const void*,first), V(int,header_size), SP(CvMemStorage,storage) ) ) 

/* The function implements the K-means algorithm for clustering an array of sample
   vectors in a specified number of classes */
// #define CV_KMEANS_USE_INITIAL_LABELS    1
#pragma push_macro( "CV_KMEANS_USE_INITIAL_LABELS" )
#undef CV_KMEANS_USE_INITIAL_LABELS
static const int CV_KMEANS_USE_INITIAL_LABELS
#pragma pop_macro( "CV_KMEANS_USE_INITIAL_LABELS" )
	= CV_KMEANS_USE_INITIAL_LABELS;
// CVAPI(int) cvKMeans2( const CvArr* samples, int cluster_count, CvArr* labels,
//                       CvTermCriteria termcrit, int attempts CV_DEFAULT(1),
//                       CvRNG* rng CV_DEFAULT(0), int flags CV_DEFAULT(0),
//                       CvArr* _centers CV_DEFAULT(0), double* compactness CV_DEFAULT(0) );
DEFINE_FUNCTION( V(int), cvKMeans2, 9( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts), VP(unsigned long long,rng), V(int,flags), MP(UMemory,CvArr,_centers), VP(double,compactness) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 9( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts), P(unsigned long long*,rng), V(int,flags), MP(UMemory,CvArr,_centers), VP(double,compactness) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 9( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts), VP(unsigned long long,rng), V(int,flags), MP(UMemory,CvArr,_centers), P(double*,compactness) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 9( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts), P(unsigned long long*,rng), V(int,flags), MP(UMemory,CvArr,_centers), P(double*,compactness) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 8( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts), VP(unsigned long long,rng), V(int,flags), MP(UMemory,CvArr,_centers) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 8( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts), P(unsigned long long*,rng), V(int,flags), MP(UMemory,CvArr,_centers) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 7( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts), VP(unsigned long long,rng), V(int,flags) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 7( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts), P(unsigned long long*,rng), V(int,flags) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 6( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts), VP(unsigned long long,rng) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 6( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts), P(unsigned long long*,rng) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 5( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit), V(int,attempts) ) ) 
DEFINE_FUNCTION( V(int), cvKMeans2, 4( MP(UMemory,CvArr,samples), V(int,cluster_count), MP(UMemory,CvArr,labels), S(CvTermCriteria,termcrit) ) ) 

/****************************************************************************************\
*                                    System functions                                    *
\****************************************************************************************/

/* Add the function pointers table with associated information to the IPP primitives list */
// CVAPI(int)  cvRegisterModule( const CvModuleInfo* module_info );
DEFINE_FUNCTION( V(int), cvRegisterModule, 1( SP(CvModuleInfo,module_info) ) ) 

/* Loads optimized functions from IPP, MKL etc. or switches back to pure C code */
// CVAPI(int)  cvUseOptimized( int on_off );
DEFINE_FUNCTION( V(int), cvUseOptimized, 1( V(int,on_off) ) ) 

/* Retrieves information about the registered modules and loaded optimized plugins */
// CVAPI(void)  cvGetModuleInfo( const char* module_name,
//                               const char** version,
//                               const char** loaded_addon_plugins );
DEFINE_FUNCTION( N(void), cvGetModuleInfo, 3( T(const,module_name), TP(const,version), TP(const,loaded_addon_plugins) ) ) 

/* Get current OpenCV error status */
// CVAPI(int) cvGetErrStatus( void );
DEFINE_FUNCTION( V(int), cvGetErrStatus, 0() ) 

/* Sets error status silently */
// CVAPI(void) cvSetErrStatus( int status );
DEFINE_FUNCTION( N(void), cvSetErrStatus, 1( V(int,status) ) ) 

// #define CV_ErrModeLeaf     0   /* Print error and exit program */
#pragma push_macro( "CV_ErrModeLeaf" )
#undef CV_ErrModeLeaf
static const int CV_ErrModeLeaf
#pragma pop_macro( "CV_ErrModeLeaf" )
	= CV_ErrModeLeaf;
// #define CV_ErrModeParent   1   /* Print error and continue */
#pragma push_macro( "CV_ErrModeParent" )
#undef CV_ErrModeParent
static const int CV_ErrModeParent
#pragma pop_macro( "CV_ErrModeParent" )
	= CV_ErrModeParent;
// #define CV_ErrModeSilent   2   /* Don't print and continue */
#pragma push_macro( "CV_ErrModeSilent" )
#undef CV_ErrModeSilent
static const int CV_ErrModeSilent
#pragma pop_macro( "CV_ErrModeSilent" )
	= CV_ErrModeSilent;

/* Retrives current error processing mode */
// CVAPI(int)  cvGetErrMode( void );
DEFINE_FUNCTION( V(int), cvGetErrMode, 0() ) 

/* Sets error processing mode, returns previously used mode */
// CVAPI(int) cvSetErrMode( int mode );
DEFINE_FUNCTION( V(int), cvSetErrMode, 1( V(int,mode) ) ) 

/* Sets error status and performs some additonal actions (displaying message box,
   writing message to stderr, terminating application etc.)
   depending on the current error mode */
// CVAPI(void) cvError( int status, const char* func_name,
//                     const char* err_msg, const char* file_name, int line );
DEFINE_FUNCTION( N(void), cvError, 5( V(int,status), T(const,func_name), T(const,err_msg), T(const,file_name), V(int,line) ) ) 

/* Retrieves textual description of the error given its code */
// CVAPI(const char*) cvErrorStr( int status );
DEFINE_FUNCTION( T(const char), cvErrorStr, 1( V(int,status) ) ) 

/* Retrieves detailed information about the last error occured */
// CVAPI(int) cvGetErrInfo( const char** errcode_desc, const char** description,
//                         const char** filename, int* line );
DEFINE_FUNCTION( V(int), cvGetErrInfo, 4( TP(const,errcode_desc), TP(const,description), TP(const,filename), VP(int,line) ) ) 
DEFINE_FUNCTION( V(int), cvGetErrInfo, 4( TP(const,errcode_desc), TP(const,description), TP(const,filename), P(int*,line) ) ) 

/* Maps IPP error codes to the counterparts from OpenCV */
// CVAPI(int) cvErrorFromIppStatus( int ipp_status );
DEFINE_FUNCTION( V(int), cvErrorFromIppStatus, 1( V(int,ipp_status) ) ) 

// typedef int (CV_CDECL *CvErrorCallback)( int status, const char* func_name,
//                     const char* err_msg, const char* file_name, int line, void* userdata );
DEFINE_CALLBACK( V(int), CvErrorCallback, 6( V(int,status), T(const,func_name), T(const,err_msg), T(const,file_name), V(int,line), P(void*,userdata) ) ) 

/* Assigns a new error-handling function */
// CVAPI(CvErrorCallback) cvRedirectError( CvErrorCallback error_handler,
//                                        void* userdata CV_DEFAULT(NULL),
//                                        void** prev_userdata CV_DEFAULT(NULL) );
DEFINE_FUNCTION( F(CvErrorCallback), cvRedirectError, 3( F(CvErrorCallback,error_handler), P(void*,userdata), P(void**,prev_userdata) ) ) 
DEFINE_FUNCTION( F(CvErrorCallback), cvRedirectError, 2( F(CvErrorCallback,error_handler), P(void*,userdata) ) ) 
DEFINE_FUNCTION( F(CvErrorCallback), cvRedirectError, 1( F(CvErrorCallback,error_handler) ) ) 

/*
    Output to:
        cvNulDevReport - nothing
        cvStdErrReport - console(fprintf(stderr,...))
        cvGuiBoxReport - MessageBox(WIN32)
*/
// CVAPI(int) cvNulDevReport( int status, const char* func_name, const char* err_msg,
//                           const char* file_name, int line, void* userdata );
DEFINE_FUNCTION( V(int), cvNulDevReport, 6( V(int,status), T(const,func_name), T(const,err_msg), T(const,file_name), V(int,line), P(void*,userdata) ) ) 

// CVAPI(int) cvStdErrReport( int status, const char* func_name, const char* err_msg,
//                           const char* file_name, int line, void* userdata );
DEFINE_FUNCTION( V(int), cvStdErrReport, 6( V(int,status), T(const,func_name), T(const,err_msg), T(const,file_name), V(int,line), P(void*,userdata) ) ) 

// CVAPI(int) cvGuiBoxReport( int status, const char* func_name, const char* err_msg,
//                           const char* file_name, int line, void* userdata );
DEFINE_FUNCTION( V(int), cvGuiBoxReport, 6( V(int,status), T(const,func_name), T(const,err_msg), T(const,file_name), V(int,line), P(void*,userdata) ) ) 

// typedef void* (CV_CDECL *CvAllocFunc)(size_t size, void* userdata);
DEFINE_CALLBACK( P(void*), CvAllocFunc, 2( V(size_t,size), P(void*,userdata) ) ) 
// typedef int (CV_CDECL *CvFreeFunc)(void* pptr, void* userdata);
DEFINE_CALLBACK( V(int), CvFreeFunc, 2( P(void*,pptr), P(void*,userdata) ) ) 

/* Set user-defined memory managment functions (substitutors for malloc and free) that
   will be called by cvAlloc, cvFree and higher-level functions (e.g. cvCreateImage) */
// CVAPI(void) cvSetMemoryManager( CvAllocFunc alloc_func CV_DEFAULT(NULL),
//                                CvFreeFunc free_func CV_DEFAULT(NULL),
//                                void* userdata CV_DEFAULT(NULL));
DEFINE_FUNCTION( N(void), cvSetMemoryManager, 3( F(CvAllocFunc,alloc_func), F(CvFreeFunc,free_func), P(void*,userdata) ) ) 
DEFINE_FUNCTION( N(void), cvSetMemoryManager, 2( F(CvAllocFunc,alloc_func), F(CvFreeFunc,free_func) ) ) 
DEFINE_FUNCTION( N(void), cvSetMemoryManager, 1( F(CvAllocFunc,alloc_func) ) ) 


// typedef IplImage* (CV_STDCALL* Cv_iplCreateImageHeader)
//                             (int,int,int,char*,char*,int,int,int,int,int,
//                             IplROI*,IplImage*,void*,IplTileInfo*);
DEFINE_CALLBACK( SP(IplImage), Cv_iplCreateImageHeader, 14( V(int,), V(int,), V(int,), VP(char,), VP(char,), V(int,), V(int,), V(int,), V(int,), V(int,), SP(IplROI,), SP(IplImage,), P(void*,), SP(IplTileInfo,) ) ) 
// typedef void (CV_STDCALL* Cv_iplAllocateImageData)(IplImage*,int,int);
DEFINE_CALLBACK( N(void), Cv_iplAllocateImageData, 3( SP(IplImage,), V(int,), V(int,) ) ) 
// typedef void (CV_STDCALL* Cv_iplDeallocate)(IplImage*,int);
DEFINE_CALLBACK( N(void), Cv_iplDeallocate, 2( SP(IplImage,), V(int,) ) ) 
// typedef IplROI* (CV_STDCALL* Cv_iplCreateROI)(int,int,int,int,int);
DEFINE_CALLBACK( SP(IplROI), Cv_iplCreateROI, 5( V(int,), V(int,), V(int,), V(int,), V(int,) ) ) 
// typedef IplImage* (CV_STDCALL* Cv_iplCloneImage)(const IplImage*);
DEFINE_CALLBACK( SP(IplImage), Cv_iplCloneImage, 1( SP(IplImage,) ) ) 

/* Makes OpenCV use IPL functions for IplImage allocation/deallocation */
// CVAPI(void) cvSetIPLAllocators( Cv_iplCreateImageHeader create_header,
//                                Cv_iplAllocateImageData allocate_data,
//                                Cv_iplDeallocate deallocate,
//                                Cv_iplCreateROI create_roi,
//                                Cv_iplCloneImage clone_image );
DEFINE_FUNCTION( N(void), cvSetIPLAllocators, 5( F(Cv_iplCreateImageHeader,create_header), F(Cv_iplAllocateImageData,allocate_data), F(Cv_iplDeallocate,deallocate), F(Cv_iplCreateROI,create_roi), F(Cv_iplCloneImage,clone_image) ) ) 

// #define CV_TURN_ON_IPL_COMPATIBILITY()                                  \
//     cvSetIPLAllocators( iplCreateImageHeader, iplAllocateImage,         \
//                         iplDeallocate, iplCreateROI, iplCloneImage )
// Unsupport : CV_TURN_ON_IPL_COMPATIBILITY

/****************************************************************************************\
*                                    Data Persistence                                    *
\****************************************************************************************/

/********************************** High-level functions ********************************/

/* opens existing or creates new file storage */
// CVAPI(CvFileStorage*)  cvOpenFileStorage( const char* filename,
//                                           CvMemStorage* memstorage,
//                                           int flags );
DEFINE_FUNCTION( SP(CvFileStorage), cvOpenFileStorage, 3( T(const,filename), SP(CvMemStorage,memstorage), V(int,flags) ) ) 

/* closes file storage and deallocates buffers */
// CVAPI(void) cvReleaseFileStorage( CvFileStorage** fs );
DEFINE_FUNCTION( N(void), cvReleaseFileStorage, 1( SPP(CvFileStorage,fs) ) ) 

/* returns attribute value or 0 (NULL) if there is no such attribute */
// CVAPI(const char*) cvAttrValue( const CvAttrList* attr, const char* attr_name );
DEFINE_FUNCTION( T(const char), cvAttrValue, 2( SP(CvAttrList,attr), T(const,attr_name) ) ) 

/* starts writing compound structure (map or sequence) */
// CVAPI(void) cvStartWriteStruct( CvFileStorage* fs, const char* name,
//                                 int struct_flags, const char* type_name CV_DEFAULT(NULL),
//                                 CvAttrList attributes CV_DEFAULT(cvAttrList()));
DEFINE_FUNCTION( N(void), cvStartWriteStruct, 5( SP(CvFileStorage,fs), T(const,name), V(int,struct_flags), T(const,type_name), S(CvAttrList,attributes) ) ) 
DEFINE_FUNCTION( N(void), cvStartWriteStruct, 4( SP(CvFileStorage,fs), T(const,name), V(int,struct_flags), T(const,type_name) ) ) 
DEFINE_FUNCTION( N(void), cvStartWriteStruct, 3( SP(CvFileStorage,fs), T(const,name), V(int,struct_flags) ) ) 

/* finishes writing compound structure */
// CVAPI(void) cvEndWriteStruct( CvFileStorage* fs );
DEFINE_FUNCTION( N(void), cvEndWriteStruct, 1( SP(CvFileStorage,fs) ) ) 

/* writes an integer */
// CVAPI(void) cvWriteInt( CvFileStorage* fs, const char* name, int value );
DEFINE_FUNCTION( N(void), cvWriteInt, 3( SP(CvFileStorage,fs), T(const,name), V(int,value) ) ) 

/* writes a floating-point number */
// CVAPI(void) cvWriteReal( CvFileStorage* fs, const char* name, double value );
DEFINE_FUNCTION( N(void), cvWriteReal, 3( SP(CvFileStorage,fs), T(const,name), V(double,value) ) ) 

/* writes a string */
// CVAPI(void) cvWriteString( CvFileStorage* fs, const char* name,
//                            const char* str, int quote CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvWriteString, 4( SP(CvFileStorage,fs), T(const,name), T(const,str), V(int,quote) ) ) 
DEFINE_FUNCTION( N(void), cvWriteString, 3( SP(CvFileStorage,fs), T(const,name), T(const,str) ) ) 

/* writes a comment */
// CVAPI(void) cvWriteComment( CvFileStorage* fs, const char* comment,
//                             int eol_comment );
DEFINE_FUNCTION( N(void), cvWriteComment, 3( SP(CvFileStorage,fs), T(const,comment), V(int,eol_comment) ) ) 

/* writes instance of a standard type (matrix, image, sequence, graph etc.)
   or user-defined type */
// CVAPI(void) cvWrite( CvFileStorage* fs, const char* name, const void* ptr,
//                          CvAttrList attributes CV_DEFAULT(cvAttrList()));
DEFINE_FUNCTION( N(void), cvWrite, 4( SP(CvFileStorage,fs), T(const,name), P(const void*,ptr), S(CvAttrList,attributes) ) ) 
DEFINE_FUNCTION( N(void), cvWrite, 3( SP(CvFileStorage,fs), T(const,name), P(const void*,ptr) ) ) 

/* starts the next stream */
// CVAPI(void) cvStartNextStream( CvFileStorage* fs );
DEFINE_FUNCTION( N(void), cvStartNextStream, 1( SP(CvFileStorage,fs) ) ) 

/* helper function: writes multiple integer or floating-point numbers */
// CVAPI(void) cvWriteRawData( CvFileStorage* fs, const void* src,
//                                 int len, const char* dt );
DEFINE_FUNCTION( N(void), cvWriteRawData, 4( SP(CvFileStorage,fs), P(const void*,src), V(int,len), T(const,dt) ) ) 

/* returns the hash entry corresponding to the specified literal key string or 0
   if there is no such a key in the storage */
// CVAPI(CvStringHashNode*) cvGetHashedKey( CvFileStorage* fs, const char* name,
//                                         int len CV_DEFAULT(-1),
//                                         int create_missing CV_DEFAULT(0));
DEFINE_FUNCTION( SP(CvStringHashNode), cvGetHashedKey, 4( SP(CvFileStorage,fs), T(const,name), V(int,len), V(int,create_missing) ) ) 
DEFINE_FUNCTION( SP(CvStringHashNode), cvGetHashedKey, 3( SP(CvFileStorage,fs), T(const,name), V(int,len) ) ) 
DEFINE_FUNCTION( SP(CvStringHashNode), cvGetHashedKey, 2( SP(CvFileStorage,fs), T(const,name) ) ) 

/* returns file node with the specified key within the specified map
   (collection of named nodes) */
// CVAPI(CvFileNode*) cvGetRootFileNode( const CvFileStorage* fs,
//                                      int stream_index CV_DEFAULT(0) );
DEFINE_FUNCTION( SP(CvFileNode), cvGetRootFileNode, 2( SP(CvFileStorage,fs), V(int,stream_index) ) ) 
DEFINE_FUNCTION( SP(CvFileNode), cvGetRootFileNode, 1( SP(CvFileStorage,fs) ) ) 

/* returns file node with the specified key within the specified map
   (collection of named nodes) */
// CVAPI(CvFileNode*) cvGetFileNode( CvFileStorage* fs, CvFileNode* map,
//                                  const CvStringHashNode* key,
//                                  int create_missing CV_DEFAULT(0) );
DEFINE_FUNCTION( SP(CvFileNode), cvGetFileNode, 4( SP(CvFileStorage,fs), SP(CvFileNode,map), SP(CvStringHashNode,key), V(int,create_missing) ) ) 
DEFINE_FUNCTION( SP(CvFileNode), cvGetFileNode, 3( SP(CvFileStorage,fs), SP(CvFileNode,map), SP(CvStringHashNode,key) ) ) 

/* this is a slower version of cvGetFileNode that takes the key as a literal string */
// CVAPI(CvFileNode*) cvGetFileNodeByName( const CvFileStorage* fs,
//                                        const CvFileNode* map,
//                                        const char* name );
DEFINE_FUNCTION( SP(CvFileNode), cvGetFileNodeByName, 3( SP(CvFileStorage,fs), SP(CvFileNode,map), T(const,name) ) ) 

// CV_INLINE int cvReadInt( const CvFileNode* node, int default_value CV_DEFAULT(0) )
// {
//     return !node ? default_value :
//         CV_NODE_IS_INT(node->tag) ? node->data.i :
//         CV_NODE_IS_REAL(node->tag) ? cvRound(node->data.f) : 0x7fffffff;
// }
DEFINE_FUNCTION( V(int), cvReadInt, 2( SP(CvFileNode,node), V(int,default_value) ) ) 
DEFINE_FUNCTION( V(int), cvReadInt, 1( SP(CvFileNode,node) ) ) 


// CV_INLINE int cvReadIntByName( const CvFileStorage* fs, const CvFileNode* map,
//                          const char* name, int default_value CV_DEFAULT(0) )
// {
//     return cvReadInt( cvGetFileNodeByName( fs, map, name ), default_value );
// }
DEFINE_FUNCTION( V(int), cvReadIntByName, 4( SP(CvFileStorage,fs), SP(CvFileNode,map), T(const,name), V(int,default_value) ) ) 
DEFINE_FUNCTION( V(int), cvReadIntByName, 3( SP(CvFileStorage,fs), SP(CvFileNode,map), T(const,name) ) ) 


// CV_INLINE double cvReadReal( const CvFileNode* node, double default_value CV_DEFAULT(0.) )
// {
//     return !node ? default_value :
//         CV_NODE_IS_INT(node->tag) ? (double)node->data.i :
//         CV_NODE_IS_REAL(node->tag) ? node->data.f : 1e300;
// }
DEFINE_FUNCTION( V(double), cvReadReal, 2( SP(CvFileNode,node), V(double,default_value) ) ) 
DEFINE_FUNCTION( V(double), cvReadReal, 1( SP(CvFileNode,node) ) ) 


// CV_INLINE double cvReadRealByName( const CvFileStorage* fs, const CvFileNode* map,
//                         const char* name, double default_value CV_DEFAULT(0.) )
// {
//     return cvReadReal( cvGetFileNodeByName( fs, map, name ), default_value );
// }
DEFINE_FUNCTION( V(double), cvReadRealByName, 4( SP(CvFileStorage,fs), SP(CvFileNode,map), T(const,name), V(double,default_value) ) ) 
DEFINE_FUNCTION( V(double), cvReadRealByName, 3( SP(CvFileStorage,fs), SP(CvFileNode,map), T(const,name) ) ) 


// CV_INLINE const char* cvReadString( const CvFileNode* node,
//                         const char* default_value CV_DEFAULT(NULL) )
// {
//     return !node ? default_value : CV_NODE_IS_STRING(node->tag) ? node->data.str.ptr : 0;
// }
DEFINE_FUNCTION( T(const char), cvReadString, 2( SP(CvFileNode,node), T(const,default_value) ) ) 
DEFINE_FUNCTION( T(const char), cvReadString, 1( SP(CvFileNode,node) ) ) 


// CV_INLINE const char* cvReadStringByName( const CvFileStorage* fs, const CvFileNode* map,
//                         const char* name, const char* default_value CV_DEFAULT(NULL) )
// {
//     return cvReadString( cvGetFileNodeByName( fs, map, name ), default_value );
// }
DEFINE_FUNCTION( T(const char), cvReadStringByName, 4( SP(CvFileStorage,fs), SP(CvFileNode,map), T(const,name), T(const,default_value) ) ) 
DEFINE_FUNCTION( T(const char), cvReadStringByName, 3( SP(CvFileStorage,fs), SP(CvFileNode,map), T(const,name) ) ) 


/* decodes standard or user-defined object and returns it */
// CVAPI(void*) cvRead( CvFileStorage* fs, CvFileNode* node,
//                         CvAttrList* attributes CV_DEFAULT(NULL));
DEFINE_FUNCTION( P(void*), cvRead, 3( SP(CvFileStorage,fs), SP(CvFileNode,node), SP(CvAttrList,attributes) ) ) 
DEFINE_FUNCTION( P(void*), cvRead, 2( SP(CvFileStorage,fs), SP(CvFileNode,node) ) ) 

/* decodes standard or user-defined object and returns it */
// CV_INLINE void* cvReadByName( CvFileStorage* fs, const CvFileNode* map,
//                               const char* name, CvAttrList* attributes CV_DEFAULT(NULL) )
// {
//     return cvRead( fs, cvGetFileNodeByName( fs, map, name ), attributes );
// }
DEFINE_FUNCTION( P(void*), cvReadByName, 4( SP(CvFileStorage,fs), SP(CvFileNode,map), T(const,name), SP(CvAttrList,attributes) ) ) 
DEFINE_FUNCTION( P(void*), cvReadByName, 3( SP(CvFileStorage,fs), SP(CvFileNode,map), T(const,name) ) ) 


/* starts reading data from sequence or scalar numeric node */
// CVAPI(void) cvStartReadRawData( const CvFileStorage* fs, const CvFileNode* src,
//                                CvSeqReader* reader );
DEFINE_FUNCTION( N(void), cvStartReadRawData, 3( SP(CvFileStorage,fs), SP(CvFileNode,src), SP(CvSeqReader,reader) ) ) 

/* reads multiple numbers and stores them to array */
// CVAPI(void) cvReadRawDataSlice( const CvFileStorage* fs, CvSeqReader* reader,
//                                int count, void* dst, const char* dt );
DEFINE_FUNCTION( N(void), cvReadRawDataSlice, 5( SP(CvFileStorage,fs), SP(CvSeqReader,reader), V(int,count), P(void*,dst), T(const,dt) ) ) 

/* combination of two previous functions for easier reading of whole sequences */
// CVAPI(void) cvReadRawData( const CvFileStorage* fs, const CvFileNode* src,
//                           void* dst, const char* dt );
DEFINE_FUNCTION( N(void), cvReadRawData, 4( SP(CvFileStorage,fs), SP(CvFileNode,src), P(void*,dst), T(const,dt) ) ) 

/* writes a copy of file node to file storage */
// CVAPI(void) cvWriteFileNode( CvFileStorage* fs, const char* new_node_name,
//                             const CvFileNode* node, int embed );
DEFINE_FUNCTION( N(void), cvWriteFileNode, 4( SP(CvFileStorage,fs), T(const,new_node_name), SP(CvFileNode,node), V(int,embed) ) ) 

/* returns name of file node */
// CVAPI(const char*) cvGetFileNodeName( const CvFileNode* node );
DEFINE_FUNCTION( T(const char), cvGetFileNodeName, 1( SP(CvFileNode,node) ) ) 

/*********************************** Adding own types ***********************************/

// CVAPI(void) cvRegisterType( const CvTypeInfo* info );
DEFINE_FUNCTION( N(void), cvRegisterType, 1( SP(CvTypeInfo,info) ) ) 
// CVAPI(void) cvUnregisterType( const char* type_name );
DEFINE_FUNCTION( N(void), cvUnregisterType, 1( T(const,type_name) ) ) 
// CVAPI(CvTypeInfo*) cvFirstType(void);
DEFINE_FUNCTION( SP(CvTypeInfo), cvFirstType, 0() ) 
// CVAPI(CvTypeInfo*) cvFindType( const char* type_name );
DEFINE_FUNCTION( SP(CvTypeInfo), cvFindType, 1( T(const,type_name) ) ) 
// CVAPI(CvTypeInfo*) cvTypeOf( const void* struct_ptr );
DEFINE_FUNCTION( SP(CvTypeInfo), cvTypeOf, 1( P(const void*,struct_ptr) ) ) 

/* universal functions */
// CVAPI(void) cvRelease( void** struct_ptr );
DEFINE_FUNCTION( N(void), cvRelease, 1( P(void**,struct_ptr) ) ) 
// CVAPI(void*) cvClone( const void* struct_ptr );
DEFINE_FUNCTION( P(void*), cvClone, 1( P(const void*,struct_ptr) ) ) 

/* simple API for reading/writing data */
// CVAPI(void) cvSave( const char* filename, const void* struct_ptr,
//                     const char* name CV_DEFAULT(NULL),
//                     const char* comment CV_DEFAULT(NULL),
//                     CvAttrList attributes CV_DEFAULT(cvAttrList()));
DEFINE_FUNCTION( N(void), cvSave, 5( T(const,filename), P(const void*,struct_ptr), T(const,name), T(const,comment), S(CvAttrList,attributes) ) ) 
DEFINE_FUNCTION( N(void), cvSave, 4( T(const,filename), P(const void*,struct_ptr), T(const,name), T(const,comment) ) ) 
DEFINE_FUNCTION( N(void), cvSave, 3( T(const,filename), P(const void*,struct_ptr), T(const,name) ) ) 
DEFINE_FUNCTION( N(void), cvSave, 2( T(const,filename), P(const void*,struct_ptr) ) ) 
// CVAPI(void*) cvLoad( const char* filename,
//                      CvMemStorage* memstorage CV_DEFAULT(NULL),
//                      const char* name CV_DEFAULT(NULL),
//                      const char** real_name CV_DEFAULT(NULL) );
DEFINE_FUNCTION( P(void*), cvLoad, 4( T(const,filename), SP(CvMemStorage,memstorage), T(const,name), TP(const,real_name) ) ) 
DEFINE_FUNCTION( P(void*), cvLoad, 3( T(const,filename), SP(CvMemStorage,memstorage), T(const,name) ) ) 
DEFINE_FUNCTION( P(void*), cvLoad, 2( T(const,filename), SP(CvMemStorage,memstorage) ) ) 
DEFINE_FUNCTION( P(void*), cvLoad, 1( T(const,filename) ) ) 

/*********************************** Measuring Execution Time ***************************/

/* helper functions for RNG initialization and accurate time measurement:
   uses internal clock counter on x86 */
// CVAPI(int64)  cvGetTickCount( void );
DEFINE_FUNCTION( V(long long), cvGetTickCount, 0() ) 
// CVAPI(double) cvGetTickFrequency( void );
DEFINE_FUNCTION( V(double), cvGetTickFrequency, 0() ) 

/*********************************** CPU capabilities ***********************************/

// #define CV_CPU_NONE    0    
#pragma push_macro( "CV_CPU_NONE" )
#undef CV_CPU_NONE
static const int CV_CPU_NONE
#pragma pop_macro( "CV_CPU_NONE" )
	= CV_CPU_NONE;
// #define CV_CPU_MMX     1
#pragma push_macro( "CV_CPU_MMX" )
#undef CV_CPU_MMX
static const int CV_CPU_MMX
#pragma pop_macro( "CV_CPU_MMX" )
	= CV_CPU_MMX;
// #define CV_CPU_SSE     2
#pragma push_macro( "CV_CPU_SSE" )
#undef CV_CPU_SSE
static const int CV_CPU_SSE
#pragma pop_macro( "CV_CPU_SSE" )
	= CV_CPU_SSE;
// #define CV_CPU_SSE2    3
#pragma push_macro( "CV_CPU_SSE2" )
#undef CV_CPU_SSE2
static const int CV_CPU_SSE2
#pragma pop_macro( "CV_CPU_SSE2" )
	= CV_CPU_SSE2;
// #define CV_CPU_SSE3    4
#pragma push_macro( "CV_CPU_SSE3" )
#undef CV_CPU_SSE3
static const int CV_CPU_SSE3
#pragma pop_macro( "CV_CPU_SSE3" )
	= CV_CPU_SSE3;
// #define CV_CPU_SSSE3   5
#pragma push_macro( "CV_CPU_SSSE3" )
#undef CV_CPU_SSSE3
static const int CV_CPU_SSSE3
#pragma pop_macro( "CV_CPU_SSSE3" )
	= CV_CPU_SSSE3;
// #define CV_CPU_SSE4_1  6
#pragma push_macro( "CV_CPU_SSE4_1" )
#undef CV_CPU_SSE4_1
static const int CV_CPU_SSE4_1
#pragma pop_macro( "CV_CPU_SSE4_1" )
	= CV_CPU_SSE4_1;
// #define CV_CPU_SSE4_2  7
#pragma push_macro( "CV_CPU_SSE4_2" )
#undef CV_CPU_SSE4_2
static const int CV_CPU_SSE4_2
#pragma pop_macro( "CV_CPU_SSE4_2" )
	= CV_CPU_SSE4_2;
// #define CV_CPU_AVX    10
#pragma push_macro( "CV_CPU_AVX" )
#undef CV_CPU_AVX
static const int CV_CPU_AVX
#pragma pop_macro( "CV_CPU_AVX" )
	= CV_CPU_AVX;
// #define CV_HARDWARE_MAX_FEATURE 255
#pragma push_macro( "CV_HARDWARE_MAX_FEATURE" )
#undef CV_HARDWARE_MAX_FEATURE
static const int CV_HARDWARE_MAX_FEATURE
#pragma pop_macro( "CV_HARDWARE_MAX_FEATURE" )
	= CV_HARDWARE_MAX_FEATURE;

// CVAPI(int) cvCheckHardwareSupport(int feature);
DEFINE_FUNCTION( V(int), cvCheckHardwareSupport, 1( V(int,feature) ) ) 

/*********************************** Multi-Threading ************************************/

/* retrieve/set the number of threads used in OpenMP implementations */
// CVAPI(int)  cvGetNumThreads( void );
DEFINE_FUNCTION( V(int), cvGetNumThreads, 0() ) 
// CVAPI(void) cvSetNumThreads( int threads CV_DEFAULT(0) );
DEFINE_FUNCTION( N(void), cvSetNumThreads, 1( V(int,threads) ) ) 
/* get index of the thread being executed */
// CVAPI(int)  cvGetThreadNum( void );
DEFINE_FUNCTION( V(int), cvGetThreadNum, 0() ) 
    

////#ifdef __cplusplus
////}
////
////// classes for automatic module/RTTI data registration/unregistration
////struct CV_EXPORTS CvModule
////{
////    CvModule( CvModuleInfo* _info );
////    ~CvModule();
////    CvModuleInfo* info;
////
////    static CvModuleInfo* first;
////    static CvModuleInfo* last;
////};
////
////struct CV_EXPORTS CvType
////{
////    CvType( const char* type_name,
////            CvIsInstanceFunc is_instance, CvReleaseFunc release=0,
////            CvReadFunc read=0, CvWriteFunc write=0, CvCloneFunc clone=0 );
////    ~CvType();
////    CvTypeInfo* info;
////
////    static CvTypeInfo* first;
////    static CvTypeInfo* last;
////};
////
////#endif
////
////#ifndef SKIP_INCLUDES // for now only expose old interface to swig
////#include "cxcore.hpp"
////#endif // SKIP_INCLUDES
////
////#endif
