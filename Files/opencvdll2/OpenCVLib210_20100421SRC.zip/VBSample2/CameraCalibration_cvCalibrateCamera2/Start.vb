﻿Option Explicit On
Option Strict On

'このサンプルは、http://opencv.jp/sample/ で公開されている
'　カメラキャリブレーション cvFitEllipse2,cvFindExtrinsicCameraParams2
'を移植したものです。
'作成者の怡土順一氏、及び、サイトを支えて頂いている方々に感謝します。

Imports ManagedOpenCV

Module Start

    Const IMAGE_NUM As Integer = 3 '画素数
    Const PAT_ROW As Integer = 7 'パターンの行数
    Const PAT_COL As Integer = 10 'パターンの列数
    Const PAT_SIZE As Integer = PAT_ROW * PAT_COL
    Const ALL_POINTS As Integer = IMAGE_NUM * PAT_SIZE
    Const CHESS_SIZE As Single = 24.0 'パターン１ますの１辺サイズ[mm]

    Sub Main()
        Dim i, j, k As Integer
        Dim corner_count, found As Integer
        Dim p_count As UIntArray = New UIntArray(IMAGE_NUM - 1)
        Dim src_img(IMAGE_NUM - 1) As IplImage
        Dim pattern_size As CvSize = cvSize_(PAT_COL, PAT_ROW)
        Dim objects() As CvPoint3D32f = CvPoint3D32f.CreateNewArray(ALL_POINTS)
        Dim corners() As CvPoint2D32f = CvPoint2D32f.CreateNewArray(ALL_POINTS)
        Dim object_points As New CvMat
        Dim image_points As New CvMat
        Dim point_counts As New CvMat
        Dim intrinsic As CvMat = cvCreateMat(3, 3, CV_32FC1)
        Dim rotation As CvMat = cvCreateMat(1, 3, CV_32FC1)
        Dim translation As CvMat = cvCreateMat(1, 3, CV_32FC1)
        Dim distortion As CvMat = cvCreateMat(1, 4, CV_32FC1)

        '(1)キャリブレーション画像の読み込み
        For i = 0 To IMAGE_NUM - 1
            Dim buf As String = String.Format("W:\Work\temp\cv\{0:00}.bmp", i)
            src_img(i) = cvLoadImage(buf, CV_LOAD_IMAGE_COLOR)
            If src_img(i) Is Nothing Then
                Debug.Print("cannot load image file : {0}", buf)
            End If
        Next

        '(2)３次空間座標の設定
        For i = 0 To IMAGE_NUM - 1
            For j = 0 To PAT_ROW - 1
                For k = 0 To PAT_COL - 1
                    objects(i * PAT_SIZE + j * PAT_COL + k).x = j * CHESS_SIZE
                    objects(i * PAT_SIZE + j * PAT_COL + k).y = k * CHESS_SIZE
                    objects(i * PAT_SIZE + j * PAT_COL + k).z = 0
                Next
            Next
        Next
        cvInitMatHeader(object_points, ALL_POINTS, 3, CV_32FC1, objects(0).Address)

        '(3)チェスボード（キャリブレーションパターン）のコーナー検出
        Dim found_num As Integer = 0
        cvNamedWindow("Calibration", CV_WINDOW_AUTOSIZE)
        For i = 0 To IMAGE_NUM - 1
            found = cvFindChessboardCorners(src_img(i).Address, pattern_size, corners(i * PAT_SIZE), corner_count)
            Dim msg As String = String.Format("{0:00}...", i)
            If found <> 0 Then
                msg += "ok"
                found_num += 1
            Else
                msg += "fail"
            End If
            Debug.Print(msg)

            '(4)コーナー位置をサブピクセル精度に修正、描画
            Dim src_gray As IplImage = cvCreateImage(cvGetSize(src_img(i)), IPL_DEPTH_8U, 1)
            cvCvtColor(src_img(i), src_gray, CV_BGR2GRAY)
            cvFindCornerSubPix(src_gray, corners(i * PAT_SIZE), corner_count, cvSize_(3, 3), cvSize_(-1, -1), cvTermCriteria_(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03))
            cvDrawChessboardCorners(src_img(i), pattern_size, corners(i * PAT_SIZE), corner_count, found)
            p_count(i) = corner_count
            cvShowImage("Calibration", src_img(i))
            cvWaitKey(0)
        Next
        cvDestroyWindow("Calibration")

        If found_num <> IMAGE_NUM Then
            Return
        End If
        cvInitMatHeader(image_points, ALL_POINTS, 1, CV_32FC2, corners(0).Address)
        cvInitMatHeader(point_counts, IMAGE_NUM, 1, CV_32SC1, p_count.Address)

        '(5)内部パラメータ、ゆがみ係数の推定
        cvCalibrateCamera2(object_points, image_points, point_counts, cvSize_(640, 480), intrinsic, distortion)

        '(6)外部パラメータの推定
        Dim sub_image_points As New CvMat, sub_object_points As New CvMat
        Dim base As Integer = 0
        cvGetRows(image_points, sub_image_points, base * PAT_SIZE, (base + 1) * PAT_SIZE)
        cvGetRows(object_points, sub_object_points, base * PAT_SIZE, (base + 1) * PAT_SIZE)
        cvFindExtrinsicCameraParams2(sub_object_points, sub_image_points, intrinsic, distortion, rotation, translation)

        '(7)XMLファイルへの書き出し
        Dim fs As CvFileStorage
        fs = cvOpenFileStorage("camera.xml", Nothing, CV_STORAGE_WRITE)
        cvWrite(fs, "intrinsic", intrinsic.Address)
        cvWrite(fs, "rotation", rotation.Address)
        cvWrite(fs, "translation", translation.Address)
        cvWrite(fs, "distortion", distortion.Address)
        cvReleaseFileStorage(fs)

        For i = 0 To IMAGE_NUM - 1
            cvReleaseImage(src_img(i))
        Next

    End Sub

End Module
