﻿Option Explicit On
Option Strict On

Imports OpenCVLib

Module Module1

    ''' <summary>
    ''' 出力ウィンドウの名称です。
    ''' </summary>
    ''' <remarks></remarks>
    Private Const OUTWINDOW As String = "Output"

    ''' <summary>
    ''' プログラムの開始位置です。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Main()

        '入力フォームの準備
        Dim frm As New Form1
        frm.Show()

        '表示ウィンドウの準備
        cvNamedWindow(OUTWINDOW, CV_WINDOW_AUTOSIZE)

        '準備
        Dim cap As IntPtr = IntPtr.Zero
        Dim srcimg As IntPtr = IntPtr.Zero
        Dim gryimg As IntPtr = IntPtr.Zero
        Dim outimg As IntPtr = IntPtr.Zero
        Dim wkimg8u As IntPtr = IntPtr.Zero
        Dim wkimg16s As IntPtr = IntPtr.Zero
        Dim imginfo As IplImage

        'フォームが閉じられる(ESCキー押下)までループ
        Do While frm.Created

            'ソース画像の取得
            If frm.SourceChanged Then
                '入力形式の変更

                'キャプチャソース生成
                cap = GetCaptureSource(frm)
                frm.SourceChanged = False

                '１フレーム読込
                srcimg = cvQueryFrame(cap)

                'イメージ情報取得
                imginfo = CvUtility.GetIplImage(srcimg)
                If (imginfo.nChannels <> 1) And (imginfo.depth <> 8) Then Exit Do '未サポート

                'グレイスケールイメージ/出力イメージ/作業量イメージの準備
                CreateImage(gryimg, srcimg)
                CreateImage(outimg, srcimg)
                CreateImage(wkimg8u, srcimg, IPL_DEPTH_8U, 1)
                CreateImage(wkimg16s, srcimg, IPL_DEPTH_16S, 1)

            Else
                '前回と同じ入力形式

                '１フレーム読込
                srcimg = cvQueryFrame(cap)

            End If

            'グレイスケール化
            If imginfo.nChannels = 1 Then
                'ソースがグレイ画像

                'コピー
                cvCopy(srcimg, gryimg, IntPtr.Zero)

            Else
                'ソースがカラー画像

                '変換
                cvCvtColor(srcimg, gryimg, CV_BGR2GRAY)

            End If

            '出力画像作成
            Select Case frm.ProcessingType
                Case Form1.ImageProcessingType.None
                    'グレイスケール化のみ

                    'コピー
                    cvCopy(gryimg, outimg, IntPtr.Zero)


                Case Form1.ImageProcessingType.Sobel
                    'cvSobel

                    'Sobel変換
                    cvSobel(gryimg, wkimg16s, frm.Sobel_Xorder, frm.Sobel_Yorder, frm.Sobel_ApertureSize)

                    '資格化方式の選択
                    If frm.Sobel_UseAbs Then
                        '絶対値を使用
                        cvConvertScaleAbs(wkimg16s, outimg, 1, 0)
                    Else
                        '中間にシフト
                        cvConvertScale(wkimg16s, outimg, 0.5, 128)
                    End If


                Case Form1.ImageProcessingType.Laplacian
                    'cvLaplace

                    'Laplacian変換
                    cvLaplace(gryimg, wkimg16s, frm.Laplace_ApertureSize)

                    '資格化方式の選択
                    If frm.Laplace_UseAbs Then
                        '絶対値を使用
                        cvConvertScaleAbs(wkimg16s, outimg, 1, 0)
                    Else
                        '中間にシフト
                        cvConvertScale(wkimg16s, outimg, 0.5, 128)
                    End If

                Case Form1.ImageProcessingType.Canny
                    'cvCanny

                    '変換
                    cvCanny(gryimg, outimg, frm.Canny_Threshold1, frm.Canny_Threshold2, frm.Canny_ApertureSize)

            End Select

            '出力
            If outimg <> IntPtr.Zero Then
                cvShowImage(OUTWINDOW, outimg)
            End If

            'キーチェック
            Dim k As Integer = cvWaitKey(10)
            If k = 27 Then
                'ESCキー押下(出力ウィンドウがフォーカスを持っている時用)

                '入力フォームを閉じる
                frm.Close()
            End If

            'メッセージ処理
            Application.DoEvents()
        Loop

        '後片付け
        cvDestroyAllWindows()
        frm.Close()

    End Sub

    ''' <summary>
    ''' キャプチャソースを取得します。
    ''' </summary>
    ''' <param name="Frm">設定画面</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCaptureSource(ByVal Frm As Form1) As IntPtr

        Dim ret As IntPtr = IntPtr.Zero
        Select Case Frm.SourceType
            Case Form1.InputSourceType.Camera
                'カメラからの入力
                ret = cvCaptureFromCAM(Frm.CameraIndex)

            Case Form1.InputSourceType.File
                'ファイルからの入力
                ret = cvCaptureFromFile(Frm.SourceFile)

            Case Else
                ret = IntPtr.Zero

        End Select

        Return ret
    End Function

    ''' <summary>
    ''' ソース画像と同サイズのイメージを作成します。
    ''' </summary>
    ''' <param name="SrcImg">ソース画像</param>
    ''' <param name="Img">作成したイメージが格納される</param>
    ''' <remarks>
    ''' ImgがIntPtr.Zeroでない場合、そのイメージを破棄します。
    ''' </remarks>
    Private Sub CreateImage(ByRef Img As IntPtr, ByVal SrcImg As IntPtr, Optional ByVal Depth As Integer = IPL_DEPTH_8U, Optional ByVal Channel As Integer = 1)

        'サイズ取得
        Dim srcsz As CvSize = CvUtility.GetIplImageSize(SrcImg)

        '現在のイメージを破棄
        If Img <> IntPtr.Zero Then
            cvReleaseImage(Img)
        End If

        '作成
        Img = cvCreateImage(srcsz, Depth, Channel)

        'データ形式を合わせる
        CvUtility.SetIplImageOrigin(Img, CvUtility.GetIplImageOrigin(SrcImg))

    End Sub

End Module
