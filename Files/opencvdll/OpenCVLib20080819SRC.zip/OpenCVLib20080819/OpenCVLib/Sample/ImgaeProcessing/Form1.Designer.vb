﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Grp_Source = New System.Windows.Forms.GroupBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Btn_SourceCameraChange = New System.Windows.Forms.Button
        Me.Txt_SourceCameraIndex = New System.Windows.Forms.TextBox
        Me.Btn_SourceFilename = New System.Windows.Forms.Button
        Me.Txt_SourceFilename = New System.Windows.Forms.TextBox
        Me.Rdo_SourceFile = New System.Windows.Forms.RadioButton
        Me.Rdo_SourceCamera = New System.Windows.Forms.RadioButton
        Me.Grp_Processing = New System.Windows.Forms.GroupBox
        Me.Rdo_Canny = New System.Windows.Forms.RadioButton
        Me.Chk_LaplaceUseAbs = New System.Windows.Forms.CheckBox
        Me.Chk_SobelUseAbs = New System.Windows.Forms.CheckBox
        Me.Cmb_LaplaceAperture = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Rdo_Laplace = New System.Windows.Forms.RadioButton
        Me.Cmb_CannyAperture = New System.Windows.Forms.ComboBox
        Me.Cmb_SobelAperture = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Txt_CannyThreshold2 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_SobelYorder = New System.Windows.Forms.TextBox
        Me.Txt_CannyThreshold1 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Txt_SobelXorder = New System.Windows.Forms.TextBox
        Me.Rdo_Sobel = New System.Windows.Forms.RadioButton
        Me.Rdo_ProcNothing = New System.Windows.Forms.RadioButton
        Me.Grp_Source.SuspendLayout()
        Me.Grp_Processing.SuspendLayout()
        Me.SuspendLayout()
        '
        'Grp_Source
        '
        Me.Grp_Source.Controls.Add(Me.Label4)
        Me.Grp_Source.Controls.Add(Me.Btn_SourceCameraChange)
        Me.Grp_Source.Controls.Add(Me.Txt_SourceCameraIndex)
        Me.Grp_Source.Controls.Add(Me.Btn_SourceFilename)
        Me.Grp_Source.Controls.Add(Me.Txt_SourceFilename)
        Me.Grp_Source.Controls.Add(Me.Rdo_SourceFile)
        Me.Grp_Source.Controls.Add(Me.Rdo_SourceCamera)
        Me.Grp_Source.Location = New System.Drawing.Point(8, 8)
        Me.Grp_Source.Name = "Grp_Source"
        Me.Grp_Source.Size = New System.Drawing.Size(424, 104)
        Me.Grp_Source.TabIndex = 0
        Me.Grp_Source.TabStop = False
        Me.Grp_Source.Text = "入力画像"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(32, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 12)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "カメラ番号"
        '
        'Btn_SourceCameraChange
        '
        Me.Btn_SourceCameraChange.Location = New System.Drawing.Point(128, 32)
        Me.Btn_SourceCameraChange.Name = "Btn_SourceCameraChange"
        Me.Btn_SourceCameraChange.Size = New System.Drawing.Size(96, 19)
        Me.Btn_SourceCameraChange.TabIndex = 4
        Me.Btn_SourceCameraChange.Text = "カメラ番号変更"
        Me.Btn_SourceCameraChange.UseVisualStyleBackColor = True
        '
        'Txt_SourceCameraIndex
        '
        Me.Txt_SourceCameraIndex.Location = New System.Drawing.Point(88, 32)
        Me.Txt_SourceCameraIndex.Name = "Txt_SourceCameraIndex"
        Me.Txt_SourceCameraIndex.Size = New System.Drawing.Size(32, 19)
        Me.Txt_SourceCameraIndex.TabIndex = 3
        Me.Txt_SourceCameraIndex.Text = "0"
        Me.Txt_SourceCameraIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Btn_SourceFilename
        '
        Me.Btn_SourceFilename.Location = New System.Drawing.Point(384, 72)
        Me.Btn_SourceFilename.Name = "Btn_SourceFilename"
        Me.Btn_SourceFilename.Size = New System.Drawing.Size(32, 19)
        Me.Btn_SourceFilename.TabIndex = 2
        Me.Btn_SourceFilename.Text = "..."
        Me.Btn_SourceFilename.UseVisualStyleBackColor = True
        '
        'Txt_SourceFilename
        '
        Me.Txt_SourceFilename.Location = New System.Drawing.Point(24, 72)
        Me.Txt_SourceFilename.Name = "Txt_SourceFilename"
        Me.Txt_SourceFilename.Size = New System.Drawing.Size(360, 19)
        Me.Txt_SourceFilename.TabIndex = 1
        '
        'Rdo_SourceFile
        '
        Me.Rdo_SourceFile.AutoSize = True
        Me.Rdo_SourceFile.Location = New System.Drawing.Point(8, 56)
        Me.Rdo_SourceFile.Name = "Rdo_SourceFile"
        Me.Rdo_SourceFile.Size = New System.Drawing.Size(81, 16)
        Me.Rdo_SourceFile.TabIndex = 0
        Me.Rdo_SourceFile.Text = "ファイル入力"
        Me.Rdo_SourceFile.UseVisualStyleBackColor = True
        '
        'Rdo_SourceCamera
        '
        Me.Rdo_SourceCamera.AutoSize = True
        Me.Rdo_SourceCamera.Checked = True
        Me.Rdo_SourceCamera.Location = New System.Drawing.Point(8, 16)
        Me.Rdo_SourceCamera.Name = "Rdo_SourceCamera"
        Me.Rdo_SourceCamera.Size = New System.Drawing.Size(72, 16)
        Me.Rdo_SourceCamera.TabIndex = 0
        Me.Rdo_SourceCamera.TabStop = True
        Me.Rdo_SourceCamera.Text = "カメラ入力"
        Me.Rdo_SourceCamera.UseVisualStyleBackColor = True
        '
        'Grp_Processing
        '
        Me.Grp_Processing.Controls.Add(Me.Rdo_Canny)
        Me.Grp_Processing.Controls.Add(Me.Chk_LaplaceUseAbs)
        Me.Grp_Processing.Controls.Add(Me.Chk_SobelUseAbs)
        Me.Grp_Processing.Controls.Add(Me.Cmb_LaplaceAperture)
        Me.Grp_Processing.Controls.Add(Me.Label5)
        Me.Grp_Processing.Controls.Add(Me.Rdo_Laplace)
        Me.Grp_Processing.Controls.Add(Me.Cmb_CannyAperture)
        Me.Grp_Processing.Controls.Add(Me.Cmb_SobelAperture)
        Me.Grp_Processing.Controls.Add(Me.Label8)
        Me.Grp_Processing.Controls.Add(Me.Label7)
        Me.Grp_Processing.Controls.Add(Me.Label3)
        Me.Grp_Processing.Controls.Add(Me.Txt_CannyThreshold2)
        Me.Grp_Processing.Controls.Add(Me.Label2)
        Me.Grp_Processing.Controls.Add(Me.Label6)
        Me.Grp_Processing.Controls.Add(Me.Txt_SobelYorder)
        Me.Grp_Processing.Controls.Add(Me.Txt_CannyThreshold1)
        Me.Grp_Processing.Controls.Add(Me.Label1)
        Me.Grp_Processing.Controls.Add(Me.Txt_SobelXorder)
        Me.Grp_Processing.Controls.Add(Me.Rdo_Sobel)
        Me.Grp_Processing.Controls.Add(Me.Rdo_ProcNothing)
        Me.Grp_Processing.Location = New System.Drawing.Point(8, 120)
        Me.Grp_Processing.Name = "Grp_Processing"
        Me.Grp_Processing.Size = New System.Drawing.Size(424, 184)
        Me.Grp_Processing.TabIndex = 1
        Me.Grp_Processing.TabStop = False
        Me.Grp_Processing.Text = "画像処理"
        '
        'Rdo_Canny
        '
        Me.Rdo_Canny.AutoSize = True
        Me.Rdo_Canny.Location = New System.Drawing.Point(8, 136)
        Me.Rdo_Canny.Name = "Rdo_Canny"
        Me.Rdo_Canny.Size = New System.Drawing.Size(67, 16)
        Me.Rdo_Canny.TabIndex = 13
        Me.Rdo_Canny.Text = "cvCanny"
        Me.Rdo_Canny.UseVisualStyleBackColor = True
        '
        'Chk_LaplaceUseAbs
        '
        Me.Chk_LaplaceUseAbs.AutoSize = True
        Me.Chk_LaplaceUseAbs.Location = New System.Drawing.Point(168, 104)
        Me.Chk_LaplaceUseAbs.Name = "Chk_LaplaceUseAbs"
        Me.Chk_LaplaceUseAbs.Size = New System.Drawing.Size(112, 16)
        Me.Chk_LaplaceUseAbs.TabIndex = 12
        Me.Chk_LaplaceUseAbs.Text = "絶対値を使用する"
        Me.Chk_LaplaceUseAbs.UseVisualStyleBackColor = True
        '
        'Chk_SobelUseAbs
        '
        Me.Chk_SobelUseAbs.AutoSize = True
        Me.Chk_SobelUseAbs.Location = New System.Drawing.Point(304, 56)
        Me.Chk_SobelUseAbs.Name = "Chk_SobelUseAbs"
        Me.Chk_SobelUseAbs.Size = New System.Drawing.Size(112, 16)
        Me.Chk_SobelUseAbs.TabIndex = 11
        Me.Chk_SobelUseAbs.Text = "絶対値を使用する"
        Me.Chk_SobelUseAbs.UseVisualStyleBackColor = True
        '
        'Cmb_LaplaceAperture
        '
        Me.Cmb_LaplaceAperture.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_LaplaceAperture.FormattingEnabled = True
        Me.Cmb_LaplaceAperture.Items.AddRange(New Object() {"1", "3", "5", "7"})
        Me.Cmb_LaplaceAperture.Location = New System.Drawing.Point(104, 104)
        Me.Cmb_LaplaceAperture.Name = "Cmb_LaplaceAperture"
        Me.Cmb_LaplaceAperture.Size = New System.Drawing.Size(40, 20)
        Me.Cmb_LaplaceAperture.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(32, 104)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 12)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "ApertureSize"
        '
        'Rdo_Laplace
        '
        Me.Rdo_Laplace.AutoSize = True
        Me.Rdo_Laplace.Location = New System.Drawing.Point(8, 88)
        Me.Rdo_Laplace.Name = "Rdo_Laplace"
        Me.Rdo_Laplace.Size = New System.Drawing.Size(74, 16)
        Me.Rdo_Laplace.TabIndex = 8
        Me.Rdo_Laplace.Text = "cvLaplace"
        Me.Rdo_Laplace.UseVisualStyleBackColor = True
        '
        'Cmb_CannyAperture
        '
        Me.Cmb_CannyAperture.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_CannyAperture.FormattingEnabled = True
        Me.Cmb_CannyAperture.Items.AddRange(New Object() {"3", "5", "7"})
        Me.Cmb_CannyAperture.Location = New System.Drawing.Point(328, 152)
        Me.Cmb_CannyAperture.Name = "Cmb_CannyAperture"
        Me.Cmb_CannyAperture.Size = New System.Drawing.Size(40, 20)
        Me.Cmb_CannyAperture.TabIndex = 7
        '
        'Cmb_SobelAperture
        '
        Me.Cmb_SobelAperture.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_SobelAperture.FormattingEnabled = True
        Me.Cmb_SobelAperture.Items.AddRange(New Object() {"1", "3", "5", "7"})
        Me.Cmb_SobelAperture.Location = New System.Drawing.Point(248, 56)
        Me.Cmb_SobelAperture.Name = "Cmb_SobelAperture"
        Me.Cmb_SobelAperture.Size = New System.Drawing.Size(40, 20)
        Me.Cmb_SobelAperture.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(256, 152)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(70, 12)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "ApertureSize"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(144, 152)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(61, 12)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "Threshold2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(176, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 12)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "ApertureSize"
        '
        'Txt_CannyThreshold2
        '
        Me.Txt_CannyThreshold2.Location = New System.Drawing.Point(208, 152)
        Me.Txt_CannyThreshold2.Name = "Txt_CannyThreshold2"
        Me.Txt_CannyThreshold2.Size = New System.Drawing.Size(32, 19)
        Me.Txt_CannyThreshold2.TabIndex = 4
        Me.Txt_CannyThreshold2.Text = "200"
        Me.Txt_CannyThreshold2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(104, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 12)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Yorder"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(32, 152)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 12)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Threshold1"
        '
        'Txt_SobelYorder
        '
        Me.Txt_SobelYorder.Location = New System.Drawing.Point(144, 56)
        Me.Txt_SobelYorder.Name = "Txt_SobelYorder"
        Me.Txt_SobelYorder.Size = New System.Drawing.Size(24, 19)
        Me.Txt_SobelYorder.TabIndex = 4
        Me.Txt_SobelYorder.Text = "1"
        Me.Txt_SobelYorder.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Txt_CannyThreshold1
        '
        Me.Txt_CannyThreshold1.Location = New System.Drawing.Point(96, 152)
        Me.Txt_CannyThreshold1.Name = "Txt_CannyThreshold1"
        Me.Txt_CannyThreshold1.Size = New System.Drawing.Size(32, 19)
        Me.Txt_CannyThreshold1.TabIndex = 2
        Me.Txt_CannyThreshold1.Text = "100"
        Me.Txt_CannyThreshold1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 12)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Xorder"
        '
        'Txt_SobelXorder
        '
        Me.Txt_SobelXorder.Location = New System.Drawing.Point(72, 56)
        Me.Txt_SobelXorder.Name = "Txt_SobelXorder"
        Me.Txt_SobelXorder.Size = New System.Drawing.Size(24, 19)
        Me.Txt_SobelXorder.TabIndex = 2
        Me.Txt_SobelXorder.Text = "1"
        Me.Txt_SobelXorder.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Rdo_Sobel
        '
        Me.Rdo_Sobel.AutoSize = True
        Me.Rdo_Sobel.Location = New System.Drawing.Point(8, 40)
        Me.Rdo_Sobel.Name = "Rdo_Sobel"
        Me.Rdo_Sobel.Size = New System.Drawing.Size(63, 16)
        Me.Rdo_Sobel.TabIndex = 1
        Me.Rdo_Sobel.Text = "cvSobel"
        Me.Rdo_Sobel.UseVisualStyleBackColor = True
        '
        'Rdo_ProcNothing
        '
        Me.Rdo_ProcNothing.AutoSize = True
        Me.Rdo_ProcNothing.Checked = True
        Me.Rdo_ProcNothing.Location = New System.Drawing.Point(8, 16)
        Me.Rdo_ProcNothing.Name = "Rdo_ProcNothing"
        Me.Rdo_ProcNothing.Size = New System.Drawing.Size(121, 16)
        Me.Rdo_ProcNothing.TabIndex = 0
        Me.Rdo_ProcNothing.TabStop = True
        Me.Rdo_ProcNothing.Text = "グレイスケール化のみ"
        Me.Rdo_ProcNothing.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(441, 314)
        Me.Controls.Add(Me.Grp_Processing)
        Me.Controls.Add(Me.Grp_Source)
        Me.KeyPreview = True
        Me.Name = "Form1"
        Me.Text = "Image Processing Sample"
        Me.Grp_Source.ResumeLayout(False)
        Me.Grp_Source.PerformLayout()
        Me.Grp_Processing.ResumeLayout(False)
        Me.Grp_Processing.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Grp_Source As System.Windows.Forms.GroupBox
    Friend WithEvents Txt_SourceCameraIndex As System.Windows.Forms.TextBox
    Friend WithEvents Btn_SourceFilename As System.Windows.Forms.Button
    Friend WithEvents Txt_SourceFilename As System.Windows.Forms.TextBox
    Friend WithEvents Rdo_SourceFile As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_SourceCamera As System.Windows.Forms.RadioButton
    Friend WithEvents Grp_Processing As System.Windows.Forms.GroupBox
    Friend WithEvents Rdo_Sobel As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_ProcNothing As System.Windows.Forms.RadioButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_SobelYorder As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Txt_SobelXorder As System.Windows.Forms.TextBox
    Friend WithEvents Cmb_SobelAperture As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Btn_SourceCameraChange As System.Windows.Forms.Button
    Friend WithEvents Rdo_Laplace As System.Windows.Forms.RadioButton
    Friend WithEvents Cmb_LaplaceAperture As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Chk_SobelUseAbs As System.Windows.Forms.CheckBox
    Friend WithEvents Rdo_Canny As System.Windows.Forms.RadioButton
    Friend WithEvents Chk_LaplaceUseAbs As System.Windows.Forms.CheckBox
    Friend WithEvents Cmb_CannyAperture As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_CannyThreshold2 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_CannyThreshold1 As System.Windows.Forms.TextBox

End Class
