﻿Option Explicit On
Option Strict On

''' <summary>
''' 設定入力用のフォームです。
''' </summary>
''' <remarks>
''' このフォームは入力処理のみを担当し、
''' 実際の処理はModule1で行います。
''' </remarks>
Public Class Form1

#Region "フォーム関係"

    ''' <summary>
    ''' ロード時の処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>
    ''' このフォームはModule1のMainで作成されることを想定しています。
    ''' </remarks>
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'コントロールの初期化
        Cmb_SobelAperture.SelectedIndex = 1     '='3'
        Cmb_LaplaceAperture.SelectedIndex = 1   '='3'
        Cmb_CannyAperture.SelectedIndex = 0     '='3'

    End Sub

    ''' <summary>
    ''' キー押下時の処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        'ESCキー押下時に閉じる(フォームがフォーカスを持っている時用)
        If e.KeyCode = Keys.Escape Then Me.Close()

    End Sub

#End Region

#Region "入力画像関係"

    ''' <summary>
    ''' 入力画像変更の有無を保持します。
    ''' </summary>
    ''' <remarks></remarks>
    Private mSourceChanged As Boolean = True


    ''' <summary>
    ''' 入力画像形式(カメラ/ファイル)を変更したときの処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Rdo_SourceChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rdo_SourceCamera.CheckedChanged, Rdo_SourceFile.CheckedChanged

        '入力画像変更
        mSourceChanged = True

    End Sub

    ''' <summary>
    ''' カメラ番号変更ボタンが押下されたときの処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_SourceCameraChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SourceCameraChange.Click

        '入力画像変更
        mSourceChanged = True

    End Sub

    ''' <summary>
    ''' 入力ファイルの選択ボタンが押下されたときの処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_SourceFilename_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SourceFilename.Click

        'ファイルの選択
        Dim dlg As New OpenFileDialog
        dlg.Filter = "全てのファイル(*.*)|*.*"
        If dlg.ShowDialog <> Windows.Forms.DialogResult.OK Then
            Exit Sub 'キャンセル
        End If

        'ファイル名設定
        Txt_SourceFilename.Text = dlg.FileName

        '入力画像変更
        mSourceChanged = True

    End Sub


    ''' <summary>
    ''' 入力画像変更の有無を取得・設定します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks>
    ''' 入力ソースの変更が必要な場合Trueになります。
    ''' </remarks>
    Public Property SourceChanged() As Boolean
        Get
            Return mSourceChanged
        End Get
        Set(ByVal value As Boolean)
            mSourceChanged = value
        End Set
    End Property


    ''' <summary>
    ''' 入力画像形式を表す定数です。
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum InputSourceType
        ''' <summary>入力画像なし</summary>
        None = 0
        ''' <summary>カメラからの入力</summary>
        Camera = 1
        ''' <summary>ファイルからの入力</summary>
        File = 2
    End Enum

    ''' <summary>
    ''' 入力画像形式を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property SourceType() As InputSourceType
        Get
            If Rdo_SourceCamera.Checked Then Return InputSourceType.Camera
            If Rdo_SourceFile.Checked Then Return InputSourceType.File
            Return InputSourceType.None
        End Get
    End Property

    ''' <summary>
    ''' カメラ番号を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property CameraIndex() As Integer
        Get
            Dim idx As Integer
            If Integer.TryParse(Txt_SourceCameraIndex.Text, idx) Then
                Return idx
            End If

            Txt_SourceCameraIndex.Text = "0"
            Return 0
        End Get
    End Property

    ''' <summary>
    ''' 入力ファイル名を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property SourceFile() As String
        Get
            Return Txt_SourceFilename.Text
        End Get
    End Property

#End Region

#Region "画像処理関係"

    ''' <summary>
    ''' 画像処理形式を表す定数です。
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum ImageProcessingType

        ''' <summary>なし(グレイスケール化のみ)</summary>
        None = 0

        ''' <summary>cvSobel</summary>
        Sobel = 1

        ''' <summary>cvLaplace</summary>
        Laplacian = 2

        ''' <summary>cvCanny</summary>
        Canny = 3

    End Enum

    ''' <summary>
    ''' 実施する画像処理形式を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ProcessingType() As ImageProcessingType
        Get
            If Rdo_Sobel.Checked Then Return ImageProcessingType.Sobel
            If Rdo_Laplace.Checked Then Return ImageProcessingType.Laplacian
            If Rdo_Canny.Checked Then Return ImageProcessingType.Canny

            Return ImageProcessingType.None
        End Get
    End Property


    ''' <summary>
    ''' 整数パラメタを返します。
    ''' </summary>
    ''' <param name="Txt">入力テキストボックス</param>
    ''' <param name="DefaultValue">デフォルト値</param>
    ''' <returns></returns>
    ''' <remarks>
    ''' 不正な入力であった場合、デフォルト値が設定されます。
    ''' </remarks>
    Private Function GetIntegerParameter(ByVal Txt As TextBox, Optional ByVal DefaultValue As Integer = 1) As Integer

        '変換
        Dim ret As Integer
        If Integer.TryParse(Txt.Text, ret) Then
            Return ret
        End If

        '不正値時の処理
        Txt.Text = DefaultValue.ToString
        Return DefaultValue
    End Function

    ''' <summary>
    ''' 整数パラメタを返します。
    ''' </summary>
    ''' <param name="Str">文字列</param>
    ''' <param name="DefaultValue">デフォルト値</param>
    ''' <returns></returns>
    ''' <remarks>
    ''' 不正な入力であった場合、デフォルト値が返されます。
    ''' </remarks>
    Private Function GetIntegerParameter(ByVal Str As String, Optional ByVal DefaultValue As Integer = 1) As Integer

        '変換
        Dim ret As Integer
        If Integer.TryParse(Str, ret) Then
            Return ret
        End If

        '不正値時の処理
        Return DefaultValue
    End Function



    ''' <summary>
    ''' cvSobel用のxorder値を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Sobel_Xorder() As Integer
        Get
            Return GetIntegerParameter(Txt_SobelXorder)
        End Get
    End Property

    ''' <summary>
    ''' cvSobel用のyorder値を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Sobel_Yorder() As Integer
        Get
            Return GetIntegerParameter(Txt_SobelYorder)
        End Get
    End Property

    ''' <summary>
    ''' cvSobel用のApertureSize値を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Sobel_ApertureSize() As Integer
        Get
            Return GetIntegerParameter(Cmb_SobelAperture.Text)
        End Get
    End Property

    ''' <summary>
    ''' cvSobel出力の絶対値を使用するかどうかを返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Sobel_UseAbs() As Boolean
        Get
            Return Chk_SobelUseAbs.Checked
        End Get
    End Property


    ''' <summary>
    ''' cvLaplace用のApertureSize値を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Laplace_ApertureSize() As Integer
        Get
            Return GetIntegerParameter(Cmb_LaplaceAperture.Text)
        End Get
    End Property

    ''' <summary>
    ''' cvLaplace出力の絶対値を使用するかどうかを返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Laplace_UseAbs() As Boolean
        Get
            Return Chk_LaplaceUseAbs.Checked
        End Get
    End Property


    ''' <summary>
    ''' cvCanny用のThreshold1値を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Canny_Threshold1() As Integer
        Get
            Return GetIntegerParameter(Txt_CannyThreshold1)
        End Get
    End Property

    ''' <summary>
    ''' cvCanny用のThreshold2値を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Canny_Threshold2() As Integer
        Get
            Return GetIntegerParameter(Txt_CannyThreshold2)
        End Get
    End Property

    ''' <summary>
    ''' cvCanny用のApertureSize値を返します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Canny_ApertureSize() As Integer
        Get
            Return GetIntegerParameter(Cmb_CannyAperture.Text, 3)
        End Get
    End Property

#End Region

End Class
