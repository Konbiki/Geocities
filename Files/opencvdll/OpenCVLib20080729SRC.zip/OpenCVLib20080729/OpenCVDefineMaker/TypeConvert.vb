Option Explicit On
Option Strict On

Imports System.IO

Module ConvertDataModule

    Public ConvertData As New Dictionary(Of String, String)

    Public Sub InitializeConvertData()

        '�f�[�^���\�[�X����
        Dim asm As System.Reflection.Assembly = System.Reflection.Assembly.GetCallingAssembly()
        Dim resname As String = My.Application.Info.ProductName + ".typeconvdata.txt"
        Dim stm As Stream = asm.GetManifestResourceStream(resname)
        Dim dat As New StreamReader(stm, System.Text.Encoding.GetEncoding("Shift_JIS"))

        '�N���A
        ConvertData.Clear()

        '�Ǎ�
        Dim dname As String = ""
        Dim codetxt As String = ""
        Dim ss As String
        Do While Not dat.EndOfStream
            ss = dat.ReadLine

            If ss.StartsWith("*") Then
                '�L�[���[�h

                If dname <> "" Then
                    ConvertData.Add(dname, codetxt)
                End If

                dname = ss.Substring(1)
                codetxt = ""
            Else
                '�L�[���[�h�f�[�^

                If dname <> "" Then
                    codetxt += ss + vbCrLf
                End If
            End If
        Loop
        If dname <> "" Then
            ConvertData.Add(dname, codetxt)
        End If

    End Sub

End Module
