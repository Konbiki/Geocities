Option Explicit On
Option Strict On

Imports System.Runtime.InteropServices

Public Module CvCam
	'/*M///////////////////////////////////////////////////////////////////////////////////////
	'//
	'//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
	'//
	'//  By downloading, copying, installing or using the software you agree to this license.
	'//  If you do not agree to this license, do not download, install,
	'//  copy or use the software.
	'//
	'//
	'//                        Intel License Agreement
	'//                For Open Source Computer Vision Library
	'//
	'// Copyright (C) 2000, Intel Corporation, all rights reserved.
	'// Third party copyrights are property of their respective owners.
	'//
	'// Redistribution and use in source and binary forms, with or without modification,
	'// are permitted provided that the following conditions are met:
	'//
	'//   * Redistribution's of source code must retain the above copyright notice,
	'//     this list of conditions and the following disclaimer.
	'//
	'//   * Redistribution's in binary form must reproduce the above copyright notice,
	'//     this list of conditions and the following disclaimer in the documentation
	'//     and/or other materials provided with the distribution.
	'//
	'//   * The name of Intel Corporation may not be used to endorse or promote products
	'//     derived from this software without specific prior written permission.
	'//
	'// This software is provided by the copyright holders and contributors "as is" and
	'// any express or implied warranties, including, but not limited to, the implied
	'// warranties of merchantability and fitness for a particular purpose are disclaimed.
	'// In no event shall the Intel Corporation or contributors be liable for any direct,
	'// indirect, incidental, special, exemplary, or consequential damages
	'// (including, but not limited to, procurement of substitute goods or services;
	'// loss of use, data, or profits; or business interruption) however caused
	'// and on any theory of liability, whether in contract, strict liability,
	'// or tort (including negligence or otherwise) arising in any way out of
	'// the use of this software, even if advised of the possibility of such damage.
	'//
	'//M*/

	'#ifndef __CVCAM_H__
	'Skip : 
	'#define __CVCAM_H__
	'Skip : 

	'#ifdef __cplusplus
	'Skip : 
	'#define CVCAM_EXTERN_C extern "C" 
	'Skip : 
	'extern "C" {
	'#else
	'Skip : 
	'#define CVCAM_EXTERN_C
	'Skip : 
	'#endif /* __cplusplus */
	'Skip : 


	'#ifdef CVCAM_EXPORTS
	'Skip : 
	'#define CVCAM_API CVCAM_EXTERN_C __declspec(dllexport)
	'Skip : 
	'#else
	'Skip : 
	'#define CVCAM_API CVCAM_EXTERN_C
	'Skip : 
	'#endif /* CVCAM_DLLEXPORT */
	'Skip : 

	'/* Returns the actual number of currently available cameras */
	'CVCAM_API int cvcamGetCamerasCount();
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamGetCamerasCount() as integer
	end function

	'/* get/set the property of the camera. returns 0 if the property is not supported */
	'CVCAM_API int cvcamGetProperty(int camera, const char* property, void* value);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamGetProperty(byval camera as integer,byval [property] as string,byval value as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamGetProperty(byval camera as integer,byval [property] as string,byref value as integer) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamGetProperty(byval camera as integer,byval [property] as string,byref value as VidFormat) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamGetProperty(byval camera as integer,byval [property] as string,byref value as CameraDescription) as integer
	end function


	'CVCAM_API int cvcamSetProperty(int camera, const char* property, void* value);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamSetProperty(byval camera as integer,byval [property] as string,byval value as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamSetProperty(byval camera as integer,byval [property] as string,byref value as integer) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamSetProperty(byval camera as integer,byval [property] as string,byval value as cvcamCallback) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamSetProperty(byval camera as integer,byval [property] as string,byref value as VidFormat) as integer
	end function



	'/* gets all property names. the actual number of properties is returned. */
	'CVCAM_API int cvcamGetPropertiesList(int camera, const char** properties, int count);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamGetPropertiesList(byval camera as integer,byref properties as string,byval count as integer) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamGetPropertiesList(byval camera as integer,byval properties as intptr,byval count as integer) as integer
	end function

	'CVCAM_API int cvcamBuildStereo(void); 
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamBuildStereo() as integer
	end function

	'/* Prepares the currently enabled cameras for work */
	'CVCAM_API int cvcamInit(void);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamInit() as integer
	end function

	'/* Start the video */
	'CVCAM_API int cvcamStart(void);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamStart() as integer
	end function

	'/* Stop the video */
	'CVCAM_API int cvcamStop(void);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamStop() as integer
	end function

	'/* Pause the video; should be used for preventing data changes during frame reading 
	'    using "frame" and other properties */
	'CVCAM_API int cvcamPause(void);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamPause() as integer
	end function

	'/* Resume the video */
	'CVCAM_API int cvcamResume(void);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamResume() as integer
	end function

	'/* Frees all resources */
	'CVCAM_API int cvcamExit(void);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamExit() as integer
	end function

	'/*Pops up a camera(s) selection dialog
	'Return value - number of cameras selected (0,1 or 2);
	'Argument: an array of selected cameras numbers
	'NULL if none selected. Should be released with free() when not needed.
	'if NULL passed, not used.
	'*/
	'CVCAM_API int cvcamSelectCamera(int** out);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamSelectCamera(byval out as intptr) as integer
	end function

	'/*Plays a specified avi file into a specified window
	'if file is NULL, file browser is opened. if window is 0,
	'it is created. width and height mean output size's 0 means
	'those of avi file are used. __cdecl (*callback)(IplImage*) would be
	'called on every frame. NULL means no callback*/
	'CVCAM_API int cvcamPlayAVI(const char* file, 
	'                           void* window, 
	'                           int width, 
	'                           int height,
	'                           void* callback); 
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamPlayAVI(byval file as string,byval window as intptr,byval width as integer,byval height as integer,byval callback as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamPlayAVI(byval file as byte(),byval window as intptr,byval width as integer,byval height as integer,byval callback as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamPlayAVI(byval file as intptr,byval window as intptr,byval width as integer,byval height as integer,byval callback as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamPlayAVI(byval file as string,byval window as intptr,byval width as integer,byval height as integer,byval callback as cvcamCallback) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamPlayAVI(byval file as byte(),byval window as intptr,byval width as integer,byval height as integer,byval callback as cvcamCallback) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamPlayAVI(byval file as intptr,byval window as intptr,byval width as integer,byval height as integer,byval callback as cvcamCallback) as integer
	end function

    <UnmanagedFunctionPointer(CallingConvention.Cdecl)> _
    Public Delegate Sub cvcamCallback(ByVal Image as IntPtr)
	



	'/*Advanced API for dealing with AVI files*/

	'typedef unsigned int cvcamAVIFILE;
	'Typedef : Unsupport


	'/*Opens a given file or pops up a dialog if file is NULL
	'returns a handle to the file opened for success or -1 for failure*/
	'CVCAM_API cvcamAVIFILE cvcamAVIOpenFile(char* file);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVIOpenFile(byval file as string) as uinteger
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVIOpenFile(byval file as byte()) as uinteger
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVIOpenFile(byval file as intptr) as uinteger
	end function

	'/*The next functions just do what they say and return 0
	'for success, anything other for failure*/

	'CVCAM_API int cvcamAVICloseFile(cvcamAVIFILE file);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVICloseFile(byval file as uinteger) as integer
	end function

	'CVCAM_API int cvcamAVISetWindow(cvcamAVIFILE file, void* window);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVISetWindow(byval file as uinteger,byval window as intptr) as integer
	end function

	'CVCAM_API int cvcamAVISetCallback(cvcamAVIFILE file, void* callback);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVISetCallback(byval file as uinteger,byval callback as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVISetCallback(byval file as uinteger,byval callback as cvcamCallback) as integer
	end function
	


	'CVCAM_API int cvcamAVISetSize(cvcamAVIFILE file, int width, int height);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVISetSize(byval file as uinteger,byval width as integer,byval height as integer) as integer
	end function

	'CVCAM_API int cvcamAVIRun(cvcamAVIFILE file);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVIRun(byval file as uinteger) as integer
	end function

	'CVCAM_API int cvcamAVIStop(cvcamAVIFILE file);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVIStop(byval file as uinteger) as integer
	end function

	'CVCAM_API int cvcamAVIPause(cvcamAVIFILE file);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVIPause(byval file as uinteger) as integer
	end function

	'CVCAM_API int cvcamAVIResume(cvcamAVIFILE file);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVIResume(byval file as uinteger) as integer
	end function

	'CVCAM_API int cvcamAVIWaitCompletion(cvcamAVIFILE file);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVIWaitCompletion(byval file as uinteger) as integer
	end function

	'CVCAM_API int cvcamAVIIsRunning(cvcamAVIFILE file);
	<DllImport(OpenCVInformation.CvCam, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvcamAVIIsRunning(byval file as uinteger) as integer
	end function

	'static const char CVCAM_PROP_ENABLE[] = "enable";
	public const CVCAM_PROP_ENABLE as string = "enable"
	'static const char CVCAM_PROP_RENDER[] = "render";
	public const CVCAM_PROP_RENDER as string = "render"
	'static const char CVCAM_PROP_WINDOW[] = "window";
	public const CVCAM_PROP_WINDOW as string = "window"
	'static const char CVCAM_PROP_CALLBACK[] = "callback";
	public const CVCAM_PROP_CALLBACK as string = "callback"
	'static const char CVCAM_DESCRIPTION[] = "description";
	public const CVCAM_DESCRIPTION as string = "description"
	'static const char CVCAM_VIDEOFORMAT[] = "video_pp";
	public const CVCAM_VIDEOFORMAT as string = "video_pp"
	'static const char CVCAM_CAMERAPROPS[] = "camera_pp";
	public const CVCAM_CAMERAPROPS as string = "camera_pp"
	'static const char CVCAM_RNDWIDTH[] = "rendering_width";
	public const CVCAM_RNDWIDTH as string = "rendering_width"
	'static const char CVCAM_RNDHEIGHT[] = "rendering_height";
	public const CVCAM_RNDHEIGHT as string = "rendering_height"
	'static const char CVCAM_SRCWIDTH[] = "source_width";
	public const CVCAM_SRCWIDTH as string = "source_width"
	'static const char CVCAM_SRCHEIGHT[] = "source_height";
	public const CVCAM_SRCHEIGHT as string = "source_height"
	'static const char CVCAM_STEREO_CALLBACK[] = "stereo_callback";
	public const CVCAM_STEREO_CALLBACK as string = "stereo_callback"
	'static const char CVCAM_STEREO3_CALLBACK[] = "stereo3_callback";
	public const CVCAM_STEREO3_CALLBACK as string = "stereo3_callback"
	'static const char CVCAM_STEREO4_CALLBACK[] = "stereo4_callback";
	public const CVCAM_STEREO4_CALLBACK as string = "stereo4_callback"
	'static const char CVCAM_PROP_SETFORMAT[] = "set_video_format";
	public const CVCAM_PROP_SETFORMAT as string = "set_video_format"
	'static const char CVCAM_PROP_RAW[] = "raw_image";
	public const CVCAM_PROP_RAW as string = "raw_image"
	'static const char CVCAM_PROP_TIME_FORMAT[] = "time_format";
	public const CVCAM_PROP_TIME_FORMAT as string = "time_format"
	'static const char CVCAM_PROP_DURATION[] = "duration";
	public const CVCAM_PROP_DURATION as string = "duration"
	'static const char CVCAM_PROP_POSITION[] = "current_position";
	public const CVCAM_PROP_POSITION as string = "current_position"

	'extern const int FRAMES_FORMAT ;
	'extern const int TIME_FORMAT ;

	'typedef struct
	'{
	'    char DeviceDescription[100];
	'    char device[100];
	'    int  channel;
	'    char ChannelDescription[100];
	'    int  maxwidth;
	'    int  maxheight;
	'    int  minwidth;
	'    int  minheight;
	'}CameraDescription;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CameraDescription
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=100)> _
        Public DeviceDescription As Byte()
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=100)> _
        Public device As Byte()
        Public channel As Integer
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=100)> _
        Public ChannelDescription As Byte()
        Public maxwidth As Integer
        Public maxheight As Integer
        Public minwidth As Integer
        Public minheight As Integer

        'clear all
        Public Sub Clear()
            ReDim DeviceDescription(99)
            ReDim device(99)
            channel = 0
            ReDim ChannelDescription(99)
            maxwidth = 0
            maxheight = 0
            minwidth = 0
            minheight = 0
        End Sub

        'Convert DeviceDescription to string
        Public ReadOnly Property DeviceDescriptionString() As String
            Get
                Return GetString(DeviceDescription)
            End Get
        End Property

        'Convert device to string
        Public ReadOnly Property deviceString() As String
            Get
                Return GetString(device)
            End Get
        End Property

        'Convert ChannelDescription to string
        Public ReadOnly Property ChannelDescriptionString() As String
            Get
                Return GetString(ChannelDescription)
            End Get
        End Property

        'Convert byte array to string
        Private Function GetString(ByVal Data() As Byte) As String

            Dim cnt As Integer = 0
            Do While cnt < Data.Length
                If Data(cnt) = 0 Then Exit Do
                cnt += 1
            Loop

            Return System.Text.Encoding.Default.GetString(Data, 0, cnt)
        End Function

    End Structure



	'typedef struct
	'{
	'    int width;
	'    int height;
	'    double framerate;
	'}VidFormat;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure VidFormat
        Public width As Integer
        Public height As Integer
        Public framerate As Double

        'constructor
        Public Sub New(ByVal w As Integer, ByVal h As Integer, ByVal f As Double)
            width = w
            height = h
            framerate = f
        End Sub
    End Structure




	'#define CVCAMTRUE  (void*)1
	Public const CVCAMTRUE As integer = 1


	'#define CVCAMFALSE (void*)0
	Public const CVCAMFALSE As integer = 0



	'typedef int cvcamWindow;
	'Typedef : Unsupport


	'#ifdef __cplusplus
	'Skip : 
	'}
	'#endif /* __cplusplus */
	'Skip : 

	'#endif //__CVCAM_H__
	'Skip : 


End Module
