Option Explicit On
Option Strict On

Imports System.Runtime.InteropServices

Public Module CxCore
	'/*M///////////////////////////////////////////////////////////////////////////////////////
	'//
	'//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
	'//
	'//  By downloading, copying, installing or using the software you agree to this license.
	'//  If you do not agree to this license, do not download, install,
	'//  copy or use the software.
	'//
	'//
	'//                        Intel License Agreement
	'//                For Open Source Computer Vision Library
	'//
	'// Copyright (C) 2000, Intel Corporation, all rights reserved.
	'// Third party copyrights are property of their respective owners.
	'//
	'// Redistribution and use in source and binary forms, with or without modification,
	'// are permitted provided that the following conditions are met:
	'//
	'//   * Redistribution's of source code must retain the above copyright notice,
	'//     this list of conditions and the following disclaimer.
	'//
	'//   * Redistribution's in binary form must reproduce the above copyright notice,
	'//     this list of conditions and the following disclaimer in the documentation
	'//     and/or other materials provided with the distribution.
	'//
	'//   * The name of Intel Corporation may not be used to endorse or promote products
	'//     derived from this software without specific prior written permission.
	'//
	'// This software is provided by the copyright holders and contributors "as is" and
	'// any express or implied warranties, including, but not limited to, the implied
	'// warranties of merchantability and fitness for a particular purpose are disclaimed.
	'// In no event shall the Intel Corporation or contributors be liable for any direct,
	'// indirect, incidental, special, exemplary, or consequential damages
	'// (including, but not limited to, procurement of substitute goods or services;
	'// loss of use, data, or profits; or business interruption) however caused
	'// and on any theory of liability, whether in contract, strict liability,
	'// or tort (including negligence or otherwise) arising in any way out of
	'// the use of this software, even if advised of the possibility of such damage.
	'//
	'//M*/


	'/****************************************************************************************\
	'*          Array allocation, deallocation, initialization and access to elements         *
	'\****************************************************************************************/

	'/* <malloc> wrapper.
	'   If there is no enough memory, the function
	'   (as well as other OpenCV functions that call cvAlloc)
	'   raises an error. */
	'CVAPI(void*)  cvAlloc( size_t size );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvAlloc(byval size as integer) as IntPtr
	end function

	'/* <free> wrapper.
	'   Here and further all the memory releasing functions
	'   (that all call cvFree) take double pointer in order to
	'   to clear pointer to the data after releasing it.
	'   Passing pointer to NULL pointer is Ok: nothing happens in this case
	'*/
	'CVAPI(void)   cvFree_( void* ptr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFree_(byval ptr as intptr)
	end sub
	'#define cvFree(ptr) (cvFree_(*(ptr)), *(ptr)=0)
	'Skip : 

	'/* Allocates and initializes IplImage header */
	'CVAPI(IplImage*)  cvCreateImageHeader( CvSize size, int depth, int channels );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateImageHeader(byval size as CvSize,byval depth as integer,byval channels as integer) as IntPtr
	end function

	'/* Inializes IplImage header */
	'CVAPI(IplImage*) cvInitImageHeader( IplImage* image, CvSize size, int depth,
	'                                   int channels, int origin CV_DEFAULT(0),
	'                                   int align CV_DEFAULT(4));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitImageHeader(byref image as IplImage,byval size as CvSize,byval depth as integer,byval channels as integer,byval origin as integer,byval align as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitImageHeader(byval image as intptr,byval size as CvSize,byval depth as integer,byval channels as integer,byval origin as integer,byval align as integer) as IntPtr
	end function

	'/* Creates IPL image (header and data) */
	'CVAPI(IplImage*)  cvCreateImage( CvSize size, int depth, int channels );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateImage(byval size as CvSize,byval depth as integer,byval channels as integer) as IntPtr
	end function

	'/* Releases (i.e. deallocates) IPL image header */
	'CVAPI(void)  cvReleaseImageHeader( IplImage** image );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReleaseImageHeader(byref image as intptr)
	end sub

	'/* Releases IPL image header and data */
	'CVAPI(void)  cvReleaseImage( IplImage** image );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReleaseImage(byref image as intptr)
	end sub

	'/* Creates a copy of IPL image (widthStep may differ) */
	'CVAPI(IplImage*) cvCloneImage( const IplImage* image );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneImage(byref image as IplImage) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneImage(byval image as intptr) as IntPtr
	end function

	'/* Sets a Channel Of Interest (only a few functions support COI) - 
	'   use cvCopy to extract the selected channel and/or put it back */
	'CVAPI(void)  cvSetImageCOI( IplImage* image, int coi );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetImageCOI(byref image as IplImage,byval coi as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetImageCOI(byval image as intptr,byval coi as integer)
	end sub

	'/* Retrieves image Channel Of Interest */
	'CVAPI(int)  cvGetImageCOI( const IplImage* image );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetImageCOI(byref image as IplImage) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetImageCOI(byval image as intptr) as integer
	end function

	'/* Sets image ROI (region of interest) (COI is not changed) */
	'CVAPI(void)  cvSetImageROI( IplImage* image, CvRect rect );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetImageROI(byref image as IplImage,byval rect as CvRect)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetImageROI(byval image as intptr,byval rect as CvRect)
	end sub

	'/* Resets image ROI and COI */
	'CVAPI(void)  cvResetImageROI( IplImage* image );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvResetImageROI(byref image as IplImage)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvResetImageROI(byval image as intptr)
	end sub

	'/* Retrieves image ROI */
	'CVAPI(CvRect) cvGetImageROI( const IplImage* image );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetImageROI(byref image as IplImage) as CvRect
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetImageROI(byval image as intptr) as CvRect
	end function

	'/* Allocates and initalizes CvMat header */
	'CVAPI(CvMat*)  cvCreateMatHeader( int rows, int cols, int type );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateMatHeader(byval rows as integer,byval cols as integer,byval type as integer) as IntPtr
	end function

	'#define CV_AUTOSTEP  0x7fffffff
	public const  CV_AUTOSTEP as integer =  &H7fffffff

	'/* Initializes CvMat header */
	'CVAPI(CvMat*) cvInitMatHeader( CvMat* mat, int rows, int cols,
	'                              int type, void* data CV_DEFAULT(NULL),
	'                              int step CV_DEFAULT(CV_AUTOSTEP) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitMatHeader(byref mat as CvMat,byval rows as integer,byval cols as integer,byval type as integer,byval data as intptr,byval [step] as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitMatHeader(byval mat as intptr,byval rows as integer,byval cols as integer,byval type as integer,byval data as intptr,byval [step] as integer) as IntPtr
	end function

	'/* Allocates and initializes CvMat header and allocates data */
	'CVAPI(CvMat*)  cvCreateMat( int rows, int cols, int type );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateMat(byval rows as integer,byval cols as integer,byval type as integer) as IntPtr
	end function

	'/* Releases CvMat header and deallocates matrix data
	'   (reference counting is used for data) */
	'CVAPI(void)  cvReleaseMat( CvMat** mat );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReleaseMat(byref mat as intptr)
	end sub

	'/* Decrements CvMat data reference counter and deallocates the data if
	'   it reaches 0 */
	'CV_INLINE  void  cvDecRefData( CvArr* arr )
	'{
	'    if( CV_IS_MAT( arr ))
	'    {
	'        CvMat* mat = (CvMat*)arr;
	'        mat->data.ptr = NULL;
	'        if( mat->refcount != NULL && --*mat->refcount == 0 )
	'            cvFree( &mat->refcount );
	'        mat->refcount = NULL;
	'    }
	'    else if( CV_IS_MATND( arr ))
	'    {
	'        CvMatND* mat = (CvMatND*)arr;
	'        mat->data.ptr = NULL;
	'        if( mat->refcount != NULL && --*mat->refcount == 0 )
	'            cvFree( &mat->refcount );
	'        mat->refcount = NULL;
	'    }
	'}
	'ToDo : Function

	'/* Increments CvMat data reference counter */
	'CV_INLINE  int  cvIncRefData( CvArr* arr )
	'{
	'    int refcount = 0;
	'    if( CV_IS_MAT( arr ))
	'    {
	'        CvMat* mat = (CvMat*)arr;
	'        if( mat->refcount != NULL )
	'            refcount = ++*mat->refcount;
	'    }
	'    else if( CV_IS_MATND( arr ))
	'    {
	'        CvMatND* mat = (CvMatND*)arr;
	'        if( mat->refcount != NULL )
	'            refcount = ++*mat->refcount;
	'    }
	'    return refcount;
	'}
	'ToDo : Function


	'/* Creates an exact copy of the input matrix (except, may be, step value) */
	'CVAPI(CvMat*) cvCloneMat( const CvMat* mat );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneMat(byref mat as CvMat) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneMat(byval mat as intptr) as IntPtr
	end function


	'/* Makes a new matrix from <rect> subrectangle of input array.
	'   No data is copied */
	'CVAPI(CvMat*) cvGetSubRect( const CvArr* arr, CvMat* submat, CvRect rect );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetSubRect(byval arr as intptr,byref submat as CvMat,byval rect as CvRect) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetSubRect(byval arr as intptr,byval submat as intptr,byval rect as CvRect) as IntPtr
	end function
	'#define cvGetSubArr cvGetSubRect
	'Skip : 

	'/* Selects row span of the input array: arr(start_row:delta_row:end_row,:)
	'    (end_row is not included into the span). */
	'CVAPI(CvMat*) cvGetRows( const CvArr* arr, CvMat* submat,
	'                        int start_row, int end_row,
	'                        int delta_row CV_DEFAULT(1));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetRows(byval arr as intptr,byref submat as CvMat,byval start_row as integer,byval end_row as integer,byval delta_row as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetRows(byval arr as intptr,byval submat as intptr,byval start_row as integer,byval end_row as integer,byval delta_row as integer) as IntPtr
	end function

	'CV_INLINE  CvMat*  cvGetRow( const CvArr* arr, CvMat* submat, int row )
	'{
	'    return cvGetRows( arr, submat, row, row + 1, 1 );
	'}
	'ToDo : Function


	'/* Selects column span of the input array: arr(:,start_col:end_col)
	'   (end_col is not included into the span) */
	'CVAPI(CvMat*) cvGetCols( const CvArr* arr, CvMat* submat,
	'                        int start_col, int end_col );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetCols(byval arr as intptr,byref submat as CvMat,byval start_col as integer,byval end_col as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetCols(byval arr as intptr,byval submat as intptr,byval start_col as integer,byval end_col as integer) as IntPtr
	end function

	'CV_INLINE  CvMat*  cvGetCol( const CvArr* arr, CvMat* submat, int col )
	'{
	'    return cvGetCols( arr, submat, col, col + 1 );
	'}
	'ToDo : Function

	'/* Select a diagonal of the input array.
	'   (diag = 0 means the main diagonal, >0 means a diagonal above the main one,
	'   <0 - below the main one).
	'   The diagonal will be represented as a column (nx1 matrix). */
	'CVAPI(CvMat*) cvGetDiag( const CvArr* arr, CvMat* submat,
	'                            int diag CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetDiag(byval arr as intptr,byref submat as CvMat,byval diag as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetDiag(byval arr as intptr,byval submat as intptr,byval diag as integer) as IntPtr
	end function

	'/* low-level scalar <-> raw data conversion functions */
	'CVAPI(void) cvScalarToRawData( const CvScalar* scalar, void* data, int type,
	'                              int extend_to_12 CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvScalarToRawData(byref scalar as CvScalar,byval data as intptr,byval type as integer,byval extend_to_12 as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvScalarToRawData(byval scalar as intptr,byval data as intptr,byval type as integer,byval extend_to_12 as integer)
	end sub

	'CVAPI(void) cvRawDataToScalar( const void* data, int type, CvScalar* scalar );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRawDataToScalar(byval data as intptr,byval type as integer,byref scalar as CvScalar)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRawDataToScalar(byval data as intptr,byval type as integer,byval scalar as intptr)
	end sub

	'/* Allocates and initializes CvMatND header */
	'CVAPI(CvMatND*)  cvCreateMatNDHeader( int dims, const int* sizes, int type );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateMatNDHeader(byval dims as integer,byval sizes as integer(),byval type as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateMatNDHeader(byval dims as integer,byref sizes as integer,byval type as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateMatNDHeader(byval dims as integer,byval sizes as intptr,byval type as integer) as IntPtr
	end function

	'/* Allocates and initializes CvMatND header and allocates data */
	'CVAPI(CvMatND*)  cvCreateMatND( int dims, const int* sizes, int type );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateMatND(byval dims as integer,byval sizes as integer(),byval type as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateMatND(byval dims as integer,byref sizes as integer,byval type as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateMatND(byval dims as integer,byval sizes as intptr,byval type as integer) as IntPtr
	end function

	'/* Initializes preallocated CvMatND header */
	'CVAPI(CvMatND*)  cvInitMatNDHeader( CvMatND* mat, int dims, const int* sizes,
	'                                    int type, void* data CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitMatNDHeader(byref mat as CvMatND,byval dims as integer,byval sizes as integer(),byval type as integer,byval data as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitMatNDHeader(byval mat as intptr,byval dims as integer,byval sizes as integer(),byval type as integer,byval data as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitMatNDHeader(byref mat as CvMatND,byval dims as integer,byref sizes as integer,byval type as integer,byval data as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitMatNDHeader(byval mat as intptr,byval dims as integer,byref sizes as integer,byval type as integer,byval data as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitMatNDHeader(byref mat as CvMatND,byval dims as integer,byval sizes as intptr,byval type as integer,byval data as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitMatNDHeader(byval mat as intptr,byval dims as integer,byval sizes as intptr,byval type as integer,byval data as intptr) as IntPtr
	end function

	'/* Releases CvMatND */
	'CV_INLINE  void  cvReleaseMatND( CvMatND** mat )
	'{
	'    cvReleaseMat( (CvMat**)mat );
	'}
	'ToDo : Function

	'/* Creates a copy of CvMatND (except, may be, steps) */
	'CVAPI(CvMatND*) cvCloneMatND( const CvMatND* mat );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneMatND(byref mat as CvMatND) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneMatND(byval mat as intptr) as IntPtr
	end function

	'/* Allocates and initializes CvSparseMat header and allocates data */
	'CVAPI(CvSparseMat*)  cvCreateSparseMat( int dims, const int* sizes, int type );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateSparseMat(byval dims as integer,byval sizes as integer(),byval type as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateSparseMat(byval dims as integer,byref sizes as integer,byval type as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateSparseMat(byval dims as integer,byval sizes as intptr,byval type as integer) as IntPtr
	end function

	'/* Releases CvSparseMat */
	'CVAPI(void)  cvReleaseSparseMat( CvSparseMat** mat );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReleaseSparseMat(byref mat as intptr)
	end sub

	'/* Creates a copy of CvSparseMat (except, may be, zero items) */
	'CVAPI(CvSparseMat*) cvCloneSparseMat( const CvSparseMat* mat );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneSparseMat(byref mat as CvSparseMat) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneSparseMat(byval mat as intptr) as IntPtr
	end function

	'/* Initializes sparse array iterator
	'   (returns the first node or NULL if the array is empty) */
	'CVAPI(CvSparseNode*) cvInitSparseMatIterator( const CvSparseMat* mat,
	'                                              CvSparseMatIterator* mat_iterator );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitSparseMatIterator(byref mat as CvSparseMat,byref mat_iterator as CvSparseMatIterator) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitSparseMatIterator(byval mat as intptr,byref mat_iterator as CvSparseMatIterator) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitSparseMatIterator(byref mat as CvSparseMat,byval mat_iterator as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitSparseMatIterator(byval mat as intptr,byval mat_iterator as intptr) as IntPtr
	end function

	'// returns next sparse array node (or NULL if there is no more nodes)
	'CV_INLINE CvSparseNode* cvGetNextSparseNode( CvSparseMatIterator* mat_iterator )
	'{
	'    if( mat_iterator->node->next )
	'        return mat_iterator->node = mat_iterator->node->next;
	'    else
	'    {
	'        int idx;
	'        for( idx = ++mat_iterator->curidx; idx < mat_iterator->mat->hashsize; idx++ )
	'        {
	'            CvSparseNode* node = (CvSparseNode*)mat_iterator->mat->hashtable[idx];
	'            if( node )
	'            {
	'                mat_iterator->curidx = idx;
	'                return mat_iterator->node = node;
	'            }
	'        }
	'        return NULL;
	'    }
	'}
	'ToDo : Function

	'/**************** matrix iterator: used for n-ary operations on dense arrays *********/

	'#define CV_MAX_ARR 10
	public const  CV_MAX_ARR as integer =  10

	'typedef struct CvNArrayIterator
	'{
	'    int count; /* number of arrays */
	'    int dims; /* number of dimensions to iterate */
	'    CvSize size; /* maximal common linear size: { width = size, height = 1 } */
	'    uchar* ptr[CV_MAX_ARR]; /* pointers to the array slices */
	'    int stack[CV_MAX_DIM]; /* for internal use */
	'    CvMatND* hdr[CV_MAX_ARR]; /* pointers to the headers of the
	'                                 matrices that are processed */
	'}
	'CvNArrayIterator;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvNArrayIterator
        Public count As Integer
        Public dims As Integer
        Public size As CvSize
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=CV_MAX_ARR)> Public ptr() As IntPtr
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=CV_MAX_DIM)> Public stack() As Integer
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=CV_MAX_ARR)> Public hdr() As IntPtr

        Public Sub Initialize()
            ReDim ptr(CV_MAX_ARR - 1)
            ReDim stack(CV_MAX_DIM - 1)
            ReDim hdr(CV_MAX_ARR - 1)
        End Sub
    End Structure



	'#define CV_NO_DEPTH_CHECK     1
	public const  CV_NO_DEPTH_CHECK as integer =  1
	'#define CV_NO_CN_CHECK        2
	public const  CV_NO_CN_CHECK as integer =  2
	'#define CV_NO_SIZE_CHECK      4
	public const  CV_NO_SIZE_CHECK as integer =  4

	'/* initializes iterator that traverses through several arrays simulteneously
	'   (the function together with cvNextArraySlice is used for
	'    N-ari element-wise operations) */
	'CVAPI(int) cvInitNArrayIterator( int count, CvArr** arrs,
	'                                 const CvArr* mask, CvMatND* stubs,
	'                                 CvNArrayIterator* array_iterator,
	'                                 int flags CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitNArrayIterator(byval count as integer,byval arrs as intptr(),byval mask as intptr,byref stubs as CvMatND,byref array_iterator as CvNArrayIterator,byval flags as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitNArrayIterator(byval count as integer,byval arrs as intptr,byval mask as intptr,byref stubs as CvMatND,byref array_iterator as CvNArrayIterator,byval flags as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitNArrayIterator(byval count as integer,byval arrs as intptr(),byval mask as intptr,byval stubs as intptr,byref array_iterator as CvNArrayIterator,byval flags as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitNArrayIterator(byval count as integer,byval arrs as intptr,byval mask as intptr,byval stubs as intptr,byref array_iterator as CvNArrayIterator,byval flags as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitNArrayIterator(byval count as integer,byval arrs as intptr(),byval mask as intptr,byref stubs as CvMatND,byval array_iterator as intptr,byval flags as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitNArrayIterator(byval count as integer,byval arrs as intptr,byval mask as intptr,byref stubs as CvMatND,byval array_iterator as intptr,byval flags as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitNArrayIterator(byval count as integer,byval arrs as intptr(),byval mask as intptr,byval stubs as intptr,byval array_iterator as intptr,byval flags as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitNArrayIterator(byval count as integer,byval arrs as intptr,byval mask as intptr,byval stubs as intptr,byval array_iterator as intptr,byval flags as integer) as integer
	end function

	'/* returns zero value if iteration is finished, non-zero (slice length) otherwise */
	'CVAPI(int) cvNextNArraySlice( CvNArrayIterator* array_iterator );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNextNArraySlice(byref array_iterator as CvNArrayIterator) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNextNArraySlice(byval array_iterator as intptr) as integer
	end function


	'/* Returns type of array elements:
	'   CV_8UC1 ... CV_64FC4 ... */
	'CVAPI(int) cvGetElemType( const CvArr* arr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetElemType(byval arr as intptr) as integer
	end function

	'/* Retrieves number of an array dimensions and
	'   optionally sizes of the dimensions */
	'CVAPI(int) cvGetDims( const CvArr* arr, int* sizes CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetDims(byval arr as intptr,byval sizes as integer()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetDims(byval arr as intptr,byref sizes as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetDims(byval arr as intptr,byval sizes as intptr) as integer
	end function


	'/* Retrieves size of a particular array dimension.
	'   For 2d arrays cvGetDimSize(arr,0) returns number of rows (image height)
	'   and cvGetDimSize(arr,1) returns number of columns (image width) */
	'CVAPI(int) cvGetDimSize( const CvArr* arr, int index );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetDimSize(byval arr as intptr,byval index as integer) as integer
	end function


	'/* ptr = &arr(idx0,idx1,...). All indexes are zero-based,
	'   the major dimensions go first (e.g. (y,x) for 2D, (z,y,x) for 3D */
	'CVAPI(uchar*) cvPtr1D( const CvArr* arr, int idx0, int* type CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtr1D(byval arr as intptr,byval idx0 as integer,byval type as integer()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtr1D(byval arr as intptr,byval idx0 as integer,byref type as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtr1D(byval arr as intptr,byval idx0 as integer,byval type as intptr) as IntPtr
	end function
	'CVAPI(uchar*) cvPtr2D( const CvArr* arr, int idx0, int idx1, int* type CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtr2D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval type as integer()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtr2D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byref type as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtr2D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval type as intptr) as IntPtr
	end function
	'CVAPI(uchar*) cvPtr3D( const CvArr* arr, int idx0, int idx1, int idx2,
	'                      int* type CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtr3D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval idx2 as integer,byval type as integer()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtr3D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval idx2 as integer,byref type as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtr3D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval idx2 as integer,byval type as intptr) as IntPtr
	end function

	'/* For CvMat or IplImage number of indices should be 2
	'   (row index (y) goes first, column index (x) goes next).
	'   For CvMatND or CvSparseMat number of infices should match number of <dims> and
	'   indices order should match the array dimension order. */
	'CVAPI(uchar*) cvPtrND( const CvArr* arr, const int* idx, int* type CV_DEFAULT(NULL),
	'                      int create_node CV_DEFAULT(1),
	'                      unsigned* precalc_hashval CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as integer(),byval type as integer(),byval create_node as integer,byval precalc_hashval as ushort()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byref idx as integer,byval type as integer(),byval create_node as integer,byval precalc_hashval as ushort()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as intptr,byval type as integer(),byval create_node as integer,byval precalc_hashval as ushort()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as integer(),byref type as integer,byval create_node as integer,byval precalc_hashval as ushort()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byref idx as integer,byref type as integer,byval create_node as integer,byval precalc_hashval as ushort()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as intptr,byref type as integer,byval create_node as integer,byval precalc_hashval as ushort()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as integer(),byval type as intptr,byval create_node as integer,byval precalc_hashval as ushort()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byref idx as integer,byval type as intptr,byval create_node as integer,byval precalc_hashval as ushort()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as intptr,byval type as intptr,byval create_node as integer,byval precalc_hashval as ushort()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as integer(),byval type as integer(),byval create_node as integer,byref precalc_hashval as ushort) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byref idx as integer,byval type as integer(),byval create_node as integer,byref precalc_hashval as ushort) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as intptr,byval type as integer(),byval create_node as integer,byref precalc_hashval as ushort) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as integer(),byref type as integer,byval create_node as integer,byref precalc_hashval as ushort) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byref idx as integer,byref type as integer,byval create_node as integer,byref precalc_hashval as ushort) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as intptr,byref type as integer,byval create_node as integer,byref precalc_hashval as ushort) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as integer(),byval type as intptr,byval create_node as integer,byref precalc_hashval as ushort) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byref idx as integer,byval type as intptr,byval create_node as integer,byref precalc_hashval as ushort) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as intptr,byval type as intptr,byval create_node as integer,byref precalc_hashval as ushort) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as integer(),byval type as integer(),byval create_node as integer,byval precalc_hashval as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byref idx as integer,byval type as integer(),byval create_node as integer,byval precalc_hashval as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as intptr,byval type as integer(),byval create_node as integer,byval precalc_hashval as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as integer(),byref type as integer,byval create_node as integer,byval precalc_hashval as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byref idx as integer,byref type as integer,byval create_node as integer,byval precalc_hashval as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as intptr,byref type as integer,byval create_node as integer,byval precalc_hashval as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as integer(),byval type as intptr,byval create_node as integer,byval precalc_hashval as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byref idx as integer,byval type as intptr,byval create_node as integer,byval precalc_hashval as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPtrND(byval arr as intptr,byval idx as intptr,byval type as intptr,byval create_node as integer,byval precalc_hashval as intptr) as IntPtr
	end function

	'/* value = arr(idx0,idx1,...) */
	'CVAPI(CvScalar) cvGet1D( const CvArr* arr, int idx0 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGet1D(byval arr as intptr,byval idx0 as integer) as CvScalar
	end function
	'CVAPI(CvScalar) cvGet2D( const CvArr* arr, int idx0, int idx1 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGet2D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer) as CvScalar
	end function
	'CVAPI(CvScalar) cvGet3D( const CvArr* arr, int idx0, int idx1, int idx2 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGet3D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval idx2 as integer) as CvScalar
	end function
	'CVAPI(CvScalar) cvGetND( const CvArr* arr, const int* idx );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetND(byval arr as intptr,byval idx as integer()) as CvScalar
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetND(byval arr as intptr,byref idx as integer) as CvScalar
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetND(byval arr as intptr,byval idx as intptr) as CvScalar
	end function

	'/* for 1-channel arrays */
	'CVAPI(double) cvGetReal1D( const CvArr* arr, int idx0 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetReal1D(byval arr as intptr,byval idx0 as integer) as double
	end function
	'CVAPI(double) cvGetReal2D( const CvArr* arr, int idx0, int idx1 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetReal2D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer) as double
	end function
	'CVAPI(double) cvGetReal3D( const CvArr* arr, int idx0, int idx1, int idx2 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetReal3D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval idx2 as integer) as double
	end function
	'CVAPI(double) cvGetRealND( const CvArr* arr, const int* idx );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetRealND(byval arr as intptr,byval idx as integer()) as double
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetRealND(byval arr as intptr,byref idx as integer) as double
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetRealND(byval arr as intptr,byval idx as intptr) as double
	end function

	'/* arr(idx0,idx1,...) = value */
	'CVAPI(void) cvSet1D( CvArr* arr, int idx0, CvScalar value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSet1D(byval arr as intptr,byval idx0 as integer,byval value as CvScalar)
	end sub
	'CVAPI(void) cvSet2D( CvArr* arr, int idx0, int idx1, CvScalar value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSet2D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval value as CvScalar)
	end sub
	'CVAPI(void) cvSet3D( CvArr* arr, int idx0, int idx1, int idx2, CvScalar value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSet3D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval idx2 as integer,byval value as CvScalar)
	end sub
	'CVAPI(void) cvSetND( CvArr* arr, const int* idx, CvScalar value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetND(byval arr as intptr,byval idx as integer(),byval value as CvScalar)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetND(byval arr as intptr,byref idx as integer,byval value as CvScalar)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetND(byval arr as intptr,byval idx as intptr,byval value as CvScalar)
	end sub

	'/* for 1-channel arrays */
	'CVAPI(void) cvSetReal1D( CvArr* arr, int idx0, double value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetReal1D(byval arr as intptr,byval idx0 as integer,byval value as double)
	end sub
	'CVAPI(void) cvSetReal2D( CvArr* arr, int idx0, int idx1, double value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetReal2D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval value as double)
	end sub
	'CVAPI(void) cvSetReal3D( CvArr* arr, int idx0,
	'                        int idx1, int idx2, double value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetReal3D(byval arr as intptr,byval idx0 as integer,byval idx1 as integer,byval idx2 as integer,byval value as double)
	end sub
	'CVAPI(void) cvSetRealND( CvArr* arr, const int* idx, double value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetRealND(byval arr as intptr,byval idx as integer(),byval value as double)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetRealND(byval arr as intptr,byref idx as integer,byval value as double)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetRealND(byval arr as intptr,byval idx as intptr,byval value as double)
	end sub

	'/* clears element of ND dense array,
	'   in case of sparse arrays it deletes the specified node */
	'CVAPI(void) cvClearND( CvArr* arr, const int* idx );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearND(byval arr as intptr,byval idx as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearND(byval arr as intptr,byref idx as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearND(byval arr as intptr,byval idx as intptr)
	end sub

	'/* Converts CvArr (IplImage or CvMat,...) to CvMat.
	'   If the last parameter is non-zero, function can
	'   convert multi(>2)-dimensional array to CvMat as long as
	'   the last array's dimension is continous. The resultant
	'   matrix will be have appropriate (a huge) number of rows */
	'CVAPI(CvMat*) cvGetMat( const CvArr* arr, CvMat* header,
	'                       int* coi CV_DEFAULT(NULL),
	'                       int allowND CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetMat(byval arr as intptr,byref header as CvMat,byval coi as integer(),byval allowND as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetMat(byval arr as intptr,byval header as intptr,byval coi as integer(),byval allowND as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetMat(byval arr as intptr,byref header as CvMat,byref coi as integer,byval allowND as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetMat(byval arr as intptr,byval header as intptr,byref coi as integer,byval allowND as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetMat(byval arr as intptr,byref header as CvMat,byval coi as intptr,byval allowND as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetMat(byval arr as intptr,byval header as intptr,byval coi as intptr,byval allowND as integer) as IntPtr
	end function

	'/* Converts CvArr (IplImage or CvMat) to IplImage */
	'CVAPI(IplImage*) cvGetImage( const CvArr* arr, IplImage* image_header );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetImage(byval arr as intptr,byref image_header as IplImage) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetImage(byval arr as intptr,byval image_header as intptr) as IntPtr
	end function


	'/* Changes a shape of multi-dimensional array.
	'   new_cn == 0 means that number of channels remains unchanged.
	'   new_dims == 0 means that number and sizes of dimensions remain the same
	'   (unless they need to be changed to set the new number of channels)
	'   if new_dims == 1, there is no need to specify new dimension sizes
	'   The resultant configuration should be achievable w/o data copying.
	'   If the resultant array is sparse, CvSparseMat header should be passed
	'   to the function else if the result is 1 or 2 dimensional,
	'   CvMat header should be passed to the function
	'   else CvMatND header should be passed */
	'CVAPI(CvArr*) cvReshapeMatND( const CvArr* arr,
	'                             int sizeof_header, CvArr* header,
	'                             int new_cn, int new_dims, int* new_sizes );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvReshapeMatND(byval arr as intptr,byval sizeof_header as integer,byval header as intptr,byval new_cn as integer,byval new_dims as integer,byval new_sizes as integer()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvReshapeMatND(byval arr as intptr,byval sizeof_header as integer,byval header as intptr,byval new_cn as integer,byval new_dims as integer,byref new_sizes as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvReshapeMatND(byval arr as intptr,byval sizeof_header as integer,byval header as intptr,byval new_cn as integer,byval new_dims as integer,byval new_sizes as intptr) as IntPtr
	end function

	'#define cvReshapeND( arr, header, new_cn, new_dims, new_sizes )   \
	'      cvReshapeMatND( (arr), sizeof(*(header)), (header),         \
	'                      (new_cn), (new_dims), (new_sizes))
	'Skip : 

	'CVAPI(CvMat*) cvReshape( const CvArr* arr, CvMat* header,
	'                        int new_cn, int new_rows CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvReshape(byval arr as intptr,byref header as CvMat,byval new_cn as integer,byval new_rows as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvReshape(byval arr as intptr,byval header as intptr,byval new_cn as integer,byval new_rows as integer) as IntPtr
	end function

	'/* Repeats source 2d array several times in both horizontal and
	'   vertical direction to fill destination array */
	'CVAPI(void) cvRepeat( const CvArr* src, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRepeat(byval src as intptr,byval dst as intptr)
	end sub

	'/* Allocates array data */
	'CVAPI(void)  cvCreateData( CvArr* arr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCreateData(byval arr as intptr)
	end sub

	'/* Releases array data */
	'CVAPI(void)  cvReleaseData( CvArr* arr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReleaseData(byval arr as intptr)
	end sub

	'/* Attaches user data to the array header. The step is reffered to
	'   the pre-last dimension. That is, all the planes of the array
	'   must be joint (w/o gaps) */
	'CVAPI(void)  cvSetData( CvArr* arr, void* data, int step );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetData(byval arr as intptr,byval data as intptr,byval [step] as integer)
	end sub

	'/* Retrieves raw data of CvMat, IplImage or CvMatND.
	'   In the latter case the function raises an error if
	'   the array can not be represented as a matrix */
	'CVAPI(void) cvGetRawData( const CvArr* arr, uchar** data,
	'                         int* step CV_DEFAULT(NULL),
	'                         CvSize* roi_size CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetRawData(byval arr as intptr,byref data as intptr,byval [step] as integer(),byref roi_size as CvSize)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetRawData(byval arr as intptr,byref data as intptr,byref [step] as integer,byref roi_size as CvSize)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetRawData(byval arr as intptr,byref data as intptr,byval [step] as intptr,byref roi_size as CvSize)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetRawData(byval arr as intptr,byref data as intptr,byval [step] as integer(),byval roi_size as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetRawData(byval arr as intptr,byref data as intptr,byref [step] as integer,byval roi_size as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetRawData(byval arr as intptr,byref data as intptr,byval [step] as intptr,byval roi_size as intptr)
	end sub

	'/* Returns width and height of array in elements */
	'CVAPI(CvSize) cvGetSize( const CvArr* arr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetSize(byval arr as intptr) as CvSize
	end function

	'/* Copies source array to destination array */
	'CVAPI(void)  cvCopy( const CvArr* src, CvArr* dst,
	'                     const CvArr* mask CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCopy(byval src as intptr,byval dst as intptr,byval mask as intptr)
	end sub

	'/* Sets all or "masked" elements of input array
	'   to the same value*/
	'CVAPI(void)  cvSet( CvArr* arr, CvScalar value,
	'                    const CvArr* mask CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSet(byval arr as intptr,byval value as CvScalar,byval mask as intptr)
	end sub

	'/* Clears all the array elements (sets them to 0) */
	'CVAPI(void)  cvSetZero( CvArr* arr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetZero(byval arr as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvSetZero")> _
	public sub cvZero(byval arr as intptr)
	end sub
	'#define cvZero  cvSetZero
	'Skip : 


	'/* Splits a multi-channel array into the set of single-channel arrays or
	'   extracts particular [color] plane */
	'CVAPI(void)  cvSplit( const CvArr* src, CvArr* dst0, CvArr* dst1,
	'                      CvArr* dst2, CvArr* dst3 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSplit(byval src as intptr,byval dst0 as intptr,byval dst1 as intptr,byval dst2 as intptr,byval dst3 as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvSplit")> _
	public sub cvCvtPixToPlane(byval src as intptr,byval dst0 as intptr,byval dst1 as intptr,byval dst2 as intptr,byval dst3 as intptr)
	end sub

	'/* Merges a set of single-channel arrays into the single multi-channel array
	'   or inserts one particular [color] plane to the array */
	'CVAPI(void)  cvMerge( const CvArr* src0, const CvArr* src1,
	'                      const CvArr* src2, const CvArr* src3,
	'                      CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMerge(byval src0 as intptr,byval src1 as intptr,byval src2 as intptr,byval src3 as intptr,byval dst as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvMerge")> _
	public sub cvCvtPlaneToPix(byval src0 as intptr,byval src1 as intptr,byval src2 as intptr,byval src3 as intptr,byval dst as intptr)
	end sub

	'/* Copies several channels from input arrays to
	'   certain channels of output arrays */
	'CVAPI(void)  cvMixChannels( const CvArr** src, int src_count,
	'                            CvArr** dst, int dst_count,
	'                            const int* from_to, int pair_count );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr(),byval src_count as integer,byval dst as intptr(),byval dst_count as integer,byval from_to as integer(),byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr,byval src_count as integer,byval dst as intptr(),byval dst_count as integer,byval from_to as integer(),byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr(),byval src_count as integer,byval dst as intptr,byval dst_count as integer,byval from_to as integer(),byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr,byval src_count as integer,byval dst as intptr,byval dst_count as integer,byval from_to as integer(),byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr(),byval src_count as integer,byval dst as intptr(),byval dst_count as integer,byref from_to as integer,byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr,byval src_count as integer,byval dst as intptr(),byval dst_count as integer,byref from_to as integer,byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr(),byval src_count as integer,byval dst as intptr,byval dst_count as integer,byref from_to as integer,byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr,byval src_count as integer,byval dst as intptr,byval dst_count as integer,byref from_to as integer,byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr(),byval src_count as integer,byval dst as intptr(),byval dst_count as integer,byval from_to as intptr,byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr,byval src_count as integer,byval dst as intptr(),byval dst_count as integer,byval from_to as intptr,byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr(),byval src_count as integer,byval dst as intptr,byval dst_count as integer,byval from_to as intptr,byval pair_count as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMixChannels(byval src as intptr,byval src_count as integer,byval dst as intptr,byval dst_count as integer,byval from_to as intptr,byval pair_count as integer)
	end sub

	'/* Performs linear transformation on every source array element:
	'   dst(x,y,c) = scale*src(x,y,c)+shift.
	'   Arbitrary combination of input and output array depths are allowed
	'   (number of channels must be the same), thus the function can be used
	'   for type conversion */
	'CVAPI(void)  cvConvertScale( const CvArr* src, CvArr* dst,
	'                             double scale CV_DEFAULT(1),
	'                             double shift CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvConvertScale(byval src as intptr,byval dst as intptr,byval scale as double,byval shift as double)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvConvertScale")> _
	public sub cvCvtScale(byval src as intptr,byval dst as intptr,byval scale as double,byval shift as double)
	end sub
	'#define cvCvtScale cvConvertScale
	'Skip : 
	'#define cvScale  cvConvertScale
	'Skip : 
	'#define cvConvert( src, dst )  cvConvertScale( (src), (dst), 1, 0 )
    Public Sub cvConvert(ByVal src As IntPtr, ByVal dst As IntPtr)
        cvConvertScale(src, dst, 1, 0)
    End Sub




	'/* Performs linear transformation on every source array element,
	'   stores absolute value of the result:
	'   dst(x,y,c) = abs(scale*src(x,y,c)+shift).
	'   destination array must have 8u type.
	'   In other cases one may use cvConvertScale + cvAbsDiffS */
	'CVAPI(void)  cvConvertScaleAbs( const CvArr* src, CvArr* dst,
	'                                double scale CV_DEFAULT(1),
	'                                double shift CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvConvertScaleAbs(byval src as intptr,byval dst as intptr,byval scale as double,byval shift as double)
	end sub
	'#define cvCvtScaleAbs  cvConvertScaleAbs
	'Skip : 


	'/* checks termination criteria validity and
	'   sets eps to default_eps (if it is not set),
	'   max_iter to default_max_iters (if it is not set)
	'*/
	'CVAPI(CvTermCriteria) cvCheckTermCriteria( CvTermCriteria criteria,
	'                                           double default_eps,
	'                                           int default_max_iters );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCheckTermCriteria(byval criteria as CvTermCriteria,byval default_eps as double,byval default_max_iters as integer) as CvTermCriteria
	end function

	'/****************************************************************************************\
	'*                   Arithmetic, logic and comparison operations                          *
	'\****************************************************************************************/

	'/* dst(mask) = src1(mask) + src2(mask) */
	'CVAPI(void)  cvAdd( const CvArr* src1, const CvArr* src2, CvArr* dst,
	'                    const CvArr* mask CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAdd(byval src1 as intptr,byval src2 as intptr,byval dst as intptr,byval mask as intptr)
	end sub

	'/* dst(mask) = src(mask) + value */
	'CVAPI(void)  cvAddS( const CvArr* src, CvScalar value, CvArr* dst,
	'                     const CvArr* mask CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAddS(byval src as intptr,byval value as CvScalar,byval dst as intptr,byval mask as intptr)
	end sub

	'/* dst(mask) = src1(mask) - src2(mask) */
	'CVAPI(void)  cvSub( const CvArr* src1, const CvArr* src2, CvArr* dst,
	'                    const CvArr* mask CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSub(byval src1 as intptr,byval src2 as intptr,byval dst as intptr,byval mask as intptr)
	end sub

	'/* dst(mask) = src(mask) - value = src(mask) + (-value) */
	'CV_INLINE  void  cvSubS( const CvArr* src, CvScalar value, CvArr* dst,
	'                         const CvArr* mask CV_DEFAULT(NULL))
	'{
	'    cvAddS( src, cvScalar( -value.val[0], -value.val[1], -value.val[2], -value.val[3]),
	'            dst, mask );
	'}
	'ToDo : Function

	'/* dst(mask) = value - src(mask) */
	'CVAPI(void)  cvSubRS( const CvArr* src, CvScalar value, CvArr* dst,
	'                      const CvArr* mask CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSubRS(byval src as intptr,byval value as CvScalar,byval dst as intptr,byval mask as intptr)
	end sub

	'/* dst(idx) = src1(idx) * src2(idx) * scale
	'   (scaled element-wise multiplication of 2 arrays) */
	'CVAPI(void)  cvMul( const CvArr* src1, const CvArr* src2,
	'                    CvArr* dst, double scale CV_DEFAULT(1) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMul(byval src1 as intptr,byval src2 as intptr,byval dst as intptr,byval scale as double)
	end sub

	'/* element-wise division/inversion with scaling: 
	'    dst(idx) = src1(idx) * scale / src2(idx)
	'    or dst(idx) = scale / src2(idx) if src1 == 0 */
	'CVAPI(void)  cvDiv( const CvArr* src1, const CvArr* src2,
	'                    CvArr* dst, double scale CV_DEFAULT(1));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvDiv(byval src1 as intptr,byval src2 as intptr,byval dst as intptr,byval scale as double)
	end sub

	'/* dst = src1 * scale + src2 */
	'CVAPI(void)  cvScaleAdd( const CvArr* src1, CvScalar scale,
	'                         const CvArr* src2, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvScaleAdd(byval src1 as intptr,byval scale as CvScalar,byval src2 as intptr,byval dst as intptr)
	end sub
	'#define cvAXPY( A, real_scalar, B, C ) cvScaleAdd(A, cvRealScalar(real_scalar), B, C)
	'Skip : 

	'/* dst = src1 * alpha + src2 * beta + gamma */
	'CVAPI(void)  cvAddWeighted( const CvArr* src1, double alpha,
	'                            const CvArr* src2, double beta,
	'                            double gamma, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAddWeighted(byval src1 as intptr,byval alpha as double,byval src2 as intptr,byval beta as double,byval gamma as double,byval dst as intptr)
	end sub

	'/* result = sum_i(src1(i) * src2(i)) (results for all channels are accumulated together) */
	'CVAPI(double)  cvDotProduct( const CvArr* src1, const CvArr* src2 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvDotProduct(byval src1 as intptr,byval src2 as intptr) as double
	end function

	'/* dst(idx) = src1(idx) & src2(idx) */
	'CVAPI(void) cvAnd( const CvArr* src1, const CvArr* src2,
	'                  CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAnd(byval src1 as intptr,byval src2 as intptr,byval dst as intptr,byval mask as intptr)
	end sub

	'/* dst(idx) = src(idx) & value */
	'CVAPI(void) cvAndS( const CvArr* src, CvScalar value,
	'                   CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAndS(byval src as intptr,byval value as CvScalar,byval dst as intptr,byval mask as intptr)
	end sub

	'/* dst(idx) = src1(idx) | src2(idx) */
	'CVAPI(void) cvOr( const CvArr* src1, const CvArr* src2,
	'                 CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvOr(byval src1 as intptr,byval src2 as intptr,byval dst as intptr,byval mask as intptr)
	end sub

	'/* dst(idx) = src(idx) | value */
	'CVAPI(void) cvOrS( const CvArr* src, CvScalar value,
	'                  CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvOrS(byval src as intptr,byval value as CvScalar,byval dst as intptr,byval mask as intptr)
	end sub

	'/* dst(idx) = src1(idx) ^ src2(idx) */
	'CVAPI(void) cvXor( const CvArr* src1, const CvArr* src2,
	'                  CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvXor(byval src1 as intptr,byval src2 as intptr,byval dst as intptr,byval mask as intptr)
	end sub

	'/* dst(idx) = src(idx) ^ value */
	'CVAPI(void) cvXorS( const CvArr* src, CvScalar value,
	'                   CvArr* dst, const CvArr* mask CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvXorS(byval src as intptr,byval value as CvScalar,byval dst as intptr,byval mask as intptr)
	end sub

	'/* dst(idx) = ~src(idx) */
	'CVAPI(void) cvNot( const CvArr* src, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvNot(byval src as intptr,byval dst as intptr)
	end sub

	'/* dst(idx) = lower(idx) <= src(idx) < upper(idx) */
	'CVAPI(void) cvInRange( const CvArr* src, const CvArr* lower,
	'                      const CvArr* upper, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvInRange(byval src as intptr,byval lower as intptr,byval upper as intptr,byval dst as intptr)
	end sub

	'/* dst(idx) = lower <= src(idx) < upper */
	'CVAPI(void) cvInRangeS( const CvArr* src, CvScalar lower,
	'                       CvScalar upper, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvInRangeS(byval src as intptr,byval lower as CvScalar,byval upper as CvScalar,byval dst as intptr)
	end sub

	'#define CV_CMP_EQ   0
	public const  CV_CMP_EQ as integer =  0
	'#define CV_CMP_GT   1
	public const  CV_CMP_GT as integer =  1
	'#define CV_CMP_GE   2
	public const  CV_CMP_GE as integer =  2
	'#define CV_CMP_LT   3
	public const  CV_CMP_LT as integer =  3
	'#define CV_CMP_LE   4
	public const  CV_CMP_LE as integer =  4
	'#define CV_CMP_NE   5
	public const  CV_CMP_NE as integer =  5

	'/* The comparison operation support single-channel arrays only.
	'   Destination image should be 8uC1 or 8sC1 */

	'/* dst(idx) = src1(idx) _cmp_op_ src2(idx) */
	'CVAPI(void) cvCmp( const CvArr* src1, const CvArr* src2, CvArr* dst, int cmp_op );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCmp(byval src1 as intptr,byval src2 as intptr,byval dst as intptr,byval cmp_op as integer)
	end sub

	'/* dst(idx) = src1(idx) _cmp_op_ value */
	'CVAPI(void) cvCmpS( const CvArr* src, double value, CvArr* dst, int cmp_op );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCmpS(byval src as intptr,byval value as double,byval dst as intptr,byval cmp_op as integer)
	end sub

	'/* dst(idx) = min(src1(idx),src2(idx)) */
	'CVAPI(void) cvMin( const CvArr* src1, const CvArr* src2, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMin(byval src1 as intptr,byval src2 as intptr,byval dst as intptr)
	end sub

	'/* dst(idx) = max(src1(idx),src2(idx)) */
	'CVAPI(void) cvMax( const CvArr* src1, const CvArr* src2, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMax(byval src1 as intptr,byval src2 as intptr,byval dst as intptr)
	end sub

	'/* dst(idx) = min(src(idx),value) */
	'CVAPI(void) cvMinS( const CvArr* src, double value, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinS(byval src as intptr,byval value as double,byval dst as intptr)
	end sub

	'/* dst(idx) = max(src(idx),value) */
	'CVAPI(void) cvMaxS( const CvArr* src, double value, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMaxS(byval src as intptr,byval value as double,byval dst as intptr)
	end sub

	'/* dst(x,y,c) = abs(src1(x,y,c) - src2(x,y,c)) */
	'CVAPI(void) cvAbsDiff( const CvArr* src1, const CvArr* src2, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAbsDiff(byval src1 as intptr,byval src2 as intptr,byval dst as intptr)
	end sub

	'/* dst(x,y,c) = abs(src(x,y,c) - value(c)) */
	'CVAPI(void) cvAbsDiffS( const CvArr* src, CvArr* dst, CvScalar value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAbsDiffS(byval src as intptr,byval dst as intptr,byval value as CvScalar)
	end sub
	'#define cvAbs( src, dst ) cvAbsDiffS( (src), (dst), cvScalarAll(0))
	'Skip : 

	'/****************************************************************************************\
	'*                                Math operations                                         *
	'\****************************************************************************************/

	'/* Does cartesian->polar coordinates conversion.
	'   Either of output components (magnitude or angle) is optional */
	'CVAPI(void)  cvCartToPolar( const CvArr* x, const CvArr* y,
	'                            CvArr* magnitude, CvArr* angle CV_DEFAULT(NULL),
	'                            int angle_in_degrees CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCartToPolar(byval x as intptr,byval y as intptr,byval magnitude as intptr,byval angle as intptr,byval angle_in_degrees as integer)
	end sub

	'/* Does polar->cartesian coordinates conversion.
	'   Either of output components (magnitude or angle) is optional.
	'   If magnitude is missing it is assumed to be all 1's */
	'CVAPI(void)  cvPolarToCart( const CvArr* magnitude, const CvArr* angle,
	'                            CvArr* x, CvArr* y,
	'                            int angle_in_degrees CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPolarToCart(byval magnitude as intptr,byval angle as intptr,byval x as intptr,byval y as intptr,byval angle_in_degrees as integer)
	end sub

	'/* Does powering: dst(idx) = src(idx)^power */
	'CVAPI(void)  cvPow( const CvArr* src, CvArr* dst, double power );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPow(byval src as intptr,byval dst as intptr,byval power as double)
	end sub

	'/* Does exponention: dst(idx) = exp(src(idx)).
	'   Overflow is not handled yet. Underflow is handled.
	'   Maximal relative error is ~7e-6 for single-precision input */
	'CVAPI(void)  cvExp( const CvArr* src, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvExp(byval src as intptr,byval dst as intptr)
	end sub

	'/* Calculates natural logarithms: dst(idx) = log(abs(src(idx))).
	'   Logarithm of 0 gives large negative number(~-700)
	'   Maximal relative error is ~3e-7 for single-precision output
	'*/
	'CVAPI(void)  cvLog( const CvArr* src, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvLog(byval src as intptr,byval dst as intptr)
	end sub

	'/* Fast arctangent calculation */
	'CVAPI(float) cvFastArctan( float y, float x );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFastArctan(byval y as single,byval x as single) as single
	end function

	'/* Fast cubic root calculation */
	'CVAPI(float)  cvCbrt( float value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCbrt(byval value as single) as single
	end function

	'/* Checks array values for NaNs, Infs or simply for too large numbers
	'   (if CV_CHECK_RANGE is set). If CV_CHECK_QUIET is set,
	'   no runtime errors is raised (function returns zero value in case of "bad" values).
	'   Otherwise cvError is called */ 
	'#define  CV_CHECK_RANGE    1
	public const  CV_CHECK_RANGE as integer =  1
	'#define  CV_CHECK_QUIET    2
	public const  CV_CHECK_QUIET as integer =  2
	'CVAPI(int)  cvCheckArr( const CvArr* arr, int flags CV_DEFAULT(0),
	'                        double min_val CV_DEFAULT(0), double max_val CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCheckArr(byval arr as intptr,byval flags as integer,byval min_val as double,byval max_val as double) as integer
	end function
	'#define cvCheckArray cvCheckArr
	'Skip : 

	'#define CV_RAND_UNI      0
	public const  CV_RAND_UNI as integer =  0
	'#define CV_RAND_NORMAL   1
	public const  CV_RAND_NORMAL as integer =  1
	'CVAPI(void) cvRandArr( CvRNG* rng, CvArr* arr, int dist_type,
	'                      CvScalar param1, CvScalar param2 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRandArr(byref rng as long,byval arr as intptr,byval dist_type as integer,byval param1 as CvScalar,byval param2 as CvScalar)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRandArr(byval rng as intptr,byval arr as intptr,byval dist_type as integer,byval param1 as CvScalar,byval param2 as CvScalar)
	end sub

	'CVAPI(void) cvRandShuffle( CvArr* mat, CvRNG* rng,
	'                           double iter_factor CV_DEFAULT(1.));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRandShuffle(byval mat as intptr,byref rng as long,byval iter_factor as double)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRandShuffle(byval mat as intptr,byval rng as intptr,byval iter_factor as double)
	end sub

	'/* Finds real roots of a cubic equation */
	'CVAPI(int) cvSolveCubic( const CvMat* coeffs, CvMat* roots );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSolveCubic(byref coeffs as CvMat,byref roots as CvMat) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSolveCubic(byval coeffs as intptr,byref roots as CvMat) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSolveCubic(byref coeffs as CvMat,byval roots as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSolveCubic(byval coeffs as intptr,byval roots as intptr) as integer
	end function

	'/****************************************************************************************\
	'*                                Matrix operations                                       *
	'\****************************************************************************************/

	'/* Calculates cross product of two 3d vectors */
	'CVAPI(void)  cvCrossProduct( const CvArr* src1, const CvArr* src2, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCrossProduct(byval src1 as intptr,byval src2 as intptr,byval dst as intptr)
	end sub

	'/* Matrix transform: dst = A*B + C, C is optional */
	'#define cvMatMulAdd( src1, src2, src3, dst ) cvGEMM( (src1), (src2), 1., (src3), 1., (dst), 0 )
	'Skip : 
	'#define cvMatMul( src1, src2, dst )  cvMatMulAdd( (src1), (src2), NULL, (dst))
	'Skip : 

	'#define CV_GEMM_A_T 1
	public const  CV_GEMM_A_T as integer =  1
	'#define CV_GEMM_B_T 2
	public const  CV_GEMM_B_T as integer =  2
	'#define CV_GEMM_C_T 4
	public const  CV_GEMM_C_T as integer =  4
	'/* Extended matrix transform:
	'   dst = alpha*op(A)*op(B) + beta*op(C), where op(X) is X or X^T */
	'CVAPI(void)  cvGEMM( const CvArr* src1, const CvArr* src2, double alpha,
	'                     const CvArr* src3, double beta, CvArr* dst,
	'                     int tABC CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGEMM(byval src1 as intptr,byval src2 as intptr,byval alpha as double,byval src3 as intptr,byval beta as double,byval dst as intptr,byval tABC as integer)
	end sub
	'#define cvMatMulAddEx cvGEMM
	'Skip : 

	'/* Transforms each element of source array and stores
	'   resultant vectors in destination array */
	'CVAPI(void)  cvTransform( const CvArr* src, CvArr* dst,
	'                          const CvMat* transmat,
	'                          const CvMat* shiftvec CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvTransform(byval src as intptr,byval dst as intptr,byref transmat as CvMat,byref shiftvec as CvMat)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvTransform(byval src as intptr,byval dst as intptr,byval transmat as intptr,byref shiftvec as CvMat)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvTransform(byval src as intptr,byval dst as intptr,byref transmat as CvMat,byval shiftvec as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvTransform(byval src as intptr,byval dst as intptr,byval transmat as intptr,byval shiftvec as intptr)
	end sub
	'#define cvMatMulAddS cvTransform
	'Skip : 

	'/* Does perspective transform on every element of input array */
	'CVAPI(void)  cvPerspectiveTransform( const CvArr* src, CvArr* dst,
	'                                     const CvMat* mat );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPerspectiveTransform(byval src as intptr,byval dst as intptr,byref mat as CvMat)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPerspectiveTransform(byval src as intptr,byval dst as intptr,byval mat as intptr)
	end sub

	'/* Calculates (A-delta)*(A-delta)^T (order=0) or (A-delta)^T*(A-delta) (order=1) */
	'CVAPI(void) cvMulTransposed( const CvArr* src, CvArr* dst, int order,
	'                             const CvArr* delta CV_DEFAULT(NULL),
	'                             double scale CV_DEFAULT(1.) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMulTransposed(byval src as intptr,byval dst as intptr,byval order as integer,byval delta as intptr,byval scale as double)
	end sub

	'/* Tranposes matrix. Square matrices can be transposed in-place */
	'CVAPI(void)  cvTranspose( const CvArr* src, CvArr* dst );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvTranspose(byval src as intptr,byval dst as intptr)
	end sub
	'#define cvT cvTranspose
	'Skip : 


	'/* Mirror array data around horizontal (flip=0),
	'   vertical (flip=1) or both(flip=-1) axises:
	'   cvFlip(src) flips images vertically and sequences horizontally (inplace) */
	'CVAPI(void)  cvFlip( const CvArr* src, CvArr* dst CV_DEFAULT(NULL),
	'                     int flip_mode CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFlip(byval src as intptr,byval dst as intptr,byval flip_mode as integer)
	end sub
	'#define cvMirror cvFlip
	'Skip : 


	'#define CV_SVD_MODIFY_A   1
	public const  CV_SVD_MODIFY_A as integer =  1
	'#define CV_SVD_U_T        2
	public const  CV_SVD_U_T as integer =  2
	'#define CV_SVD_V_T        4
	public const  CV_SVD_V_T as integer =  4

	'/* Performs Singular Value Decomposition of a matrix */
	'CVAPI(void)   cvSVD( CvArr* A, CvArr* W, CvArr* U CV_DEFAULT(NULL),
	'                     CvArr* V CV_DEFAULT(NULL), int flags CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSVD(byval A as intptr,byval W as intptr,byval U as intptr,byval V as intptr,byval flags as integer)
	end sub

	'/* Performs Singular Value Back Substitution (solves A*X = B):
	'   flags must be the same as in cvSVD */
	'CVAPI(void)   cvSVBkSb( const CvArr* W, const CvArr* U,
	'                        const CvArr* V, const CvArr* B,
	'                        CvArr* X, int flags );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSVBkSb(byval W as intptr,byval U as intptr,byval V as intptr,byval B as intptr,byval X as intptr,byval flags as integer)
	end sub

	'#define CV_LU  0
	public const  CV_LU as integer =  0
	'#define CV_SVD 1
	public const  CV_SVD as integer =  1
	'#define CV_SVD_SYM 2
	public const  CV_SVD_SYM as integer =  2
	'/* Inverts matrix */
	'CVAPI(double)  cvInvert( const CvArr* src, CvArr* dst,
	'                         int method CV_DEFAULT(CV_LU));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInvert(byval src as intptr,byval dst as intptr,byval method as integer) as double
	end function
	'#define cvInv cvInvert
	'Skip : 

	'/* Solves linear system (src1)*(dst) = (src2)
	'   (returns 0 if src1 is a singular and CV_LU method is used) */
	'CVAPI(int)  cvSolve( const CvArr* src1, const CvArr* src2, CvArr* dst,
	'                     int method CV_DEFAULT(CV_LU));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSolve(byval src1 as intptr,byval src2 as intptr,byval dst as intptr,byval method as integer) as integer
	end function

	'/* Calculates determinant of input matrix */
	'CVAPI(double) cvDet( const CvArr* mat );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvDet(byval mat as intptr) as double
	end function

	'/* Calculates trace of the matrix (sum of elements on the main diagonal) */
	'CVAPI(CvScalar) cvTrace( const CvArr* mat );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvTrace(byval mat as intptr) as CvScalar
	end function

	'/* Finds eigen values and vectors of a symmetric matrix */
	'CVAPI(void)  cvEigenVV( CvArr* mat, CvArr* evects,
	'                        CvArr* evals, double eps CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvEigenVV(byval mat as intptr,byval evects as intptr,byval evals as intptr,byval eps as double)
	end sub

	'/* Makes an identity matrix (mat_ij = i == j) */
	'CVAPI(void)  cvSetIdentity( CvArr* mat, CvScalar value CV_DEFAULT(cvRealScalar(1)) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetIdentity(byval mat as intptr,byval value as CvScalar)
	end sub

	'/* Fills matrix with given range of numbers */
	'CVAPI(CvArr*)  cvRange( CvArr* mat, double start, double end );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvRange(byval mat as intptr,byval start as double,byval [end] as double) as IntPtr
	end function

	'/* Calculates covariation matrix for a set of vectors */
	'/* transpose([v1-avg, v2-avg,...]) * [v1-avg,v2-avg,...] */
	'#define CV_COVAR_SCRAMBLED 0
	public const  CV_COVAR_SCRAMBLED as integer =  0

	'/* [v1-avg, v2-avg,...] * transpose([v1-avg,v2-avg,...]) */
	'#define CV_COVAR_NORMAL    1
	public const  CV_COVAR_NORMAL as integer =  1

	'/* do not calc average (i.e. mean vector) - use the input vector instead
	'   (useful for calculating covariance matrix by parts) */
	'#define CV_COVAR_USE_AVG   2
	public const  CV_COVAR_USE_AVG as integer =  2

	'/* scale the covariance matrix coefficients by number of the vectors */
	'#define CV_COVAR_SCALE     4
	public const  CV_COVAR_SCALE as integer =  4

	'/* all the input vectors are stored in a single matrix, as its rows */
	'#define CV_COVAR_ROWS      8
	public const  CV_COVAR_ROWS as integer =  8

	'/* all the input vectors are stored in a single matrix, as its columns */
	'#define CV_COVAR_COLS     16
	public const  CV_COVAR_COLS as integer =  16

	'CVAPI(void)  cvCalcCovarMatrix( const CvArr** vects, int count,
	'                                CvArr* cov_mat, CvArr* avg, int flags );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCalcCovarMatrix(byval vects as intptr(),byval count as integer,byval cov_mat as intptr,byval avg as intptr,byval flags as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCalcCovarMatrix(byval vects as intptr,byval count as integer,byval cov_mat as intptr,byval avg as intptr,byval flags as integer)
	end sub

	'#define CV_PCA_DATA_AS_ROW 0 
	public const  CV_PCA_DATA_AS_ROW as integer =  0
	'#define CV_PCA_DATA_AS_COL 1
	public const  CV_PCA_DATA_AS_COL as integer =  1
	'#define CV_PCA_USE_AVG 2
	public const  CV_PCA_USE_AVG as integer =  2
	'CVAPI(void)  cvCalcPCA( const CvArr* data, CvArr* mean,
	'                        CvArr* eigenvals, CvArr* eigenvects, int flags );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCalcPCA(byval data as intptr,byval mean as intptr,byval eigenvals as intptr,byval eigenvects as intptr,byval flags as integer)
	end sub

	'CVAPI(void)  cvProjectPCA( const CvArr* data, const CvArr* mean,
	'                           const CvArr* eigenvects, CvArr* result );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvProjectPCA(byval data as intptr,byval mean as intptr,byval eigenvects as intptr,byval result as intptr)
	end sub

	'CVAPI(void)  cvBackProjectPCA( const CvArr* proj, const CvArr* mean,
	'                               const CvArr* eigenvects, CvArr* result );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvBackProjectPCA(byval proj as intptr,byval mean as intptr,byval eigenvects as intptr,byval result as intptr)
	end sub

	'/* Calculates Mahalanobis(weighted) distance */
	'CVAPI(double)  cvMahalanobis( const CvArr* vec1, const CvArr* vec2, CvArr* mat );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMahalanobis(byval vec1 as intptr,byval vec2 as intptr,byval mat as intptr) as double
	end function
	'#define cvMahalonobis  cvMahalanobis
	'Skip : 

	'/****************************************************************************************\
	'*                                    Array Statistics                                    *
	'\****************************************************************************************/

	'/* Finds sum of array elements */
	'CVAPI(CvScalar)  cvSum( const CvArr* arr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSum(byval arr as intptr) as CvScalar
	end function

	'/* Calculates number of non-zero pixels */
	'CVAPI(int)  cvCountNonZero( const CvArr* arr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCountNonZero(byval arr as intptr) as integer
	end function

	'/* Calculates mean value of array elements */
	'CVAPI(CvScalar)  cvAvg( const CvArr* arr, const CvArr* mask CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvAvg(byval arr as intptr,byval mask as intptr) as CvScalar
	end function

	'/* Calculates mean and standard deviation of pixel values */
	'CVAPI(void)  cvAvgSdv( const CvArr* arr, CvScalar* mean, CvScalar* std_dev,
	'                       const CvArr* mask CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAvgSdv(byval arr as intptr,byref mean as CvScalar,byref std_dev as CvScalar,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAvgSdv(byval arr as intptr,byval mean as intptr,byref std_dev as CvScalar,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAvgSdv(byval arr as intptr,byref mean as CvScalar,byval std_dev as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvAvgSdv(byval arr as intptr,byval mean as intptr,byval std_dev as intptr,byval mask as intptr)
	end sub

	'/* Finds global minimum, maximum and their positions */
	'CVAPI(void)  cvMinMaxLoc( const CvArr* arr, double* min_val, double* max_val,
	'                          CvPoint* min_loc CV_DEFAULT(NULL),
	'                          CvPoint* max_loc CV_DEFAULT(NULL),
	'                          const CvArr* mask CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byref max_val as double,byref min_loc as CvPoint,byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byref max_val as double,byref min_loc as CvPoint,byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byval max_val as intptr,byref min_loc as CvPoint,byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byval max_val as intptr,byref min_loc as CvPoint,byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byref max_val as double,< [In], Out > byval min_loc as CvPoint(),byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byref max_val as double,< [In], Out > byval min_loc as CvPoint(),byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byval max_val as intptr,< [In], Out > byval min_loc as CvPoint(),byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byval max_val as intptr,< [In], Out > byval min_loc as CvPoint(),byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byref max_val as double,byval min_loc as intptr,byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byref max_val as double,byval min_loc as intptr,byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byval max_val as intptr,byval min_loc as intptr,byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byval max_val as intptr,byval min_loc as intptr,byref max_loc as CvPoint,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byref max_val as double,byref min_loc as CvPoint,< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byref max_val as double,byref min_loc as CvPoint,< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byval max_val as intptr,byref min_loc as CvPoint,< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byval max_val as intptr,byref min_loc as CvPoint,< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byref max_val as double,< [In], Out > byval min_loc as CvPoint(),< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byref max_val as double,< [In], Out > byval min_loc as CvPoint(),< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byval max_val as intptr,< [In], Out > byval min_loc as CvPoint(),< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byval max_val as intptr,< [In], Out > byval min_loc as CvPoint(),< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byref max_val as double,byval min_loc as intptr,< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byref max_val as double,byval min_loc as intptr,< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byval max_val as intptr,byval min_loc as intptr,< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byval max_val as intptr,byval min_loc as intptr,< [In], Out > byval max_loc as CvPoint(),byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byref max_val as double,byref min_loc as CvPoint,byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byref max_val as double,byref min_loc as CvPoint,byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byval max_val as intptr,byref min_loc as CvPoint,byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byval max_val as intptr,byref min_loc as CvPoint,byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byref max_val as double,< [In], Out > byval min_loc as CvPoint(),byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byref max_val as double,< [In], Out > byval min_loc as CvPoint(),byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byval max_val as intptr,< [In], Out > byval min_loc as CvPoint(),byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byval max_val as intptr,< [In], Out > byval min_loc as CvPoint(),byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byref max_val as double,byval min_loc as intptr,byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byref max_val as double,byval min_loc as intptr,byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byref min_val as double,byval max_val as intptr,byval min_loc as intptr,byval max_loc as intptr,byval mask as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMinMaxLoc(byval arr as intptr,byval min_val as intptr,byval max_val as intptr,byval min_loc as intptr,byval max_loc as intptr,byval mask as intptr)
	end sub

	'/* types of array norm */
	'#define CV_C            1
	public const  CV_C as integer =  1
	'#define CV_L1           2
	public const  CV_L1 as integer =  2
	'#define CV_L2           4
	public const  CV_L2 as integer =  4
	'#define CV_NORM_MASK    7
	public const  CV_NORM_MASK as integer =  7
	'#define CV_RELATIVE     8
	public const  CV_RELATIVE as integer =  8
	'#define CV_DIFF         16
	public const  CV_DIFF as integer =  16
	'#define CV_MINMAX       32
	public const  CV_MINMAX as integer =  32

	'#define CV_DIFF_C       (CV_DIFF | CV_C)
	public const  CV_DIFF_C as integer =  (CV_DIFF  or  CV_C)
	'#define CV_DIFF_L1      (CV_DIFF | CV_L1)
	public const  CV_DIFF_L1 as integer =  (CV_DIFF  or  CV_L1)
	'#define CV_DIFF_L2      (CV_DIFF | CV_L2)
	public const  CV_DIFF_L2 as integer =  (CV_DIFF  or  CV_L2)
	'#define CV_RELATIVE_C   (CV_RELATIVE | CV_C)
	public const  CV_RELATIVE_C as integer =  (CV_RELATIVE  or  CV_C)
	'#define CV_RELATIVE_L1  (CV_RELATIVE | CV_L1)
	public const  CV_RELATIVE_L1 as integer =  (CV_RELATIVE  or  CV_L1)
	'#define CV_RELATIVE_L2  (CV_RELATIVE | CV_L2)
	public const  CV_RELATIVE_L2 as integer =  (CV_RELATIVE  or  CV_L2)

	'/* Finds norm, difference norm or relative difference norm for an array (or two arrays) */
	'CVAPI(double)  cvNorm( const CvArr* arr1, const CvArr* arr2 CV_DEFAULT(NULL),
	'                       int norm_type CV_DEFAULT(CV_L2),
	'                       const CvArr* mask CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNorm(byval arr1 as intptr,byval arr2 as intptr,byval norm_type as integer,byval mask as intptr) as double
	end function

	'CVAPI(void)  cvNormalize( const CvArr* src, CvArr* dst,
	'                          double a CV_DEFAULT(1.), double b CV_DEFAULT(0.),
	'                          int norm_type CV_DEFAULT(CV_L2),
	'                          const CvArr* mask CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvNormalize(byval src as intptr,byval dst as intptr,byval a as double,byval b as double,byval norm_type as integer,byval mask as intptr)
	end sub


	'#define CV_REDUCE_SUM 0
	public const  CV_REDUCE_SUM as integer =  0
	'#define CV_REDUCE_AVG 1
	public const  CV_REDUCE_AVG as integer =  1
	'#define CV_REDUCE_MAX 2
	public const  CV_REDUCE_MAX as integer =  2
	'#define CV_REDUCE_MIN 3
	public const  CV_REDUCE_MIN as integer =  3

	'CVAPI(void)  cvReduce( const CvArr* src, CvArr* dst, int dim CV_DEFAULT(-1),
	'                       int op CV_DEFAULT(CV_REDUCE_SUM) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReduce(byval src as intptr,byval dst as intptr,byval [dim] as integer,byval op as integer)
	end sub

	'/****************************************************************************************\
	'*                      Discrete Linear Transforms and Related Functions                  *
	'\****************************************************************************************/

	'#define CV_DXT_FORWARD  0
	public const  CV_DXT_FORWARD as integer =  0
	'#define CV_DXT_INVERSE  1
	public const  CV_DXT_INVERSE as integer =  1
	'#define CV_DXT_SCALE    2 /* divide result by size of array */
	public const  CV_DXT_SCALE as integer =  2
	'#define CV_DXT_INV_SCALE (CV_DXT_INVERSE + CV_DXT_SCALE)
	public const  CV_DXT_INV_SCALE as integer =  (CV_DXT_INVERSE + CV_DXT_SCALE)
	'#define CV_DXT_INVERSE_SCALE CV_DXT_INV_SCALE
	public const  CV_DXT_INVERSE_SCALE as integer =  CV_DXT_INV_SCALE
	'#define CV_DXT_ROWS     4 /* transform each row individually */
	public const  CV_DXT_ROWS as integer =  4
	'#define CV_DXT_MUL_CONJ 8 /* conjugate the second argument of cvMulSpectrums */
	public const  CV_DXT_MUL_CONJ as integer =  8

	'/* Discrete Fourier Transform:
	'    complex->complex,
	'    real->ccs (forward),
	'    ccs->real (inverse) */
	'CVAPI(void)  cvDFT( const CvArr* src, CvArr* dst, int flags,
	'                    int nonzero_rows CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvDFT(byval src as intptr,byval dst as intptr,byval flags as integer,byval nonzero_rows as integer)
	end sub
	'#define cvFFT cvDFT
	'Skip : 

	'/* Multiply results of DFTs: DFT(X)*DFT(Y) or DFT(X)*conj(DFT(Y)) */
	'CVAPI(void)  cvMulSpectrums( const CvArr* src1, const CvArr* src2,
	'                             CvArr* dst, int flags );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMulSpectrums(byval src1 as intptr,byval src2 as intptr,byval dst as intptr,byval flags as integer)
	end sub

	'/* Finds optimal DFT vector size >= size0 */
	'CVAPI(int)  cvGetOptimalDFTSize( int size0 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetOptimalDFTSize(byval size0 as integer) as integer
	end function

	'/* Discrete Cosine Transform */
	'CVAPI(void)  cvDCT( const CvArr* src, CvArr* dst, int flags );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvDCT(byval src as intptr,byval dst as intptr,byval flags as integer)
	end sub

	'/****************************************************************************************\
	'*                              Dynamic data structures                                   *
	'\****************************************************************************************/

	'/* Calculates length of sequence slice (with support of negative indices). */
	'CVAPI(int) cvSliceLength( CvSlice slice, const CvSeq* seq );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSliceLength(byval slice as CvSlice,byref seq as CvSeq) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSliceLength(byval slice as CvSlice,byval seq as intptr) as integer
	end function


	'/* Creates new memory storage.
	'   block_size == 0 means that default,
	'   somewhat optimal size, is used (currently, it is 64K) */
	'CVAPI(CvMemStorage*)  cvCreateMemStorage( int block_size CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateMemStorage(byval block_size as integer) as IntPtr
	end function


	'/* Creates a memory storage that will borrow memory blocks from parent storage */
	'CVAPI(CvMemStorage*)  cvCreateChildMemStorage( CvMemStorage* parent );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateChildMemStorage(byref parent as CvMemStorage) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateChildMemStorage(byval parent as intptr) as IntPtr
	end function


	'/* Releases memory storage. All the children of a parent must be released before
	'   the parent. A child storage returns all the blocks to parent when it is released */
	'CVAPI(void)  cvReleaseMemStorage( CvMemStorage** storage );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReleaseMemStorage(byref storage as intptr)
	end sub


	'/* Clears memory storage. This is the only way(!!!) (besides cvRestoreMemStoragePos)
	'   to reuse memory allocated for the storage - cvClearSeq,cvClearSet ...
	'   do not free any memory.
	'   A child storage returns all the blocks to the parent when it is cleared */
	'CVAPI(void)  cvClearMemStorage( CvMemStorage* storage );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearMemStorage(byref storage as CvMemStorage)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearMemStorage(byval storage as intptr)
	end sub

	'/* Remember a storage "free memory" position */
	'CVAPI(void)  cvSaveMemStoragePos( const CvMemStorage* storage, CvMemStoragePos* pos );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSaveMemStoragePos(byref storage as CvMemStorage,byref pos as CvMemStoragePos)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSaveMemStoragePos(byval storage as intptr,byref pos as CvMemStoragePos)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSaveMemStoragePos(byref storage as CvMemStorage,byval pos as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSaveMemStoragePos(byval storage as intptr,byval pos as intptr)
	end sub

	'/* Restore a storage "free memory" position */
	'CVAPI(void)  cvRestoreMemStoragePos( CvMemStorage* storage, CvMemStoragePos* pos );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRestoreMemStoragePos(byref storage as CvMemStorage,byref pos as CvMemStoragePos)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRestoreMemStoragePos(byval storage as intptr,byref pos as CvMemStoragePos)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRestoreMemStoragePos(byref storage as CvMemStorage,byval pos as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRestoreMemStoragePos(byval storage as intptr,byval pos as intptr)
	end sub

	'/* Allocates continuous buffer of the specified size in the storage */
	'CVAPI(void*) cvMemStorageAlloc( CvMemStorage* storage, size_t size );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMemStorageAlloc(byref storage as CvMemStorage,byval size as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMemStorageAlloc(byval storage as intptr,byval size as integer) as IntPtr
	end function

	'/* Allocates string in memory storage */
	'CVAPI(CvString) cvMemStorageAllocString( CvMemStorage* storage, const char* ptr,
	'                                        int len CV_DEFAULT(-1) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMemStorageAllocString(byref storage as CvMemStorage,byval ptr as string,byval len as integer) as CvString
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMemStorageAllocString(byval storage as intptr,byval ptr as string,byval len as integer) as CvString
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMemStorageAllocString(byref storage as CvMemStorage,byval ptr as byte(),byval len as integer) as CvString
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMemStorageAllocString(byval storage as intptr,byval ptr as byte(),byval len as integer) as CvString
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMemStorageAllocString(byref storage as CvMemStorage,byval ptr as intptr,byval len as integer) as CvString
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMemStorageAllocString(byval storage as intptr,byval ptr as intptr,byval len as integer) as CvString
	end function

	'/* Creates new empty sequence that will reside in the specified storage */
	'CVAPI(CvSeq*)  cvCreateSeq( int seq_flags, int header_size,
	'                            int elem_size, CvMemStorage* storage );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateSeq(byval seq_flags as integer,byval header_size as integer,byval elem_size as integer,byref storage as CvMemStorage) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateSeq(byval seq_flags as integer,byval header_size as integer,byval elem_size as integer,byval storage as intptr) as IntPtr
	end function

	'/* Changes default size (granularity) of sequence blocks.
	'   The default size is ~1Kbyte */
	'CVAPI(void)  cvSetSeqBlockSize( CvSeq* seq, int delta_elems );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetSeqBlockSize(byref seq as CvSeq,byval delta_elems as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetSeqBlockSize(byval seq as intptr,byval delta_elems as integer)
	end sub


	'/* Adds new element to the end of sequence. Returns pointer to the element */
	'CVAPI(char*)  cvSeqPush( CvSeq* seq, void* element CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqPush(byref seq as CvSeq,byval element as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqPush(byval seq as intptr,byval element as intptr) as IntPtr
	end function


	'/* Adds new element to the beginning of sequence. Returns pointer to it */
	'CVAPI(char*)  cvSeqPushFront( CvSeq* seq, void* element CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqPushFront(byref seq as CvSeq,byval element as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqPushFront(byval seq as intptr,byval element as intptr) as IntPtr
	end function


	'/* Removes the last element from sequence and optionally saves it */
	'CVAPI(void)  cvSeqPop( CvSeq* seq, void* element CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqPop(byref seq as CvSeq,byval element as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqPop(byval seq as intptr,byval element as intptr)
	end sub


	'/* Removes the first element from sequence and optioanally saves it */
	'CVAPI(void)  cvSeqPopFront( CvSeq* seq, void* element CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqPopFront(byref seq as CvSeq,byval element as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqPopFront(byval seq as intptr,byval element as intptr)
	end sub


	'#define CV_FRONT 1
	public const  CV_FRONT as integer =  1
	'#define CV_BACK 0
	public const  CV_BACK as integer =  0
	'/* Adds several new elements to the end of sequence */
	'CVAPI(void)  cvSeqPushMulti( CvSeq* seq, void* elements,
	'                             int count, int in_front CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqPushMulti(byref seq as CvSeq,byval elements as intptr,byval count as integer,byval in_front as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqPushMulti(byval seq as intptr,byval elements as intptr,byval count as integer,byval in_front as integer)
	end sub

	'/* Removes several elements from the end of sequence and optionally saves them */
	'CVAPI(void)  cvSeqPopMulti( CvSeq* seq, void* elements,
	'                            int count, int in_front CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqPopMulti(byref seq as CvSeq,byval elements as intptr,byval count as integer,byval in_front as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqPopMulti(byval seq as intptr,byval elements as intptr,byval count as integer,byval in_front as integer)
	end sub

	'/* Inserts a new element in the middle of sequence.
	'   cvSeqInsert(seq,0,elem) == cvSeqPushFront(seq,elem) */
	'CVAPI(char*)  cvSeqInsert( CvSeq* seq, int before_index,
	'                           void* element CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqInsert(byref seq as CvSeq,byval before_index as integer,byval element as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqInsert(byval seq as intptr,byval before_index as integer,byval element as intptr) as IntPtr
	end function

	'/* Removes specified sequence element */
	'CVAPI(void)  cvSeqRemove( CvSeq* seq, int index );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqRemove(byref seq as CvSeq,byval index as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqRemove(byval seq as intptr,byval index as integer)
	end sub


	'/* Removes all the elements from the sequence. The freed memory
	'   can be reused later only by the same sequence unless cvClearMemStorage
	'   or cvRestoreMemStoragePos is called */
	'CVAPI(void)  cvClearSeq( CvSeq* seq );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearSeq(byref seq as CvSeq)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearSeq(byval seq as intptr)
	end sub


	'/* Retrives pointer to specified sequence element.
	'   Negative indices are supported and mean counting from the end
	'   (e.g -1 means the last sequence element) */
	'CVAPI(char*)  cvGetSeqElem( const CvSeq* seq, int index );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetSeqElem(byref seq as CvSeq,byval index as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetSeqElem(byval seq as intptr,byval index as integer) as IntPtr
	end function

	'/* Calculates index of the specified sequence element.
	'   Returns -1 if element does not belong to the sequence */
	'CVAPI(int)  cvSeqElemIdx( const CvSeq* seq, const void* element,
	'                         CvSeqBlock** block CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqElemIdx(byref seq as CvSeq,byval element as intptr,byref block as CvSeqBlock) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqElemIdx(byval seq as intptr,byval element as intptr,byref block as CvSeqBlock) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqElemIdx(byref seq as CvSeq,byval element as intptr,byval block as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqElemIdx(byval seq as intptr,byval element as intptr,byval block as intptr) as integer
	end function

	'/* Initializes sequence writer. The new elements will be added to the end of sequence */
	'CVAPI(void)  cvStartAppendToSeq( CvSeq* seq, CvSeqWriter* writer );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartAppendToSeq(byref seq as CvSeq,byref writer as CvSeqWriter)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartAppendToSeq(byval seq as intptr,byref writer as CvSeqWriter)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartAppendToSeq(byref seq as CvSeq,byval writer as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartAppendToSeq(byval seq as intptr,byval writer as intptr)
	end sub


	'/* Combination of cvCreateSeq and cvStartAppendToSeq */
	'CVAPI(void)  cvStartWriteSeq( int seq_flags, int header_size,
	'                              int elem_size, CvMemStorage* storage,
	'                              CvSeqWriter* writer );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteSeq(byval seq_flags as integer,byval header_size as integer,byval elem_size as integer,byref storage as CvMemStorage,byref writer as CvSeqWriter)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteSeq(byval seq_flags as integer,byval header_size as integer,byval elem_size as integer,byval storage as intptr,byref writer as CvSeqWriter)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteSeq(byval seq_flags as integer,byval header_size as integer,byval elem_size as integer,byref storage as CvMemStorage,byval writer as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteSeq(byval seq_flags as integer,byval header_size as integer,byval elem_size as integer,byval storage as intptr,byval writer as intptr)
	end sub

	'/* Closes sequence writer, updates sequence header and returns pointer
	'   to the resultant sequence
	'   (which may be useful if the sequence was created using cvStartWriteSeq))
	'*/
	'CVAPI(CvSeq*)  cvEndWriteSeq( CvSeqWriter* writer );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvEndWriteSeq(byref writer as CvSeqWriter) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvEndWriteSeq(byval writer as intptr) as IntPtr
	end function


	'/* Updates sequence header. May be useful to get access to some of previously
	'   written elements via cvGetSeqElem or sequence reader */
	'CVAPI(void)   cvFlushSeqWriter( CvSeqWriter* writer );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFlushSeqWriter(byref writer as CvSeqWriter)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFlushSeqWriter(byval writer as intptr)
	end sub


	'/* Initializes sequence reader.
	'   The sequence can be read in forward or backward direction */
	'CVAPI(void) cvStartReadSeq( const CvSeq* seq, CvSeqReader* reader,
	'                           int reverse CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartReadSeq(byref seq as CvSeq,byref reader as CvSeqReader,byval reverse as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartReadSeq(byval seq as intptr,byref reader as CvSeqReader,byval reverse as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartReadSeq(byref seq as CvSeq,byval reader as intptr,byval reverse as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartReadSeq(byval seq as intptr,byval reader as intptr,byval reverse as integer)
	end sub


	'/* Returns current sequence reader position (currently observed sequence element) */
	'CVAPI(int)  cvGetSeqReaderPos( CvSeqReader* reader );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetSeqReaderPos(byref reader as CvSeqReader) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetSeqReaderPos(byval reader as intptr) as integer
	end function


	'/* Changes sequence reader position. It may seek to an absolute or
	'   to relative to the current position */
	'CVAPI(void)   cvSetSeqReaderPos( CvSeqReader* reader, int index,
	'                                 int is_relative CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetSeqReaderPos(byref reader as CvSeqReader,byval index as integer,byval is_relative as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetSeqReaderPos(byval reader as intptr,byval index as integer,byval is_relative as integer)
	end sub

	'/* Copies sequence content to a continuous piece of memory */
	'CVAPI(void*)  cvCvtSeqToArray( const CvSeq* seq, void* elements,
	'                               CvSlice slice CV_DEFAULT(CV_WHOLE_SEQ) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCvtSeqToArray(byref seq as CvSeq,byval elements as intptr,byval slice as CvSlice) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCvtSeqToArray(byval seq as intptr,byval elements as intptr,byval slice as CvSlice) as IntPtr
	end function

	'/* Creates sequence header for array.
	'   After that all the operations on sequences that do not alter the content
	'   can be applied to the resultant sequence */
	'CVAPI(CvSeq*) cvMakeSeqHeaderForArray( int seq_type, int header_size,
	'                                       int elem_size, void* elements, int total,
	'                                       CvSeq* seq, CvSeqBlock* block );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMakeSeqHeaderForArray(byval seq_type as integer,byval header_size as integer,byval elem_size as integer,byval elements as intptr,byval total as integer,byref seq as CvSeq,byref block as CvSeqBlock) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMakeSeqHeaderForArray(byval seq_type as integer,byval header_size as integer,byval elem_size as integer,byval elements as intptr,byval total as integer,byval seq as intptr,byref block as CvSeqBlock) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMakeSeqHeaderForArray(byval seq_type as integer,byval header_size as integer,byval elem_size as integer,byval elements as intptr,byval total as integer,byref seq as CvSeq,byval block as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvMakeSeqHeaderForArray(byval seq_type as integer,byval header_size as integer,byval elem_size as integer,byval elements as intptr,byval total as integer,byval seq as intptr,byval block as intptr) as IntPtr
	end function

	'/* Extracts sequence slice (with or without copying sequence elements) */
	'CVAPI(CvSeq*) cvSeqSlice( const CvSeq* seq, CvSlice slice,
	'                         CvMemStorage* storage CV_DEFAULT(NULL),
	'                         int copy_data CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqSlice(byref seq as CvSeq,byval slice as CvSlice,byref storage as CvMemStorage,byval copy_data as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqSlice(byval seq as intptr,byval slice as CvSlice,byref storage as CvMemStorage,byval copy_data as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqSlice(byref seq as CvSeq,byval slice as CvSlice,byval storage as intptr,byval copy_data as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqSlice(byval seq as intptr,byval slice as CvSlice,byval storage as intptr,byval copy_data as integer) as IntPtr
	end function

	'CV_INLINE CvSeq* cvCloneSeq( const CvSeq* seq, CvMemStorage* storage CV_DEFAULT(NULL))
	'{
	'    return cvSeqSlice( seq, CV_WHOLE_SEQ, storage, 1 );
	'}
	'ToDo : Function

	'/* Removes sequence slice */
	'CVAPI(void)  cvSeqRemoveSlice( CvSeq* seq, CvSlice slice );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqRemoveSlice(byref seq as CvSeq,byval slice as CvSlice)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqRemoveSlice(byval seq as intptr,byval slice as CvSlice)
	end sub

	'/* Inserts a sequence or array into another sequence */
	'CVAPI(void)  cvSeqInsertSlice( CvSeq* seq, int before_index, const CvArr* from_arr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqInsertSlice(byref seq as CvSeq,byval before_index as integer,byval from_arr as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqInsertSlice(byval seq as intptr,byval before_index as integer,byval from_arr as intptr)
	end sub

	'/* a < b ? -1 : a > b ? 1 : 0 */
	'typedef int (CV_CDECL* CvCmpFunc)(const void* a, const void* b, void* userdata );
	'Typedef : Unsupport

	'/* Sorts sequence in-place given element comparison function */
	'CVAPI(void) cvSeqSort( CvSeq* seq, CvCmpFunc func, void* userdata CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqSort(byref seq as CvSeq,byval func as intptr,byval userdata as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqSort(byval seq as intptr,byval func as intptr,byval userdata as intptr)
	end sub

	'/* Finds element in a [sorted] sequence */
	'CVAPI(char*) cvSeqSearch( CvSeq* seq, const void* elem, CvCmpFunc func,
	'                          int is_sorted, int* elem_idx,
	'                          void* userdata CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqSearch(byref seq as CvSeq,byval elem as intptr,byval func as intptr,byval is_sorted as integer,byval elem_idx as integer(),byval userdata as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqSearch(byval seq as intptr,byval elem as intptr,byval func as intptr,byval is_sorted as integer,byval elem_idx as integer(),byval userdata as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqSearch(byref seq as CvSeq,byval elem as intptr,byval func as intptr,byval is_sorted as integer,byref elem_idx as integer,byval userdata as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqSearch(byval seq as intptr,byval elem as intptr,byval func as intptr,byval is_sorted as integer,byref elem_idx as integer,byval userdata as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqSearch(byref seq as CvSeq,byval elem as intptr,byval func as intptr,byval is_sorted as integer,byval elem_idx as intptr,byval userdata as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqSearch(byval seq as intptr,byval elem as intptr,byval func as intptr,byval is_sorted as integer,byval elem_idx as intptr,byval userdata as intptr) as IntPtr
	end function

	'/* Reverses order of sequence elements in-place */
	'CVAPI(void) cvSeqInvert( CvSeq* seq );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqInvert(byref seq as CvSeq)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSeqInvert(byval seq as intptr)
	end sub

	'/* Splits sequence into one or more equivalence classes using the specified criteria */
	'CVAPI(int)  cvSeqPartition( const CvSeq* seq, CvMemStorage* storage,
	'                            CvSeq** labels, CvCmpFunc is_equal, void* userdata );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqPartition(byref seq as CvSeq,byref storage as CvMemStorage,ByRef labels As intptr,byval is_equal as intptr,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqPartition(byval seq as intptr,byref storage as CvMemStorage,ByRef labels As intptr,byval is_equal as intptr,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqPartition(byref seq as CvSeq,byval storage as intptr,ByRef labels As intptr,byval is_equal as intptr,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSeqPartition(byval seq as intptr,byval storage as intptr,ByRef labels As intptr,byval is_equal as intptr,byval userdata as intptr) as integer
	end function

	'/************ Internal sequence functions ************/
	'CVAPI(void)  cvChangeSeqBlock( void* reader, int direction );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvChangeSeqBlock(byval reader as intptr,byval direction as integer)
	end sub
	'CVAPI(void)  cvCreateSeqBlock( CvSeqWriter* writer );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCreateSeqBlock(byref writer as CvSeqWriter)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCreateSeqBlock(byval writer as intptr)
	end sub


	'/* Creates a new set */
	'CVAPI(CvSet*)  cvCreateSet( int set_flags, int header_size,
	'                            int elem_size, CvMemStorage* storage );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateSet(byval set_flags as integer,byval header_size as integer,byval elem_size as integer,byref storage as CvMemStorage) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateSet(byval set_flags as integer,byval header_size as integer,byval elem_size as integer,byval storage as intptr) as IntPtr
	end function

	'/* Adds new element to the set and returns pointer to it */
	'CVAPI(int)  cvSetAdd( CvSet* set_header, CvSetElem* elem CV_DEFAULT(NULL),
	'                      CvSetElem** inserted_elem CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSetAdd(byref set_header as CvSet,byref elem as CvSetElem,byref inserted_elem as CvSetElem) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSetAdd(byval set_header as intptr,byref elem as CvSetElem,byref inserted_elem as CvSetElem) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSetAdd(byref set_header as CvSet,byval elem as intptr,byref inserted_elem as CvSetElem) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSetAdd(byval set_header as intptr,byval elem as intptr,byref inserted_elem as CvSetElem) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSetAdd(byref set_header as CvSet,byref elem as CvSetElem,byval inserted_elem as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSetAdd(byval set_header as intptr,byref elem as CvSetElem,byval inserted_elem as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSetAdd(byref set_header as CvSet,byval elem as intptr,byval inserted_elem as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSetAdd(byval set_header as intptr,byval elem as intptr,byval inserted_elem as intptr) as integer
	end function

	'/* Fast variant of cvSetAdd */
	'CV_INLINE  CvSetElem* cvSetNew( CvSet* set_header )
	'{
	'    CvSetElem* elem = set_header->free_elems;
	'    if( elem )
	'    {
	'        set_header->free_elems = elem->next_free;
	'        elem->flags = elem->flags & CV_SET_ELEM_IDX_MASK;
	'        set_header->active_count++;
	'    }
	'    else
	'        cvSetAdd( set_header, NULL, (CvSetElem**)&elem );
	'    return elem;
	'}
	'ToDo : Function

	'/* Removes set element given its pointer */
	'CV_INLINE  void cvSetRemoveByPtr( CvSet* set_header, void* elem )
	'{
	'    CvSetElem* _elem = (CvSetElem*)elem;
	'    assert( _elem->flags >= 0 /*&& (elem->flags & CV_SET_ELEM_IDX_MASK) < set_header->total*/ );
	'    _elem->next_free = set_header->free_elems;
	'    _elem->flags = (_elem->flags & CV_SET_ELEM_IDX_MASK) | CV_SET_ELEM_FREE_FLAG;
	'    set_header->free_elems = _elem;
	'    set_header->active_count--;
	'}
	'ToDo : Function

	'/* Removes element from the set by its index  */
	'CVAPI(void)   cvSetRemove( CvSet* set_header, int index );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetRemove(byref set_header as CvSet,byval index as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetRemove(byval set_header as intptr,byval index as integer)
	end sub

	'/* Returns a set element by index. If the element doesn't belong to the set,
	'   NULL is returned */
	'CV_INLINE CvSetElem* cvGetSetElem( const CvSet* set_header, int index )
	'{
	'    CvSetElem* elem = (CvSetElem*)cvGetSeqElem( (CvSeq*)set_header, index );
	'    return elem && CV_IS_SET_ELEM( elem ) ? elem : 0;
	'}
	'ToDo : Function

	'/* Removes all the elements from the set */
	'CVAPI(void)  cvClearSet( CvSet* set_header );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearSet(byref set_header as CvSet)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearSet(byval set_header as intptr)
	end sub

	'/* Creates new graph */
	'CVAPI(CvGraph*)  cvCreateGraph( int graph_flags, int header_size,
	'                                int vtx_size, int edge_size,
	'                                CvMemStorage* storage );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateGraph(byval graph_flags as integer,byval header_size as integer,byval vtx_size as integer,byval edge_size as integer,byref storage as CvMemStorage) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateGraph(byval graph_flags as integer,byval header_size as integer,byval vtx_size as integer,byval edge_size as integer,byval storage as intptr) as IntPtr
	end function

	'/* Adds new vertex to the graph */
	'CVAPI(int)  cvGraphAddVtx( CvGraph* graph, const CvGraphVtx* vtx CV_DEFAULT(NULL),
	'                           CvGraphVtx** inserted_vtx CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddVtx(byref graph as CvGraph,byref vtx as CvGraphVtx,byref inserted_vtx as CvGraphVtx) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddVtx(byval graph as intptr,byref vtx as CvGraphVtx,byref inserted_vtx as CvGraphVtx) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddVtx(byref graph as CvGraph,byval vtx as intptr,byref inserted_vtx as CvGraphVtx) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddVtx(byval graph as intptr,byval vtx as intptr,byref inserted_vtx as CvGraphVtx) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddVtx(byref graph as CvGraph,byref vtx as CvGraphVtx,byval inserted_vtx as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddVtx(byval graph as intptr,byref vtx as CvGraphVtx,byval inserted_vtx as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddVtx(byref graph as CvGraph,byval vtx as intptr,byval inserted_vtx as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddVtx(byval graph as intptr,byval vtx as intptr,byval inserted_vtx as intptr) as integer
	end function


	'/* Removes vertex from the graph together with all incident edges */
	'CVAPI(int)  cvGraphRemoveVtx( CvGraph* graph, int index );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphRemoveVtx(byref graph as CvGraph,byval index as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphRemoveVtx(byval graph as intptr,byval index as integer) as integer
	end function
	'CVAPI(int)  cvGraphRemoveVtxByPtr( CvGraph* graph, CvGraphVtx* vtx );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphRemoveVtxByPtr(byref graph as CvGraph,byref vtx as CvGraphVtx) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphRemoveVtxByPtr(byval graph as intptr,byref vtx as CvGraphVtx) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphRemoveVtxByPtr(byref graph as CvGraph,byval vtx as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphRemoveVtxByPtr(byval graph as intptr,byval vtx as intptr) as integer
	end function


	'/* Link two vertices specifed by indices or pointers if they
	'   are not connected or return pointer to already existing edge
	'   connecting the vertices.
	'   Functions return 1 if a new edge was created, 0 otherwise */
	'CVAPI(int)  cvGraphAddEdge( CvGraph* graph,
	'                            int start_idx, int end_idx,
	'                            const CvGraphEdge* edge CV_DEFAULT(NULL),
	'                            CvGraphEdge** inserted_edge CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdge(byref graph as CvGraph,byval start_idx as integer,byval end_idx as integer,byref edge as CvGraphEdge,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdge(byval graph as intptr,byval start_idx as integer,byval end_idx as integer,byref edge as CvGraphEdge,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdge(byref graph as CvGraph,byval start_idx as integer,byval end_idx as integer,byval edge as intptr,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdge(byval graph as intptr,byval start_idx as integer,byval end_idx as integer,byval edge as intptr,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdge(byref graph as CvGraph,byval start_idx as integer,byval end_idx as integer,byref edge as CvGraphEdge,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdge(byval graph as intptr,byval start_idx as integer,byval end_idx as integer,byref edge as CvGraphEdge,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdge(byref graph as CvGraph,byval start_idx as integer,byval end_idx as integer,byval edge as intptr,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdge(byval graph as intptr,byval start_idx as integer,byval end_idx as integer,byval edge as intptr,byval inserted_edge as intptr) as integer
	end function

	'CVAPI(int)  cvGraphAddEdgeByPtr( CvGraph* graph,
	'                               CvGraphVtx* start_vtx, CvGraphVtx* end_vtx,
	'                               const CvGraphEdge* edge CV_DEFAULT(NULL),
	'                               CvGraphEdge** inserted_edge CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx,byref edge as CvGraphEdge,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx,byref edge as CvGraphEdge,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byref end_vtx as CvGraphVtx,byref edge as CvGraphEdge,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byref end_vtx as CvGraphVtx,byref edge as CvGraphEdge,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byval end_vtx as intptr,byref edge as CvGraphEdge,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byval end_vtx as intptr,byref edge as CvGraphEdge,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byval end_vtx as intptr,byref edge as CvGraphEdge,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byval end_vtx as intptr,byref edge as CvGraphEdge,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx,byval edge as intptr,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx,byval edge as intptr,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byref end_vtx as CvGraphVtx,byval edge as intptr,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byref end_vtx as CvGraphVtx,byval edge as intptr,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byval end_vtx as intptr,byval edge as intptr,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byval end_vtx as intptr,byval edge as intptr,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byval end_vtx as intptr,byval edge as intptr,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byval end_vtx as intptr,byval edge as intptr,byref inserted_edge as CvGraphEdge) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx,byref edge as CvGraphEdge,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx,byref edge as CvGraphEdge,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byref end_vtx as CvGraphVtx,byref edge as CvGraphEdge,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byref end_vtx as CvGraphVtx,byref edge as CvGraphEdge,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byval end_vtx as intptr,byref edge as CvGraphEdge,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byval end_vtx as intptr,byref edge as CvGraphEdge,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byval end_vtx as intptr,byref edge as CvGraphEdge,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byval end_vtx as intptr,byref edge as CvGraphEdge,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx,byval edge as intptr,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx,byval edge as intptr,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byref end_vtx as CvGraphVtx,byval edge as intptr,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byref end_vtx as CvGraphVtx,byval edge as intptr,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byval end_vtx as intptr,byval edge as intptr,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byval end_vtx as intptr,byval edge as intptr,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byval end_vtx as intptr,byval edge as intptr,byval inserted_edge as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphAddEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byval end_vtx as intptr,byval edge as intptr,byval inserted_edge as intptr) as integer
	end function

	'/* Remove edge connecting two vertices */
	'CVAPI(void)  cvGraphRemoveEdge( CvGraph* graph, int start_idx, int end_idx );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGraphRemoveEdge(byref graph as CvGraph,byval start_idx as integer,byval end_idx as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGraphRemoveEdge(byval graph as intptr,byval start_idx as integer,byval end_idx as integer)
	end sub
	'CVAPI(void)  cvGraphRemoveEdgeByPtr( CvGraph* graph, CvGraphVtx* start_vtx,
	'                                     CvGraphVtx* end_vtx );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGraphRemoveEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGraphRemoveEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGraphRemoveEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byref end_vtx as CvGraphVtx)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGraphRemoveEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byref end_vtx as CvGraphVtx)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGraphRemoveEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byval end_vtx as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGraphRemoveEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byval end_vtx as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGraphRemoveEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byval end_vtx as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGraphRemoveEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byval end_vtx as intptr)
	end sub

	'/* Find edge connecting two vertices */
	'CVAPI(CvGraphEdge*)  cvFindGraphEdge( const CvGraph* graph, int start_idx, int end_idx );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindGraphEdge(byref graph as CvGraph,byval start_idx as integer,byval end_idx as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindGraphEdge(byval graph as intptr,byval start_idx as integer,byval end_idx as integer) as IntPtr
	end function
	'CVAPI(CvGraphEdge*)  cvFindGraphEdgeByPtr( const CvGraph* graph,
	'                                           const CvGraphVtx* start_vtx,
	'                                           const CvGraphVtx* end_vtx );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindGraphEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindGraphEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byref end_vtx as CvGraphVtx) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindGraphEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byref end_vtx as CvGraphVtx) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindGraphEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byref end_vtx as CvGraphVtx) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindGraphEdgeByPtr(byref graph as CvGraph,byref start_vtx as CvGraphVtx,byval end_vtx as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindGraphEdgeByPtr(byval graph as intptr,byref start_vtx as CvGraphVtx,byval end_vtx as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindGraphEdgeByPtr(byref graph as CvGraph,byval start_vtx as intptr,byval end_vtx as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindGraphEdgeByPtr(byval graph as intptr,byval start_vtx as intptr,byval end_vtx as intptr) as IntPtr
	end function
	'#define cvGraphFindEdge cvFindGraphEdge
	'Skip : 
	'#define cvGraphFindEdgeByPtr cvFindGraphEdgeByPtr
	'Skip : 

	'/* Remove all vertices and edges from the graph */
	'CVAPI(void)  cvClearGraph( CvGraph* graph );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearGraph(byref graph as CvGraph)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvClearGraph(byval graph as intptr)
	end sub


	'/* Count number of edges incident to the vertex */
	'CVAPI(int)  cvGraphVtxDegree( const CvGraph* graph, int vtx_idx );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphVtxDegree(byref graph as CvGraph,byval vtx_idx as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphVtxDegree(byval graph as intptr,byval vtx_idx as integer) as integer
	end function
	'CVAPI(int)  cvGraphVtxDegreeByPtr( const CvGraph* graph, const CvGraphVtx* vtx );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphVtxDegreeByPtr(byref graph as CvGraph,byref vtx as CvGraphVtx) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphVtxDegreeByPtr(byval graph as intptr,byref vtx as CvGraphVtx) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphVtxDegreeByPtr(byref graph as CvGraph,byval vtx as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGraphVtxDegreeByPtr(byval graph as intptr,byval vtx as intptr) as integer
	end function


	'/* Retrieves graph vertex by given index */
	'#define cvGetGraphVtx( graph, idx ) (CvGraphVtx*)cvGetSetElem((CvSet*)(graph), (idx))
	'Skip : 

	'/* Retrieves index of a graph vertex given its pointer */
	'#define cvGraphVtxIdx( graph, vtx ) ((vtx)->flags & CV_SET_ELEM_IDX_MASK)
	'Skip : 

	'/* Retrieves index of a graph edge given its pointer */
	'#define cvGraphEdgeIdx( graph, edge ) ((edge)->flags & CV_SET_ELEM_IDX_MASK)
	'Skip : 

	'#define cvGraphGetVtxCount( graph ) ((graph)->active_count)
	'Skip : 
	'#define cvGraphGetEdgeCount( graph ) ((graph)->edges->active_count)
	'Skip : 

	'#define  CV_GRAPH_VERTEX        1
	public const  CV_GRAPH_VERTEX as integer =  1
	'#define  CV_GRAPH_TREE_EDGE     2
	public const  CV_GRAPH_TREE_EDGE as integer =  2
	'#define  CV_GRAPH_BACK_EDGE     4
	public const  CV_GRAPH_BACK_EDGE as integer =  4
	'#define  CV_GRAPH_FORWARD_EDGE  8
	public const  CV_GRAPH_FORWARD_EDGE as integer =  8
	'#define  CV_GRAPH_CROSS_EDGE    16
	public const  CV_GRAPH_CROSS_EDGE as integer =  16
	'#define  CV_GRAPH_ANY_EDGE      30
	public const  CV_GRAPH_ANY_EDGE as integer =  30
	'#define  CV_GRAPH_NEW_TREE      32
	public const  CV_GRAPH_NEW_TREE as integer =  32
	'#define  CV_GRAPH_BACKTRACKING  64
	public const  CV_GRAPH_BACKTRACKING as integer =  64
	'#define  CV_GRAPH_OVER          -1
	public const  CV_GRAPH_OVER as integer =  -1

	'#define  CV_GRAPH_ALL_ITEMS    -1
	public const  CV_GRAPH_ALL_ITEMS as integer =  -1

	'/* flags for graph vertices and edges */
	'#define  CV_GRAPH_ITEM_VISITED_FLAG  (1 << 30)
	public const  CV_GRAPH_ITEM_VISITED_FLAG as integer =  (1 << 30)
	'#define  CV_IS_GRAPH_VERTEX_VISITED(vtx) \
	'    (((CvGraphVtx*)(vtx))->flags & CV_GRAPH_ITEM_VISITED_FLAG)
	'ToDo : 
	'#define  CV_IS_GRAPH_EDGE_VISITED(edge) \
	'    (((CvGraphEdge*)(edge))->flags & CV_GRAPH_ITEM_VISITED_FLAG)
	'ToDo : 
	'#define  CV_GRAPH_SEARCH_TREE_NODE_FLAG   (1 << 29)
	public const  CV_GRAPH_SEARCH_TREE_NODE_FLAG as integer =  (1 << 29)
	'#define  CV_GRAPH_FORWARD_EDGE_FLAG       (1 << 28)
	public const  CV_GRAPH_FORWARD_EDGE_FLAG as integer =  (1 << 28)

	'typedef struct CvGraphScanner
	'{
	'    CvGraphVtx* vtx;       /* current graph vertex (or current edge origin) */
	'    CvGraphVtx* dst;       /* current graph edge destination vertex */
	'    CvGraphEdge* edge;     /* current edge */

	'    CvGraph* graph;        /* the graph */
	'    CvSeq*   stack;        /* the graph vertex stack */
	'    int      index;        /* the lower bound of certainly visited vertices */
	'    int      mask;         /* event mask */
	'}
	'CvGraphScanner;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvGraphScanner
        Public vtx As IntPtr
        Public dst As IntPtr
        Public edge As IntPtr
        Public graph As IntPtr
        Public stack As IntPtr
        Public index As Integer
        Public mask As Integer
    End Structure



	'/* Creates new graph scanner. */
	'CVAPI(CvGraphScanner*)  cvCreateGraphScanner( CvGraph* graph,
	'                                             CvGraphVtx* vtx CV_DEFAULT(NULL),
	'                                             int mask CV_DEFAULT(CV_GRAPH_ALL_ITEMS));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateGraphScanner(byref graph as CvGraph,byref vtx as CvGraphVtx,byval mask as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateGraphScanner(byval graph as intptr,byref vtx as CvGraphVtx,byval mask as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateGraphScanner(byref graph as CvGraph,byval vtx as intptr,byval mask as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateGraphScanner(byval graph as intptr,byval vtx as intptr,byval mask as integer) as IntPtr
	end function

	'/* Releases graph scanner. */
	'CVAPI(void) cvReleaseGraphScanner( CvGraphScanner** scanner );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReleaseGraphScanner(byref scanner as intptr)
	end sub

	'/* Get next graph element */
	'CVAPI(int)  cvNextGraphItem( CvGraphScanner* scanner );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNextGraphItem(byref scanner as CvGraphScanner) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNextGraphItem(byval scanner as intptr) as integer
	end function

	'/* Creates a copy of graph */
	'CVAPI(CvGraph*) cvCloneGraph( const CvGraph* graph, CvMemStorage* storage );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneGraph(byref graph as CvGraph,byref storage as CvMemStorage) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneGraph(byval graph as intptr,byref storage as CvMemStorage) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneGraph(byref graph as CvGraph,byval storage as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCloneGraph(byval graph as intptr,byval storage as intptr) as IntPtr
	end function

	'/****************************************************************************************\
	'*                                     Drawing                                            *
	'\****************************************************************************************/

	'/****************************************************************************************\
	'*       Drawing functions work with images/matrices of arbitrary type.                   *
	'*       For color images the channel order is BGR[A]                                     *
	'*       Antialiasing is supported only for 8-bit image now.                              *
	'*       All the functions include parameter color that means rgb value (that may be      *
	'*       constructed with CV_RGB macro) for color images and brightness                   *
	'*       for grayscale images.                                                            *
	'*       If a drawn figure is partially or completely outside of the image, it is clipped.*
	'\****************************************************************************************/

	'#define CV_RGB( r, g, b )  cvScalar( (b), (g), (r), 0 )
    Public Function CV_RGB(ByVal r As Integer, ByVal g As Integer, ByVal b As Integer) As CxTypes.CvScalar
        Return New CxTypes.CvScalar(b, g, r, 0)
    End Function


	'#define CV_FILLED -1
	public const  CV_FILLED as integer =  -1

	'#define CV_AA 16
	public const  CV_AA as integer =  16

	'/* Draws 4-connected, 8-connected or antialiased line segment connecting two points */
	'CVAPI(void)  cvLine( CvArr* img, CvPoint pt1, CvPoint pt2,
	'                     CvScalar color, int thickness CV_DEFAULT(1),
	'                     int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvLine(byval img as intptr,byval pt1 as CvPoint,byval pt2 as CvPoint,byval color as CvScalar,byval thickness as integer,byval line_type as integer,byval shift as integer)
	end sub

	'/* Draws a rectangle given two opposite corners of the rectangle (pt1 & pt2),
	'   if thickness<0 (e.g. thickness == CV_FILLED), the filled box is drawn */
	'CVAPI(void)  cvRectangle( CvArr* img, CvPoint pt1, CvPoint pt2,
	'                          CvScalar color, int thickness CV_DEFAULT(1),
	'                          int line_type CV_DEFAULT(8),
	'                          int shift CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRectangle(byval img as intptr,byval pt1 as CvPoint,byval pt2 as CvPoint,byval color as CvScalar,byval thickness as integer,byval line_type as integer,byval shift as integer)
	end sub

	'/* Draws a circle with specified center and radius.
	'   Thickness works in the same way as with cvRectangle */
	'CVAPI(void)  cvCircle( CvArr* img, CvPoint center, int radius,
	'                       CvScalar color, int thickness CV_DEFAULT(1),
	'                       int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvCircle(byval img as intptr,byval center as CvPoint,byval radius as integer,byval color as CvScalar,byval thickness as integer,byval line_type as integer,byval shift as integer)
	end sub

	'/* Draws ellipse outline, filled ellipse, elliptic arc or filled elliptic sector,
	'   depending on <thickness>, <start_angle> and <end_angle> parameters. The resultant figure
	'   is rotated by <angle>. All the angles are in degrees */
	'CVAPI(void)  cvEllipse( CvArr* img, CvPoint center, CvSize axes,
	'                        double angle, double start_angle, double end_angle,
	'                        CvScalar color, int thickness CV_DEFAULT(1),
	'                        int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvEllipse(byval img as intptr,byval center as CvPoint,byval axes as CvSize,byval angle as double,byval start_angle as double,byval end_angle as double,byval color as CvScalar,byval thickness as integer,byval line_type as integer,byval shift as integer)
	end sub

	'CV_INLINE  void  cvEllipseBox( CvArr* img, CvBox2D box, CvScalar color,
	'                               int thickness CV_DEFAULT(1),
	'                               int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0) )
	'{
	'    CvSize axes;
	'    axes.width = cvRound(box.size.height*0.5);
	'    axes.height = cvRound(box.size.width*0.5);

	'    cvEllipse( img, cvPointFrom32f( box.center ), axes, box.angle,
	'               0, 360, color, thickness, line_type, shift );
	'}
    Public Sub cvEllipseBox(ByVal img As IntPtr, ByVal box As CvBox2D, ByVal color As CvScalar, ByVal thickness As Integer, ByVal line_type As Integer, ByVal shift As Integer)

        Dim axes As CvSize
        axes.width = cvRound(box.size.height / 2)
        axes.height = cvRound(box.size.width / 2)

        cvEllipse(img, cvPointFrom32f(box.center), axes, box.angle * 180 / CV_PI, 0, 360, color, thickness, line_type, shift)
    End Sub



	'/* Fills convex or monotonous polygon. */
	'CVAPI(void)  cvFillConvexPoly( CvArr* img, CvPoint* pts, int npts, CvScalar color,
	'                               int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFillConvexPoly(byval img as intptr,byref pts as CvPoint,byval npts as integer,byval color as CvScalar,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFillConvexPoly(byval img as intptr,< [In], Out > byval pts as CvPoint(),byval npts as integer,byval color as CvScalar,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFillConvexPoly(byval img as intptr,byval pts as intptr,byval npts as integer,byval color as CvScalar,byval line_type as integer,byval shift as integer)
	end sub

	'/* Fills an area bounded by one or more arbitrary polygons */
	'CVAPI(void)  cvFillPoly( CvArr* img, CvPoint** pts, int* npts, int contours, CvScalar color,
	'                         int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFillPoly(byval img as intptr,Byref pts As CxTypes.CvPoint(),byval npts as integer(),byval contours as integer,byval color as CvScalar,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFillPoly(byval img as intptr,byval pts as intptr,byval npts as integer(),byval contours as integer,byval color as CvScalar,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFillPoly(byval img as intptr,Byref pts As CxTypes.CvPoint(),byref npts as integer,byval contours as integer,byval color as CvScalar,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFillPoly(byval img as intptr,byval pts as intptr,byref npts as integer,byval contours as integer,byval color as CvScalar,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFillPoly(byval img as intptr,Byref pts As CxTypes.CvPoint(),byval npts as intptr,byval contours as integer,byval color as CvScalar,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvFillPoly(byval img as intptr,byval pts as intptr,byval npts as intptr,byval contours as integer,byval color as CvScalar,byval line_type as integer,byval shift as integer)
	end sub

	'/* Draws one or more polygonal curves */
	'CVAPI(void)  cvPolyLine( CvArr* img, CvPoint** pts, int* npts, int contours,
	'                         int is_closed, CvScalar color, int thickness CV_DEFAULT(1),
	'                         int line_type CV_DEFAULT(8), int shift CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPolyLine(byval img as intptr,Byref pts As CxTypes.CvPoint(),byval npts as integer(),byval contours as integer,byval is_closed as integer,byval color as CvScalar,byval thickness as integer,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPolyLine(byval img as intptr,byval pts as intptr,byval npts as integer(),byval contours as integer,byval is_closed as integer,byval color as CvScalar,byval thickness as integer,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPolyLine(byval img as intptr,Byref pts As CxTypes.CvPoint(),byref npts as integer,byval contours as integer,byval is_closed as integer,byval color as CvScalar,byval thickness as integer,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPolyLine(byval img as intptr,byval pts as intptr,byref npts as integer,byval contours as integer,byval is_closed as integer,byval color as CvScalar,byval thickness as integer,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPolyLine(byval img as intptr,Byref pts As CxTypes.CvPoint(),byval npts as intptr,byval contours as integer,byval is_closed as integer,byval color as CvScalar,byval thickness as integer,byval line_type as integer,byval shift as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPolyLine(byval img as intptr,byval pts as intptr,byval npts as intptr,byval contours as integer,byval is_closed as integer,byval color as CvScalar,byval thickness as integer,byval line_type as integer,byval shift as integer)
	end sub

	'#define cvDrawRect cvRectangle
	'Skip : 
	'#define cvDrawLine cvLine
	'Skip : 
	'#define cvDrawCircle cvCircle
	'Skip : 
	'#define cvDrawEllipse cvEllipse
	'Skip : 
	'#define cvDrawPolyLine cvPolyLine
	'Skip : 

	'/* Clips the line segment connecting *pt1 and *pt2
	'   by the rectangular window
	'   (0<=x<img_size.width, 0<=y<img_size.height). */
	'CVAPI(int) cvClipLine( CvSize img_size, CvPoint* pt1, CvPoint* pt2 );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvClipLine(byval img_size as CvSize,byref pt1 as CvPoint,byref pt2 as CvPoint) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvClipLine(byval img_size as CvSize,< [In], Out > byval pt1 as CvPoint(),byref pt2 as CvPoint) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvClipLine(byval img_size as CvSize,byval pt1 as intptr,byref pt2 as CvPoint) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvClipLine(byval img_size as CvSize,byref pt1 as CvPoint,< [In], Out > byval pt2 as CvPoint()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvClipLine(byval img_size as CvSize,< [In], Out > byval pt1 as CvPoint(),< [In], Out > byval pt2 as CvPoint()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvClipLine(byval img_size as CvSize,byval pt1 as intptr,< [In], Out > byval pt2 as CvPoint()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvClipLine(byval img_size as CvSize,byref pt1 as CvPoint,byval pt2 as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvClipLine(byval img_size as CvSize,< [In], Out > byval pt1 as CvPoint(),byval pt2 as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvClipLine(byval img_size as CvSize,byval pt1 as intptr,byval pt2 as intptr) as integer
	end function

	'/* Initializes line iterator. Initially, line_iterator->ptr will point
	'   to pt1 (or pt2, see left_to_right description) location in the image.
	'   Returns the number of pixels on the line between the ending points. */
	'CVAPI(int)  cvInitLineIterator( const CvArr* image, CvPoint pt1, CvPoint pt2,
	'                                CvLineIterator* line_iterator,
	'                                int connectivity CV_DEFAULT(8),
	'                                int left_to_right CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitLineIterator(byval image as intptr,byval pt1 as CvPoint,byval pt2 as CvPoint,byref line_iterator as CvLineIterator,byval connectivity as integer,byval left_to_right as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitLineIterator(byval image as intptr,byval pt1 as CvPoint,byval pt2 as CvPoint,byval line_iterator as intptr,byval connectivity as integer,byval left_to_right as integer) as integer
	end function

	'/* Moves iterator to the next line point */
	'#define CV_NEXT_LINE_POINT( line_iterator )                     \
	'{                                                               \
	'    int _line_iterator_mask = (line_iterator).err < 0 ? -1 : 0; \
	'    (line_iterator).err += (line_iterator).minus_delta +        \
	'        ((line_iterator).plus_delta & _line_iterator_mask);     \
	'    (line_iterator).ptr += (line_iterator).minus_step +         \
	'        ((line_iterator).plus_step & _line_iterator_mask);      \
	'}
	'ToDo : 


	'/* basic font types */
	'#define CV_FONT_HERSHEY_SIMPLEX         0
	public const  CV_FONT_HERSHEY_SIMPLEX as integer =  0
	'#define CV_FONT_HERSHEY_PLAIN           1
	public const  CV_FONT_HERSHEY_PLAIN as integer =  1
	'#define CV_FONT_HERSHEY_DUPLEX          2
	public const  CV_FONT_HERSHEY_DUPLEX as integer =  2
	'#define CV_FONT_HERSHEY_COMPLEX         3 
	public const  CV_FONT_HERSHEY_COMPLEX as integer =  3
	'#define CV_FONT_HERSHEY_TRIPLEX         4
	public const  CV_FONT_HERSHEY_TRIPLEX as integer =  4
	'#define CV_FONT_HERSHEY_COMPLEX_SMALL   5
	public const  CV_FONT_HERSHEY_COMPLEX_SMALL as integer =  5
	'#define CV_FONT_HERSHEY_SCRIPT_SIMPLEX  6
	public const  CV_FONT_HERSHEY_SCRIPT_SIMPLEX as integer =  6
	'#define CV_FONT_HERSHEY_SCRIPT_COMPLEX  7
	public const  CV_FONT_HERSHEY_SCRIPT_COMPLEX as integer =  7

	'/* font flags */
	'#define CV_FONT_ITALIC                 16  
	public const  CV_FONT_ITALIC as integer =  16

	'#define CV_FONT_VECTOR0    CV_FONT_HERSHEY_SIMPLEX
	public const  CV_FONT_VECTOR0 as integer =  CV_FONT_HERSHEY_SIMPLEX

	'/* Font structure */
	'typedef struct CvFont
	'{
	'    int         font_face; /* =CV_FONT_* */
	'    const int*  ascii; /* font data and metrics */
	'    const int*  greek;
	'    const int*  cyrillic;
	'    float       hscale, vscale;
	'    float       shear; /* slope coefficient: 0 - normal, >0 - italic */
	'    int         thickness; /* letters thickness */
	'    float       dx; /* horizontal interval between letters */
	'    int         line_type;
	'}
	'CvFont;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvFont
        Public font_face As Integer
        Public ascii As IntPtr
        Public greek As IntPtr
        Public cyrillic As IntPtr
        Public hscale As Single
        Public vscale As Single
        Public shear As Single
        Public thickness As Integer
        Public dx As Single
        Public line_type As Integer
    End Structure



	'/* Initializes font structure used further in cvPutText */
	'CVAPI(void)  cvInitFont( CvFont* font, int font_face,
	'                         double hscale, double vscale,
	'                         double shear CV_DEFAULT(0),
	'                         int thickness CV_DEFAULT(1),
	'                         int line_type CV_DEFAULT(8));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvInitFont(byref font as CvFont,byval font_face as integer,byval hscale as double,byval vscale as double,byval shear as double,byval thickness as integer,byval line_type as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvInitFont(byval font as intptr,byval font_face as integer,byval hscale as double,byval vscale as double,byval shear as double,byval thickness as integer,byval line_type as integer)
	end sub

	'CV_INLINE CvFont cvFont( double scale, int thickness CV_DEFAULT(1) )
	'{
	'    CvFont font;
	'    cvInitFont( &font, CV_FONT_HERSHEY_PLAIN, scale, scale, 0, thickness, CV_AA );
	'    return font;
	'}
	'ToDo : Function

	'/* Renders text stroke with specified font and color at specified location.
	'   CvFont should be initialized with cvInitFont */
	'CVAPI(void)  cvPutText( CvArr* img, const char* text, CvPoint org,
	'                        const CvFont* font, CvScalar color );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPutText(byval img as intptr,byval text as string,byval org as CvPoint,byref font as CvFont,byval color as CvScalar)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPutText(byval img as intptr,byval text as byte(),byval org as CvPoint,byref font as CvFont,byval color as CvScalar)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPutText(byval img as intptr,byval text as intptr,byval org as CvPoint,byref font as CvFont,byval color as CvScalar)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPutText(byval img as intptr,byval text as string,byval org as CvPoint,byval font as intptr,byval color as CvScalar)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPutText(byval img as intptr,byval text as byte(),byval org as CvPoint,byval font as intptr,byval color as CvScalar)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvPutText(byval img as intptr,byval text as intptr,byval org as CvPoint,byval font as intptr,byval color as CvScalar)
	end sub

	'/* Calculates bounding box of text stroke (useful for alignment) */
	'CVAPI(void)  cvGetTextSize( const char* text_string, const CvFont* font,
	'                            CvSize* text_size, int* baseline );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byref font as CvFont,byref text_size as CvSize,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byref font as CvFont,byref text_size as CvSize,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byref font as CvFont,byref text_size as CvSize,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byval font as intptr,byref text_size as CvSize,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byval font as intptr,byref text_size as CvSize,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byval font as intptr,byref text_size as CvSize,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byref font as CvFont,byval text_size as intptr,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byref font as CvFont,byval text_size as intptr,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byref font as CvFont,byval text_size as intptr,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byval font as intptr,byval text_size as intptr,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byval font as intptr,byval text_size as intptr,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byval font as intptr,byval text_size as intptr,byval baseline as integer())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byref font as CvFont,byref text_size as CvSize,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byref font as CvFont,byref text_size as CvSize,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byref font as CvFont,byref text_size as CvSize,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byval font as intptr,byref text_size as CvSize,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byval font as intptr,byref text_size as CvSize,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byval font as intptr,byref text_size as CvSize,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byref font as CvFont,byval text_size as intptr,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byref font as CvFont,byval text_size as intptr,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byref font as CvFont,byval text_size as intptr,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byval font as intptr,byval text_size as intptr,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byval font as intptr,byval text_size as intptr,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byval font as intptr,byval text_size as intptr,byref baseline as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byref font as CvFont,byref text_size as CvSize,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byref font as CvFont,byref text_size as CvSize,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byref font as CvFont,byref text_size as CvSize,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byval font as intptr,byref text_size as CvSize,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byval font as intptr,byref text_size as CvSize,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byval font as intptr,byref text_size as CvSize,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byref font as CvFont,byval text_size as intptr,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byref font as CvFont,byval text_size as intptr,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byref font as CvFont,byval text_size as intptr,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as string,byval font as intptr,byval text_size as intptr,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as byte(),byval font as intptr,byval text_size as intptr,byval baseline as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetTextSize(byval text_string as intptr,byval font as intptr,byval text_size as intptr,byval baseline as intptr)
	end sub

	'/* Unpacks color value, if arrtype is CV_8UC?, <color> is treated as
	'   packed color value, otherwise the first channels (depending on arrtype)
	'   of destination scalar are set to the same value = <color> */
	'CVAPI(CvScalar)  cvColorToScalar( double packed_color, int arrtype );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvColorToScalar(byval packed_color as double,byval arrtype as integer) as CvScalar
	end function

	'/* Returns the polygon points which make up the given ellipse.  The ellipse is define by
	'   the box of size 'axes' rotated 'angle' around the 'center'.  A partial sweep
	'   of the ellipse arc can be done by spcifying arc_start and arc_end to be something
	'   other than 0 and 360, respectively.  The input array 'pts' must be large enough to
	'   hold the result.  The total number of points stored into 'pts' is returned by this
	'   function. */
	'CVAPI(int) cvEllipse2Poly( CvPoint center, CvSize axes,
	'                 int angle, int arc_start, int arc_end, CvPoint * pts, int delta );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvEllipse2Poly(byval center as CvPoint,byval axes as CvSize,byval angle as integer,byval arc_start as integer,byval arc_end as integer,byref pts as CvPoint,byval delta as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvEllipse2Poly(byval center as CvPoint,byval axes as CvSize,byval angle as integer,byval arc_start as integer,byval arc_end as integer,< [In], Out > byval pts as CvPoint(),byval delta as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvEllipse2Poly(byval center as CvPoint,byval axes as CvSize,byval angle as integer,byval arc_start as integer,byval arc_end as integer,byval pts as intptr,byval delta as integer) as integer
	end function

	'/* Draws contour outlines or filled interiors on the image */
	'CVAPI(void)  cvDrawContours( CvArr *img, CvSeq* contour,
	'                            CvScalar external_color, CvScalar hole_color,
	'                            int max_level, int thickness CV_DEFAULT(1),
	'                            int line_type CV_DEFAULT(8),
	'                            CvPoint offset CV_DEFAULT(cvPoint(0,0)));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvDrawContours(byval img as intptr,byref contour as CvSeq,byval external_color as CvScalar,byval hole_color as CvScalar,byval max_level as integer,byval thickness as integer,byval line_type as integer,byval offset as CvPoint)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvDrawContours(byval img as intptr,byval contour as intptr,byval external_color as CvScalar,byval hole_color as CvScalar,byval max_level as integer,byval thickness as integer,byval line_type as integer,byval offset as CvPoint)
	end sub

	'/* Does look-up transformation. Elements of the source array
	'   (that should be 8uC1 or 8sC1) are used as indexes in lutarr 256-element table */
	'CVAPI(void) cvLUT( const CvArr* src, CvArr* dst, const CvArr* lut );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvLUT(byval src as intptr,byval dst as intptr,byval lut as intptr)
	end sub


	'/******************* Iteration through the sequence tree *****************/
	'typedef struct CvTreeNodeIterator
	'{
	'    const void* node;
	'    int level;
	'    int max_level;
	'}
	'CvTreeNodeIterator;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvTreeNodeIterator
        Public node As IntPtr
        Public level As Integer
        Public max_level As Integer
    End Structure
    


	'CVAPI(void) cvInitTreeNodeIterator( CvTreeNodeIterator* tree_iterator,
	'                                   const void* first, int max_level );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvInitTreeNodeIterator(byref tree_iterator as CvTreeNodeIterator,byval first as intptr,byval max_level as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvInitTreeNodeIterator(byval tree_iterator as intptr,byval first as intptr,byval max_level as integer)
	end sub
	'CVAPI(void*) cvNextTreeNode( CvTreeNodeIterator* tree_iterator );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNextTreeNode(byref tree_iterator as CvTreeNodeIterator) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNextTreeNode(byval tree_iterator as intptr) as IntPtr
	end function
	'CVAPI(void*) cvPrevTreeNode( CvTreeNodeIterator* tree_iterator );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPrevTreeNode(byref tree_iterator as CvTreeNodeIterator) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvPrevTreeNode(byval tree_iterator as intptr) as IntPtr
	end function

	'/* Inserts sequence into tree with specified "parent" sequence.
	'   If parent is equal to frame (e.g. the most external contour),
	'   then added contour will have null pointer to parent. */
	'CVAPI(void) cvInsertNodeIntoTree( void* node, void* parent, void* frame );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvInsertNodeIntoTree(byval node as intptr,byval parent as intptr,byval frame as intptr)
	end sub

	'/* Removes contour from tree (together with the contour children). */
	'CVAPI(void) cvRemoveNodeFromTree( void* node, void* frame );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRemoveNodeFromTree(byval node as intptr,byval frame as intptr)
	end sub

	'/* Gathers pointers to all the sequences,
	'   accessible from the <first>, to the single sequence */
	'CVAPI(CvSeq*) cvTreeToNodeSeq( const void* first, int header_size,
	'                              CvMemStorage* storage );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvTreeToNodeSeq(byval first as intptr,byval header_size as integer,byref storage as CvMemStorage) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvTreeToNodeSeq(byval first as intptr,byval header_size as integer,byval storage as intptr) as IntPtr
	end function

	'/* The function implements the K-means algorithm for clustering an array of sample
	'   vectors in a specified number of classes */
	'CVAPI(void)  cvKMeans2( const CvArr* samples, int cluster_count,
	'                        CvArr* labels, CvTermCriteria termcrit );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvKMeans2(byval samples as intptr,byval cluster_count as integer,byval labels as intptr,byval termcrit as CvTermCriteria)
	end sub

	'/****************************************************************************************\
	'*                                    System functions                                    *
	'\****************************************************************************************/

	'/* Add the function pointers table with associated information to the IPP primitives list */
	'CVAPI(int)  cvRegisterModule( const CvModuleInfo* module_info );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvRegisterModule(byref module_info as CvModuleInfo) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvRegisterModule(byval module_info as intptr) as integer
	end function

	'/* Loads optimized functions from IPP, MKL etc. or switches back to pure C code */
	'CVAPI(int)  cvUseOptimized( int on_off );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvUseOptimized(byval on_off as integer) as integer
	end function

	'/* Retrieves information about the registered modules and loaded optimized plugins */
	'CVAPI(void)  cvGetModuleInfo( const char* module_name,
	'                              const char** version,
	'                              const char** loaded_addon_plugins );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as string,byref version as string,byref loaded_addon_plugins as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as byte(),byref version as string,byref loaded_addon_plugins as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as intptr,byref version as string,byref loaded_addon_plugins as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as string,byval version as intptr,byref loaded_addon_plugins as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as byte(),byval version as intptr,byref loaded_addon_plugins as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as intptr,byval version as intptr,byref loaded_addon_plugins as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as string,byref version as string,byval loaded_addon_plugins as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as byte(),byref version as string,byval loaded_addon_plugins as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as intptr,byref version as string,byval loaded_addon_plugins as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as string,byval version as intptr,byval loaded_addon_plugins as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as byte(),byval version as intptr,byval loaded_addon_plugins as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvGetModuleInfo(byval module_name as intptr,byval version as intptr,byval loaded_addon_plugins as intptr)
	end sub

	'/* Get current OpenCV error status */
	'CVAPI(int) cvGetErrStatus( void );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrStatus() as integer
	end function

	'/* Sets error status silently */
	'CVAPI(void) cvSetErrStatus( int status );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetErrStatus(byval status as integer)
	end sub

	'#define CV_ErrModeLeaf     0   /* Print error and exit program */
	public const  CV_ErrModeLeaf as integer =  0
	'#define CV_ErrModeParent   1   /* Print error and continue */
	public const  CV_ErrModeParent as integer =  1
	'#define CV_ErrModeSilent   2   /* Don't print and continue */
	public const  CV_ErrModeSilent as integer =  2

	'/* Retrives current error processing mode */
	'CVAPI(int)  cvGetErrMode( void );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrMode() as integer
	end function

	'/* Sets error processing mode, returns previously used mode */
	'CVAPI(int) cvSetErrMode( int mode );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSetErrMode(byval mode as integer) as integer
	end function

	'/* Sets error status and performs some additonal actions (displaying message box,
	'   writing message to stderr, terminating application etc.)
	'   depending on the current error mode */
	'CVAPI(void) cvError( int status, const char* func_name,
	'                    const char* err_msg, const char* file_name, int line );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as string,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as string,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as string,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as string,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as string,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as string,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as string,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as string,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as string,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as byte(),byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as byte(),byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as byte(),byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as byte(),byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as byte(),byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as byte(),byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as byte(),byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as byte(),byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as byte(),byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as intptr,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as intptr,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as intptr,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as intptr,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as intptr,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as intptr,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as intptr,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as intptr,byval line as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvError(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as intptr,byval line as integer)
	end sub

	'/* Retrieves textual description of the error given its code */
	'CVAPI(const char*) cvErrorStr( int status );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvErrorStr(byval status as integer) as IntPtr
	end function

	'/* Retrieves detailed information about the last error occured */
	'CVAPI(int) cvGetErrInfo( const char** errcode_desc, const char** description,
	'                        const char** filename, int* line );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byref description as string,byref filename as string,byval line as integer()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byref description as string,byref filename as string,byval line as integer()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byval description as intptr,byref filename as string,byval line as integer()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byval description as intptr,byref filename as string,byval line as integer()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byref description as string,byval filename as intptr,byval line as integer()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byref description as string,byval filename as intptr,byval line as integer()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byval description as intptr,byval filename as intptr,byval line as integer()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byval description as intptr,byval filename as intptr,byval line as integer()) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byref description as string,byref filename as string,byref line as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byref description as string,byref filename as string,byref line as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byval description as intptr,byref filename as string,byref line as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byval description as intptr,byref filename as string,byref line as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byref description as string,byval filename as intptr,byref line as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byref description as string,byval filename as intptr,byref line as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byval description as intptr,byval filename as intptr,byref line as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byval description as intptr,byval filename as intptr,byref line as integer) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byref description as string,byref filename as string,byval line as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byref description as string,byref filename as string,byval line as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byval description as intptr,byref filename as string,byval line as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byval description as intptr,byref filename as string,byval line as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byref description as string,byval filename as intptr,byval line as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byref description as string,byval filename as intptr,byval line as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byref errcode_desc as string,byval description as intptr,byval filename as intptr,byval line as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetErrInfo(byval errcode_desc as intptr,byval description as intptr,byval filename as intptr,byval line as intptr) as integer
	end function

	'/* Maps IPP error codes to the counterparts from OpenCV */
	'CVAPI(int) cvErrorFromIppStatus( int ipp_status );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvErrorFromIppStatus(byval ipp_status as integer) as integer
	end function

	'typedef int (CV_CDECL *CvErrorCallback)( int status, const char* func_name,
	'                    const char* err_msg, const char* file_name, int line, void* userdata );
	'Typedef : Unsupport

	'/* Assigns a new error-handling function */
	'CVAPI(CvErrorCallback) cvRedirectError( CvErrorCallback error_handler,
	'                                       void* userdata CV_DEFAULT(NULL),
	'                                       void** prev_userdata CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvRedirectError(byval error_handler as intptr,byval userdata as intptr,byref prev_userdata as intptr) as IntPtr
	end function

	'/*
	'    Output to:
	'        cvNulDevReport - nothing
	'        cvStdErrReport - console(fprintf(stderr,...))
	'        cvGuiBoxReport - MessageBox(WIN32)
	'*/
	'CVAPI(int) cvNulDevReport( int status, const char* func_name, const char* err_msg,
	'                          const char* file_name, int line, void* userdata );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNulDevReport(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function

	'CVAPI(int) cvStdErrReport( int status, const char* func_name, const char* err_msg,
	'                          const char* file_name, int line, void* userdata );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStdErrReport(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function

	'CVAPI(int) cvGuiBoxReport( int status, const char* func_name, const char* err_msg,
	'                          const char* file_name, int line, void* userdata );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as string,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as byte(),byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as string,byval err_msg as string,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as byte(),byval err_msg as string,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as intptr,byval err_msg as string,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as string,byval err_msg as byte(),byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as byte(),byval err_msg as byte(),byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as intptr,byval err_msg as byte(),byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as string,byval err_msg as intptr,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as byte(),byval err_msg as intptr,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGuiBoxReport(byval status as integer,byval func_name as intptr,byval err_msg as intptr,byval file_name as intptr,byval line as integer,byval userdata as intptr) as integer
	end function

	'typedef void* (CV_CDECL *CvAllocFunc)(size_t size, void* userdata);
	'Typedef : Unsupport
	'typedef int (CV_CDECL *CvFreeFunc)(void* pptr, void* userdata);
	'Typedef : Unsupport

	'/* Set user-defined memory managment functions (substitutors for malloc and free) that
	'   will be called by cvAlloc, cvFree and higher-level functions (e.g. cvCreateImage) */
	'CVAPI(void) cvSetMemoryManager( CvAllocFunc alloc_func CV_DEFAULT(NULL),
	'                               CvFreeFunc free_func CV_DEFAULT(NULL),
	'                               void* userdata CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetMemoryManager(byval alloc_func as intptr,byval free_func as intptr,byval userdata as intptr)
	end sub


	'typedef IplImage* (CV_STDCALL* Cv_iplCreateImageHeader)
	'                            (int,int,int,char*,char*,int,int,int,int,int,
	'                            IplROI*,IplImage*,void*,IplTileInfo*);
	'Typedef : Unsupport
	'typedef void (CV_STDCALL* Cv_iplAllocateImageData)(IplImage*,int,int);
	'Typedef : Unsupport
	'typedef void (CV_STDCALL* Cv_iplDeallocate)(IplImage*,int);
	'Typedef : Unsupport
	'typedef IplROI* (CV_STDCALL* Cv_iplCreateROI)(int,int,int,int,int);
	'Typedef : Unsupport
	'typedef IplImage* (CV_STDCALL* Cv_iplCloneImage)(const IplImage*);
	'Typedef : Unsupport

	'/* Makes OpenCV use IPL functions for IplImage allocation/deallocation */
	'CVAPI(void) cvSetIPLAllocators( Cv_iplCreateImageHeader create_header,
	'                               Cv_iplAllocateImageData allocate_data,
	'                               Cv_iplDeallocate deallocate,
	'                               Cv_iplCreateROI create_roi,
	'                               Cv_iplCloneImage clone_image );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetIPLAllocators(byval create_header as intptr,byval allocate_data as intptr,byval deallocate as intptr,byval create_roi as intptr,byval clone_image as intptr)
	end sub

	'#define CV_TURN_ON_IPL_COMPATIBILITY()                                  \
	'    cvSetIPLAllocators( iplCreateImageHeader, iplAllocateImage,         \
	'                        iplDeallocate, iplCreateROI, iplCloneImage )
	'ToDo : 

	'/****************************************************************************************\
	'*                                    Data Persistence                                    *
	'\****************************************************************************************/

	'/********************************** High-level functions ********************************/

	'/* opens existing or creates new file storage */
	'CVAPI(CvFileStorage*)  cvOpenFileStorage( const char* filename,
	'                                          CvMemStorage* memstorage,
	'                                          int flags );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvOpenFileStorage(byval filename as string,byref memstorage as CvMemStorage,byval flags as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvOpenFileStorage(byval filename as byte(),byref memstorage as CvMemStorage,byval flags as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvOpenFileStorage(byval filename as intptr,byref memstorage as CvMemStorage,byval flags as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvOpenFileStorage(byval filename as string,byval memstorage as intptr,byval flags as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvOpenFileStorage(byval filename as byte(),byval memstorage as intptr,byval flags as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvOpenFileStorage(byval filename as intptr,byval memstorage as intptr,byval flags as integer) as IntPtr
	end function

	'/* closes file storage and deallocates buffers */
	'CVAPI(void) cvReleaseFileStorage( CvFileStorage** fs );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReleaseFileStorage(byref fs as intptr)
	end sub

	'/* returns attribute value or 0 (NULL) if there is no such attribute */
	'CVAPI(const char*) cvAttrValue( const CvAttrList* attr, const char* attr_name );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvAttrValue(byref attr as CvAttrList,byval attr_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvAttrValue(byval attr as intptr,byval attr_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvAttrValue(byref attr as CvAttrList,byval attr_name as byte()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvAttrValue(byval attr as intptr,byval attr_name as byte()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvAttrValue(byref attr as CvAttrList,byval attr_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvAttrValue(byval attr as intptr,byval attr_name as intptr) as IntPtr
	end function

	'/* starts writing compound structure (map or sequence) */
	'CVAPI(void) cvStartWriteStruct( CvFileStorage* fs, const char* name,
	'                                int struct_flags, const char* type_name CV_DEFAULT(NULL),
	'                                CvAttrList attributes CV_DEFAULT(cvAttrList()));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteStruct(byval fs as intptr,byval name as string,byval struct_flags as integer,byval type_name as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteStruct(byval fs as intptr,byval name as byte(),byval struct_flags as integer,byval type_name as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteStruct(byval fs as intptr,byval name as intptr,byval struct_flags as integer,byval type_name as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteStruct(byval fs as intptr,byval name as string,byval struct_flags as integer,byval type_name as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteStruct(byval fs as intptr,byval name as byte(),byval struct_flags as integer,byval type_name as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteStruct(byval fs as intptr,byval name as intptr,byval struct_flags as integer,byval type_name as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteStruct(byval fs as intptr,byval name as string,byval struct_flags as integer,byval type_name as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteStruct(byval fs as intptr,byval name as byte(),byval struct_flags as integer,byval type_name as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartWriteStruct(byval fs as intptr,byval name as intptr,byval struct_flags as integer,byval type_name as intptr,byval attributes as CvAttrList)
	end sub

	'/* finishes writing compound structure */
	'CVAPI(void) cvEndWriteStruct( CvFileStorage* fs );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvEndWriteStruct(byval fs as intptr)
	end sub

	'/* writes an integer */
	'CVAPI(void) cvWriteInt( CvFileStorage* fs, const char* name, int value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteInt(byval fs as intptr,byval name as string,byval value as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteInt(byval fs as intptr,byval name as byte(),byval value as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteInt(byval fs as intptr,byval name as intptr,byval value as integer)
	end sub

	'/* writes a floating-point number */
	'CVAPI(void) cvWriteReal( CvFileStorage* fs, const char* name, double value );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteReal(byval fs as intptr,byval name as string,byval value as double)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteReal(byval fs as intptr,byval name as byte(),byval value as double)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteReal(byval fs as intptr,byval name as intptr,byval value as double)
	end sub

	'/* writes a string */
	'CVAPI(void) cvWriteString( CvFileStorage* fs, const char* name,
	'                           const char* str, int quote CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteString(byval fs as intptr,byval name as string,byval str as string,byval quote as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteString(byval fs as intptr,byval name as byte(),byval str as string,byval quote as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteString(byval fs as intptr,byval name as intptr,byval str as string,byval quote as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteString(byval fs as intptr,byval name as string,byval str as byte(),byval quote as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteString(byval fs as intptr,byval name as byte(),byval str as byte(),byval quote as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteString(byval fs as intptr,byval name as intptr,byval str as byte(),byval quote as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteString(byval fs as intptr,byval name as string,byval str as intptr,byval quote as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteString(byval fs as intptr,byval name as byte(),byval str as intptr,byval quote as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteString(byval fs as intptr,byval name as intptr,byval str as intptr,byval quote as integer)
	end sub

	'/* writes a comment */
	'CVAPI(void) cvWriteComment( CvFileStorage* fs, const char* comment,
	'                            int eol_comment );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteComment(byval fs as intptr,byval comment as string,byval eol_comment as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteComment(byval fs as intptr,byval comment as byte(),byval eol_comment as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteComment(byval fs as intptr,byval comment as intptr,byval eol_comment as integer)
	end sub

	'/* writes instance of a standard type (matrix, image, sequence, graph etc.)
	'   or user-defined type */
	'CVAPI(void) cvWrite( CvFileStorage* fs, const char* name, const void* ptr,
	'                         CvAttrList attributes CV_DEFAULT(cvAttrList()));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWrite(byval fs as intptr,byval name as string,byval ptr as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWrite(byval fs as intptr,byval name as byte(),byval ptr as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWrite(byval fs as intptr,byval name as intptr,byval ptr as intptr,byval attributes as CvAttrList)
	end sub

	'/* starts the next stream */
	'CVAPI(void) cvStartNextStream( CvFileStorage* fs );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartNextStream(byval fs as intptr)
	end sub

	'/* helper function: writes multiple integer or floating-point numbers */
	'CVAPI(void) cvWriteRawData( CvFileStorage* fs, const void* src,
	'                                int len, const char* dt );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteRawData(byval fs as intptr,byval src as intptr,byval len as integer,byval dt as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteRawData(byval fs as intptr,byval src as intptr,byval len as integer,byval dt as byte())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteRawData(byval fs as intptr,byval src as intptr,byval len as integer,byval dt as intptr)
	end sub

	'/* returns the hash entry corresponding to the specified literal key string or 0
	'   if there is no such a key in the storage */
	'CVAPI(CvStringHashNode*) cvGetHashedKey( CvFileStorage* fs, const char* name,
	'                                        int len CV_DEFAULT(-1),
	'                                        int create_missing CV_DEFAULT(0));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetHashedKey(byval fs as intptr,byval name as string,byval len as integer,byval create_missing as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetHashedKey(byval fs as intptr,byval name as byte(),byval len as integer,byval create_missing as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetHashedKey(byval fs as intptr,byval name as intptr,byval len as integer,byval create_missing as integer) as IntPtr
	end function

	'/* returns file node with the specified key within the specified map
	'   (collection of named nodes) */
	'CVAPI(CvFileNode*) cvGetRootFileNode( const CvFileStorage* fs,
	'                                     int stream_index CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetRootFileNode(byval fs as intptr,byval stream_index as integer) as IntPtr
	end function

	'/* returns file node with the specified key within the specified map
	'   (collection of named nodes) */
	'CVAPI(CvFileNode*) cvGetFileNode( CvFileStorage* fs, CvFileNode* map,
	'                                 const CvStringHashNode* key,
	'                                 int create_missing CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNode(byval fs as intptr,byref map as CvFileNode,byref key as CvStringHashNode,byval create_missing as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNode(byval fs as intptr,byval map as intptr,byref key as CvStringHashNode,byval create_missing as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNode(byval fs as intptr,byref map as CvFileNode,byval key as intptr,byval create_missing as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNode(byval fs as intptr,byval map as intptr,byval key as intptr,byval create_missing as integer) as IntPtr
	end function

	'/* this is a slower version of cvGetFileNode that takes the key as a literal string */
	'CVAPI(CvFileNode*) cvGetFileNodeByName( const CvFileStorage* fs,
	'                                       const CvFileNode* map,
	'                                       const char* name );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNodeByName(byval fs as intptr,byref map as CvFileNode,byval name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNodeByName(byval fs as intptr,byval map as intptr,byval name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNodeByName(byval fs as intptr,byref map as CvFileNode,byval name as byte()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNodeByName(byval fs as intptr,byval map as intptr,byval name as byte()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNodeByName(byval fs as intptr,byref map as CvFileNode,byval name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNodeByName(byval fs as intptr,byval map as intptr,byval name as intptr) as IntPtr
	end function

	'CV_INLINE int cvReadInt( const CvFileNode* node, int default_value CV_DEFAULT(0) )
	'{
	'    return !node ? default_value :
	'        CV_NODE_IS_INT(node->tag) ? node->data.i :
	'        CV_NODE_IS_REAL(node->tag) ? cvRound(node->data.f) : 0x7fffffff;
	'}
	'ToDo : Function


	'CV_INLINE int cvReadIntByName( const CvFileStorage* fs, const CvFileNode* map,
	'                         const char* name, int default_value CV_DEFAULT(0) )
	'{
	'    return cvReadInt( cvGetFileNodeByName( fs, map, name ), default_value );
	'}
	'ToDo : Function


	'CV_INLINE double cvReadReal( const CvFileNode* node, double default_value CV_DEFAULT(0.) )
	'{
	'    return !node ? default_value :
	'        CV_NODE_IS_INT(node->tag) ? (double)node->data.i :
	'        CV_NODE_IS_REAL(node->tag) ? node->data.f : 1e300;
	'}
	'ToDo : Function


	'CV_INLINE double cvReadRealByName( const CvFileStorage* fs, const CvFileNode* map,
	'                        const char* name, double default_value CV_DEFAULT(0.) )
	'{
	'    return cvReadReal( cvGetFileNodeByName( fs, map, name ), default_value );
	'}
	'ToDo : Function


	'CV_INLINE const char* cvReadString( const CvFileNode* node,
	'                        const char* default_value CV_DEFAULT(NULL) )
	'{
	'    return !node ? default_value : CV_NODE_IS_STRING(node->tag) ? node->data.str.ptr : 0;
	'}
	'ToDo : Function


	'CV_INLINE const char* cvReadStringByName( const CvFileStorage* fs, const CvFileNode* map,
	'                        const char* name, const char* default_value CV_DEFAULT(NULL) )
	'{
	'    return cvReadString( cvGetFileNodeByName( fs, map, name ), default_value );
	'}
	'ToDo : Function


	'/* decodes standard or user-defined object and returns it */
	'CVAPI(void*) cvRead( CvFileStorage* fs, CvFileNode* node,
	'                        CvAttrList* attributes CV_DEFAULT(NULL));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvRead(byval fs as intptr,byref node as CvFileNode,byref attributes as CvAttrList) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvRead(byval fs as intptr,byval node as intptr,byref attributes as CvAttrList) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvRead(byval fs as intptr,byref node as CvFileNode,byval attributes as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvRead(byval fs as intptr,byval node as intptr,byval attributes as intptr) as IntPtr
	end function

	'/* decodes standard or user-defined object and returns it */
	'CV_INLINE void* cvReadByName( CvFileStorage* fs, const CvFileNode* map,
	'                              const char* name, CvAttrList* attributes CV_DEFAULT(NULL) )
	'{
	'    return cvRead( fs, cvGetFileNodeByName( fs, map, name ), attributes );
	'}
	'ToDo : Function


	'/* starts reading data from sequence or scalar numeric node */
	'CVAPI(void) cvStartReadRawData( const CvFileStorage* fs, const CvFileNode* src,
	'                               CvSeqReader* reader );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartReadRawData(byval fs as intptr,byref src as CvFileNode,byref reader as CvSeqReader)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartReadRawData(byval fs as intptr,byval src as intptr,byref reader as CvSeqReader)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartReadRawData(byval fs as intptr,byref src as CvFileNode,byval reader as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvStartReadRawData(byval fs as intptr,byval src as intptr,byval reader as intptr)
	end sub

	'/* reads multiple numbers and stores them to array */
	'CVAPI(void) cvReadRawDataSlice( const CvFileStorage* fs, CvSeqReader* reader,
	'                               int count, void* dst, const char* dt );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawDataSlice(byval fs as intptr,byref reader as CvSeqReader,byval count as integer,byval dst as intptr,byval dt as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawDataSlice(byval fs as intptr,byval reader as intptr,byval count as integer,byval dst as intptr,byval dt as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawDataSlice(byval fs as intptr,byref reader as CvSeqReader,byval count as integer,byval dst as intptr,byval dt as byte())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawDataSlice(byval fs as intptr,byval reader as intptr,byval count as integer,byval dst as intptr,byval dt as byte())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawDataSlice(byval fs as intptr,byref reader as CvSeqReader,byval count as integer,byval dst as intptr,byval dt as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawDataSlice(byval fs as intptr,byval reader as intptr,byval count as integer,byval dst as intptr,byval dt as intptr)
	end sub

	'/* combination of two previous functions for easier reading of whole sequences */
	'CVAPI(void) cvReadRawData( const CvFileStorage* fs, const CvFileNode* src,
	'                          void* dst, const char* dt );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawData(byval fs as intptr,byref src as CvFileNode,byval dst as intptr,byval dt as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawData(byval fs as intptr,byval src as intptr,byval dst as intptr,byval dt as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawData(byval fs as intptr,byref src as CvFileNode,byval dst as intptr,byval dt as byte())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawData(byval fs as intptr,byval src as intptr,byval dst as intptr,byval dt as byte())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawData(byval fs as intptr,byref src as CvFileNode,byval dst as intptr,byval dt as intptr)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReadRawData(byval fs as intptr,byval src as intptr,byval dst as intptr,byval dt as intptr)
	end sub

	'/* writes a copy of file node to file storage */
	'CVAPI(void) cvWriteFileNode( CvFileStorage* fs, const char* new_node_name,
	'                            const CvFileNode* node, int embed );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteFileNode(byval fs as intptr,byval new_node_name as string,byref node as CvFileNode,byval embed as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteFileNode(byval fs as intptr,byval new_node_name as byte(),byref node as CvFileNode,byval embed as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteFileNode(byval fs as intptr,byval new_node_name as intptr,byref node as CvFileNode,byval embed as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteFileNode(byval fs as intptr,byval new_node_name as string,byval node as intptr,byval embed as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteFileNode(byval fs as intptr,byval new_node_name as byte(),byval node as intptr,byval embed as integer)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvWriteFileNode(byval fs as intptr,byval new_node_name as intptr,byval node as intptr,byval embed as integer)
	end sub

	'/* returns name of file node */
	'CVAPI(const char*) cvGetFileNodeName( const CvFileNode* node );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNodeName(byref node as CvFileNode) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetFileNodeName(byval node as intptr) as IntPtr
	end function

	'/*********************************** Adding own types ***********************************/

	'CVAPI(void) cvRegisterType( const CvTypeInfo* info );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRegisterType(byref info as CvTypeInfo)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRegisterType(byval info as intptr)
	end sub
	'CVAPI(void) cvUnregisterType( const char* type_name );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvUnregisterType(byval type_name as string)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvUnregisterType(byval type_name as byte())
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvUnregisterType(byval type_name as intptr)
	end sub
	'CVAPI(CvTypeInfo*) cvFirstType(void);
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFirstType() as IntPtr
	end function
	'CVAPI(CvTypeInfo*) cvFindType( const char* type_name );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindType(byval type_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindType(byval type_name as byte()) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvFindType(byval type_name as intptr) as IntPtr
	end function
	'CVAPI(CvTypeInfo*) cvTypeOf( const void* struct_ptr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvTypeOf(byval struct_ptr as intptr) as IntPtr
	end function

	'/* universal functions */
	'CVAPI(void) cvRelease( void** struct_ptr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvRelease(byref struct_ptr as intptr)
	end sub
	'CVAPI(void*) cvClone( const void* struct_ptr );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvClone(byval struct_ptr as intptr) as IntPtr
	end function

	'/* simple API for reading/writing data */
	'CVAPI(void) cvSave( const char* filename, const void* struct_ptr,
	'                    const char* name CV_DEFAULT(NULL),
	'                    const char* comment CV_DEFAULT(NULL),
	'                    CvAttrList attributes CV_DEFAULT(cvAttrList()));
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as string,byval struct_ptr as intptr,byval name as string,byval comment as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as byte(),byval struct_ptr as intptr,byval name as string,byval comment as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as intptr,byval struct_ptr as intptr,byval name as string,byval comment as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as string,byval struct_ptr as intptr,byval name as byte(),byval comment as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as byte(),byval struct_ptr as intptr,byval name as byte(),byval comment as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as intptr,byval struct_ptr as intptr,byval name as byte(),byval comment as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as string,byval struct_ptr as intptr,byval name as intptr,byval comment as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as byte(),byval struct_ptr as intptr,byval name as intptr,byval comment as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as intptr,byval struct_ptr as intptr,byval name as intptr,byval comment as string,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as string,byval struct_ptr as intptr,byval name as string,byval comment as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as byte(),byval struct_ptr as intptr,byval name as string,byval comment as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as intptr,byval struct_ptr as intptr,byval name as string,byval comment as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as string,byval struct_ptr as intptr,byval name as byte(),byval comment as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as byte(),byval struct_ptr as intptr,byval name as byte(),byval comment as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as intptr,byval struct_ptr as intptr,byval name as byte(),byval comment as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as string,byval struct_ptr as intptr,byval name as intptr,byval comment as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as byte(),byval struct_ptr as intptr,byval name as intptr,byval comment as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as intptr,byval struct_ptr as intptr,byval name as intptr,byval comment as byte(),byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as string,byval struct_ptr as intptr,byval name as string,byval comment as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as byte(),byval struct_ptr as intptr,byval name as string,byval comment as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as intptr,byval struct_ptr as intptr,byval name as string,byval comment as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as string,byval struct_ptr as intptr,byval name as byte(),byval comment as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as byte(),byval struct_ptr as intptr,byval name as byte(),byval comment as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as intptr,byval struct_ptr as intptr,byval name as byte(),byval comment as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as string,byval struct_ptr as intptr,byval name as intptr,byval comment as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as byte(),byval struct_ptr as intptr,byval name as intptr,byval comment as intptr,byval attributes as CvAttrList)
	end sub
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSave(byval filename as intptr,byval struct_ptr as intptr,byval name as intptr,byval comment as intptr,byval attributes as CvAttrList)
	end sub
	'CVAPI(void*) cvLoad( const char* filename,
	'                     CvMemStorage* memstorage CV_DEFAULT(NULL),
	'                     const char* name CV_DEFAULT(NULL),
	'                     const char** real_name CV_DEFAULT(NULL) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byref memstorage as CvMemStorage,byval name as string,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byref memstorage as CvMemStorage,byval name as string,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byref memstorage as CvMemStorage,byval name as string,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byval memstorage as intptr,byval name as string,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byval memstorage as intptr,byval name as string,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byval memstorage as intptr,byval name as string,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byref memstorage as CvMemStorage,byval name as byte(),byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byref memstorage as CvMemStorage,byval name as byte(),byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byref memstorage as CvMemStorage,byval name as byte(),byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byval memstorage as intptr,byval name as byte(),byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byval memstorage as intptr,byval name as byte(),byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byval memstorage as intptr,byval name as byte(),byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byref memstorage as CvMemStorage,byval name as intptr,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byref memstorage as CvMemStorage,byval name as intptr,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byref memstorage as CvMemStorage,byval name as intptr,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byval memstorage as intptr,byval name as intptr,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byval memstorage as intptr,byval name as intptr,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byval memstorage as intptr,byval name as intptr,byref real_name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byref memstorage as CvMemStorage,byval name as string,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byref memstorage as CvMemStorage,byval name as string,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byref memstorage as CvMemStorage,byval name as string,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byval memstorage as intptr,byval name as string,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byval memstorage as intptr,byval name as string,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byval memstorage as intptr,byval name as string,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byref memstorage as CvMemStorage,byval name as byte(),byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byref memstorage as CvMemStorage,byval name as byte(),byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byref memstorage as CvMemStorage,byval name as byte(),byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byval memstorage as intptr,byval name as byte(),byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byval memstorage as intptr,byval name as byte(),byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byval memstorage as intptr,byval name as byte(),byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byref memstorage as CvMemStorage,byval name as intptr,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byref memstorage as CvMemStorage,byval name as intptr,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byref memstorage as CvMemStorage,byval name as intptr,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as string,byval memstorage as intptr,byval name as intptr,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as byte(),byval memstorage as intptr,byval name as intptr,byval real_name as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoad(byval filename as intptr,byval memstorage as intptr,byval name as intptr,byval real_name as intptr) as IntPtr
	end function

	'/*********************************** Measuring Execution Time ***************************/

	'/* helper functions for RNG initialization and accurate time measurement:
	'   uses internal clock counter on x86 */
	'CVAPI(int64)  cvGetTickCount( void );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTickCount() as long
	end function
	'CVAPI(double) cvGetTickFrequency( void );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTickFrequency() as double
	end function

	'/*********************************** Multi-Threading ************************************/

	'/* retrieve/set the number of threads used in OpenMP implementations */
	'CVAPI(int)  cvGetNumThreads( void );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetNumThreads() as integer
	end function
	'CVAPI(void) cvSetNumThreads( int threads CV_DEFAULT(0) );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetNumThreads(byval threads as integer)
	end sub
	'/* get index of the thread being executed */
	'CVAPI(int)  cvGetThreadNum( void );
	<DllImport(OpenCVInformation.CxCore, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetThreadNum() as integer
	end function


End Module
