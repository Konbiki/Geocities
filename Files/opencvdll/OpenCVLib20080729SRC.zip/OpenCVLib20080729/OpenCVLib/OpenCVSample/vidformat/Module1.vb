﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル vidformat
'・OpenCV付属サンプル「vidformat」(otherlibs\cvcam\sample(の移植です。
'//////////////////////////////////////////////////////////////

Imports OpenCVLib
Imports System.Runtime.InteropServices

Module Module1

    '/**************************************************************************\
    '            How to set video resolution programatically
    '\**************************************************************************/ 
    Sub callback(ByVal Image As IntPtr)

        'cvShowImage("Test", Image)

    End Sub

#If 1 Then
    Function ShowCamVideo(ByVal hwnd As IntPtr, ByVal width As Integer, ByVal height As Integer) As Integer

        'cvNamedWindow("Test", CV_WINDOW_AUTOSIZE)

        Dim vidFmt As New vidformat(width, height, 30)

        Dim ncams As Integer = cvcamGetCamerasCount()
        cvcamSetProperty(1, CVCAM_PROP_ENABLE, CVCAMTRUE)
        cvcamSetProperty(1, CVCAM_PROP_CALLBACK, AddressOf callback)
        Dim hwndint As Integer = hwnd.ToInt32
        cvcamSetProperty(1, CVCAM_PROP_WINDOW, hwndint)

        'Set Video Format Property
        cvcamSetProperty(1, CVCAM_PROP_SETFORMAT, vidFmt)

        If cvcamInit() = 0 Then
            Return 0
        End If
        cvcamStart()
        Return 1
    End Function

    Sub Main()

        'ShowCameraList()

        cvNamedWindow("cvcam window", CV_WINDOW_AUTOSIZE)
        If ShowCamVideo(cvGetWindowHandle("cvcam window"), 640, 480) <> 0 Then
            cvWaitKey(0)
            cvcamStop()
        End If
        cvcamExit()

    End Sub

#Region "test"

    'カメラリストをコンソールに出力する
    Private Sub ShowCameraList()

        Dim cnt As Integer = cvcamGetCamerasCount()
        Console.WriteLine("camera count = {0}", cnt)

        Dim des As New CameraDescription
        For x As Integer = 0 To cnt - 1
            des.Clear()
            Dim rc As Integer = cvcamGetProperty(x, CVCAM_DESCRIPTION, des)
            If rc = 0 Then
                Console.WriteLine("[{0}] : {1}", x, des.DeviceDescriptionString)
            Else
                Console.WriteLine("[{0}] : error ({1})", x, rc)
            End If
        Next

    End Sub

#End Region

#Else
    '/**************************************************************************\
    '                       How To Play Media file by CvCam
    '\**************************************************************************/
    Sub ShowAVIVideo(ByVal Filename As String, ByVal hwnd As IntPtr, ByVal width As Integer, ByVal height As Integer)

        Dim f As UInteger = cvcamAVIOpenFile(Filename)
        If (f And &H80000000) <> 0 Then Exit Sub

        'cvcamavi.hのReleaseSource/operator[]内で
        'ハンドル値のバイアスを戻していない(なぜかコメントアウトしてある)為、
        'cvcamAVIOpenFileの戻り値をそのまま使うとアクセス例外が発生してしまう。
        'この問題を回避する為、バイアス分を引いた値にして つじつま を合わせる。
        '恐らく次のリリースでは修正されるであろう。
        f = CUInt(f - 1000) '1000 = AVIS_START

        cvcamAVISetWindow(f, hwnd)
        cvcamAVISetCallback(f, AddressOf callback)
        cvcamAVISetSize(f, width, height)
        cvcamAVIRun(f)
        cvcamAVIWaitCompletion(f)
        cvcamAVIStop(f)
        cvcamAVICloseFile(f)

    End Sub

    Sub Main()

        If My.Application.CommandLineArgs.Count > 0 Then
            cvNamedWindow("avi window", CV_WINDOW_AUTOSIZE)
            ShowAVIVideo(My.Application.CommandLineArgs(0), cvGetWindowHandle("avi window"), 320, 240)
        End If

    End Sub

#End If


End Module
