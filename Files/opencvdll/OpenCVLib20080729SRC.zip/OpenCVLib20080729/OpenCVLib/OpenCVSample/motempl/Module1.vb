Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLib�T���v�� motempl
'�EOpenCV�t���T���v���umotempl�v�̈ڐA�ł��B
'//////////////////////////////////////////////////////////////

Imports OpenCVLib
Imports System.Runtime.InteropServices

Module Module1

    'various tracking parameters (in seconds)
    Private Const MHI_DURATION As Double = 1
    Private Const MAX_TIME_DELTA As Double = 0.5
    Private Const MIN_TIME_DELTA As Double = 0.05

    'number of cyclic frame buffer used for motion detection
    '(should, probably, depend on FPS)
    Private Const N As Integer = 4

    'ring image buffer
    Private buf As IntPtr()
    Private last As Integer = 0

    'temporary images
    Private mhi As IntPtr       'MHI(Motion History Image)
    Private orient As IntPtr    'orientation
    Private mask As IntPtr      'valid orientation mask
    Private segmask As IntPtr   'motion segmentation map
    Private storage As IntPtr   'temporary storage


    'parameters:
    'img - input video frame
    'dst - resultant motion picture
    'args - optional parameters
    Private Sub update_mhi(ByVal img As IntPtr, ByVal dst As IntPtr, ByVal diff_threshold As Integer)

        Dim timestamp As Double = System.Environment.TickCount / 1000   'get current time in seconds
        Dim size As CvSize = CvUtility.GetIplImageSize(img)             'get current frame size
        Dim i As Integer, idx1 As Integer = last, idx2 As Integer
        Dim silh As IntPtr
        Dim seq As CvSeq
        Dim comp_rect As CvRect
        Dim count As Double
        Dim angle As Double
        Dim center As CvPoint
        Dim magnitude As Double
        Dim color As CvScalar

        'allocate images at the beginning or
        'reallocate them if the frame size is changed
        Dim mhisize As CvSize = CvUtility.GetIplImageSize(mhi)
        If (mhi = IntPtr.Zero) Or (mhisize.width <> size.width) Or (mhisize.height <> size.height) Then
            If buf Is Nothing Then
                ReDim buf(N - 1)
            End If
            For i = 0 To N - 1
                cvReleaseImage(buf(i))
                buf(i) = cvCreateImage(size, IPL_DEPTH_8U, 1)
                cvZero(buf(i))
            Next
            cvReleaseImage(mhi)
            cvReleaseImage(orient)
            cvReleaseImage(segmask)
            cvReleaseImage(mask)

            mhi = cvCreateImage(size, IPL_DEPTH_32F, 1)
            cvZero(mhi)     'clear MHI at the beginning
            orient = cvCreateImage(size, IPL_DEPTH_32F, 1)
            segmask = cvCreateImage(size, IPL_DEPTH_32F, 1)
            mask = cvCreateImage(size, IPL_DEPTH_8U, 1)
        End If

        cvCvtColor(img, buf(last), CV_BGR2GRAY) 'convert frame to grayscale

        idx2 = (last + 1) Mod N     'index of (last - (N-1))th frame
        last = idx2

        silh = buf(idx2)
        cvAbsDiff(buf(idx1), buf(idx2), silh)   'get difference between frames

        cvThreshold(silh, silh, diff_threshold, 1, CV_THRESH_BINARY)    'and threshold it
        cvUpdateMotionHistory(silh, mhi, timestamp, MHI_DURATION)       'update MHI

        'convert MHI to blue 8u image
        cvCvtScale(mhi, mask, 255 / MHI_DURATION, _
                (MHI_DURATION - timestamp) * 255 / MHI_DURATION)
        cvZero(dst)
        cvCvtPlaneToPix(mask, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, dst)

        'calculate motion gradient orientation and valid orientation mask
        cvCalcMotionGradient(mhi, mask, orient, MAX_TIME_DELTA, MIN_TIME_DELTA, 3)

        If storage = IntPtr.Zero Then
            storage = cvCreateMemStorage(0)
        Else
            cvClearMemStorage(storage)
        End If

        'segment motion: get sequence of motion components
        'segmask is marked motion components map. It is not used further
        Dim seqptr As IntPtr = cvSegmentMotion(mhi, segmask, storage, timestamp, MAX_TIME_DELTA)
        seq = CvSeq.CreateFrom(seqptr)

        'iterate through the motion components,
        'One more iteration (i == -1) corresponds to the whole image (global motion)
        For i = -1 To seq.total - 1

            If i < 0 Then   'case of the whole image
                comp_rect = New CvRect(0, 0, size.width, size.height)
                color = CV_RGB(255, 255, 255)
                magnitude = 100
            Else    'i-th motion component
                Dim conn As CvConnectedComp = CvUtility.PtrToStructure(Of CvConnectedComp)(cvGetSeqElem(seqptr, i))
                comp_rect = conn.rect
                If comp_rect.width + comp_rect.height < 100 Then    'reject very small components
                    Continue For
                End If
                color = CV_RGB(255, 0, 0)
                magnitude = 30
            End If

            'select component ROI
            cvSetImageROI(silh, comp_rect)
            cvSetImageROI(mhi, comp_rect)
            cvSetImageROI(orient, comp_rect)
            cvSetImageROI(mask, comp_rect)

            'calculate orientation
            angle = cvCalcGlobalOrientation(orient, mask, mhi, timestamp, MHI_DURATION)
            angle = 360.0 - angle   'adjust for images with top-left origin

            count = cvNorm(silh, IntPtr.Zero, CV_L1, IntPtr.Zero)  'calculate number of points within silhouette ROI

            cvResetImageROI(mhi)
            cvResetImageROI(orient)
            cvResetImageROI(mask)
            cvResetImageROI(silh)

            'check for the case of little motion
            If count < comp_rect.width * comp_rect.height * 0.05 Then
                Continue For
            End If

            'draw a clock with arrow indicating the direction
            center = New CvPoint((comp_rect.x + comp_rect.width \ 2), _
                              (comp_rect.y + comp_rect.height \ 2))

            cvCircle(dst, center, cvRound(magnitude * 1.2), color, 3, CV_AA, 0)
            cvLine(dst, center, New CvPoint(cvRound(center.x + magnitude * Math.Cos(angle * CV_PI / 180)), _
                    cvRound(center.y - magnitude * Math.Sin(angle * CV_PI / 180))), color, 3, CV_AA, 0)
        Next

    End Sub


    '���C��
    Sub Main()

        Dim motion As IntPtr
        Dim capture As IntPtr

        Dim argc As Integer = My.Application.CommandLineArgs.Count
        Dim idx As Integer
        If (argc = 0) OrElse ((argc > 0) AndAlso (Integer.TryParse(My.Application.CommandLineArgs(0), idx))) Then
            capture = cvCaptureFromCAM(idx)
        Else
            capture = cvCaptureFromFile(My.Application.CommandLineArgs(0))
        End If

        If capture <> IntPtr.Zero Then
            cvNamedWindow("Motion", 1)

            Do
                Dim image As IntPtr
                If cvGrabFrame(capture) = 0 Then Exit Do
                image = cvRetrieveFrame(capture)

                If image <> IntPtr.Zero Then
                    If motion = IntPtr.Zero Then
                        motion = cvCreateImage(CvUtility.GetIplImageSize(image), 8, 3)
                        cvZero(motion)
                        CvUtility.SetIplImageOrigin(motion, CvUtility.GetIplImageOrigin(image))
                    End If
                End If

                update_mhi(image, motion, 30)
                cvShowImage("Motion", motion)

                If cvWaitKey(10) >= 0 Then Exit Do
            Loop
            cvReleaseCapture(capture)
            cvDestroyWindow("Motion")

        End If

    End Sub

End Module
