Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLib�T���v�� edge
'�EOpenCV�t���T���v���uedge�v�̈ڐA�ł��B
'//////////////////////////////////////////////////////////////

Imports OpenCVLib
Imports System.Runtime.InteropServices

Module Module1

    '�萔
    Private Const WNDNAME As String = "Edge"
    Private Const TBARNAME As String = "Threshold"

    '���W���[���ϐ�
    Private mImage As IntPtr
    Private mCedge As IntPtr
    Private mGray As IntPtr
    Private mEdge As IntPtr

    '���C��
    Sub Main()

        '�摜�t�@�C��������
        Dim filename As String
        If My.Application.CommandLineArgs.Count > 0 Then
            filename = My.Application.CommandLineArgs(0)
        Else
            filename = CvUtility.GetDLLPath() + "\samples\c\fruits.jpg"
        End If

        '���̓C���[�W�̓Ǎ�
        mImage = cvLoadImage(filename, 1)
        If mImage = IntPtr.Zero Then Exit Sub

        '���̓C���[�W�̃T�C�Y�擾
        Dim sz As CvSize = CvUtility.GetIplImageSize(mImage)

        'Create the output image
        mCedge = cvCreateImage(sz, IPL_DEPTH_8U, 3)

        'Convert to grayscale
        mGray = cvCreateImage(sz, IPL_DEPTH_8U, 1)
        mEdge = cvCreateImage(sz, IPL_DEPTH_8U, 1)
        cvCvtColor(mImage, mGray, CV_BGR2GRAY)

        'Create a window
        cvNamedWindow(WNDNAME, 1)

        'create a toolbar 
        cvCreateTrackbar(TBARNAME, WNDNAME, IntPtr.Zero, 100, AddressOf on_trackbar)
        cvSetTrackbarPos(TBARNAME, WNDNAME, 1)

        'Show the image
        on_trackbar(0)

        'Wait for a key stroke; the same function arranges events processing
        cvWaitKey(0)
        cvReleaseImage(mImage)
        cvReleaseImage(mGray)
        cvReleaseImage(mEdge)
        cvDestroyWindow(WNDNAME)

    End Sub

    Private Sub on_trackbar(ByVal h As Integer)

        cvSmooth(mGray, mEdge, CV_BLUR, 3, 3, 0, 0)
        cvNot(mGray, mEdge)

        'Run the edge detector on grayscale
        cvCanny(mGray, mEdge, CDbl(h), CDbl(h * 3), 3)

        cvZero(mCedge)

        ' copy edge points
        cvCopy(mImage, mCedge, mEdge)

        cvShowImage(WNDNAME, mCedge)

    End Sub

End Module
