Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLib�T���v�� contours
'�EOpenCV�t���T���v���ucontours�v�̈ڐA�ł��B
'//////////////////////////////////////////////////////////////

Imports OpenCVLib
Imports System.Runtime.InteropServices

Module Module1

    '�萔
    Private Const W As Integer = 500

    '���W���[���ϐ�
    Private mContours As IntPtr

    '���C��
    Sub Main()

        Dim storage As IntPtr = cvCreateMemStorage(0)
        Dim img As IntPtr = cvCreateImage(New CvSize(W, W), 8, 1)

        cvZero(img)

        For i As Integer = 0 To 5

            Dim dx As Integer = (i Mod 2) * 250 - 30
            Dim dy As Integer = (i \ 2) * 150
            Dim white As CvScalar = cvrealscalar(255)
            Dim black As CvScalar = cvrealscalar(0)

            If i = 0 Then
                For j As Integer = 0 To 10
                    Dim angle As Double = (j + 5) * CV_PI / 21
                    cvLine(img, _
                        New CvPoint(cvRound(dx + 100 + j * 10 - 80 * Math.Cos(angle)), _
                            cvRound(dy + 100 - 90 * Math.Sin(angle))), _
                        New CvPoint(cvRound(dx + 100 + j * 10 - 30 * Math.Cos(angle)), _
                            cvRound(dy + 100 - 30 * Math.Sin(angle))), white, 1, 8, 0)
                Next
            End If


            cvEllipse(img, New CvPoint(dx + 150, dy + 100), New CvSize(100, 70), 0, 0, 360, white, -1, 8, 0)
            cvEllipse(img, New CvPoint(dx + 115, dy + 70), New CvSize(30, 20), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, New CvPoint(dx + 185, dy + 70), New CvSize(30, 20), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, New CvPoint(dx + 115, dy + 70), New CvSize(15, 15), 0, 0, 360, white, -1, 8, 0)
            cvEllipse(img, New CvPoint(dx + 185, dy + 70), New CvSize(15, 15), 0, 0, 360, white, -1, 8, 0)
            cvEllipse(img, New CvPoint(dx + 115, dy + 70), New CvSize(5, 5), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, New CvPoint(dx + 185, dy + 70), New CvSize(5, 5), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, New CvPoint(dx + 150, dy + 100), New CvSize(10, 5), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, New CvPoint(dx + 150, dy + 150), New CvSize(40, 10), 0, 0, 360, black, -1, 8, 0)
            cvEllipse(img, New CvPoint(dx + 27, dy + 100), New CvSize(20, 35), 0, 0, 360, white, -1, 8, 0)
            cvEllipse(img, New CvPoint(dx + 273, dy + 100), New CvSize(20, 35), 0, 0, 360, white, -1, 8, 0)

        Next

        cvNamedWindow("image", 1)
        cvShowImage("image", img)

        cvFindContours(img, storage, mContours, Marshal.SizeOf(GetType(CvContour)), _
                        CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, New CvPoint(0, 0))

        'comment this out if you do not want approximation
        mContours = cvApproxPoly(mContours, Marshal.SizeOf(GetType(CvContour)), storage, CV_POLY_APPROX_DP, 3, 1)

        cvNamedWindow("contours", 1)
        cvCreateTrackbar("levels+3", "contours", IntPtr.Zero, 7, AddressOf on_trackbar)
        cvSetTrackbarPos("levels+3", "contours", 3)

        on_trackbar(0)
        cvWaitKey(0)
        cvReleaseMemStorage(storage)
        cvReleaseImage(img)

    End Sub

    Private Sub on_trackbar(ByVal pos As Integer)
        Dim cnt_img As IntPtr = cvCreateImage(New CvSize(W, W), 8, 3)
        Dim _contours As IntPtr = mContours
        Dim _levels As Integer = pos - 3
        If _levels <= 0 Then  ' get to the nearest face to make it look more funny
            '_contours = _contours->h_next->h_next->h_next;
            Dim w1 As CvSeq = CvSeq.CreateFrom(_contours)
            Dim w2 As CvSeq = CvSeq.CreateFrom(w1.h_next)
            Dim w3 As CvSeq = CvSeq.CreateFrom(w2.h_next)
            _contours = w3.h_next
        End If
        cvZero(cnt_img)
        cvDrawContours(cnt_img, _contours, CV_RGB(255, 0, 0), CV_RGB(0, 255, 0), _levels, 3, CV_AA, New CvPoint(0, 0))
        cvShowImage("contours", cnt_img)
        cvReleaseImage(cnt_img)
    End Sub

End Module
