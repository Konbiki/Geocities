﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル motempl
'・OpenCV付属サンプル「motempl」の移植です。
'・動作は全く同じですが、２つの方式で移植してあります。
'//////////////////////////////////////////////////////////////

Imports OpenCVLib
Imports System.Runtime.InteropServices
Imports System.drawing

Module Module1

#If False Then
    'Ｃソース上でポインタで扱っているものを
    'IntPtrで扱うように移植したサンプルです。
    '大抵の場合はこの方法でいけます
    '（引数や戻り値の意味を理解してなくともよかったりします）が、
    'データの取り出し/更新が直接行えないため面倒になります。

    Private image As IntPtr = IntPtr.Zero
    Private grey As IntPtr = IntPtr.Zero
    Private prev_grey As IntPtr = IntPtr.Zero
    Private pyramid As IntPtr = IntPtr.Zero
    Private prev_pyramid As IntPtr = IntPtr.Zero
    Private swap_temp As IntPtr

    Private win_size As Integer = 10
    Private Const MAX_COUNT As Integer = 500
    Private points(1) As IntPtr
    Private swap_points As IntPtr
    Private status As IntPtr = IntPtr.Zero
    Private count As Integer = 0
    Private need_to_init As Integer = 0
    Private night_mode As Integer = 0
    Private flags As Integer = 0
    Private add_remove_pt As Integer = 0
    Private pt As New CvPoint

    Private wrap_image As IplImageWrapper
    Private SizeOfCvPoint2D32f As Integer = Marshal.SizeOf(GetType(CvPoint2D32f))

    Public Sub on_mouse(ByVal eventcode As Integer, ByVal x As Integer, ByVal y As Integer, ByVal flags As Integer, ByVal param As System.IntPtr)

        If image = IntPtr.Zero Then Return

        If wrap_image.Origin <> 0 Then
            y = wrap_image.Size.Height - y
        End If

        If eventcode = CV_EVENT_LBUTTONDOWN Then
            pt = New CvPoint(x, y)
            add_remove_pt = 1
        End If

    End Sub

    Sub Main()

        Dim capture As IntPtr

        Dim argc As Integer = My.Application.CommandLineArgs.Count
        Dim idx As Integer
        If (argc = 0) OrElse ((argc > 0) AndAlso (Integer.TryParse(My.Application.CommandLineArgs(0), idx))) Then
            capture = cvCaptureFromCAM(idx)
        Else
            capture = cvCaptureFromFile(My.Application.CommandLineArgs(0))
        End If

        If capture = IntPtr.Zero Then
            Console.WriteLine("Could not initialize capturing...")
            Exit Sub
        End If

        'print a welcome message, and the OpenCV version
        Console.WriteLine("Welcome to lkdemo, using OpenCV dll path '{0}'", GetDLLPath())
        Console.WriteLine("Hot keys: ")
        Console.WriteLine(vbTab + "ESC - quit the program")
        Console.WriteLine(vbTab + "r - auto-initialize tracking")
        Console.WriteLine(vbTab + "c - delete all the points")
        Console.WriteLine(vbTab + "n - switch the """"night"""" mode on/off")
        Console.WriteLine(vbTab + "To add/remove a feature point click it")

        cvNamedWindow("LkDemo", 1) 'original is 0
        Dim onmouseeventhandler As New HighGUI.CvMouseCallback(AddressOf on_mouse)
        cvSetMouseCallback("LkDemo", onmouseeventhandler, IntPtr.Zero)

        Dim wrap_frame As IplImageWrapper = Nothing
        Do
            Dim frame As IntPtr
            Dim i As Integer, k As Integer, c As Integer

            frame = cvQueryFrame(capture)
            If frame = IntPtr.Zero Then Exit Do
            If wrap_frame Is Nothing Then wrap_frame = New IplImageWrapper(frame)

            If image = IntPtr.Zero Then
                'allocate all the buffers
                image = cvCreateImage(cvGetSize(frame), 8, 3)
                wrap_image = New IplImageWrapper(image)
                wrap_image.Origin = wrap_frame.Origin
                grey = cvCreateImage(cvGetSize(frame), 8, 1)
                prev_grey = cvCreateImage(cvGetSize(frame), 8, 1)
                pyramid = cvCreateImage(cvGetSize(frame), 8, 1)
                prev_pyramid = cvCreateImage(cvGetSize(frame), 8, 1)
                points(0) = cvAlloc(MAX_COUNT * SizeOfCvPoint2D32f)
                points(1) = cvAlloc(MAX_COUNT * SizeOfCvPoint2D32f)
                status = cvAlloc(MAX_COUNT)
                flags = 0
            End If

            cvCopy(frame, image, IntPtr.Zero)
            cvCvtColor(image, grey, CV_BGR2GRAY)

            If night_mode <> 0 Then
                cvZero(image)
            End If

            If need_to_init <> 0 Then
                'automatic initialization
                Dim eig As IntPtr = cvCreateImage(cvGetSize(grey), 32, 1)
                Dim temp As IntPtr = cvCreateImage(cvGetSize(grey), 32, 1)
                Dim quality As Double = 0.01
                Dim min_distance As Double = 10

                count = MAX_COUNT
                cvGoodFeaturesToTrack(grey, eig, temp, points(1), count, _
                                        quality, min_distance, IntPtr.Zero, 3, 0, 0.04)
                cvFindCornerSubPix(grey, points(1), count, _
                    New CvSize(win_size, win_size), New CvSize(-1, -1), _
                    New CvTermCriteria(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03))
                cvReleaseImage(eig)
                cvReleaseImage(temp)

                add_remove_pt = 0

            ElseIf count > 0 Then
                cvCalcOpticalFlowPyrLK(prev_grey, grey, prev_pyramid, pyramid, _
                    points(0), points(1), count, New CvSize(win_size, win_size), 3, status, IntPtr.Zero, _
                    New CvTermCriteria(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03), flags)
                flags = flags Or CV_LKFLOW_PYR_A_READY
                k = 0
                For i = 0 To count - 1
                    Dim ppptr As IntPtr = CvPoint2D32fPtr(points(1), i)
                    Dim pp As CvPoint2D32f = PtrToStructure(Of CvPoint2D32f)(ppptr)
                    If add_remove_pt <> 0 Then
                        Dim dx As Double = pt.x - pp.x
                        Dim dy As Double = pt.y - pp.y
                        If dx * dx + dy * dy <= 25 Then
                            add_remove_pt = 0
                            Continue For
                        End If
                    End If

                    If Marshal.ReadByte(status, i) = 0 Then
                        Continue For
                    End If

                    Dim pkptr As IntPtr = CvPoint2D32fPtr(points(1), k)
                    CopyMemory(pkptr, ppptr, SizeOfCvPoint2D32f)
                    k += 1
                    cvCircle(image, cvPointFrom32f(pp), 3, CV_RGB(0, 255, 0), -1, 8, 0)
                Next
                count = k
            End If

            If (add_remove_pt <> 0) And (count < MAX_COUNT) Then
                Dim ptr As IntPtr = CType(points(1).ToInt32 + count * SizeOfCvPoint2D32f, IntPtr)
                StructureToPtr(Of CvPoint2D32f)(cvPointTo32f(pt), ptr)
                count += 1
                cvFindCornerSubPix(grey, ptr, 1, New CvSize(win_size, win_size), New CvSize(-1, -1), New CvTermCriteria(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03))
                add_remove_pt = 0
            End If

            CV_SWAP(prev_grey, grey, swap_temp)
            CV_SWAP(prev_pyramid, pyramid, swap_temp)
            CV_SWAP(points(0), points(1), swap_points)
            need_to_init = 0
            cvShowImage("LkDemo", image)

            c = cvWaitKey(10)
            If c = 27 Then Exit Do
            Select Case c
                Case Asc("r")
                    need_to_init = 1

                Case Asc("c")
                    count = 0

                Case Asc("n")
                    night_mode = night_mode Xor 1

            End Select
        Loop

        cvReleaseCapture(capture)
        cvDestroyWindow("LkDemo")

    End Sub

    Private Function CvPoint2D32fPtr(ByVal Base As IntPtr, ByVal Index As Integer) As IntPtr
        Return CType(Base.ToInt32 + Index * SizeOfCvPoint2D32f, IntPtr)
    End Function

#Else
    'マーシャリングを活用したサンプルです。
    '本来のコードの意味にあうように型などを指定する必要がありますが、
    'データの取り出しなどが大変容易になります。
    '（パフォーマンスはケースバイケースでしょう。）

    Private image As IntPtr = IntPtr.Zero
    Private grey As IntPtr = IntPtr.Zero
    Private prev_grey As IntPtr = IntPtr.Zero
    Private pyramid As IntPtr = IntPtr.Zero
    Private prev_pyramid As IntPtr = IntPtr.Zero
    Private swap_temp As IntPtr

    Private win_size As Integer = 10
    Private Const MAX_COUNT As Integer = 500
    Private points_0() As CvPoint2D32f
    Private points_1() As CvPoint2D32f
    Private swap_points() As CvPoint2D32f
    Private status() As Byte
    Private count As Integer = 0
    Private need_to_init As Integer = 0
    Private night_mode As Integer = 0
    Private flags As Integer = 0
    Private add_remove_pt As Integer = 0
    Private pt As New CvPoint

    Private wrap_image As IplImageWrapper

    Public Sub on_mouse(ByVal eventcode As Integer, ByVal x As Integer, ByVal y As Integer, ByVal flags As Integer, ByVal param As System.IntPtr)

        If image = IntPtr.Zero Then Return

        If wrap_image.Origin <> 0 Then
            y = wrap_image.Size.Height - y
        End If

        If eventcode = CV_EVENT_LBUTTONDOWN Then
            pt = New CvPoint(x, y)
            add_remove_pt = 1
        End If

    End Sub

    Sub Main()

        Dim capture As IntPtr

        Dim argc As Integer = My.Application.CommandLineArgs.Count
        Dim idx As Integer
        If (argc = 0) OrElse ((argc > 0) AndAlso (Integer.TryParse(My.Application.CommandLineArgs(0), idx))) Then
            capture = cvCaptureFromCAM(idx)
        Else
            capture = cvCaptureFromFile(My.Application.CommandLineArgs(0))
        End If

        If capture = IntPtr.Zero Then
            Console.WriteLine("Could not initialize capturing...")
            Exit Sub
        End If

        'print a welcome message, and the OpenCV version
        Console.WriteLine("Welcome to lkdemo, using OpenCV dll path '{0}'", GetDLLPath())
        Console.WriteLine("Hot keys: ")
        Console.WriteLine(vbTab + "ESC - quit the program")
        Console.WriteLine(vbTab + "r - auto-initialize tracking")
        Console.WriteLine(vbTab + "c - delete all the points")
        Console.WriteLine(vbTab + "n - switch the """"night"""" mode on/off")
        Console.WriteLine(vbTab + "To add/remove a feature point click it")

        cvNamedWindow("LkDemo", 1) 'original is 0
        Dim onmouseeventhandler As New HighGUI.CvMouseCallback(AddressOf on_mouse)
        cvSetMouseCallback("LkDemo", onmouseeventhandler, IntPtr.Zero)

        Dim wrap_frame As IplImageWrapper = Nothing
        Do
            Dim frame As IntPtr
            Dim i As Integer, k As Integer, c As Integer

            frame = cvQueryFrame(capture)
            If frame = IntPtr.Zero Then Exit Do
            If wrap_frame Is Nothing Then wrap_frame = New IplImageWrapper(frame)

            If image = IntPtr.Zero Then
                'allocate all the buffers
                image = cvCreateImage(cvGetSize(frame), 8, 3)
                wrap_image = New IplImageWrapper(image)
                wrap_image.Origin = wrap_frame.Origin
                grey = cvCreateImage(cvGetSize(frame), 8, 1)
                prev_grey = cvCreateImage(cvGetSize(frame), 8, 1)
                pyramid = cvCreateImage(cvGetSize(frame), 8, 1)
                prev_pyramid = cvCreateImage(cvGetSize(frame), 8, 1)
                ReDim points_0(MAX_COUNT - 1)
                ReDim points_1(MAX_COUNT - 1)
                ReDim status(MAX_COUNT - 1)
                flags = 0
            End If

            cvCopy(frame, image, IntPtr.Zero)
            cvCvtColor(image, grey, CV_BGR2GRAY)

            If night_mode <> 0 Then
                cvZero(image)
            End If

            If need_to_init <> 0 Then
                'automatic initialization
                Dim eig As IntPtr = cvCreateImage(cvGetSize(grey), 32, 1)
                Dim temp As IntPtr = cvCreateImage(cvGetSize(grey), 32, 1)
                Dim quality As Double = 0.01
                Dim min_distance As Double = 10

                count = MAX_COUNT
                cvGoodFeaturesToTrack(grey, eig, temp, points_1, count, _
                                        quality, min_distance, IntPtr.Zero, 3, 0, 0.04)
                cvFindCornerSubPix(grey, points_1, count, _
                    New CvSize(win_size, win_size), New CvSize(-1, -1), _
                    New CvTermCriteria(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03))
                cvReleaseImage(eig)
                cvReleaseImage(temp)

                add_remove_pt = 0

            ElseIf count > 0 Then
                cvCalcOpticalFlowPyrLK(prev_grey, grey, prev_pyramid, pyramid, _
                    points_0, points_1, count, New CvSize(win_size, win_size), 3, status, IntPtr.Zero, _
                    New CvTermCriteria(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03), flags)
                flags = flags Or CV_LKFLOW_PYR_A_READY
                k = 0
                For i = 0 To count - 1
                    Dim pp As CvPoint2D32f = points_1(i)
                    If add_remove_pt <> 0 Then
                        Dim dx As Double = pt.x - pp.x
                        Dim dy As Double = pt.y - pp.y
                        If dx * dx + dy * dy <= 25 Then
                            add_remove_pt = 0
                            Continue For
                        End If
                    End If

                    If status(i) = 0 Then
                        Continue For
                    End If

                    points_1(k) = points_1(i)
                    k += 1
                    cvCircle(image, cvPointFrom32f(pp), 3, CV_RGB(0, 255, 0), -1, 8, 0)
                Next
                count = k
            End If

            If (add_remove_pt <> 0) And (count < MAX_COUNT) Then
                points_1(count) = cvPointTo32f(pt)
                count += 1
                cvFindCornerSubPix(grey, points_1(count - 1), 1, New CvSize(win_size, win_size), New CvSize(-1, -1), New CvTermCriteria(CV_TERMCRIT_ITER Or CV_TERMCRIT_EPS, 20, 0.03))
                add_remove_pt = 0
            End If

            CV_SWAP(prev_grey, grey, swap_temp)
            CV_SWAP(prev_pyramid, pyramid, swap_temp)
            CV_SWAP(points_0, points_1, swap_points)

            need_to_init = 0
            cvShowImage("LkDemo", image)

            c = cvWaitKey(10)
            If c = 27 Then Exit Do
            Select Case c
                Case Asc("r")
                    need_to_init = 1

                Case Asc("c")
                    count = 0

                Case Asc("n")
                    night_mode = night_mode Xor 1

            End Select
        Loop

        cvReleaseCapture(capture)
        cvDestroyWindow("LkDemo")

    End Sub

#End If

End Module
