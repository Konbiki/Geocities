Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLib�T���v�� laplace
'�EOpenCV�t���T���v���ulaplace�v�̈ڐA�ł��B
'//////////////////////////////////////////////////////////////

Imports OpenCVLib
Imports System.Runtime.InteropServices

Module Module1

    '���C��
    Sub Main()
        Dim laplace As IntPtr = IntPtr.Zero
        Dim colorlaplace As IntPtr = IntPtr.Zero
        Dim planes() As IntPtr = {IntPtr.Zero, IntPtr.Zero, IntPtr.Zero}
        Dim capture As IntPtr = IntPtr.Zero

        If My.Application.CommandLineArgs.Count = 0 Then
            capture = cvCaptureFromCAM(0)
        ElseIf My.Application.CommandLineArgs.Count = 1 Then
            Dim cmdline As String = My.Application.CommandLineArgs(0)
            Dim camidx As Integer = 0
            If Integer.TryParse(cmdline, camidx) Then
                capture = cvCaptureFromCAM(camidx)
            Else
                capture = cvCaptureFromAVI(cmdline)
            End If
        End If
        If capture = IntPtr.Zero Then
            Console.WriteLine("Could not initialize capturing...")
            Exit Sub
        End If

        cvNamedWindow("Laplacian", 0)

        Do
            Dim frame As IntPtr = cvQueryFrame(capture)
            If frame = IntPtr.Zero Then Exit Do

            If laplace = IntPtr.Zero Then
                Dim sz As CvSize = CvUtility.GetIplImageSize(frame)
                For i As Integer = 0 To 2
                    planes(i) = cvCreateImage(sz, 8, 1)
                Next
                laplace = cvCreateImage(sz, IPL_DEPTH_16S, 1)
                colorlaplace = cvCreateImage(sz, 8, 3)
            End If

            cvCvtPixToPlane(frame, planes(0), planes(1), planes(2), IntPtr.Zero)
            For i As Integer = 0 To 2
                cvLaplace(planes(i), laplace, 3)
                cvConvertScaleAbs(laplace, planes(i), 1, 0)
            Next

            cvCvtPlaneToPix(planes(0), planes(1), planes(2), IntPtr.Zero, colorlaplace)
            SetIplImageOrigin(colorlaplace, GetIplImageOrigin(frame))

            cvShowImage("Laplacian", colorlaplace)

            If cvWaitKey(10) >= 0 Then Exit Do
        Loop

        cvReleaseCapture(capture)
        cvDestroyWindow("Laplacian")

    End Sub

End Module
