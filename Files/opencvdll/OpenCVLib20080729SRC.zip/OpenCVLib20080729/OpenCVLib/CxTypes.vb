Option Explicit On
Option Strict On

Imports System.Runtime.InteropServices

Public Module CxTypes
	'/*M///////////////////////////////////////////////////////////////////////////////////////
	'//
	'//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
	'//
	'//  By downloading, copying, installing or using the software you agree to this license.
	'//  If you do not agree to this license, do not download, install,
	'//  copy or use the software.
	'//
	'//
	'//                        Intel License Agreement
	'//                For Open Source Computer Vision Library
	'//
	'// Copyright (C) 2000, Intel Corporation, all rights reserved.
	'// Third party copyrights are property of their respective owners.
	'//
	'// Redistribution and use in source and binary forms, with or without modification,
	'// are permitted provided that the following conditions are met:
	'//
	'//   * Redistribution's of source code must retain the above copyright notice,
	'//     this list of conditions and the following disclaimer.
	'//
	'//   * Redistribution's in binary form must reproduce the above copyright notice,
	'//     this list of conditions and the following disclaimer in the documentation
	'//     and/or other materials provided with the distribution.
	'//
	'//   * The name of Intel Corporation may not be used to endorse or promote products
	'//     derived from this software without specific prior written permission.
	'//
	'// This software is provided by the copyright holders and contributors "as is" and
	'// any express or implied warranties, including, but not limited to, the implied
	'// warranties of merchantability and fitness for a particular purpose are disclaimed.
	'// In no event shall the Intel Corporation or contributors be liable for any direct,
	'// indirect, incidental, special, exemplary, or consequential damages
	'// (including, but not limited to, procurement of substitute goods or services;
	'// loss of use, data, or profits; or business interruption) however caused
	'// and on any theory of liability, whether in contract, strict liability,
	'// or tort (including negligence or otherwise) arising in any way out of
	'// the use of this software, even if advised of the possibility of such damage.
	'//
	'//M*/


	'/* CvArr* is used to pass arbitrary array-like data structures
	'   into the functions where the particular
	'   array type is recognized at runtime */
	'typedef void CvArr;
	'Typedef : Unsupport

	'typedef union Cv32suf
	'{
	'    int i;
	'    unsigned u;
	'    float f;
	'}
	'Cv32suf;
    <StructLayout(LayoutKind.Explicit, size:=4)> _
    Public Structure Cv32suf
        <FieldOffset(0)> Public i As Integer
        <FieldOffset(0)> Public u As UInteger
        <FieldOffset(0)> Public f As Single
    End Structure



	'typedef union Cv64suf
	'{
	'    int64 i;
	'    uint64 u;
	'    double f;
	'}
	'Cv64suf;
    <StructLayout(LayoutKind.Explicit, size:=8)> _
    Public Structure Cv64suf
        <FieldOffset(0)> Public i As Long
        <FieldOffset(0)> Public u As ULong
        <FieldOffset(0)> Public f As Double
        <FieldOffset(0)> Public it As LongToInt
    End Structure
    <StructLayout(LayoutKind.Explicit, size:=4)> _
    Public Structure LongToInt
        <FieldOffset(0)> Public l As Long
        <FieldOffset(0)> Public il As Integer
        <FieldOffset(4)> Public ih As Integer
    End Structure



	'/****************************************************************************************\
	'*                             Common macros and inline functions                         *
	'\****************************************************************************************/

	'#define CV_PI   3.1415926535897932384626433832795
	public const  CV_PI as double =  3.1415926535897932384626433832795
	'#define CV_LOG2 0.69314718055994530941723212145818
	public const  CV_LOG2 as double =  0.69314718055994530941723212145818

	'#define CV_SWAP(a,b,t) ((t) = (a), (a) = (b), (b) = (t))
    Public Function CV_SWAP(Of TYP)(ByRef a As TYP, ByRef b As TYP, ByRef t As TYP) As TYP
        t = a : a = b : b = t
        Return t
    End Function



	'#define MIN(a,b)  ((a) > (b) ? (b) : (a))
    Public Function MIN(ByVal a As Integer, ByVal b As Integer) As Integer
        If a < b Then Return a Else Return b
    End Function



	'#define MAX(a,b)  ((a) < (b) ? (b) : (a))
    Public Function MAX(ByVal a As Integer, ByVal b As Integer) As Integer
        If a > b Then Return a Else Return b
    End Function



	'/* min & max without jumps */
	'#define  CV_IMIN(a, b)  ((a) ^ (((a)^(b)) & (((a) < (b)) - 1)))
    Public Function CV_IMIN(ByVal a As Integer, ByVal b As Integer) As Integer
        If a < b Then Return a Else Return b
    End Function



	'#define  CV_IMAX(a, b)  ((a) ^ (((a)^(b)) & (((a) > (b)) - 1)))
    Public Function CV_IMAX(ByVal a As Integer, ByVal b As Integer) As Integer
        If a > b Then Return a Else Return b
    End Function



	'/* absolute value without jumps */
	'#define  CV_IABS(a)     (((a) ^ ((a) < 0 ? -1 : 0)) - ((a) < 0 ? -1 : 0))
    Public Function CV_IABS(ByVal a As Integer) As Integer
        Return Math.Abs(a)
    End Function


	'#define  CV_CMP(a,b)    (((a) > (b)) - ((a) < (b)))
    Public Function CV_CMP(ByVal a As Integer, ByVal b As Integer) As Integer
        If a < b Then Return -1
        If a > b Then Return 1
        Return 0
    End Function


	'#define  CV_SIGN(a)     CV_CMP((a),0)
    Public Function CV_SIGN(ByVal a As Integer) As Integer
        Return Math.Sign(a)
    End Function



	'CV_INLINE  int  cvRound( double value )
	'{
	'    /*
	'     the algorithm was taken from Agner Fog's optimization guide
	'     at http://www.agner.org/assem
	'     */
	'    Cv64suf temp;
	'    temp.f = value + 6755399441055744.0;
	'    return (int)temp.u;
	'}
    Public Function cvRound(ByVal value As Double) As Integer
        Dim temp As Cv64suf
        temp.f = value + 6755399441055744.0
        Return temp.it.il
    End Function




	'CV_INLINE  int  cvFloor( double value )
	'{
	'    int temp = cvRound(value);
	'    Cv32suf diff;
	'    diff.f = (float)(value - temp);
	'    return temp - (diff.i < 0);
	'}
    Public Function cvFloor(ByVal value As Double) As Integer
        Dim temp As Integer = cvRound(value)
        Dim diff As Cv32suf
        diff.f = CSng(value - temp)
        If diff.i < 0 Then temp -= 1
        Return temp
    End Function




	'CV_INLINE  int  cvCeil( double value )
	'{
	'    int temp = cvRound(value);
	'    Cv32suf diff;
	'    diff.f = (float)(temp - value);
	'    return temp + (diff.i < 0);
	'}
    Public Function cvCeil(ByVal value As Double) As Integer
        Dim temp As Integer = cvRound(value)
        Dim diff As Cv32suf
        diff.f = CSng(temp - value)
        If diff.i < 0 Then temp += 1
        Return temp
    End Function



	'#define cvInvSqrt(value) ((float)(1./sqrt(value)))
    Public Function cvInvSqrt(ByVal value As Single) As Single
        Return CSng(1 / Math.Sqrt(value))
    End Function


	'#define cvSqrt(value)  ((float)sqrt(value))
    Public Function cvSqrt(ByVal value As Single) As Single
        Return CSng(Math.Sqrt(value))
    End Function



	'CV_INLINE int cvIsNaN( double value )
	'{
	'    Cv64suf ieee754;
	'    ieee754.f = value;
	'    return ((unsigned)(ieee754.u >> 32) & 0x7fffffff) +
	'           ((unsigned)ieee754.u != 0) > 0x7ff00000;
	'}
    Public Function cvIsNaN(ByVal value As Double) As Integer
        If Double.IsNaN(value) Then Return 1
        Return 0
    End Function




	'CV_INLINE int cvIsInf( double value )
	'{
	'    Cv64suf ieee754;
	'    ieee754.f = value;
	'    return ((unsigned)(ieee754.u >> 32) & 0x7fffffff) == 0x7ff00000 &&
	'           (unsigned)ieee754.u == 0;
	'}
    Public Function cvIsInf(ByVal value As Double) As Integer
        If Double.IsInfinity(value) Then Return 1
        Return 0
    End Function




	'/*************** Random number generation *******************/

	'typedef uint64 CvRNG;
	'Typedef : Unsupport

	'CV_INLINE CvRNG cvRNG( int64 seed CV_DEFAULT(-1))
	'{
	'    CvRNG rng = seed ? (uint64)seed : (uint64)(int64)-1;
	'    return rng;
	'}
	'ToDo : Function

	'/* returns random 32-bit unsigned integer */
	'CV_INLINE unsigned cvRandInt( CvRNG* rng )
	'{
	'    uint64 temp = *rng;
	'    temp = (uint64)(unsigned)temp*1554115554 + (temp >> 32);
	'    *rng = temp;
	'    return (unsigned)temp;
	'}
	'ToDo : Function

	'/* returns random floating-point number between 0 and 1 */
	'CV_INLINE double cvRandReal( CvRNG* rng )
	'{
	'    return cvRandInt(rng)*2.3283064365386962890625e-10 /* 2^-32 */;
	'}
	'ToDo : Function

	'/****************************************************************************************\
	'*                                  Image type (IplImage)                                 *
	'\****************************************************************************************/

	'/*
	' * The following definitions (until #endif)
	' * is an extract from IPL headers.
	' * Copyright (c) 1995 Intel Corporation.
	' */
	'#define IPL_DEPTH_SIGN 0x80000000
	public const  IPL_DEPTH_SIGN as integer =  &H80000000

	'#define IPL_DEPTH_1U     1
	public const  IPL_DEPTH_1U as integer =  1
	'#define IPL_DEPTH_8U     8
	public const  IPL_DEPTH_8U as integer =  8
	'#define IPL_DEPTH_16U   16
	public const  IPL_DEPTH_16U as integer =  16
	'#define IPL_DEPTH_32F   32
	public const  IPL_DEPTH_32F as integer =  32

	'#define IPL_DEPTH_8S  (IPL_DEPTH_SIGN| 8)
	public const  IPL_DEPTH_8S as integer =  (IPL_DEPTH_SIGN or  8)
	'#define IPL_DEPTH_16S (IPL_DEPTH_SIGN|16)
	public const  IPL_DEPTH_16S as integer =  (IPL_DEPTH_SIGN or 16)
	'#define IPL_DEPTH_32S (IPL_DEPTH_SIGN|32)
	public const  IPL_DEPTH_32S as integer =  (IPL_DEPTH_SIGN or 32)

	'#define IPL_DATA_ORDER_PIXEL  0
	public const  IPL_DATA_ORDER_PIXEL as integer =  0
	'#define IPL_DATA_ORDER_PLANE  1
	public const  IPL_DATA_ORDER_PLANE as integer =  1

	'#define IPL_ORIGIN_TL 0
	public const  IPL_ORIGIN_TL as integer =  0
	'#define IPL_ORIGIN_BL 1
	public const  IPL_ORIGIN_BL as integer =  1

	'#define IPL_ALIGN_4BYTES   4
	public const  IPL_ALIGN_4BYTES as integer =  4
	'#define IPL_ALIGN_8BYTES   8
	public const  IPL_ALIGN_8BYTES as integer =  8
	'#define IPL_ALIGN_16BYTES 16
	public const  IPL_ALIGN_16BYTES as integer =  16
	'#define IPL_ALIGN_32BYTES 32
	public const  IPL_ALIGN_32BYTES as integer =  32

	'#define IPL_ALIGN_DWORD   IPL_ALIGN_4BYTES
	public const  IPL_ALIGN_DWORD as integer =  IPL_ALIGN_4BYTES
	'#define IPL_ALIGN_QWORD   IPL_ALIGN_8BYTES
	public const  IPL_ALIGN_QWORD as integer =  IPL_ALIGN_8BYTES

	'#define IPL_BORDER_CONSTANT   0
	public const  IPL_BORDER_CONSTANT as integer =  0
	'#define IPL_BORDER_REPLICATE  1
	public const  IPL_BORDER_REPLICATE as integer =  1
	'#define IPL_BORDER_REFLECT    2
	public const  IPL_BORDER_REFLECT as integer =  2
	'#define IPL_BORDER_WRAP       3
	public const  IPL_BORDER_WRAP as integer =  3

	'typedef struct _IplImage
	'{
	'    int  nSize;         /* sizeof(IplImage) */
	'    int  ID;            /* version (=0)*/
	'    int  nChannels;     /* Most of OpenCV functions support 1,2,3 or 4 channels */
	'    int  alphaChannel;  /* ignored by OpenCV */
	'    int  depth;         /* pixel depth in bits: IPL_DEPTH_8U, IPL_DEPTH_8S, IPL_DEPTH_16S,
	'                           IPL_DEPTH_32S, IPL_DEPTH_32F and IPL_DEPTH_64F are supported */
	'    char colorModel[4]; /* ignored by OpenCV */
	'    char channelSeq[4]; /* ditto */
	'    int  dataOrder;     /* 0 - interleaved color channels, 1 - separate color channels.
	'                           cvCreateImage can only create interleaved images */
	'    int  origin;        /* 0 - top-left origin,
	'                           1 - bottom-left origin (Windows bitmaps style) */
	'    int  align;         /* Alignment of image rows (4 or 8).
	'                           OpenCV ignores it and uses widthStep instead */
	'    int  width;         /* image width in pixels */
	'    int  height;        /* image height in pixels */
	'    struct _IplROI *roi;/* image ROI. if NULL, the whole image is selected */
	'    struct _IplImage *maskROI; /* must be NULL */
	'    void  *imageId;     /* ditto */
	'    struct _IplTileInfo *tileInfo; /* ditto */
	'    int  imageSize;     /* image data size in bytes
	'                           (==image->height*image->widthStep
	'                           in case of interleaved data)*/
	'    char *imageData;  /* pointer to aligned image data */
	'    int  widthStep;   /* size of aligned image row in bytes */
	'    int  BorderMode[4]; /* ignored by OpenCV */
	'    int  BorderConst[4]; /* ditto */
	'    char *imageDataOrigin; /* pointer to very origin of image data
	'                              (not necessarily aligned) -
	'                              needed for correct deallocation */
	'}
	'IplImage;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure IplImage
        Public nSize As Integer             '構造体サイズ
        Public ID As Integer                'バージョン
        Public nChannels As Integer         'チャンネル数(1,2,3,4)
        Public alphaChannel As Integer      '################ OpenCVでは未使用
        Public depth As Integer             'ビット深度
        Public colorModel As UInt32         '################ OpenCVでは未使用
        Public channelSeq As UInt32         '################ OpenCVでは未使用
        Public dataOrder As Integer         'カラーチャンネルの並び 
        Public origin As Integer            'データの格納方式 
        Public align As Integer             '################ OpenCVでは未使用
        Public width As Integer             '横ピクセル数
        Public height As Integer            '縦ピクセル数
        Public roi As IntPtr                'ROIデータ
        Public maskROI As IntPtr            '################ OpenCVでは未使用
        Public imageId As IntPtr            '################ OpenCVでは未使用
        Public tileInfo As IntPtr           '################ OpenCVでは未使用
        Public imageSize As Integer         'イメージサイズ　= height * widthstep
        Public imageData As IntPtr          'イメージデータ
        Public widthStep As Integer         '横バイト数
        Public mBorderMode0 As Integer      '################ OpenCVでは未使用
        Public mBorderMode1 As Integer      '################ OpenCVでは未使用
        Public mBorderMode2 As Integer      '################ OpenCVでは未使用
        Public mBorderMode3 As Integer      '################ OpenCVでは未使用
        Public BorderConst0 As Integer      '################ OpenCVでは未使用
        Public BorderConst1 As Integer      '################ OpenCVでは未使用
        Public BorderConst2 As Integer      '################ OpenCVでは未使用
        Public BorderConst3 As Integer      '################ OpenCVでは未使用
        Public imageDataOrigin As IntPtr    '再配置用データ
    End Structure



	'typedef struct _IplTileInfo IplTileInfo;
	'Typedef : Unsupport

	'typedef struct _IplROI
	'{
	'    int  coi; /* 0 - no COI (all channels are selected), 1 - 0th channel is selected ...*/
	'    int  xOffset;
	'    int  yOffset;
	'    int  width;
	'    int  height;
	'}
	'IplROI;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure IplROI
        Public coi As Integer
        Public xOffset As Integer
        Public yOffset As Integer
        Public width As Integer
        Public height As Integer
    End Structure



	'typedef struct _IplConvKernel
	'{
	'    int  nCols;
	'    int  nRows;
	'    int  anchorX;
	'    int  anchorY;
	'    int *values;
	'    int  nShiftR;
	'}
	'IplConvKernel;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure IplConvKernel
        Public nCols As Integer
        Public nRows As Integer
        Public anchorX As Integer
        Public anchorY As Integer
        Public values As IntPtr
        Public nShiftR As Integer
    End Structure



	'typedef struct _IplConvKernelFP
	'{
	'    int  nCols;
	'    int  nRows;
	'    int  anchorX;
	'    int  anchorY;
	'    float *values;
	'}
	'IplConvKernelFP;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure IplConvKernelFP
        Public nCols As Integer
        Public nRows As Integer
        Public anchorX As Integer
        Public anchorY As Integer
        Public values As IntPtr
    End Structure



	'#define IPL_IMAGE_HEADER 1
	public const  IPL_IMAGE_HEADER as integer =  1
	'#define IPL_IMAGE_DATA   2
	public const  IPL_IMAGE_DATA as integer =  2
	'#define IPL_IMAGE_ROI    4
	public const  IPL_IMAGE_ROI as integer =  4

	'/* extra border mode */
	'#define IPL_BORDER_REFLECT_101    4
	public const  IPL_BORDER_REFLECT_101 as integer =  4

	'#define IPL_IMAGE_MAGIC_VAL  ((int)sizeof(IplImage))
	'ToDo : unsupport
	'#define CV_TYPE_NAME_IMAGE "opencv-image"
	public const  CV_TYPE_NAME_IMAGE as string =  "opencv-image"

	'#define CV_IS_IMAGE_HDR(img) \
	'    ((img) != NULL && ((const IplImage*)(img))->nSize == sizeof(IplImage))
	'ToDo : 

	'#define CV_IS_IMAGE(img) \
	'    (CV_IS_IMAGE_HDR(img) && ((IplImage*)img)->imageData != NULL)
	'ToDo : 

	'/* for storing double-precision
	'   floating point data in IplImage's */
	'#define IPL_DEPTH_64F  64
	public const  IPL_DEPTH_64F as integer =  64

	'/* get reference to pixel at (col,row),
	'   for multi-channel images (col) should be multiplied by number of channels */
	'#define CV_IMAGE_ELEM( image, elemtype, row, col )       \
	'    (((elemtype*)((image)->imageData + (image)->widthStep*(row)))[(col)])
	'ToDo : 

	'/****************************************************************************************\
	'*                                  Matrix type (CvMat)                                   *
	'\****************************************************************************************/

	'#define CV_CN_MAX     64
	public const  CV_CN_MAX as integer =  64
	'#define CV_CN_SHIFT   3
	public const  CV_CN_SHIFT as integer =  3
	'#define CV_DEPTH_MAX  (1 << CV_CN_SHIFT)
	public const  CV_DEPTH_MAX as integer =  (1 << CV_CN_SHIFT)

	'#define CV_8U   0
	public const  CV_8U as integer =  0
	'#define CV_8S   1
	public const  CV_8S as integer =  1
	'#define CV_16U  2
	public const  CV_16U as integer =  2
	'#define CV_16S  3
	public const  CV_16S as integer =  3
	'#define CV_32S  4
	public const  CV_32S as integer =  4
	'#define CV_32F  5
	public const  CV_32F as integer =  5
	'#define CV_64F  6
	public const  CV_64F as integer =  6
	'#define CV_USRTYPE1 7
	public const  CV_USRTYPE1 as integer =  7

	'#define CV_MAKETYPE(depth,cn) ((depth) + (((cn)-1) << CV_CN_SHIFT))
    Public Function CV_MAKETYPE(ByVal depth As Integer, ByVal cn As Integer) As Integer
        Return ((depth) + (((cn) - 1) << CV_CN_SHIFT))
    End Function


	'#define CV_MAKE_TYPE CV_MAKETYPE
    Public Function CV_MAKE_TYPE(ByVal depth As Integer, ByVal cn As Integer) As Integer
        Return CV_MAKETYPE(depth, cn)
    End Function



	'#define CV_8UC1 CV_MAKETYPE(CV_8U,1)
	public const  CV_8UC1 as integer = ((CV_8U) + (((1)-1) << CV_CN_SHIFT))
	'#define CV_8UC2 CV_MAKETYPE(CV_8U,2)
	public const  CV_8UC2 as integer = ((CV_8U) + (((2)-1) << CV_CN_SHIFT))
	'#define CV_8UC3 CV_MAKETYPE(CV_8U,3)
	public const  CV_8UC3 as integer = ((CV_8U) + (((3)-1) << CV_CN_SHIFT))
	'#define CV_8UC4 CV_MAKETYPE(CV_8U,4)
	public const  CV_8UC4 as integer = ((CV_8U) + (((4)-1) << CV_CN_SHIFT))
	'#define CV_8UC(n) CV_MAKETYPE(CV_8U,(n))
    Public Function CV_8UC(ByVal n As Integer) As Integer
        Return CV_MAKETYPE(CV_8U, (n))
    End Function



	'#define CV_8SC1 CV_MAKETYPE(CV_8S,1)
	public const  CV_8SC1 as integer = ((CV_8S) + (((1)-1) << CV_CN_SHIFT))
	'#define CV_8SC2 CV_MAKETYPE(CV_8S,2)
	public const  CV_8SC2 as integer = ((CV_8S) + (((2)-1) << CV_CN_SHIFT))
	'#define CV_8SC3 CV_MAKETYPE(CV_8S,3)
	public const  CV_8SC3 as integer = ((CV_8S) + (((3)-1) << CV_CN_SHIFT))
	'#define CV_8SC4 CV_MAKETYPE(CV_8S,4)
	public const  CV_8SC4 as integer = ((CV_8S) + (((4)-1) << CV_CN_SHIFT))
	'#define CV_8SC(n) CV_MAKETYPE(CV_8S,(n))
    Public Function CV_8SC(ByVal n As Integer) As Integer
        Return CV_MAKETYPE(CV_8S, (n))
    End Function



	'#define CV_16UC1 CV_MAKETYPE(CV_16U,1)
	public const  CV_16UC1 as integer = ((CV_16U) + (((1)-1) << CV_CN_SHIFT))
	'#define CV_16UC2 CV_MAKETYPE(CV_16U,2)
	public const  CV_16UC2 as integer = ((CV_16U) + (((2)-1) << CV_CN_SHIFT))
	'#define CV_16UC3 CV_MAKETYPE(CV_16U,3)
	public const  CV_16UC3 as integer = ((CV_16U) + (((3)-1) << CV_CN_SHIFT))
	'#define CV_16UC4 CV_MAKETYPE(CV_16U,4)
	public const  CV_16UC4 as integer = ((CV_16U) + (((4)-1) << CV_CN_SHIFT))
	'#define CV_16UC(n) CV_MAKETYPE(CV_16U,(n))
    Public Function CV_16UC(ByVal n As Integer) As Integer
        Return CV_MAKETYPE(CV_16U, (n))
    End Function



	'#define CV_16SC1 CV_MAKETYPE(CV_16S,1)
	public const  CV_16SC1 as integer = ((CV_16S) + (((1)-1) << CV_CN_SHIFT))
	'#define CV_16SC2 CV_MAKETYPE(CV_16S,2)
	public const  CV_16SC2 as integer = ((CV_16S) + (((2)-1) << CV_CN_SHIFT))
	'#define CV_16SC3 CV_MAKETYPE(CV_16S,3)
	public const  CV_16SC3 as integer = ((CV_16S) + (((3)-1) << CV_CN_SHIFT))
	'#define CV_16SC4 CV_MAKETYPE(CV_16S,4)
	public const  CV_16SC4 as integer = ((CV_16S) + (((4)-1) << CV_CN_SHIFT))
	'#define CV_16SC(n) CV_MAKETYPE(CV_16S,(n))
    Public Function CV_16SC(ByVal n As Integer) As Integer
        Return CV_MAKETYPE(CV_16S, (n))
    End Function



	'#define CV_32SC1 CV_MAKETYPE(CV_32S,1)
	public const  CV_32SC1 as integer = ((CV_32S) + (((1)-1) << CV_CN_SHIFT))
	'#define CV_32SC2 CV_MAKETYPE(CV_32S,2)
	public const  CV_32SC2 as integer = ((CV_32S) + (((2)-1) << CV_CN_SHIFT))
	'#define CV_32SC3 CV_MAKETYPE(CV_32S,3)
	public const  CV_32SC3 as integer = ((CV_32S) + (((3)-1) << CV_CN_SHIFT))
	'#define CV_32SC4 CV_MAKETYPE(CV_32S,4)
	public const  CV_32SC4 as integer = ((CV_32S) + (((4)-1) << CV_CN_SHIFT))
	'#define CV_32SC(n) CV_MAKETYPE(CV_32S,(n))
    Public Function CV_32SC(ByVal n As Integer) As Integer
        Return CV_MAKETYPE(CV_32S, (n))
    End Function



	'#define CV_32FC1 CV_MAKETYPE(CV_32F,1)
	public const  CV_32FC1 as integer = ((CV_32F) + (((1)-1) << CV_CN_SHIFT))
	'#define CV_32FC2 CV_MAKETYPE(CV_32F,2)
	public const  CV_32FC2 as integer = ((CV_32F) + (((2)-1) << CV_CN_SHIFT))
	'#define CV_32FC3 CV_MAKETYPE(CV_32F,3)
	public const  CV_32FC3 as integer = ((CV_32F) + (((3)-1) << CV_CN_SHIFT))
	'#define CV_32FC4 CV_MAKETYPE(CV_32F,4)
	public const  CV_32FC4 as integer = ((CV_32F) + (((4)-1) << CV_CN_SHIFT))
	'#define CV_32FC(n) CV_MAKETYPE(CV_32F,(n))
    Public Function CV_32FC(ByVal n As Integer) As Integer
        Return CV_MAKETYPE(CV_32F, (n))
    End Function



	'#define CV_64FC1 CV_MAKETYPE(CV_64F,1)
	public const  CV_64FC1 as integer = ((CV_64F) + (((1)-1) << CV_CN_SHIFT))
	'#define CV_64FC2 CV_MAKETYPE(CV_64F,2)
	public const  CV_64FC2 as integer = ((CV_64F) + (((2)-1) << CV_CN_SHIFT))
	'#define CV_64FC3 CV_MAKETYPE(CV_64F,3)
	public const  CV_64FC3 as integer = ((CV_64F) + (((3)-1) << CV_CN_SHIFT))
	'#define CV_64FC4 CV_MAKETYPE(CV_64F,4)
	public const  CV_64FC4 as integer = ((CV_64F) + (((4)-1) << CV_CN_SHIFT))
	'#define CV_64FC(n) CV_MAKETYPE(CV_64F,(n))
    Public Function CV_64FC(ByVal n As Integer) As Integer
        Return CV_MAKETYPE(CV_64F, (n))
    End Function



	'#define CV_AUTO_STEP  0x7fffffff
	public const  CV_AUTO_STEP as integer =  &H7fffffff
	'#define CV_WHOLE_ARR  cvSlice( 0, 0x3fffffff )
	public readonly CV_WHOLE_ARR as cvSlice = new  cvSlice( 0, &H3fffffff )

	'#define CV_MAT_CN_MASK          ((CV_CN_MAX - 1) << CV_CN_SHIFT)
	public const  CV_MAT_CN_MASK as integer =  ((CV_CN_MAX - 1) << CV_CN_SHIFT)
	'#define CV_MAT_CN(flags)        ((((flags) & CV_MAT_CN_MASK) >> CV_CN_SHIFT) + 1)
	'ToDo : 
	'#define CV_MAT_DEPTH_MASK       (CV_DEPTH_MAX - 1)
	public const  CV_MAT_DEPTH_MASK as integer =  (CV_DEPTH_MAX - 1)
	'#define CV_MAT_DEPTH(flags)     ((flags) & CV_MAT_DEPTH_MASK)
	'ToDo : 
	'#define CV_MAT_TYPE_MASK        (CV_DEPTH_MAX*CV_CN_MAX - 1)
	public const  CV_MAT_TYPE_MASK as integer =  (CV_DEPTH_MAX*CV_CN_MAX - 1)
	'#define CV_MAT_TYPE(flags)      ((flags) & CV_MAT_TYPE_MASK)
	'ToDo : 
	'#define CV_MAT_CONT_FLAG_SHIFT  14
	public const  CV_MAT_CONT_FLAG_SHIFT as integer =  14
	'#define CV_MAT_CONT_FLAG        (1 << CV_MAT_CONT_FLAG_SHIFT)
	public const  CV_MAT_CONT_FLAG as integer =  (1 << CV_MAT_CONT_FLAG_SHIFT)
	'#define CV_IS_MAT_CONT(flags)   ((flags) & CV_MAT_CONT_FLAG)
	'ToDo : 
	'#define CV_IS_CONT_MAT          CV_IS_MAT_CONT
	'Skip : 
	'#define CV_MAT_TEMP_FLAG_SHIFT  15
	public const  CV_MAT_TEMP_FLAG_SHIFT as integer =  15
	'#define CV_MAT_TEMP_FLAG        (1 << CV_MAT_TEMP_FLAG_SHIFT)
	public const  CV_MAT_TEMP_FLAG as integer =  (1 << CV_MAT_TEMP_FLAG_SHIFT)
	'#define CV_IS_TEMP_MAT(flags)   ((flags) & CV_MAT_TEMP_FLAG)
	'ToDo : 

	'#define CV_MAGIC_MASK       0xFFFF0000
	public const  CV_MAGIC_MASK as integer =  &HFFFF0000
	'#define CV_MAT_MAGIC_VAL    0x42420000
	public const  CV_MAT_MAGIC_VAL as integer =  &H42420000
	'#define CV_TYPE_NAME_MAT    "opencv-matrix"
	public const  CV_TYPE_NAME_MAT as string =  "opencv-matrix"

	'typedef struct CvMat
	'{
	'    int type;
	'    int step;

	'    /* for internal use only */
	'    int* refcount;
	'    int hdr_refcount;

	'    union
	'    {
	'        uchar* ptr;
	'        short* s;
	'        int* i;
	'        float* fl;
	'        double* db;
	'    } data;

	'    int rows;
	'    int cols;
	'}
	'CvMat;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvMat
        Public [type] As Integer
        Public [step] As Integer
        Public refcount As IntPtr
        Public data As IntPtr
        Public rows As Integer
        Public cols As Integer
    End Structure




	'#define CV_IS_MAT_HDR(mat) \
	'    ((mat) != NULL && \
	'    (((const CvMat*)(mat))->type & CV_MAGIC_MASK) == CV_MAT_MAGIC_VAL && \
	'    ((const CvMat*)(mat))->cols > 0 && ((const CvMat*)(mat))->rows > 0)
	'ToDo : 

	'#define CV_IS_MAT(mat) \
	'    (CV_IS_MAT_HDR(mat) && ((const CvMat*)(mat))->data.ptr != NULL)
	'ToDo : 

	'#define CV_IS_MASK_ARR(mat) \
	'    (((mat)->type & (CV_MAT_TYPE_MASK & ~CV_8SC1)) == 0)
	'ToDo : 

	'#define CV_ARE_TYPES_EQ(mat1, mat2) \
	'    ((((mat1)->type ^ (mat2)->type) & CV_MAT_TYPE_MASK) == 0)
	'ToDo : 

	'#define CV_ARE_CNS_EQ(mat1, mat2) \
	'    ((((mat1)->type ^ (mat2)->type) & CV_MAT_CN_MASK) == 0)
	'ToDo : 

	'#define CV_ARE_DEPTHS_EQ(mat1, mat2) \
	'    ((((mat1)->type ^ (mat2)->type) & CV_MAT_DEPTH_MASK) == 0)
	'ToDo : 

	'#define CV_ARE_SIZES_EQ(mat1, mat2) \
	'    ((mat1)->height == (mat2)->height && (mat1)->width == (mat2)->width)
	'ToDo : 

	'#define CV_IS_MAT_CONST(mat)  \
	'    (((mat)->height|(mat)->width) == 1)
	'ToDo : 

	'/* size of each channel item,
	'   0x124489 = 1000 0100 0100 0010 0010 0001 0001 ~ array of sizeof(arr_type_elem) */
	'#define CV_ELEM_SIZE1(type) \
	'    ((((sizeof(size_t)<<28)|0x8442211) >> CV_MAT_DEPTH(type)*4) & 15)
	'ToDo : 

	'/* 0x3a50 = 11 10 10 01 01 00 00 ~ array of log2(sizeof(arr_type_elem)) */
	'#define CV_ELEM_SIZE(type) \
	'    (CV_MAT_CN(type) << ((((sizeof(size_t)/4+1)*16384|0x3a50) >> CV_MAT_DEPTH(type)*2) & 3))
	'ToDo : 

	'/* inline constructor. No data is allocated internally!!!
	'   (use together with cvCreateData, or use cvCreateMat instead to
	'   get a matrix with allocated data) */
	'CV_INLINE CvMat cvMat( int rows, int cols, int type, void* data CV_DEFAULT(NULL))
	'{
	'    CvMat m;

	'    assert( (unsigned)CV_MAT_DEPTH(type) <= CV_64F );
	'    type = CV_MAT_TYPE(type);
	'    m.type = CV_MAT_MAGIC_VAL | CV_MAT_CONT_FLAG | type;
	'    m.cols = cols;
	'    m.rows = rows;
	'    m.step = rows > 1 ? m.cols*CV_ELEM_SIZE(type) : 0;
	'    m.data.ptr = (uchar*)data;
	'    m.refcount = NULL;
	'    m.hdr_refcount = 0;

	'    return m;
	'}
	'ToDo : Function


	'#define CV_MAT_ELEM_PTR_FAST( mat, row, col, pix_size )  \
	'    (assert( (unsigned)(row) < (unsigned)(mat).rows &&   \
	'             (unsigned)(col) < (unsigned)(mat).cols ),   \
	'     (mat).data.ptr + (size_t)(mat).step*(row) + (pix_size)*(col))
	'ToDo : 

	'#define CV_MAT_ELEM_PTR( mat, row, col )                 \
	'    CV_MAT_ELEM_PTR_FAST( mat, row, col, CV_ELEM_SIZE((mat).type) )
	'ToDo : 

	'#define CV_MAT_ELEM( mat, elemtype, row, col )           \
	'    (*(elemtype*)CV_MAT_ELEM_PTR_FAST( mat, row, col, sizeof(elemtype)))
	'ToDo : 


	'CV_INLINE  double  cvmGet( const CvMat* mat, int row, int col )
	'{
	'    int type;

	'    type = CV_MAT_TYPE(mat->type);
	'    assert( (unsigned)row < (unsigned)mat->rows &&
	'            (unsigned)col < (unsigned)mat->cols );

	'    if( type == CV_32FC1 )
	'        return ((float*)(mat->data.ptr + (size_t)mat->step*row))[col];
	'    else
	'    {
	'        assert( type == CV_64FC1 );
	'        return ((double*)(mat->data.ptr + (size_t)mat->step*row))[col];
	'    }
	'}
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure StructFloat
        Public Data As Single
    End Structure
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure StructDouble
        Public Data As Double
    End Structure

    Private Const CvMat_type_offset As Integer = 0      'CvMat構造体のメンバtypeの先頭からのオフセット位置
    Private Const CvMat_step_offset As Integer = 4      'CvMat構造体のメンバstepの先頭からのオフセット位置
    Private Const CvMat_data_offset As Integer = 16     'CvMat構造体のメンバdataの先頭からのオフセット位置(Ver0.97とVer0.99で違う)

    Public Function cvmGet(ByVal Mat As IntPtr, ByVal row As Integer, ByVal col As Integer) As Double
        Dim datatype As Integer = Marshal.ReadInt32(Mat, CvMat_type_offset) And CV_MAT_TYPE_MASK
        Dim datastep As Integer = Marshal.ReadInt32(Mat, CvMat_step_offset)
        Dim dataptr As Integer = Marshal.ReadInt32(Mat, CvMat_data_offset)

        Dim ptr As IntPtr
        Dim ret As Double = 0
        If datatype = CV_32FC1 Then
            ptr = CType(dataptr + datastep * row + 4 * col, IntPtr)
            Dim dd As StructFloat = CType(Marshal.PtrToStructure(ptr, GetType(StructFloat)), StructFloat)
            ret = dd.Data
        Else
            ptr = CType(dataptr + datastep * row + 8 * col, IntPtr)
            Dim dd As StructDouble = CType(Marshal.PtrToStructure(ptr, GetType(StructDouble)), StructDouble)
            ret = dd.Data
        End If


        Return ret
    End Function




	'CV_INLINE  void  cvmSet( CvMat* mat, int row, int col, double value )
	'{
	'    int type;
	'    type = CV_MAT_TYPE(mat->type);
	'    assert( (unsigned)row < (unsigned)mat->rows &&
	'            (unsigned)col < (unsigned)mat->cols );

	'    if( type == CV_32FC1 )
	'        ((float*)(mat->data.ptr + (size_t)mat->step*row))[col] = (float)value;
	'    else
	'    {
	'        assert( type == CV_64FC1 );
	'        ((double*)(mat->data.ptr + (size_t)mat->step*row))[col] = (double)value;
	'    }
	'}
    Public Sub cvmSet(ByVal Mat As IntPtr, ByVal row As Integer, ByVal col As Integer, ByVal value As Double)
        Dim datatype As Integer = Marshal.ReadInt32(Mat, CvMat_type_offset) And CV_MAT_TYPE_MASK
        Dim datastep As Integer = Marshal.ReadInt32(Mat, CvMat_step_offset)
        Dim dataptr As Integer = Marshal.ReadInt32(Mat, CvMat_data_offset)

        Dim ptr As IntPtr
        Dim ret As Double = 0
        If datatype = CV_32FC1 Then
            ptr = CType(dataptr + datastep * row + 4 * col, IntPtr)
            Dim dd As StructFloat
            dd.Data = CSng(value)
            Marshal.StructureToPtr(dd, ptr, True)
        Else
            ptr = CType(dataptr + datastep * row + 8 * col, IntPtr)
            Dim dd As StructDouble
            dd.Data = value
            Marshal.StructureToPtr(dd, ptr, True)
        End If

    End Sub




	'CV_INLINE int cvCvToIplDepth( int type )
	'{
	'    int depth = CV_MAT_DEPTH(type);
	'    return CV_ELEM_SIZE1(depth)*8 | (depth == CV_8S || depth == CV_16S ||
	'           depth == CV_32S ? IPL_DEPTH_SIGN : 0);
	'}
	'ToDo : Function


	'/****************************************************************************************\
	'*                       Multi-dimensional dense array (CvMatND)                          *
	'\****************************************************************************************/

	'#define CV_MATND_MAGIC_VAL    0x42430000
	public const  CV_MATND_MAGIC_VAL as integer =  &H42430000
	'#define CV_TYPE_NAME_MATND    "opencv-nd-matrix"
	public const  CV_TYPE_NAME_MATND as string =  "opencv-nd-matrix"

	'#define CV_MAX_DIM            32
	public const  CV_MAX_DIM as integer =  32
	'#define CV_MAX_DIM_HEAP       (1 << 16)
	public const  CV_MAX_DIM_HEAP as integer =  (1 << 16)

	'typedef struct CvMatND
	'{
	'    int type;
	'    int dims;

	'    int* refcount;
	'    int hdr_refcount;

	'    union
	'    {
	'        uchar* ptr;
	'        float* fl;
	'        double* db;
	'        int* i;
	'        short* s;
	'    } data;

	'    struct
	'    {
	'        int size;
	'        int step;
	'    }
	'    dim[CV_MAX_DIM];
	'}
	'CvMatND;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvMatND
        Public [type] As Integer
        Public dims As Integer
        Public refcount As IntPtr
        Public hdr_refcount As Integer
        Public data As IntPtr
        Public cols As Integer
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=CV_MAX_DIM)> _
        Public CvMatNDDim() As CvMatNDDim
    End Structure
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvMatNDDim
        Public [size] As Integer
        Public [step] As Integer
    End Structure



	'#define CV_IS_MATND_HDR(mat) \
	'    ((mat) != NULL && (((const CvMatND*)(mat))->type & CV_MAGIC_MASK) == CV_MATND_MAGIC_VAL)
	'ToDo : 

	'#define CV_IS_MATND(mat) \
	'    (CV_IS_MATND_HDR(mat) && ((const CvMatND*)(mat))->data.ptr != NULL)
	'ToDo : 


	'/****************************************************************************************\
	'*                      Multi-dimensional sparse array (CvSparseMat)                      *
	'\****************************************************************************************/

	'#define CV_SPARSE_MAT_MAGIC_VAL    0x42440000
	public const  CV_SPARSE_MAT_MAGIC_VAL as integer =  &H42440000
	'#define CV_TYPE_NAME_SPARSE_MAT    "opencv-sparse-matrix"
	public const  CV_TYPE_NAME_SPARSE_MAT as string =  "opencv-sparse-matrix"

	'struct CvSet;
	'Skip : skip

	'typedef struct CvSparseMat
	'{
	'    int type;
	'    int dims;
	'    int* refcount;
	'    int hdr_refcount;

	'    struct CvSet* heap;
	'    void** hashtable;
	'    int hashsize;
	'    int valoffset;
	'    int idxoffset;
	'    int size[CV_MAX_DIM];
	'}
	'CvSparseMat;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSparseMat
        Public [type] As Integer
        Public dims As Integer
        Public refcount As IntPtr
        Public hdr_refcount As Integer
        Public heap As IntPtr
        Public hastable As IntPtr
        Public hashsize As Integer
        Public valoffset As Integer
        Public idxoffset As Integer
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=CV_MAX_DIM)> _
        Public [size] As Integer()
    End Structure



	'#define CV_IS_SPARSE_MAT_HDR(mat) \
	'    ((mat) != NULL && \
	'    (((const CvSparseMat*)(mat))->type & CV_MAGIC_MASK) == CV_SPARSE_MAT_MAGIC_VAL)
	'ToDo : 

	'#define CV_IS_SPARSE_MAT(mat) \
	'    CV_IS_SPARSE_MAT_HDR(mat)
	'ToDo : 

	'/**************** iteration through a sparse array *****************/

	'typedef struct CvSparseNode
	'{
	'    unsigned hashval;
	'    struct CvSparseNode* next;
	'}
	'CvSparseNode;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSparseNode
        Public hashval As UInt16
        Public [next] As IntPtr
    End Structure



	'typedef struct CvSparseMatIterator
	'{
	'    CvSparseMat* mat;
	'    CvSparseNode* node;
	'    int curidx;
	'}
	'CvSparseMatIterator;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSparseMatIterator
        Public mat As IntPtr
        Public node As IntPtr
        Public curidx As Integer
    End Structure



	'#define CV_NODE_VAL(mat,node)   ((void*)((uchar*)(node) + (mat)->valoffset))
    Public Function CV_NODE_VAL(ByVal mat As CvSparseMat, ByVal node As IntPtr) As IntPtr
        Return CType(node.ToInt32 + mat.valoffset, IntPtr)
    End Function


	'#define CV_NODE_IDX(mat,node)   ((int*)((uchar*)(node) + (mat)->idxoffset))
    Public Function CV_NODE_IDX(ByVal mat As CvSparseMat, ByVal node As IntPtr) As IntPtr
        Return CType(node.ToInt32 + mat.idxoffset, IntPtr)
    End Function



	'/****************************************************************************************\
	'*                                         Histogram                                      *
	'\****************************************************************************************/

	'typedef int CvHistType;
	'Typedef : Unsupport

	'#define CV_HIST_MAGIC_VAL     0x42450000
	public const  CV_HIST_MAGIC_VAL as integer =  &H42450000
	'#define CV_HIST_UNIFORM_FLAG  (1 << 10)
	public const  CV_HIST_UNIFORM_FLAG as integer =  (1 << 10)

	'/* indicates whether bin ranges are set already or not */
	'#define CV_HIST_RANGES_FLAG   (1 << 11)
	public const  CV_HIST_RANGES_FLAG as integer =  (1 << 11)

	'#define CV_HIST_ARRAY         0
	public const  CV_HIST_ARRAY as integer =  0
	'#define CV_HIST_SPARSE        1
	public const  CV_HIST_SPARSE as integer =  1
	'#define CV_HIST_TREE          CV_HIST_SPARSE
	public const  CV_HIST_TREE as integer =  CV_HIST_SPARSE

	'/* should be used as a parameter only,
	'   it turns to CV_HIST_UNIFORM_FLAG of hist->type */
	'#define CV_HIST_UNIFORM       1
	public const  CV_HIST_UNIFORM as integer =  1

	'typedef struct CvHistogram
	'{
	'    int     type;
	'    CvArr*  bins;
	'    float   thresh[CV_MAX_DIM][2]; /* for uniform histograms */
	'    float** thresh2; /* for non-uniform histograms */
	'    CvMatND mat; /* embedded matrix header for array histograms */
	'}
	'CvHistogram;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvHistogram
        Public [type] As Integer
        Public bins As IntPtr
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=CV_MAX_DIM * 2)> _
        Public thresh() As Single
        Public thresh2 As IntPtr
        Public mat As CvMatND
    End Structure



	'#define CV_IS_HIST( hist ) \
	'    ((hist) != NULL  && \
	'     (((CvHistogram*)(hist))->type & CV_MAGIC_MASK) == CV_HIST_MAGIC_VAL && \
	'     (hist)->bins != NULL)
	'ToDo : 

	'#define CV_IS_UNIFORM_HIST( hist ) \
	'    (((hist)->type & CV_HIST_UNIFORM_FLAG) != 0)
	'ToDo : 

	'#define CV_IS_SPARSE_HIST( hist ) \
	'    CV_IS_SPARSE_MAT((hist)->bins)
	'ToDo : 

	'#define CV_HIST_HAS_RANGES( hist ) \
	'    (((hist)->type & CV_HIST_RANGES_FLAG) != 0)
	'ToDo : 

	'/****************************************************************************************\
	'*                      Other supplementary data type definitions                         *
	'\****************************************************************************************/

	'/*************************************** CvRect *****************************************/

	'typedef struct CvRect
	'{
	'    int x;
	'    int y;
	'    int width;
	'    int height;
	'}
	'CvRect;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvRect
        Public x As Integer
        Public y As Integer
        Public width As Integer
        Public height As Integer

        Public Sub New(ByVal ValX As Integer, ByVal ValY As Integer, ByVal ValW As Integer, ByVal ValH As Integer)
            Me.x = ValX
            Me.y = ValY
            Me.width = ValW
            Me.height = ValH
        End Sub

        Public Sub CopyFrom(ByVal Rct As System.Drawing.Rectangle)
            Me.x = Rct.X
            Me.y = Rct.Y
            Me.width = Rct.Width
            Me.height = Rct.Height
        End Sub

        Public Overrides Function ToString() As String
            Return String.Format("[{0},{1},{2},{3}]", x, y, width, height)
        End Function

    End Structure



	'CV_INLINE  CvRect  cvRect( int x, int y, int width, int height )
	'{
	'    CvRect r;

	'    r.x = x;
	'    r.y = y;
	'    r.width = width;
	'    r.height = height;

	'    return r;
	'}
	' Use CvRect Constructor




	'CV_INLINE  IplROI  cvRectToROI( CvRect rect, int coi )
	'{
	'    IplROI roi;
	'    roi.xOffset = rect.x;
	'    roi.yOffset = rect.y;
	'    roi.width = rect.width;
	'    roi.height = rect.height;
	'    roi.coi = coi;

	'    return roi;
	'}
    Public Function cvRectToROI(ByVal rect As CvRect, ByVal coi As Integer) As IplROI
        Dim roi As IplROI
        roi.xOffset = rect.x
        roi.yOffset = rect.y
        roi.width = rect.width
        roi.height = rect.height
        roi.coi = coi
        Return roi
    End Function




	'CV_INLINE  CvRect  cvROIToRect( IplROI roi )
	'{
	'    return cvRect( roi.xOffset, roi.yOffset, roi.width, roi.height );
	'}
    Public Function cvROIToRect(ByVal roi As IplROI) As CvRect
        Return New CvRect(roi.xOffset, roi.yOffset, roi.width, roi.height)
    End Function



	'/*********************************** CvTermCriteria *************************************/

	'#define CV_TERMCRIT_ITER    1
	public const  CV_TERMCRIT_ITER as integer =  1
	'#define CV_TERMCRIT_NUMBER  CV_TERMCRIT_ITER
	public const  CV_TERMCRIT_NUMBER as integer =  CV_TERMCRIT_ITER
	'#define CV_TERMCRIT_EPS     2
	public const  CV_TERMCRIT_EPS as integer =  2

	'typedef struct CvTermCriteria
	'{
	'    int    type;  /* may be combination of
	'                     CV_TERMCRIT_ITER
	'                     CV_TERMCRIT_EPS */
	'    int    max_iter;
	'    double epsilon;
	'}
	'CvTermCriteria;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvTermCriteria
        Public type As Integer
        Public max_iter As Integer
        Public epsilon As Double

        Public Sub New(ByVal TypeValue As Integer, ByVal MaxIter As Integer, ByVal EpsilonValue As Double)
            Type = TypeValue
            max_iter = MaxIter
            epsilon = EpsilonValue
        End Sub
    End Structure



	'CV_INLINE  CvTermCriteria  cvTermCriteria( int type, int max_iter, double epsilon )
	'{
	'    CvTermCriteria t;

	'    t.type = type;
	'    t.max_iter = max_iter;
	'    t.epsilon = (float)epsilon;

	'    return t;
	'}
	' Use CvRect Constructor




	'/******************************* CvPoint and variants ***********************************/

	'typedef struct CvPoint
	'{
	'    int x;
	'    int y;
	'}
	'CvPoint;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvPoint
        Public x As Integer
        Public y As Integer

        Public Sub New(ByVal ValX As Integer, ByVal ValY As Integer)
            Me.x = ValX
            Me.y = ValY
        End Sub

        Public Sub CopyFrom32F(ByRef point As CvPoint2D32f)
            Me.x = CInt(point.x)
            Me.y = CInt(point.y)
        End Sub
    End Structure




	'CV_INLINE  CvPoint  cvPoint( int x, int y )
	'{
	'    CvPoint p;

	'    p.x = x;
	'    p.y = y;

	'    return p;
	'}
	' Use CvPoint Constructor




	'typedef struct CvPoint2D32f
	'{
	'    float x;
	'    float y;
	'}
	'CvPoint2D32f;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvPoint2D32f
        Public x As Single
        Public y As Single

        Public Sub New(ByVal ValX As Single, ByVal ValY As Single)
            Me.x = ValX
            Me.y = ValY
        End Sub
    End Structure




	'CV_INLINE  CvPoint2D32f  cvPoint2D32f( double x, double y )
	'{
	'    CvPoint2D32f p;

	'    p.x = (float)x;
	'    p.y = (float)y;

	'    return p;
	'}
	'ToDo : Function


	'CV_INLINE  CvPoint2D32f  cvPointTo32f( CvPoint point )
	'{
	'    return cvPoint2D32f( (float)point.x, (float)point.y );
	'}
   Public Function cvPointTo32f(ByVal point As CvPoint) As CvPoint2D32f
        Return New CvPoint2D32f(CSng(point.x), CSng(point.y))
    End Function




	'CV_INLINE  CvPoint  cvPointFrom32f( CvPoint2D32f point )
	'{
	'    CvPoint ipt;
	'    ipt.x = cvRound(point.x);
	'    ipt.y = cvRound(point.y);

	'    return ipt;
	'}
    Public Function cvPointFrom32f(ByVal pnt As CvPoint2D32f) As CvPoint
        Dim ipt As CvPoint
        ipt.x = cvRound(pnt.x)
        ipt.y = cvRound(pnt.y)
        Return ipt
    End Function




	'typedef struct CvPoint3D32f
	'{
	'    float x;
	'    float y;
	'    float z;
	'}
	'CvPoint3D32f;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvPoint3D32f
        Public x As Single
        Public y As Single
        Public z As Single

        Public Sub New(ByVal ValX As Single, ByVal ValY As Single, ByVal ValZ As Single)
            Me.x = ValX
            Me.y = ValY
            Me.z = ValZ
        End Sub
    End Structure




	'CV_INLINE  CvPoint3D32f  cvPoint3D32f( double x, double y, double z )
	'{
	'    CvPoint3D32f p;

	'    p.x = (float)x;
	'    p.y = (float)y;
	'    p.z = (float)z;

	'    return p;
	'}
	'ToDo : Function


	'typedef struct CvPoint2D64f
	'{
	'    double x;
	'    double y;
	'}
	'CvPoint2D64f;
	'Typedef : Unsupport


	'CV_INLINE  CvPoint2D64f  cvPoint2D64f( double x, double y )
	'{
	'    CvPoint2D64f p;

	'    p.x = x;
	'    p.y = y;

	'    return p;
	'}
	'ToDo : Function


	'typedef struct CvPoint3D64f
	'{
	'    double x;
	'    double y;
	'    double z;
	'}
	'CvPoint3D64f;
	'Typedef : Unsupport


	'CV_INLINE  CvPoint3D64f  cvPoint3D64f( double x, double y, double z )
	'{
	'    CvPoint3D64f p;

	'    p.x = x;
	'    p.y = y;
	'    p.z = z;

	'    return p;
	'}
	'ToDo : Function


	'/******************************** CvSize's & CvBox **************************************/

	'typedef struct
	'{
	'    int width;
	'    int height;
	'}
	'CvSize;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSize
        Public width As Integer
        Public height As Integer

        Public Sub New(ByVal SizeX As Integer, ByVal SizeY As Integer)
            width = SizeX
            height = SizeY
        End Sub
    End Structure



	'CV_INLINE  CvSize  cvSize( int width, int height )
	'{
	'    CvSize s;

	'    s.width = width;
	'    s.height = height;

	'    return s;
	'}
	'ToDo : Function

	'typedef struct CvSize2D32f
	'{
	'    float width;
	'    float height;
	'}
	'CvSize2D32f;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSize2D32f
        Public width As Single
        Public height As Single

        Public Sub New(ByVal SizeX As Single, ByVal SizeY As Single)
            width = SizeX
            height = SizeY
        End Sub
    End Structure




	'CV_INLINE  CvSize2D32f  cvSize2D32f( double width, double height )
	'{
	'    CvSize2D32f s;

	'    s.width = (float)width;
	'    s.height = (float)height;

	'    return s;
	'}
	'ToDo : Function

	'typedef struct CvBox2D
	'{
	'    CvPoint2D32f center;  /* center of the box */
	'    CvSize2D32f  size;    /* box width and length */
	'    float angle;          /* angle between the horizontal axis
	'                             and the first side (i.e. length) in degrees */
	'}
	'CvBox2D;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvBox2D
        Public center As CvPoint2D32f
        Public [size] As CvSize2D32f
        Public angle As Single
    End Structure




	'/* Line iterator state */
	'typedef struct CvLineIterator
	'{
	'    /* pointer to the current point */
	'    uchar* ptr;

	'    /* Bresenham algorithm state */
	'    int  err;
	'    int  plus_delta;
	'    int  minus_delta;
	'    int  plus_step;
	'    int  minus_step;
	'}
	'CvLineIterator;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvLineIterator
        Public ptr As IntPtr
        Public err As Integer
        Public plus_delta As Integer
        Public minus_delta As Integer
        Public plus_step As Integer
        Public minus_step As Integer
    End Structure





	'/************************************* CvSlice ******************************************/

	'typedef struct CvSlice
	'{
	'    int  start_index, end_index;
	'}
	'CvSlice;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSlice
        Public start_index As Integer
        Public end_index As Integer

        Public Sub New(ByVal StartIndex As Integer, ByVal EndIndex As Integer)
            Me.start_index = StartIndex
            Me.end_index = EndIndex
        End Sub
    End Structure



	'CV_INLINE  CvSlice  cvSlice( int start, int end )
	'{
	'    CvSlice slice;
	'    slice.start_index = start;
	'    slice.end_index = end;

	'    return slice;
	'}
	'ToDo : Function

	'#define CV_WHOLE_SEQ_END_INDEX 0x3fffffff
	public const  CV_WHOLE_SEQ_END_INDEX as integer =  &H3fffffff
	'#define CV_WHOLE_SEQ  cvSlice(0, CV_WHOLE_SEQ_END_INDEX)
	public readonly CV_WHOLE_SEQ as cvSlice = new  cvSlice(0, CV_WHOLE_SEQ_END_INDEX)


	'/************************************* CvScalar *****************************************/

	'typedef struct CvScalar
	'{
	'    double val[4];
	'}
	'CvScalar;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvScalar
        Public val0, val1, val2, val3 As Double

        Public Sub New(ByVal Value0 As Double, Optional ByVal Value1 As Double = 0, Optional ByVal Value2 As Double = 0, Optional ByVal Value3 As Double = 0)
            val0 = Value0
            val1 = Value1
            val2 = Value2
            val3 = Value3
        End Sub

        Public Sub SetReal(ByVal Value As Double)
            val0 = Value
            val1 = 0
            val2 = 0
            val3 = 0
        End Sub

        Public Sub SetAll(ByVal Value As Double)
            val0 = Value
            val1 = Value
            val2 = Value
            val3 = Value
        End Sub

    End Structure



	'CV_INLINE  CvScalar  cvScalar( double val0, double val1 CV_DEFAULT(0),
	'                               double val2 CV_DEFAULT(0), double val3 CV_DEFAULT(0))
	'{
	'    CvScalar scalar;
	'    scalar.val[0] = val0; scalar.val[1] = val1;
	'    scalar.val[2] = val2; scalar.val[3] = val3;
	'    return scalar;
	'}
	' Use CvScalar Constructor




	'CV_INLINE  CvScalar  cvRealScalar( double val0 )
	'{
	'    CvScalar scalar;
	'    scalar.val[0] = val0;
	'    scalar.val[1] = scalar.val[2] = scalar.val[3] = 0;
	'    return scalar;
	'}
    Public Function cvRealScalar(ByVal val0 As Double) As CvScalar
        Return New CvScalar(val0, 0, 0, 0)
    End Function



	'CV_INLINE  CvScalar  cvScalarAll( double val0123 )
	'{
	'    CvScalar scalar;
	'    scalar.val[0] = val0123;
	'    scalar.val[1] = val0123;
	'    scalar.val[2] = val0123;
	'    scalar.val[3] = val0123;
	'    return scalar;
	'}
    Public Function cvScalarAll(ByVal val0123 As Double) As CvScalar
        Return New CvScalar(val0123, val0123, val0123, val0123)
    End Function



	'/****************************************************************************************\
	'*                                   Dynamic Data structures                              *
	'\****************************************************************************************/

	'/******************************** Memory storage ****************************************/

	'typedef struct CvMemBlock
	'{
	'    struct CvMemBlock*  prev;
	'    struct CvMemBlock*  next;
	'}
	'CvMemBlock;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvMemBlock
        Public prev As IntPtr
        Public [next] As IntPtr
    End Structure



	'#define CV_STORAGE_MAGIC_VAL    0x42890000
	public const  CV_STORAGE_MAGIC_VAL as integer =  &H42890000

	'typedef struct CvMemStorage
	'{
	'    int signature;
	'    CvMemBlock* bottom;/* first allocated block */
	'    CvMemBlock* top;   /* current memory block - top of the stack */
	'    struct  CvMemStorage* parent; /* borrows new blocks from */
	'    int block_size;  /* block size */
	'    int free_space;  /* free space in the current block */
	'}
	'CvMemStorage;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvMemStorage
        Public signature As Integer
        Public bottom As IntPtr
        Public top As IntPtr
        Public parent As IntPtr
        Public block_size As Integer
        Public free_space As Integer
    End Structure



	'#define CV_IS_STORAGE(storage)  \
	'    ((storage) != NULL &&       \
	'    (((CvMemStorage*)(storage))->signature & CV_MAGIC_MASK) == CV_STORAGE_MAGIC_VAL)
	'ToDo : 


	'typedef struct CvMemStoragePos
	'{
	'    CvMemBlock* top;
	'    int free_space;
	'}
	'CvMemStoragePos;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvMemStoragePos
        Public top As IntPtr
        Public free_space As Integer
    End Structure




	'/*********************************** Sequence *******************************************/

	'typedef struct CvSeqBlock
	'{
	'    struct CvSeqBlock*  prev; /* previous sequence block */
	'    struct CvSeqBlock*  next; /* next sequence block */
	'    int    start_index;       /* index of the first element in the block +
	'                                 sequence->first->start_index */
	'    int    count;             /* number of elements in the block */
	'    char*  data;              /* pointer to the first element of the block */
	'}
	'CvSeqBlock;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSeqBlock
        Public prev As IntPtr
        Public [next] As IntPtr
        Public start_index As Integer
        Public count As Integer
        Public data As IntPtr
    End Structure




	'#define CV_TREE_NODE_FIELDS(node_type)                          \
	'    int       flags;         /* micsellaneous flags */          \
	'    int       header_size;   /* size of sequence header */      \
	'    struct    node_type* h_prev; /* previous sequence */        \
	'    struct    node_type* h_next; /* next sequence */            \
	'    struct    node_type* v_prev; /* 2nd previous sequence */    \
	'    struct    node_type* v_next  /* 2nd next sequence */
	'ToDo : 

	'/*
	'   Read/Write sequence.
	'   Elements can be dynamically inserted to or deleted from the sequence.
	'*/
	'#define CV_SEQUENCE_FIELDS()                                            \
	'    CV_TREE_NODE_FIELDS(CvSeq);                                         \
	'    int       total;          /* total number of elements */            \
	'    int       elem_size;      /* size of sequence element in bytes */   \
	'    char*     block_max;      /* maximal bound of the last block */     \
	'    char*     ptr;            /* current write pointer */               \
	'    int       delta_elems;    /* how many elements allocated when the seq grows */  \
	'    CvMemStorage* storage;    /* where the seq is stored */             \
	'    CvSeqBlock* free_blocks;  /* free blocks list */                    \
	'    CvSeqBlock* first; /* pointer to the first sequence block */
	'ToDo : 

	'typedef struct CvSeq
	'{
	'    CV_SEQUENCE_FIELDS()
	'}
	'CvSeq;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSeq
#Region "CV_SEQUENCE_FIELDS"
        Public flags As Integer
        Public header_size As Integer
        Public h_prev As IntPtr
        Public h_next As IntPtr
        Public v_prev As IntPtr
        Public v_next As IntPtr
        Public total As Integer
        Public elem_size As Integer
        Public block_max As IntPtr
        Public ptr As IntPtr
        Public delta_elems As Integer
        Public storage As IntPtr
        Public free_blocks As IntPtr
        Public first As IntPtr
#End Region

        ''' <summary>
        ''' アンマネージ領域のポインタからデータをコピーし、新しいインスタンスを作成します。
        ''' </summary>
        ''' <param name="Src">アンマネージ領域のポインタ</param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Shared Function CreateFrom(ByVal Src As IntPtr) As CvSeq
            Return CType(Marshal.PtrToStructure(Src, GetType(CvSeq)), CvSeq)
        End Function
    End Structure



	'#define CV_TYPE_NAME_SEQ             "opencv-sequence"
	public const  CV_TYPE_NAME_SEQ as string =  "opencv-sequence"
	'#define CV_TYPE_NAME_SEQ_TREE        "opencv-sequence-tree"
	public const  CV_TYPE_NAME_SEQ_TREE as string =  "opencv-sequence-tree"

	'/*************************************** Set ********************************************/
	'/*
	'  Set.
	'  Order is not preserved. There can be gaps between sequence elements.
	'  After the element has been inserted it stays in the same place all the time.
	'  The MSB(most-significant or sign bit) of the first field (flags) is 0 iff the element exists.
	'*/
	'#define CV_SET_ELEM_FIELDS(elem_type)   \
	'    int  flags;                         \
	'    struct elem_type* next_free;
	'ToDo : 

	'typedef struct CvSetElem
	'{
	'    CV_SET_ELEM_FIELDS(CvSetElem)
	'}
	'CvSetElem;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSetElem
        Public flags As IntPtr
        Public next_free As IntPtr
    End Structure



	'#define CV_SET_FIELDS()      \
	'    CV_SEQUENCE_FIELDS()     \
	'    CvSetElem* free_elems;   \
	'    int active_count;
	'ToDo : 

	'typedef struct CvSet
	'{
	'    CV_SET_FIELDS()
	'}
	'CvSet;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSet
#Region "CV_SET_FIELDS"
#Region "CV_SEQUENCE_FIELDS"
#Region "CV_TREE_NODE_FIELDS_CvSeq"
        Public flags As Integer
        Public header_size As Integer
        Public h_prev As IntPtr
        Public h_next As IntPtr
        Public v_prev As IntPtr
        Public v_next As IntPtr
#End Region
        Public total As Integer
        Public elem_size As Integer
        Public block_max As IntPtr
        Public ptr As IntPtr
        Public delta_elems As Integer
        Public storage As IntPtr
        Public free_blocks As IntPtr
        Public first As IntPtr
#End Region
        Public free_elems As IntPtr
        Public active_count As Integer
#End Region
    End Structure




	'#define CV_SET_ELEM_IDX_MASK   ((1 << 26) - 1)
	public const  CV_SET_ELEM_IDX_MASK as integer =  ((1 << 26) - 1)
	'#define CV_SET_ELEM_FREE_FLAG  (1 << (sizeof(int)*8-1))
	'ToDo : unsupport

	'/* Checks whether the element pointed by ptr belongs to a set or not */
	'#define CV_IS_SET_ELEM( ptr )  (((CvSetElem*)(ptr))->flags >= 0)
	'ToDo : 

	'/************************************* Graph ********************************************/

	'/*
	'  Graph is represented as a set of vertices.
	'  Vertices contain their adjacency lists (more exactly, pointers to first incoming or
	'  outcoming edge (or 0 if isolated vertex)). Edges are stored in another set.
	'  There is a single-linked list of incoming/outcoming edges for each vertex.

	'  Each edge consists of:
	'    two pointers to the starting and the ending vertices (vtx[0] and vtx[1],
	'    respectively). Graph may be oriented or not. In the second case, edges between
	'    vertex i to vertex j are not distingueshed (during the search operations).

	'    two pointers to next edges for the starting and the ending vertices.
	'    next[0] points to the next edge in the vtx[0] adjacency list and
	'    next[1] points to the next edge in the vtx[1] adjacency list.
	'*/
	'#define CV_GRAPH_EDGE_FIELDS()      \
	'    int flags;                      \
	'    float weight;                   \
	'    struct CvGraphEdge* next[2];    \
	'    struct CvGraphVtx* vtx[2];
	'ToDo : 


	'#define CV_GRAPH_VERTEX_FIELDS()    \
	'    int flags;                      \
	'    struct CvGraphEdge* first;
	'ToDo : 


	'typedef struct CvGraphEdge
	'{
	'    CV_GRAPH_EDGE_FIELDS()
	'}
	'CvGraphEdge;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvGraphEdge
#Region "CV_GRAPH_EDGE_FIELDS"
        Public flags As Integer
        Public weight As Single
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=2)> _
        Public [next] As IntPtr()
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=2)> _
        Public vtx As IntPtr()
#End Region
    End Structure



	'typedef struct CvGraphVtx
	'{
	'    CV_GRAPH_VERTEX_FIELDS()
	'}
	'CvGraphVtx;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvGraphVtx
#Region "CV_GRAPH_VERTEX_FIELDS"
        Public flags As Integer
        Public first As IntPtr
#End Region
    End Structure



	'typedef struct CvGraphVtx2D
	'{
	'    CV_GRAPH_VERTEX_FIELDS()
	'    CvPoint2D32f* ptr;
	'}
	'CvGraphVtx2D;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvGraphVtx2D
#Region "CV_GRAPH_VERTEX_FIELDS"
        Public flags As Integer
        Public first As IntPtr
#End Region
        Public ptr As IntPtr
    End Structure



	'/*
	'   Graph is "derived" from the set (this is set a of vertices)
	'   and includes another set (edges)
	'*/
	'#define  CV_GRAPH_FIELDS()   \
	'    CV_SET_FIELDS()          \
	'    CvSet* edges;
	'ToDo : 

	'typedef struct CvGraph
	'{
	'    CV_GRAPH_FIELDS()
	'}
	'CvGraph;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvGraph
#Region "CV_GRAPH_FIELDS"
#Region "CV_SET_FIELDS"
#Region "CV_SEQUENCE_FIELDS"
#Region "CV_TREE_NODE_FIELDS_CvSeq"
        Public flags As Integer
        Public header_size As Integer
        Public h_prev As IntPtr
        Public h_next As IntPtr
        Public v_prev As IntPtr
        Public v_next As IntPtr
#End Region
        Public total As Integer
        Public elem_size As Integer
        Public block_max As IntPtr
        Public ptr As IntPtr
        Public delta_elems As Integer
        Public storage As IntPtr
        Public free_blocks As IntPtr
        Public first As IntPtr
#End Region
        Public free_elems As IntPtr
        Public active_count As Integer
#End Region
        Public edges As IntPtr
#End Region
    End Structure



	'#define CV_TYPE_NAME_GRAPH "opencv-graph"
	public const  CV_TYPE_NAME_GRAPH as string =  "opencv-graph"

	'/*********************************** Chain/Countour *************************************/

	'typedef struct CvChain
	'{
	'    CV_SEQUENCE_FIELDS()
	'    CvPoint  origin;
	'}
	'CvChain;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvChain
#Region "CV_SEQUENCE_FIELDS"
#Region "CV_TREE_NODE_FIELDS_CvSeq"
        Public flags As Integer
        Public header_size As Integer
        Public h_prev As IntPtr
        Public h_next As IntPtr
        Public v_prev As IntPtr
        Public v_next As IntPtr
#End Region
        Public total As Integer
        Public elem_size As Integer
        Public block_max As IntPtr
        Public ptr As IntPtr
        Public delta_elems As Integer
        Public storage As IntPtr
        Public free_blocks As IntPtr
        Public first As IntPtr
#End Region
        Public origin As CvPoint
    End Structure



	'#define CV_CONTOUR_FIELDS()  \
	'    CV_SEQUENCE_FIELDS()     \
	'    CvRect rect;             \
	'    int color;               \
	'    int reserved[3];
	'ToDo : 

	'typedef struct CvContour
	'{
	'    CV_CONTOUR_FIELDS()
	'}
	'CvContour;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvContour
#Region "'CV_CONTOUR_FIELDS"
#Region "CV_SEQUENCE_FIELDS"
#Region "CV_TREE_NODE_FIELDS_CvSeq"
        Public flags As Integer
        Public header_size As Integer
        Public h_prev As IntPtr
        Public h_next As IntPtr
        Public v_prev As IntPtr
        Public v_next As IntPtr
#End Region
        Public total As Integer
        Public elem_size As Integer
        Public block_max As IntPtr
        Public ptr As IntPtr
        Public delta_elems As Integer
        Public storage As IntPtr
        Public free_blocks As IntPtr
        Public first As IntPtr
#End Region
        Public rect As CvRect
        Public color As Integer
        '<MarshalAs(UnmanagedType.LPArray, SizeConst:=3)> Public reserved() As Integer
        Public reserved0 As Integer
        Public reserved1 As Integer
        Public reserved2 As Integer
#End Region
    End Structure



	'typedef CvContour CvPoint2DSeq;
	'Typedef : Unsupport

	'/****************************************************************************************\
	'*                                    Sequence types                                      *
	'\****************************************************************************************/

	'#define CV_SEQ_MAGIC_VAL             0x42990000
	public const  CV_SEQ_MAGIC_VAL as integer =  &H42990000

	'#define CV_IS_SEQ(seq) \
	'    ((seq) != NULL && (((CvSeq*)(seq))->flags & CV_MAGIC_MASK) == CV_SEQ_MAGIC_VAL)
	'ToDo : 

	'#define CV_SET_MAGIC_VAL             0x42980000
	public const  CV_SET_MAGIC_VAL as integer =  &H42980000
	'#define CV_IS_SET(set) \
	'    ((set) != NULL && (((CvSeq*)(set))->flags & CV_MAGIC_MASK) == CV_SET_MAGIC_VAL)
	'ToDo : 

	'#define CV_SEQ_ELTYPE_BITS           9
	public const  CV_SEQ_ELTYPE_BITS as integer =  9
	'#define CV_SEQ_ELTYPE_MASK           ((1 << CV_SEQ_ELTYPE_BITS) - 1)
	public const  CV_SEQ_ELTYPE_MASK as integer =  ((1 << CV_SEQ_ELTYPE_BITS) - 1)

	'#define CV_SEQ_ELTYPE_POINT          CV_32SC2  /* (x,y) */
	public const  CV_SEQ_ELTYPE_POINT as integer =  CV_32SC2
	'#define CV_SEQ_ELTYPE_CODE           CV_8UC1   /* freeman code: 0..7 */
	public const  CV_SEQ_ELTYPE_CODE as integer =  CV_8UC1
	'#define CV_SEQ_ELTYPE_GENERIC        0
	public const  CV_SEQ_ELTYPE_GENERIC as integer =  0
	'#define CV_SEQ_ELTYPE_PTR            CV_USRTYPE1
	public const  CV_SEQ_ELTYPE_PTR as integer =  CV_USRTYPE1
	'#define CV_SEQ_ELTYPE_PPOINT         CV_SEQ_ELTYPE_PTR  /* &(x,y) */
	public const  CV_SEQ_ELTYPE_PPOINT as integer =  CV_SEQ_ELTYPE_PTR
	'#define CV_SEQ_ELTYPE_INDEX          CV_32SC1  /* #(x,y) */
	public const  CV_SEQ_ELTYPE_INDEX as integer =  CV_32SC1
	'#define CV_SEQ_ELTYPE_GRAPH_EDGE     0  /* &next_o, &next_d, &vtx_o, &vtx_d */
	public const  CV_SEQ_ELTYPE_GRAPH_EDGE as integer =  0
	'#define CV_SEQ_ELTYPE_GRAPH_VERTEX   0  /* first_edge, &(x,y) */
	public const  CV_SEQ_ELTYPE_GRAPH_VERTEX as integer =  0
	'#define CV_SEQ_ELTYPE_TRIAN_ATR      0  /* vertex of the binary tree   */
	public const  CV_SEQ_ELTYPE_TRIAN_ATR as integer =  0
	'#define CV_SEQ_ELTYPE_CONNECTED_COMP 0  /* connected component  */
	public const  CV_SEQ_ELTYPE_CONNECTED_COMP as integer =  0
	'#define CV_SEQ_ELTYPE_POINT3D        CV_32FC3  /* (x,y,z)  */
	public const  CV_SEQ_ELTYPE_POINT3D as integer =  CV_32FC3

	'#define CV_SEQ_KIND_BITS        3
	public const  CV_SEQ_KIND_BITS as integer =  3
	'#define CV_SEQ_KIND_MASK        (((1 << CV_SEQ_KIND_BITS) - 1)<<CV_SEQ_ELTYPE_BITS)
	public const  CV_SEQ_KIND_MASK as integer =  (((1 << CV_SEQ_KIND_BITS) - 1)<<CV_SEQ_ELTYPE_BITS)

	'/* types of sequences */
	'#define CV_SEQ_KIND_GENERIC     (0 << CV_SEQ_ELTYPE_BITS)
	public const  CV_SEQ_KIND_GENERIC as integer =  (0 << CV_SEQ_ELTYPE_BITS)
	'#define CV_SEQ_KIND_CURVE       (1 << CV_SEQ_ELTYPE_BITS)
	public const  CV_SEQ_KIND_CURVE as integer =  (1 << CV_SEQ_ELTYPE_BITS)
	'#define CV_SEQ_KIND_BIN_TREE    (2 << CV_SEQ_ELTYPE_BITS)
	public const  CV_SEQ_KIND_BIN_TREE as integer =  (2 << CV_SEQ_ELTYPE_BITS)

	'/* types of sparse sequences (sets) */
	'#define CV_SEQ_KIND_GRAPH       (3 << CV_SEQ_ELTYPE_BITS)
	public const  CV_SEQ_KIND_GRAPH as integer =  (3 << CV_SEQ_ELTYPE_BITS)
	'#define CV_SEQ_KIND_SUBDIV2D    (4 << CV_SEQ_ELTYPE_BITS)
	public const  CV_SEQ_KIND_SUBDIV2D as integer =  (4 << CV_SEQ_ELTYPE_BITS)

	'#define CV_SEQ_FLAG_SHIFT       (CV_SEQ_KIND_BITS + CV_SEQ_ELTYPE_BITS)
	public const  CV_SEQ_FLAG_SHIFT as integer =  (CV_SEQ_KIND_BITS + CV_SEQ_ELTYPE_BITS)

	'/* flags for curves */
	'#define CV_SEQ_FLAG_CLOSED     (1 << CV_SEQ_FLAG_SHIFT)
	public const  CV_SEQ_FLAG_CLOSED as integer =  (1 << CV_SEQ_FLAG_SHIFT)
	'#define CV_SEQ_FLAG_SIMPLE     (2 << CV_SEQ_FLAG_SHIFT)
	public const  CV_SEQ_FLAG_SIMPLE as integer =  (2 << CV_SEQ_FLAG_SHIFT)
	'#define CV_SEQ_FLAG_CONVEX     (4 << CV_SEQ_FLAG_SHIFT)
	public const  CV_SEQ_FLAG_CONVEX as integer =  (4 << CV_SEQ_FLAG_SHIFT)
	'#define CV_SEQ_FLAG_HOLE       (8 << CV_SEQ_FLAG_SHIFT)
	public const  CV_SEQ_FLAG_HOLE as integer =  (8 << CV_SEQ_FLAG_SHIFT)

	'/* flags for graphs */
	'#define CV_GRAPH_FLAG_ORIENTED (1 << CV_SEQ_FLAG_SHIFT)
	public const  CV_GRAPH_FLAG_ORIENTED as integer =  (1 << CV_SEQ_FLAG_SHIFT)

	'#define CV_GRAPH               CV_SEQ_KIND_GRAPH
	public const  CV_GRAPH as integer =  CV_SEQ_KIND_GRAPH
	'#define CV_ORIENTED_GRAPH      (CV_SEQ_KIND_GRAPH|CV_GRAPH_FLAG_ORIENTED)
	public const  CV_ORIENTED_GRAPH as integer =  (CV_SEQ_KIND_GRAPH or CV_GRAPH_FLAG_ORIENTED)

	'/* point sets */
	'#define CV_SEQ_POINT_SET       (CV_SEQ_KIND_GENERIC| CV_SEQ_ELTYPE_POINT)
	public const  CV_SEQ_POINT_SET as integer =  (CV_SEQ_KIND_GENERIC or  CV_SEQ_ELTYPE_POINT)
	'#define CV_SEQ_POINT3D_SET     (CV_SEQ_KIND_GENERIC| CV_SEQ_ELTYPE_POINT3D)
	public const  CV_SEQ_POINT3D_SET as integer =  (CV_SEQ_KIND_GENERIC or  CV_SEQ_ELTYPE_POINT3D)
	'#define CV_SEQ_POLYLINE        (CV_SEQ_KIND_CURVE  | CV_SEQ_ELTYPE_POINT)
	public const  CV_SEQ_POLYLINE as integer =  (CV_SEQ_KIND_CURVE  or  CV_SEQ_ELTYPE_POINT)
	'#define CV_SEQ_POLYGON         (CV_SEQ_FLAG_CLOSED | CV_SEQ_POLYLINE )
	public const  CV_SEQ_POLYGON as integer =  (CV_SEQ_FLAG_CLOSED  or  CV_SEQ_POLYLINE )
	'#define CV_SEQ_CONTOUR         CV_SEQ_POLYGON
	public const  CV_SEQ_CONTOUR as integer =  CV_SEQ_POLYGON
	'#define CV_SEQ_SIMPLE_POLYGON  (CV_SEQ_FLAG_SIMPLE | CV_SEQ_POLYGON  )
	public const  CV_SEQ_SIMPLE_POLYGON as integer =  (CV_SEQ_FLAG_SIMPLE  or  CV_SEQ_POLYGON )

	'/* chain-coded curves */
	'#define CV_SEQ_CHAIN           (CV_SEQ_KIND_CURVE  | CV_SEQ_ELTYPE_CODE)
	public const  CV_SEQ_CHAIN as integer =  (CV_SEQ_KIND_CURVE  or  CV_SEQ_ELTYPE_CODE)
	'#define CV_SEQ_CHAIN_CONTOUR   (CV_SEQ_FLAG_CLOSED | CV_SEQ_CHAIN)
	public const  CV_SEQ_CHAIN_CONTOUR as integer =  (CV_SEQ_FLAG_CLOSED  or  CV_SEQ_CHAIN)

	'/* binary tree for the contour */
	'#define CV_SEQ_POLYGON_TREE    (CV_SEQ_KIND_BIN_TREE  | CV_SEQ_ELTYPE_TRIAN_ATR)
	public const  CV_SEQ_POLYGON_TREE as integer =  (CV_SEQ_KIND_BIN_TREE  or  CV_SEQ_ELTYPE_TRIAN_ATR)

	'/* sequence of the connected components */
	'#define CV_SEQ_CONNECTED_COMP  (CV_SEQ_KIND_GENERIC  | CV_SEQ_ELTYPE_CONNECTED_COMP)
	public const  CV_SEQ_CONNECTED_COMP as integer =  (CV_SEQ_KIND_GENERIC  or  CV_SEQ_ELTYPE_CONNECTED_COMP)

	'/* sequence of the integer numbers */
	'#define CV_SEQ_INDEX           (CV_SEQ_KIND_GENERIC  | CV_SEQ_ELTYPE_INDEX)
	public const  CV_SEQ_INDEX as integer =  (CV_SEQ_KIND_GENERIC  or  CV_SEQ_ELTYPE_INDEX)

	'#define CV_SEQ_ELTYPE( seq )   ((seq)->flags & CV_SEQ_ELTYPE_MASK)
	'ToDo : 
	'#define CV_SEQ_KIND( seq )     ((seq)->flags & CV_SEQ_KIND_MASK )
	'ToDo : 

	'/* flag checking */
	'#define CV_IS_SEQ_INDEX( seq )      ((CV_SEQ_ELTYPE(seq) == CV_SEQ_ELTYPE_INDEX) && \
	'                                     (CV_SEQ_KIND(seq) == CV_SEQ_KIND_GENERIC))
	'ToDo : 

	'#define CV_IS_SEQ_CURVE( seq )      (CV_SEQ_KIND(seq) == CV_SEQ_KIND_CURVE)
	'ToDo : 
	'#define CV_IS_SEQ_CLOSED( seq )     (((seq)->flags & CV_SEQ_FLAG_CLOSED) != 0)
	'ToDo : 
	'#define CV_IS_SEQ_CONVEX( seq )     (((seq)->flags & CV_SEQ_FLAG_CONVEX) != 0)
	'ToDo : 
	'#define CV_IS_SEQ_HOLE( seq )       (((seq)->flags & CV_SEQ_FLAG_HOLE) != 0)
	'ToDo : 
	'#define CV_IS_SEQ_SIMPLE( seq )     ((((seq)->flags & CV_SEQ_FLAG_SIMPLE) != 0) || \
	'                                    CV_IS_SEQ_CONVEX(seq))
	'ToDo : 

	'/* type checking macros */
	'#define CV_IS_SEQ_POINT_SET( seq ) \
	'    ((CV_SEQ_ELTYPE(seq) == CV_32SC2 || CV_SEQ_ELTYPE(seq) == CV_32FC2))
	'ToDo : 

	'#define CV_IS_SEQ_POINT_SUBSET( seq ) \
	'    (CV_IS_SEQ_INDEX( seq ) || CV_SEQ_ELTYPE(seq) == CV_SEQ_ELTYPE_PPOINT)
	'ToDo : 

	'#define CV_IS_SEQ_POLYLINE( seq )   \
	'    (CV_SEQ_KIND(seq) == CV_SEQ_KIND_CURVE && CV_IS_SEQ_POINT_SET(seq))
	'ToDo : 

	'#define CV_IS_SEQ_POLYGON( seq )   \
	'    (CV_IS_SEQ_POLYLINE(seq) && CV_IS_SEQ_CLOSED(seq))
	'ToDo : 

	'#define CV_IS_SEQ_CHAIN( seq )   \
	'    (CV_SEQ_KIND(seq) == CV_SEQ_KIND_CURVE && (seq)->elem_size == 1)
	'ToDo : 

	'#define CV_IS_SEQ_CONTOUR( seq )   \
	'    (CV_IS_SEQ_CLOSED(seq) && (CV_IS_SEQ_POLYLINE(seq) || CV_IS_SEQ_CHAIN(seq)))
	'ToDo : 

	'#define CV_IS_SEQ_CHAIN_CONTOUR( seq ) \
	'    (CV_IS_SEQ_CHAIN( seq ) && CV_IS_SEQ_CLOSED( seq ))
	'ToDo : 

	'#define CV_IS_SEQ_POLYGON_TREE( seq ) \
	'    (CV_SEQ_ELTYPE (seq) ==  CV_SEQ_ELTYPE_TRIAN_ATR &&    \
	'    CV_SEQ_KIND( seq ) ==  CV_SEQ_KIND_BIN_TREE )
	'ToDo : 

	'#define CV_IS_GRAPH( seq )    \
	'    (CV_IS_SET(seq) && CV_SEQ_KIND((CvSet*)(seq)) == CV_SEQ_KIND_GRAPH)
	'ToDo : 

	'#define CV_IS_GRAPH_ORIENTED( seq )   \
	'    (((seq)->flags & CV_GRAPH_FLAG_ORIENTED) != 0)
	'ToDo : 

	'#define CV_IS_SUBDIV2D( seq )  \
	'    (CV_IS_SET(seq) && CV_SEQ_KIND((CvSet*)(seq)) == CV_SEQ_KIND_SUBDIV2D)
	'ToDo : 

	'/****************************************************************************************/
	'/*                            Sequence writer & reader                                  */
	'/****************************************************************************************/

	'#define CV_SEQ_WRITER_FIELDS()                                     \
	'    int          header_size;                                      \
	'    CvSeq*       seq;        /* the sequence written */            \
	'    CvSeqBlock*  block;      /* current block */                   \
	'    char*        ptr;        /* pointer to free space */           \
	'    char*        block_min;  /* pointer to the beginning of block*/\
	'    char*        block_max;  /* pointer to the end of block */
	'ToDo : 

	'typedef struct CvSeqWriter
	'{
	'    CV_SEQ_WRITER_FIELDS()
	'}
	'CvSeqWriter;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSeqWriter
#Region "CV_SEQ_WRITER_FIELDS"
        Public header_size As Integer
        Public seq As IntPtr
        Public block As IntPtr
        Public ptr As IntPtr
        Public block_min As IntPtr
        Public block_max As IntPtr
#End Region
    End Structure




	'#define CV_SEQ_READER_FIELDS()                                      \
	'    int          header_size;                                       \
	'    CvSeq*       seq;        /* sequence, beign read */             \
	'    CvSeqBlock*  block;      /* current block */                    \
	'    char*        ptr;        /* pointer to element be read next */  \
	'    char*        block_min;  /* pointer to the beginning of block */\
	'    char*        block_max;  /* pointer to the end of block */      \
	'    int          delta_index;/* = seq->first->start_index   */      \
	'    char*        prev_elem;  /* pointer to previous element */
	'ToDo : 


	'typedef struct CvSeqReader
	'{
	'    CV_SEQ_READER_FIELDS()
	'}
	'CvSeqReader;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSeqReader
#Region "CV_SEQ_READER_FIELDS"
        Public header_size As Integer
        Public seq As IntPtr
        Public block As IntPtr
        Public ptr As IntPtr
        Public block_min As IntPtr
        Public block_max As IntPtr
        Public delta_index As Integer
        Public prev_elem As IntPtr
#End Region
    End Structure



	'/****************************************************************************************/
	'/*                                Operations on sequences                               */
	'/****************************************************************************************/

	'#define  CV_SEQ_ELEM( seq, elem_type, index )                    \
	'/* assert gives some guarantee that <seq> parameter is valid */  \
	'(   assert(sizeof((seq)->first[0]) == sizeof(CvSeqBlock) &&      \
	'    (seq)->elem_size == sizeof(elem_type)),                      \
	'    (elem_type*)((seq)->first && (unsigned)index <               \
	'    (unsigned)((seq)->first->count) ?                            \
	'    (seq)->first->data + (index) * sizeof(elem_type) :           \
	'    cvGetSeqElem( (CvSeq*)(seq), (index) )))
	'ToDo : 
	'#define CV_GET_SEQ_ELEM( elem_type, seq, index ) CV_SEQ_ELEM( (seq), elem_type, (index) )
	'ToDo : 

	'/* macro that adds element to sequence */
	'#define CV_WRITE_SEQ_ELEM_VAR( elem_ptr, writer )     \
	'{                                                     \
	'    if( (writer).ptr >= (writer).block_max )          \
	'    {                                                 \
	'        cvCreateSeqBlock( &writer);                   \
	'    }                                                 \
	'    memcpy((writer).ptr, elem_ptr, (writer).seq->elem_size);\
	'    (writer).ptr += (writer).seq->elem_size;          \
	'}
	'ToDo : 

	'#define CV_WRITE_SEQ_ELEM( elem, writer )             \
	'{                                                     \
	'    assert( (writer).seq->elem_size == sizeof(elem)); \
	'    if( (writer).ptr >= (writer).block_max )          \
	'    {                                                 \
	'        cvCreateSeqBlock( &writer);                   \
	'    }                                                 \
	'    assert( (writer).ptr <= (writer).block_max - sizeof(elem));\
	'    memcpy((writer).ptr, &(elem), sizeof(elem));      \
	'    (writer).ptr += sizeof(elem);                     \
	'}
	'ToDo : 


	'/* move reader position forward */
	'#define CV_NEXT_SEQ_ELEM( elem_size, reader )                 \
	'{                                                             \
	'    if( ((reader).ptr += (elem_size)) >= (reader).block_max ) \
	'    {                                                         \
	'        cvChangeSeqBlock( &(reader), 1 );                     \
	'    }                                                         \
	'}
	'ToDo : 


	'/* move reader position backward */
	'#define CV_PREV_SEQ_ELEM( elem_size, reader )                \
	'{                                                            \
	'    if( ((reader).ptr -= (elem_size)) < (reader).block_min ) \
	'    {                                                        \
	'        cvChangeSeqBlock( &(reader), -1 );                   \
	'    }                                                        \
	'}
	'ToDo : 

	'/* read element and move read position forward */
	'#define CV_READ_SEQ_ELEM( elem, reader )                       \
	'{                                                              \
	'    assert( (reader).seq->elem_size == sizeof(elem));          \
	'    memcpy( &(elem), (reader).ptr, sizeof((elem)));            \
	'    CV_NEXT_SEQ_ELEM( sizeof(elem), reader )                   \
	'}
	'ToDo : 

	'/* read element and move read position backward */
	'#define CV_REV_READ_SEQ_ELEM( elem, reader )                     \
	'{                                                                \
	'    assert( (reader).seq->elem_size == sizeof(elem));            \
	'    memcpy(&(elem), (reader).ptr, sizeof((elem)));               \
	'    CV_PREV_SEQ_ELEM( sizeof(elem), reader )                     \
	'}
	'ToDo : 


	'#define CV_READ_CHAIN_POINT( _pt, reader )                              \
	'{                                                                       \
	'    (_pt) = (reader).pt;                                                \
	'    if( (reader).ptr )                                                  \
	'    {                                                                   \
	'        CV_READ_SEQ_ELEM( (reader).code, (reader));                     \
	'        assert( ((reader).code & ~7) == 0 );                            \
	'        (reader).pt.x += (reader).deltas[(int)(reader).code][0];        \
	'        (reader).pt.y += (reader).deltas[(int)(reader).code][1];        \
	'    }                                                                   \
	'}
	'ToDo : 

	'#define CV_CURRENT_POINT( reader )  (*((CvPoint*)((reader).ptr)))
	'ToDo : 
	'#define CV_PREV_POINT( reader )     (*((CvPoint*)((reader).prev_elem)))
	'ToDo : 

	'#define CV_READ_EDGE( pt1, pt2, reader )               \
	'{                                                      \
	'    assert( sizeof(pt1) == sizeof(CvPoint) &&          \
	'            sizeof(pt2) == sizeof(CvPoint) &&          \
	'            reader.seq->elem_size == sizeof(CvPoint)); \
	'    (pt1) = CV_PREV_POINT( reader );                   \
	'    (pt2) = CV_CURRENT_POINT( reader );                \
	'    (reader).prev_elem = (reader).ptr;                 \
	'    CV_NEXT_SEQ_ELEM( sizeof(CvPoint), (reader));      \
	'}
	'ToDo : 

	'/************ Graph macros ************/

	'/* returns next graph edge for given vertex */
	'#define  CV_NEXT_GRAPH_EDGE( edge, vertex )                              \
	'     (assert((edge)->vtx[0] == (vertex) || (edge)->vtx[1] == (vertex)),  \
	'      (edge)->next[(edge)->vtx[1] == (vertex)])
	'ToDo : 



	'/****************************************************************************************\
	'*             Data structures for persistence (a.k.a serialization) functionality        *
	'\****************************************************************************************/

	'/* "black box" file storage */
	'typedef struct CvFileStorage CvFileStorage;
	'Typedef : Unsupport

	'/* storage flags */
	'#define CV_STORAGE_READ          0
	public const  CV_STORAGE_READ as integer =  0
	'#define CV_STORAGE_WRITE         1
	public const  CV_STORAGE_WRITE as integer =  1
	'#define CV_STORAGE_WRITE_TEXT    CV_STORAGE_WRITE
	public const  CV_STORAGE_WRITE_TEXT as integer =  CV_STORAGE_WRITE
	'#define CV_STORAGE_WRITE_BINARY  CV_STORAGE_WRITE
	public const  CV_STORAGE_WRITE_BINARY as integer =  CV_STORAGE_WRITE
	'#define CV_STORAGE_APPEND        2
	public const  CV_STORAGE_APPEND as integer =  2

	'/* list of attributes */
	'typedef struct CvAttrList
	'{
	'    const char** attr; /* NULL-terminated array of (attribute_name,attribute_value) pairs */
	'    struct CvAttrList* next; /* pointer to next chunk of the attributes list */
	'}
	'CvAttrList;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvAttrList
        Public attr As IntPtr
        Public nextptr As IntPtr
    End Structure



	'CV_INLINE CvAttrList cvAttrList( const char** attr CV_DEFAULT(NULL),
	'                                 CvAttrList* next CV_DEFAULT(NULL) )
	'{
	'    CvAttrList l;
	'    l.attr = attr;
	'    l.next = next;

	'    return l;
	'}
	'ToDo : Function

	'struct CvTypeInfo;
	'Skip : skip

	'#define CV_NODE_NONE        0
	public const  CV_NODE_NONE as integer =  0
	'#define CV_NODE_INT         1
	public const  CV_NODE_INT as integer =  1
	'#define CV_NODE_INTEGER     CV_NODE_INT
	public const  CV_NODE_INTEGER as integer =  CV_NODE_INT
	'#define CV_NODE_REAL        2
	public const  CV_NODE_REAL as integer =  2
	'#define CV_NODE_FLOAT       CV_NODE_REAL
	public const  CV_NODE_FLOAT as integer =  CV_NODE_REAL
	'#define CV_NODE_STR         3
	public const  CV_NODE_STR as integer =  3
	'#define CV_NODE_STRING      CV_NODE_STR
	public const  CV_NODE_STRING as integer =  CV_NODE_STR
	'#define CV_NODE_REF         4 /* not used */
	public const  CV_NODE_REF as integer =  4
	'#define CV_NODE_SEQ         5
	public const  CV_NODE_SEQ as integer =  5
	'#define CV_NODE_MAP         6
	public const  CV_NODE_MAP as integer =  6
	'#define CV_NODE_TYPE_MASK   7
	public const  CV_NODE_TYPE_MASK as integer =  7

	'#define CV_NODE_TYPE(flags)  ((flags) & CV_NODE_TYPE_MASK)
	'ToDo : 

	'/* file node flags */
	'#define CV_NODE_FLOW        8 /* used only for writing structures to YAML format */
	public const  CV_NODE_FLOW as integer =  8
	'#define CV_NODE_USER        16
	public const  CV_NODE_USER as integer =  16
	'#define CV_NODE_EMPTY       32
	public const  CV_NODE_EMPTY as integer =  32
	'#define CV_NODE_NAMED       64
	public const  CV_NODE_NAMED as integer =  64

	'#define CV_NODE_IS_INT(flags)        (CV_NODE_TYPE(flags) == CV_NODE_INT)
	'ToDo : 
	'#define CV_NODE_IS_REAL(flags)       (CV_NODE_TYPE(flags) == CV_NODE_REAL)
	'ToDo : 
	'#define CV_NODE_IS_STRING(flags)     (CV_NODE_TYPE(flags) == CV_NODE_STRING)
	'ToDo : 
	'#define CV_NODE_IS_SEQ(flags)        (CV_NODE_TYPE(flags) == CV_NODE_SEQ)
	'ToDo : 
	'#define CV_NODE_IS_MAP(flags)        (CV_NODE_TYPE(flags) == CV_NODE_MAP)
	'ToDo : 
	'#define CV_NODE_IS_COLLECTION(flags) (CV_NODE_TYPE(flags) >= CV_NODE_SEQ)
	'ToDo : 
	'#define CV_NODE_IS_FLOW(flags)       (((flags) & CV_NODE_FLOW) != 0)
	'ToDo : 
	'#define CV_NODE_IS_EMPTY(flags)      (((flags) & CV_NODE_EMPTY) != 0)
	'ToDo : 
	'#define CV_NODE_IS_USER(flags)       (((flags) & CV_NODE_USER) != 0)
	'ToDo : 
	'#define CV_NODE_HAS_NAME(flags)      (((flags) & CV_NODE_NAMED) != 0)
	'ToDo : 

	'#define CV_NODE_SEQ_SIMPLE 256
	public const  CV_NODE_SEQ_SIMPLE as integer =  256
	'#define CV_NODE_SEQ_IS_SIMPLE(seq) (((seq)->flags & CV_NODE_SEQ_SIMPLE) != 0)
	'ToDo : 

	'typedef struct CvString
	'{
	'    int len;
	'    char* ptr;
	'}
	'CvString;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvString
        Public len As Integer
        Public ptr As IntPtr
    End Structure



	'/* all the keys (names) of elements in the readed file storage
	'   are stored in the hash to speed up the lookup operations */
	'typedef struct CvStringHashNode
	'{
	'    unsigned hashval;
	'    CvString str;
	'    struct CvStringHashNode* next;
	'}
	'CvStringHashNode;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvStringHashNode
        Public hashval As UShort
        Public str As IntPtr
        Public [next] As IntPtr
    End Structure



	'typedef struct CvGenericHash CvFileNodeHash;
	'Typedef : Unsupport

	'/* basic element of the file storage - scalar or collection */
	'typedef struct CvFileNode
	'{
	'    int tag;
	'    struct CvTypeInfo* info; /* type information
	'            (only for user-defined object, for others it is 0) */
	'    union
	'    {
	'        double f; /* scalar floating-point number */
	'        int i;    /* scalar integer number */
	'        CvString str; /* text string */
	'        CvSeq* seq; /* sequence (ordered collection of file nodes) */
	'        CvFileNodeHash* map; /* map (collection of named file nodes) */
	'    } data;
	'}
	'CvFileNode;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvFileNode
        Public tag As Integer
        Public info As IntPtr
        Public data As CvFileNode_Data
    End Structure
    <StructLayout(LayoutKind.Explicit, size:=8)> _
    Public Structure CvFileNode_Data
        <FieldOffset(0)> Public f As Double
        <FieldOffset(0)> Public i As Integer
        <FieldOffset(0)> Public str As CvString
        <FieldOffset(0)> Public seq As intptr
        <FieldOffset(0)> Public map As IntPtr
    End Structure



	'typedef int (CV_CDECL *CvIsInstanceFunc)( const void* struct_ptr );
	'Typedef : Unsupport
	'typedef void (CV_CDECL *CvReleaseFunc)( void** struct_dblptr );
	'Typedef : Unsupport
	'typedef void* (CV_CDECL *CvReadFunc)( CvFileStorage* storage, CvFileNode* node );
	'Typedef : Unsupport
	'typedef void (CV_CDECL *CvWriteFunc)( CvFileStorage* storage, const char* name,
	'                                      const void* struct_ptr, CvAttrList attributes );
	'Typedef : Unsupport
	'typedef void* (CV_CDECL *CvCloneFunc)( const void* struct_ptr );
	'Typedef : Unsupport

	'typedef struct CvTypeInfo
	'{
	'    int flags;
	'    int header_size;
	'    struct CvTypeInfo* prev;
	'    struct CvTypeInfo* next;
	'    const char* type_name;
	'    CvIsInstanceFunc is_instance;
	'    CvReleaseFunc release;
	'    CvReadFunc read;
	'    CvWriteFunc write;
	'    CvCloneFunc clone;
	'}
	'CvTypeInfo;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvTypeInfo
        Public flags As Integer
        Public header_size As Integer
        Public prev As IntPtr
        Public [next] As IntPtr
        Public type_name As IntPtr
        Public is_instance As IntPtr
        Public release As intptr
        Public read As intptr
        Public write As intptr
        Public clone As intptr
    End Structure




	'/**** System data types ******/

	'typedef struct CvPluginFuncInfo
	'{
	'    void** func_addr;
	'    void* default_func_addr;
	'    const char* func_names;
	'    int search_modules;
	'    int loaded_from;
	'}
	'CvPluginFuncInfo;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvPluginFuncInfo
        Public func_addr As IntPtr
        Public default_func_addr As IntPtr
        Public func_names As intptr
        Public search_modules As Integer
        Public loaded_from As Integer
    End Structure



	'typedef struct CvModuleInfo
	'{
	'    struct CvModuleInfo* next;
	'    const char* name;
	'    const char* version;
	'    CvPluginFuncInfo* func_tab;
	'}
	'CvModuleInfo;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvModuleInfo
        Public [next] As IntPtr
        Public name As IntPtr
        Public version As IntPtr
        Public func_tab As IntPtr
    End Structure



End Module
