Option Explicit On
Option Strict On

Imports System.Runtime.InteropServices

Public Module HighGUI
	'/*M///////////////////////////////////////////////////////////////////////////////////////
	'//
	'//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
	'//
	'//  By downloading, copying, installing or using the software you agree to this license.
	'//  If you do not agree to this license, do not download, install,
	'//  copy or use the software.
	'//
	'//
	'//                        Intel License Agreement
	'//                For Open Source Computer Vision Library
	'//
	'// Copyright (C) 2000, Intel Corporation, all rights reserved.
	'// Third party copyrights are property of their respective owners.
	'//
	'// Redistribution and use in source and binary forms, with or without modification,
	'// are permitted provided that the following conditions are met:
	'//
	'//   * Redistribution's of source code must retain the above copyright notice,
	'//     this list of conditions and the following disclaimer.
	'//
	'//   * Redistribution's in binary form must reproduce the above copyright notice,
	'//     this list of conditions and the following disclaimer in the documentation
	'//     and/or other materials provided with the distribution.
	'//
	'//   * The name of Intel Corporation may not be used to endorse or promote products
	'//     derived from this software without specific prior written permission.
	'//
	'// This software is provided by the copyright holders and contributors "as is" and
	'// any express or implied warranties, including, but not limited to, the implied
	'// warranties of merchantability and fitness for a particular purpose are disclaimed.
	'// In no event shall the Intel Corporation or contributors be liable for any direct,
	'// indirect, incidental, special, exemplary, or consequential damages
	'// (including, but not limited to, procurement of substitute goods or services;
	'// loss of use, data, or profits; or business interruption) however caused
	'// and on any theory of liability, whether in contract, strict liability,
	'// or tort (including negligence or otherwise) arising in any way out of
	'// the use of this software, even if advised of the possibility of such damage.
	'//
	'//M*/

	'/****************************************************************************************\
	'*                                  Basic GUI functions                                   *
	'\****************************************************************************************/

	'/* this function is used to set some external parameters in case of X Window */
	'CVAPI(int) cvInitSystem( int argc, char** argv );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitSystem(byval argc as integer,byref argv as string) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvInitSystem(byval argc as integer,byval argv as intptr) as integer
	end function

	'CVAPI(int) cvStartWindowThread();
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvStartWindowThread() as integer
	end function

	'#define CV_WINDOW_AUTOSIZE  1
	public const  CV_WINDOW_AUTOSIZE as integer =  1
	'/* create window */
	'CVAPI(int) cvNamedWindow( const char* name, int flags CV_DEFAULT(CV_WINDOW_AUTOSIZE) );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNamedWindow(byval name as string,byval flags as integer) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNamedWindow(byval name as byte(),byval flags as integer) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvNamedWindow(byval name as intptr,byval flags as integer) as integer
	end function

	'/* display image within window (highgui windows remember their content) */
	'CVAPI(void) cvShowImage( const char* name, const CvArr* image );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvShowImage(byval name as string,byval image as intptr)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvShowImage(byval name as byte(),byval image as intptr)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvShowImage(byval name as intptr,byval image as intptr)
	end sub

	'/* resize/move window */
	'CVAPI(void) cvResizeWindow( const char* name, int width, int height );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvResizeWindow(byval name as string,byval width as integer,byval height as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvResizeWindow(byval name as byte(),byval width as integer,byval height as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvResizeWindow(byval name as intptr,byval width as integer,byval height as integer)
	end sub
	'CVAPI(void) cvMoveWindow( const char* name, int x, int y );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMoveWindow(byval name as string,byval x as integer,byval y as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMoveWindow(byval name as byte(),byval x as integer,byval y as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvMoveWindow(byval name as intptr,byval x as integer,byval y as integer)
	end sub


	'/* destroy window and all the trackers associated with it */
	'CVAPI(void) cvDestroyWindow( const char* name );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvDestroyWindow(byval name as string)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvDestroyWindow(byval name as byte())
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvDestroyWindow(byval name as intptr)
	end sub

	'CVAPI(void) cvDestroyAllWindows(void);
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvDestroyAllWindows()
	end sub

	'/* get native window handle (HWND in case of Win32 and Widget in case of X Window) */
	'CVAPI(void*) cvGetWindowHandle( const char* name );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetWindowHandle(byval name as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetWindowHandle(byval name as byte()) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetWindowHandle(byval name as intptr) as IntPtr
	end function

	'/* get name of highgui window given its native handle */
	'CVAPI(const char*) cvGetWindowName( void* window_handle );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetWindowName(byval window_handle as intptr) as IntPtr
	end function


	'typedef void (CV_CDECL *CvTrackbarCallback)(int pos);
	'Typedef : Unsupport

	'/* create trackbar and display it on top of given window, set callback */
	'CVAPI(int) cvCreateTrackbar( const char* trackbar_name, const char* window_name,
	'                             int* value, int count, CvTrackbarCallback on_change );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateTrackbar(byval trackbar_name as string,byval window_name as string,byval value as intptr,byval count as integer,byval on_change as intptr) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateTrackbar(byval trackbar_name as string,byval window_name as string,byval value as intptr,byval count as integer,byval on_change as CvTrackbarCallback) as integer
	end function

    <UnmanagedFunctionPointer(CallingConvention.Cdecl)> _
    Public Delegate Sub CvTrackbarCallback(ByVal Pos As Integer)



	'/* retrieve or set trackbar position */
	'CVAPI(int) cvGetTrackbarPos( const char* trackbar_name, const char* window_name );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTrackbarPos(byval trackbar_name as string,byval window_name as string) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTrackbarPos(byval trackbar_name as byte(),byval window_name as string) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTrackbarPos(byval trackbar_name as intptr,byval window_name as string) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTrackbarPos(byval trackbar_name as string,byval window_name as byte()) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTrackbarPos(byval trackbar_name as byte(),byval window_name as byte()) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTrackbarPos(byval trackbar_name as intptr,byval window_name as byte()) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTrackbarPos(byval trackbar_name as string,byval window_name as intptr) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTrackbarPos(byval trackbar_name as byte(),byval window_name as intptr) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetTrackbarPos(byval trackbar_name as intptr,byval window_name as intptr) as integer
	end function
	'CVAPI(void) cvSetTrackbarPos( const char* trackbar_name, const char* window_name, int pos );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetTrackbarPos(byval trackbar_name as string,byval window_name as string,byval pos as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetTrackbarPos(byval trackbar_name as byte(),byval window_name as string,byval pos as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetTrackbarPos(byval trackbar_name as intptr,byval window_name as string,byval pos as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetTrackbarPos(byval trackbar_name as string,byval window_name as byte(),byval pos as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetTrackbarPos(byval trackbar_name as byte(),byval window_name as byte(),byval pos as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetTrackbarPos(byval trackbar_name as intptr,byval window_name as byte(),byval pos as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetTrackbarPos(byval trackbar_name as string,byval window_name as intptr,byval pos as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetTrackbarPos(byval trackbar_name as byte(),byval window_name as intptr,byval pos as integer)
	end sub
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvSetTrackbarPos(byval trackbar_name as intptr,byval window_name as intptr,byval pos as integer)
	end sub

	'#define CV_EVENT_MOUSEMOVE      0
	public const  CV_EVENT_MOUSEMOVE as integer =  0
	'#define CV_EVENT_LBUTTONDOWN    1
	public const  CV_EVENT_LBUTTONDOWN as integer =  1
	'#define CV_EVENT_RBUTTONDOWN    2
	public const  CV_EVENT_RBUTTONDOWN as integer =  2
	'#define CV_EVENT_MBUTTONDOWN    3
	public const  CV_EVENT_MBUTTONDOWN as integer =  3
	'#define CV_EVENT_LBUTTONUP      4
	public const  CV_EVENT_LBUTTONUP as integer =  4
	'#define CV_EVENT_RBUTTONUP      5
	public const  CV_EVENT_RBUTTONUP as integer =  5
	'#define CV_EVENT_MBUTTONUP      6
	public const  CV_EVENT_MBUTTONUP as integer =  6
	'#define CV_EVENT_LBUTTONDBLCLK  7
	public const  CV_EVENT_LBUTTONDBLCLK as integer =  7
	'#define CV_EVENT_RBUTTONDBLCLK  8
	public const  CV_EVENT_RBUTTONDBLCLK as integer =  8
	'#define CV_EVENT_MBUTTONDBLCLK  9
	public const  CV_EVENT_MBUTTONDBLCLK as integer =  9

	'#define CV_EVENT_FLAG_LBUTTON   1
	public const  CV_EVENT_FLAG_LBUTTON as integer =  1
	'#define CV_EVENT_FLAG_RBUTTON   2
	public const  CV_EVENT_FLAG_RBUTTON as integer =  2
	'#define CV_EVENT_FLAG_MBUTTON   4
	public const  CV_EVENT_FLAG_MBUTTON as integer =  4
	'#define CV_EVENT_FLAG_CTRLKEY   8
	public const  CV_EVENT_FLAG_CTRLKEY as integer =  8
	'#define CV_EVENT_FLAG_SHIFTKEY  16
	public const  CV_EVENT_FLAG_SHIFTKEY as integer =  16
	'#define CV_EVENT_FLAG_ALTKEY    32
	public const  CV_EVENT_FLAG_ALTKEY as integer =  32

	'typedef void (CV_CDECL *CvMouseCallback )(int event, int x, int y, int flags, void* param);
	'Typedef : Unsupport

	'/* assign callback for mouse events */
	'CVAPI(void) cvSetMouseCallback( const char* window_name, CvMouseCallback on_mouse,
	'                                void* param CV_DEFAULT(NULL));
    <DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
    Public Sub cvSetMouseCallback(ByVal window_name As String, ByVal on_mouse As CvMouseCallback, ByVal param As IntPtr)
    End Sub
    <DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
    Public Sub cvSetMouseCallback(ByVal window_name As String, ByVal on_mouse As IntPtr, ByVal param As IntPtr)
    End Sub

    <UnmanagedFunctionPointer(CallingConvention.Cdecl)> _
    Public Delegate Sub CvMouseCallback(ByVal eventcode As Integer, ByVal x As Integer, ByVal y As Integer, ByVal flags As Integer, ByVal param As IntPtr)



	'/* 8bit, color or not */
	'#define CV_LOAD_IMAGE_UNCHANGED  -1
	public const  CV_LOAD_IMAGE_UNCHANGED as integer =  -1
	'/* 8bit, gray */
	'#define CV_LOAD_IMAGE_GRAYSCALE   0
	public const  CV_LOAD_IMAGE_GRAYSCALE as integer =  0
	'/* ?, color */
	'#define CV_LOAD_IMAGE_COLOR       1
	public const  CV_LOAD_IMAGE_COLOR as integer =  1
	'/* any depth, ? */ 
	'#define CV_LOAD_IMAGE_ANYDEPTH    2
	public const  CV_LOAD_IMAGE_ANYDEPTH as integer =  2
	'/* ?, any color */
	'#define CV_LOAD_IMAGE_ANYCOLOR    4
	public const  CV_LOAD_IMAGE_ANYCOLOR as integer =  4

	'/* load image from file 
	'  iscolor can be a combination of above flags where CV_LOAD_IMAGE_UNCHANGED
	'  overrides the other flags
	'  using CV_LOAD_IMAGE_ANYCOLOR alone is equivalent to CV_LOAD_IMAGE_UNCHANGED
	'  unless CV_LOAD_IMAGE_ANYDEPTH is specified images are converted to 8bit
	'*/
	'CVAPI(IplImage*) cvLoadImage( const char* filename, int iscolor CV_DEFAULT(CV_LOAD_IMAGE_COLOR));
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoadImage(byval filename as string,byval iscolor as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoadImage(byval filename as byte(),byval iscolor as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoadImage(byval filename as intptr,byval iscolor as integer) as IntPtr
	end function
	'CVAPI(CvMat*) cvLoadImageM( const char* filename, int iscolor CV_DEFAULT(CV_LOAD_IMAGE_COLOR));
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoadImageM(byval filename as string,byval iscolor as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoadImageM(byval filename as byte(),byval iscolor as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvLoadImageM(byval filename as intptr,byval iscolor as integer) as IntPtr
	end function

	'/* save image to file */
	'CVAPI(int) cvSaveImage( const char* filename, const CvArr* image );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSaveImage(byval filename as string,byval image as intptr) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSaveImage(byval filename as byte(),byval image as intptr) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSaveImage(byval filename as intptr,byval image as intptr) as integer
	end function

	'#define CV_CVTIMG_FLIP      1
	public const  CV_CVTIMG_FLIP as integer =  1
	'#define CV_CVTIMG_SWAP_RB   2 
	public const  CV_CVTIMG_SWAP_RB as integer =  2
	'/* utility function: convert one image to another with optional vertical flip */
	'CVAPI(void) cvConvertImage( const CvArr* src, CvArr* dst, int flags CV_DEFAULT(0));
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvConvertImage(byval src as intptr,byval dst as intptr,byval flags as integer)
	end sub

	'/* wait for key event infinitely (delay<=0) or for "delay" milliseconds */
	'CVAPI(int) cvWaitKey(int delay CV_DEFAULT(0));
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvWaitKey(byval delay as integer) as integer
	end function


	'/****************************************************************************************\
	'*                         Working with Video Files and Cameras                           *
	'\****************************************************************************************/

	'/* "black box" capture structure */
	'typedef struct CvCapture CvCapture;
	'Typedef : Unsupport

	'/* start capturing frames from video file */
	'CVAPI(CvCapture*) cvCreateFileCapture( const char* filename );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateFileCapture(byval filename as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateFileCapture(byval filename as byte()) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateFileCapture(byval filename as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvCreateFileCapture")> _
	public function cvCaptureFromFile(byval filename as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvCreateFileCapture")> _
	public function cvCaptureFromFile(byval filename as byte()) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvCreateFileCapture")> _
	public function cvCaptureFromFile(byval filename as intptr) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvCreateFileCapture")> _
	public function cvCaptureFromAVI(byval filename as string) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvCreateFileCapture")> _
	public function cvCaptureFromAVI(byval filename as byte()) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvCreateFileCapture")> _
	public function cvCaptureFromAVI(byval filename as intptr) as IntPtr
	end function

	'#define CV_CAP_ANY      0     // autodetect
	public const  CV_CAP_ANY as integer =  0

	'#define CV_CAP_MIL      100   // MIL proprietary drivers
	public const  CV_CAP_MIL as integer =  100

	'#define CV_CAP_VFW      200   // platform native
	public const  CV_CAP_VFW as integer =  200
	'#define CV_CAP_V4L      200
	public const  CV_CAP_V4L as integer =  200
	'#define CV_CAP_V4L2     200
	public const  CV_CAP_V4L2 as integer =  200

	'#define CV_CAP_FIREWARE 300   // IEEE 1394 drivers
	public const  CV_CAP_FIREWARE as integer =  300
	'#define CV_CAP_IEEE1394 300
	public const  CV_CAP_IEEE1394 as integer =  300
	'#define CV_CAP_DC1394   300
	public const  CV_CAP_DC1394 as integer =  300
	'#define CV_CAP_CMU1394  300
	public const  CV_CAP_CMU1394 as integer =  300

	'#define CV_CAP_STEREO   400   // TYZX proprietary drivers
	public const  CV_CAP_STEREO as integer =  400
	'#define CV_CAP_TYZX     400
	public const  CV_CAP_TYZX as integer =  400
	'#define CV_TYZX_LEFT    400
	public const  CV_TYZX_LEFT as integer =  400
	'#define CV_TYZX_RIGHT   401
	public const  CV_TYZX_RIGHT as integer =  401
	'#define CV_TYZX_COLOR   402
	public const  CV_TYZX_COLOR as integer =  402
	'#define CV_TYZX_Z       403
	public const  CV_TYZX_Z as integer =  403

	'#define CV_CAP_QT       500   // QuickTime
	public const  CV_CAP_QT as integer =  500

	'/* start capturing frames from camera: index = camera_index + domain_offset (CV_CAP_*) */
	'CVAPI(CvCapture*) cvCreateCameraCapture( int index );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateCameraCapture(byval index as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:="cvCreateCameraCapture")> _
	public function cvCaptureFromCAM(byval index as integer) as IntPtr
	end function

	'/* grab a frame, return 1 on success, 0 on fail. 
	'  this function is thought to be fast               */  
	'CVAPI(int) cvGrabFrame( CvCapture* capture );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGrabFrame(byval capture as intptr) as integer
	end function

	'/* get the frame grabbed with cvGrabFrame(..) 
	'  This function may apply some frame processing like 
	'  frame decompression, flipping etc.
	'  !!!DO NOT RELEASE or MODIFY the retrieved frame!!! */
	'CVAPI(IplImage*) cvRetrieveFrame( CvCapture* capture );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvRetrieveFrame(byval capture as intptr) as IntPtr
	end function

	'/* Just a combination of cvGrabFrame and cvRetrieveFrame
	'   !!!DO NOT RELEASE or MODIFY the retrieved frame!!!      */
	'CVAPI(IplImage*) cvQueryFrame( CvCapture* capture );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvQueryFrame(byval capture as intptr) as IntPtr
	end function

	'/* stop capturing/reading and free resources */
	'CVAPI(void) cvReleaseCapture( CvCapture** capture );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReleaseCapture(byref capture as intptr)
	end sub

	'#define CV_CAP_PROP_POS_MSEC       0
	public const  CV_CAP_PROP_POS_MSEC as integer =  0
	'#define CV_CAP_PROP_POS_FRAMES     1
	public const  CV_CAP_PROP_POS_FRAMES as integer =  1
	'#define CV_CAP_PROP_POS_AVI_RATIO  2
	public const  CV_CAP_PROP_POS_AVI_RATIO as integer =  2
	'#define CV_CAP_PROP_FRAME_WIDTH    3
	public const  CV_CAP_PROP_FRAME_WIDTH as integer =  3
	'#define CV_CAP_PROP_FRAME_HEIGHT   4
	public const  CV_CAP_PROP_FRAME_HEIGHT as integer =  4
	'#define CV_CAP_PROP_FPS            5
	public const  CV_CAP_PROP_FPS as integer =  5
	'#define CV_CAP_PROP_FOURCC         6
	public const  CV_CAP_PROP_FOURCC as integer =  6
	'#define CV_CAP_PROP_FRAME_COUNT    7 
	public const  CV_CAP_PROP_FRAME_COUNT as integer =  7
	'#define CV_CAP_PROP_FORMAT         8
	public const  CV_CAP_PROP_FORMAT as integer =  8
	'#define CV_CAP_PROP_MODE           9
	public const  CV_CAP_PROP_MODE as integer =  9
	'#define CV_CAP_PROP_BRIGHTNESS    10
	public const  CV_CAP_PROP_BRIGHTNESS as integer =  10
	'#define CV_CAP_PROP_CONTRAST      11
	public const  CV_CAP_PROP_CONTRAST as integer =  11
	'#define CV_CAP_PROP_SATURATION    12
	public const  CV_CAP_PROP_SATURATION as integer =  12
	'#define CV_CAP_PROP_HUE           13
	public const  CV_CAP_PROP_HUE as integer =  13
	'#define CV_CAP_PROP_GAIN          14
	public const  CV_CAP_PROP_GAIN as integer =  14
	'#define CV_CAP_PROP_CONVERT_RGB   15
	public const  CV_CAP_PROP_CONVERT_RGB as integer =  15


	'/* retrieve or set capture properties */
	'CVAPI(double) cvGetCaptureProperty( CvCapture* capture, int property_id );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvGetCaptureProperty(byval capture as intptr,byval property_id as integer) as double
	end function
	'CVAPI(int)    cvSetCaptureProperty( CvCapture* capture, int property_id, double value );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvSetCaptureProperty(byval capture as intptr,byval property_id as integer,byval value as double) as integer
	end function

	'/* "black box" video file writer structure */
	'typedef struct CvVideoWriter CvVideoWriter;
	'Typedef : Unsupport

	'#define CV_FOURCC(c1,c2,c3,c4)  \
	'    (((c1)&255) + (((c2)&255)<<8) + (((c3)&255)<<16) + (((c4)&255)<<24))
    Public Function CV_FOURCC(ByVal c1 As Integer, ByVal c2 As Integer, ByVal c3 As Integer, ByVal c4 As Integer) As Integer
        Return (((c1) And 255) + (((c2) And 255) << 8) + (((c3) And 255) << 16) + (((c4) And 255) << 24))
    End Function



	'/* initialize video file writer */
	'CVAPI(CvVideoWriter*) cvCreateVideoWriter( const char* filename, int fourcc,
	'                                           double fps, CvSize frame_size,
	'                                           int is_color CV_DEFAULT(1));
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateVideoWriter(byval filename as string,byval fourcc as integer,byval fps as double,byval frame_size as CvSize,byval is_color as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateVideoWriter(byval filename as byte(),byval fourcc as integer,byval fps as double,byval frame_size as CvSize,byval is_color as integer) as IntPtr
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvCreateVideoWriter(byval filename as intptr,byval fourcc as integer,byval fps as double,byval frame_size as CvSize,byval is_color as integer) as IntPtr
	end function

	'/* write frame to video file */
	'CVAPI(int) cvWriteFrame( CvVideoWriter* writer, const IplImage* image );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvWriteFrame(byval writer as intptr,byref image as IplImage) as integer
	end function
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public function cvWriteFrame(byval writer as intptr,byval image as intptr) as integer
	end function

	'/* close video file writer */
	'CVAPI(void) cvReleaseVideoWriter( CvVideoWriter** writer );
	<DllImport(OpenCVInformation.HighGUI, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _
	public sub cvReleaseVideoWriter(byref writer as intptr)
	end sub

	'/****************************************************************************************\
	'*                              Obsolete functions/synonyms                               *
	'\****************************************************************************************/


	'/* For use with Win32 */
	'CV_INLINE RECT NormalizeRect( RECT r );
	'ToDo : Function
	'CV_INLINE RECT NormalizeRect( RECT r )
	'{
	'    int t;

	'    if( r.left > r.right )
	'    {
	'        t = r.left;
	'        r.left = r.right;
	'        r.right = t;
	'    }

	'    if( r.top > r.bottom )
	'    {
	'        t = r.top;
	'        r.top = r.bottom;
	'        r.bottom = t;
	'    }

	'    return r;
	'}
	'ToDo : Function

	'CV_INLINE CvRect RectToCvRect( RECT sr );
	'ToDo : Function
	'CV_INLINE CvRect RectToCvRect( RECT sr )
	'{
	'    sr = NormalizeRect( sr );
	'    return cvRect( sr.left, sr.top, sr.right - sr.left, sr.bottom - sr.top );
	'}
	'ToDo : Function

	'CV_INLINE RECT CvRectToRect( CvRect sr );
	'ToDo : Function
	'CV_INLINE RECT CvRectToRect( CvRect sr )
	'{
	'    RECT dr;
	'    dr.left = sr.x;
	'    dr.top = sr.y;
	'    dr.right = sr.x + sr.width;
	'    dr.bottom = sr.y + sr.height;

	'    return dr;
	'}
	'ToDo : Function

	'CV_INLINE IplROI RectToROI( RECT r );
	'ToDo : Function
	'CV_INLINE IplROI RectToROI( RECT r )
	'{
	'    IplROI roi;
	'    r = NormalizeRect( r );
	'    roi.xOffset = r.left;
	'    roi.yOffset = r.top;
	'    roi.width = r.right - r.left;
	'    roi.height = r.bottom - r.top;
	'    roi.coi = 0;

	'    return roi;
	'}
	'ToDo : Function

End Module
