﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btn_LoadFile = New System.Windows.Forms.Button
        Me.Pic_Image = New System.Windows.Forms.PictureBox
        CType(Me.Pic_Image, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Btn_LoadFile
        '
        Me.Btn_LoadFile.Location = New System.Drawing.Point(8, 8)
        Me.Btn_LoadFile.Name = "Btn_LoadFile"
        Me.Btn_LoadFile.Size = New System.Drawing.Size(144, 32)
        Me.Btn_LoadFile.TabIndex = 1
        Me.Btn_LoadFile.Text = "ファイル画像表示"
        Me.Btn_LoadFile.UseVisualStyleBackColor = True
        '
        'Pic_Image
        '
        Me.Pic_Image.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pic_Image.Location = New System.Drawing.Point(8, 48)
        Me.Pic_Image.Name = "Pic_Image"
        Me.Pic_Image.Size = New System.Drawing.Size(64, 72)
        Me.Pic_Image.TabIndex = 2
        Me.Pic_Image.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(537, 579)
        Me.Controls.Add(Me.Pic_Image)
        Me.Controls.Add(Me.Btn_LoadFile)
        Me.Name = "Form1"
        Me.Text = "PictureBox"
        CType(Me.Pic_Image, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Btn_LoadFile As System.Windows.Forms.Button
    Friend WithEvents Pic_Image As System.Windows.Forms.PictureBox

End Class
