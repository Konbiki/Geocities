﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btn_File = New System.Windows.Forms.Button
        Me.lbl_File = New System.Windows.Forms.Label
        Me.Rdo_RGB_R = New System.Windows.Forms.RadioButton
        Me.Rdo_RGB_G = New System.Windows.Forms.RadioButton
        Me.Rdo_RGB_B = New System.Windows.Forms.RadioButton
        Me.Rdo_HSV_H = New System.Windows.Forms.RadioButton
        Me.Rdo_HSV_S = New System.Windows.Forms.RadioButton
        Me.Rdo_HSV_V = New System.Windows.Forms.RadioButton
        Me.Rdo_HLS_H = New System.Windows.Forms.RadioButton
        Me.Rdo_HLS_L = New System.Windows.Forms.RadioButton
        Me.Rdo_HLS_S = New System.Windows.Forms.RadioButton
        Me.Grp_View = New System.Windows.Forms.GroupBox
        Me.Rdo_SRC = New System.Windows.Forms.RadioButton
        Me.Grp_File = New System.Windows.Forms.GroupBox
        Me.Grp_View.SuspendLayout()
        Me.Grp_File.SuspendLayout()
        Me.SuspendLayout()
        '
        'Btn_File
        '
        Me.Btn_File.Location = New System.Drawing.Point(8, 40)
        Me.Btn_File.Name = "Btn_File"
        Me.Btn_File.Size = New System.Drawing.Size(88, 24)
        Me.Btn_File.TabIndex = 10
        Me.Btn_File.Text = "ファイル選択"
        Me.Btn_File.UseVisualStyleBackColor = True
        '
        'lbl_File
        '
        Me.lbl_File.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_File.Location = New System.Drawing.Point(8, 16)
        Me.lbl_File.Name = "lbl_File"
        Me.lbl_File.Size = New System.Drawing.Size(320, 16)
        Me.lbl_File.TabIndex = 2
        Me.lbl_File.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Rdo_RGB_R
        '
        Me.Rdo_RGB_R.AutoSize = True
        Me.Rdo_RGB_R.Location = New System.Drawing.Point(88, 16)
        Me.Rdo_RGB_R.Name = "Rdo_RGB_R"
        Me.Rdo_RGB_R.Size = New System.Drawing.Size(63, 16)
        Me.Rdo_RGB_R.TabIndex = 1
        Me.Rdo_RGB_R.Text = "R(RGB)"
        Me.Rdo_RGB_R.UseVisualStyleBackColor = True
        '
        'Rdo_RGB_G
        '
        Me.Rdo_RGB_G.AutoSize = True
        Me.Rdo_RGB_G.Location = New System.Drawing.Point(88, 32)
        Me.Rdo_RGB_G.Name = "Rdo_RGB_G"
        Me.Rdo_RGB_G.Size = New System.Drawing.Size(63, 16)
        Me.Rdo_RGB_G.TabIndex = 2
        Me.Rdo_RGB_G.TabStop = True
        Me.Rdo_RGB_G.Text = "G(RGB)"
        Me.Rdo_RGB_G.UseVisualStyleBackColor = True
        '
        'Rdo_RGB_B
        '
        Me.Rdo_RGB_B.AutoSize = True
        Me.Rdo_RGB_B.Location = New System.Drawing.Point(88, 48)
        Me.Rdo_RGB_B.Name = "Rdo_RGB_B"
        Me.Rdo_RGB_B.Size = New System.Drawing.Size(63, 16)
        Me.Rdo_RGB_B.TabIndex = 3
        Me.Rdo_RGB_B.TabStop = True
        Me.Rdo_RGB_B.Text = "B(RGB)"
        Me.Rdo_RGB_B.UseVisualStyleBackColor = True
        '
        'Rdo_HSV_H
        '
        Me.Rdo_HSV_H.AutoSize = True
        Me.Rdo_HSV_H.Location = New System.Drawing.Point(176, 16)
        Me.Rdo_HSV_H.Name = "Rdo_HSV_H"
        Me.Rdo_HSV_H.Size = New System.Drawing.Size(62, 16)
        Me.Rdo_HSV_H.TabIndex = 4
        Me.Rdo_HSV_H.TabStop = True
        Me.Rdo_HSV_H.Text = "H(HSV)"
        Me.Rdo_HSV_H.UseVisualStyleBackColor = True
        '
        'Rdo_HSV_S
        '
        Me.Rdo_HSV_S.AutoSize = True
        Me.Rdo_HSV_S.Location = New System.Drawing.Point(176, 32)
        Me.Rdo_HSV_S.Name = "Rdo_HSV_S"
        Me.Rdo_HSV_S.Size = New System.Drawing.Size(61, 16)
        Me.Rdo_HSV_S.TabIndex = 5
        Me.Rdo_HSV_S.TabStop = True
        Me.Rdo_HSV_S.Text = "S(HSV)"
        Me.Rdo_HSV_S.UseVisualStyleBackColor = True
        '
        'Rdo_HSV_V
        '
        Me.Rdo_HSV_V.AutoSize = True
        Me.Rdo_HSV_V.Location = New System.Drawing.Point(176, 48)
        Me.Rdo_HSV_V.Name = "Rdo_HSV_V"
        Me.Rdo_HSV_V.Size = New System.Drawing.Size(62, 16)
        Me.Rdo_HSV_V.TabIndex = 6
        Me.Rdo_HSV_V.TabStop = True
        Me.Rdo_HSV_V.Text = "V(HSV)"
        Me.Rdo_HSV_V.UseVisualStyleBackColor = True
        '
        'Rdo_HLS_H
        '
        Me.Rdo_HLS_H.AutoSize = True
        Me.Rdo_HLS_H.Location = New System.Drawing.Point(264, 16)
        Me.Rdo_HLS_H.Name = "Rdo_HLS_H"
        Me.Rdo_HLS_H.Size = New System.Drawing.Size(60, 16)
        Me.Rdo_HLS_H.TabIndex = 7
        Me.Rdo_HLS_H.TabStop = True
        Me.Rdo_HLS_H.Text = "H(HLS)"
        Me.Rdo_HLS_H.UseVisualStyleBackColor = True
        '
        'Rdo_HLS_L
        '
        Me.Rdo_HLS_L.AutoSize = True
        Me.Rdo_HLS_L.Location = New System.Drawing.Point(264, 32)
        Me.Rdo_HLS_L.Name = "Rdo_HLS_L"
        Me.Rdo_HLS_L.Size = New System.Drawing.Size(58, 16)
        Me.Rdo_HLS_L.TabIndex = 8
        Me.Rdo_HLS_L.TabStop = True
        Me.Rdo_HLS_L.Text = "L(HLS)"
        Me.Rdo_HLS_L.UseVisualStyleBackColor = True
        '
        'Rdo_HLS_S
        '
        Me.Rdo_HLS_S.AutoSize = True
        Me.Rdo_HLS_S.Location = New System.Drawing.Point(264, 48)
        Me.Rdo_HLS_S.Name = "Rdo_HLS_S"
        Me.Rdo_HLS_S.Size = New System.Drawing.Size(59, 16)
        Me.Rdo_HLS_S.TabIndex = 9
        Me.Rdo_HLS_S.TabStop = True
        Me.Rdo_HLS_S.Text = "S(HLS)"
        Me.Rdo_HLS_S.UseVisualStyleBackColor = True
        '
        'Grp_View
        '
        Me.Grp_View.Controls.Add(Me.Rdo_HLS_S)
        Me.Grp_View.Controls.Add(Me.Rdo_RGB_B)
        Me.Grp_View.Controls.Add(Me.Rdo_SRC)
        Me.Grp_View.Controls.Add(Me.Rdo_RGB_R)
        Me.Grp_View.Controls.Add(Me.Rdo_RGB_G)
        Me.Grp_View.Controls.Add(Me.Rdo_HSV_H)
        Me.Grp_View.Controls.Add(Me.Rdo_HSV_V)
        Me.Grp_View.Controls.Add(Me.Rdo_HLS_H)
        Me.Grp_View.Controls.Add(Me.Rdo_HSV_S)
        Me.Grp_View.Controls.Add(Me.Rdo_HLS_L)
        Me.Grp_View.Location = New System.Drawing.Point(8, 88)
        Me.Grp_View.Name = "Grp_View"
        Me.Grp_View.Size = New System.Drawing.Size(336, 72)
        Me.Grp_View.TabIndex = 6
        Me.Grp_View.TabStop = False
        Me.Grp_View.Text = "表示"
        '
        'Rdo_SRC
        '
        Me.Rdo_SRC.AutoSize = True
        Me.Rdo_SRC.Checked = True
        Me.Rdo_SRC.Location = New System.Drawing.Point(8, 16)
        Me.Rdo_SRC.Name = "Rdo_SRC"
        Me.Rdo_SRC.Size = New System.Drawing.Size(59, 16)
        Me.Rdo_SRC.TabIndex = 0
        Me.Rdo_SRC.TabStop = True
        Me.Rdo_SRC.Text = "元画像"
        Me.Rdo_SRC.UseVisualStyleBackColor = True
        '
        'Grp_File
        '
        Me.Grp_File.Controls.Add(Me.lbl_File)
        Me.Grp_File.Controls.Add(Me.Btn_File)
        Me.Grp_File.Location = New System.Drawing.Point(8, 8)
        Me.Grp_File.Name = "Grp_File"
        Me.Grp_File.Size = New System.Drawing.Size(336, 72)
        Me.Grp_File.TabIndex = 7
        Me.Grp_File.TabStop = False
        Me.Grp_File.Text = "画像ファイル"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(352, 168)
        Me.Controls.Add(Me.Grp_File)
        Me.Controls.Add(Me.Grp_View)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "ColorSpace"
        Me.Grp_View.ResumeLayout(False)
        Me.Grp_View.PerformLayout()
        Me.Grp_File.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Btn_File As System.Windows.Forms.Button
    Friend WithEvents lbl_File As System.Windows.Forms.Label
    Friend WithEvents Rdo_RGB_R As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_RGB_G As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_RGB_B As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_HSV_H As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_HSV_S As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_HSV_V As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_HLS_H As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_HLS_L As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_HLS_S As System.Windows.Forms.RadioButton
    Friend WithEvents Grp_View As System.Windows.Forms.GroupBox
    Friend WithEvents Grp_File As System.Windows.Forms.GroupBox
    Friend WithEvents Rdo_SRC As System.Windows.Forms.RadioButton

End Class
