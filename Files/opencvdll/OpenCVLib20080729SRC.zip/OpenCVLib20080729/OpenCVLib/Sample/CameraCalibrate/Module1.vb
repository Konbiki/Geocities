﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'OpenCVLibサンプル CameraCalibrate
'・カメラのキャリブレーションを行い、入力画像と補正画像を表示します。
'//////////////////////////////////////////////////////////////

Imports OpenCVLib
Imports System.Runtime.InteropServices

Module Module1


    Private Const SRCIMGWIN As String = "Source Image"  '入力画像ウィンドウ名
    Private Const CNVIMGWIN As String = "Convert Image" '補正画像ウィンドウ名

    Private Const CORNERCOUNTX As Integer = 10      'チェック画像の横交点数
    Private Const CORNERCOUNTY As Integer = 8       'チェック画像の縦交点数
    Private Const CORNERCOUNT As Integer = CORNERCOUNTX * CORNERCOUNTY  '総交点数
    Private Const CORNERUNIT As Integer = 10        'チェックの単位(大きさ)
    Private mCornerSize As CvSize = New CvSize(CORNERCOUNTX, CORNERCOUNTY)  '交点個数

    Private Const CAPTURECOUNT As Integer = 3       'キャリブレーション時の撮影回数


    'メイン
    Sub Main()

        'カメラキャプチャの作成
        Dim cap As IntPtr = cvCreateCameraCapture(0)

        'キャリブレーション
        Dim intmatrixptr As IntPtr = cvCreateMat(3, 3, CV_64FC1) '内部パラメータ
        Dim dismatrixptr As IntPtr = cvCreateMat(4, 1, CV_64FC1) 'レンズ歪み
        If Calibration(cap, intmatrixptr, dismatrixptr) = True Then
            'キャリブレーション成功

            '補正表示
            ConvertView(cap, intmatrixptr, dismatrixptr)

        End If

        '破棄
        cvReleaseCapture(cap)

    End Sub


    '----------------------------------------------------------

    'キャリブレーション
    Private Function Calibration(ByVal Cap As IntPtr, ByVal IntMatPtr As IntPtr, ByVal DisMatPtr As IntPtr) As Boolean

        Dim ret As Boolean = False

        '開始
        Console.WriteLine("キャリブレーションを開始します。")
        Console.WriteLine("・チェック画像全てが収まるようにカメラを調整し、")
        Console.WriteLine("　スペースキーで撮影してください。")
        Console.WriteLine("・キャリブレーションでは、{0}枚撮影します。", CAPTURECOUNT)

        '行列/ベクトルの準備
        Dim wmatptr As IntPtr = cvCreateMat(CORNERCOUNT * CAPTURECOUNT, 3, CV_64FC1) 'ワールド座標セット
        Dim imatptr As IntPtr = cvCreateMat(CORNERCOUNT * CAPTURECOUNT, 2, CV_64FC1) '画像座標セット
        Dim cmatptr As IntPtr = cvCreateMat(CAPTURECOUNT, 1, CV_32SC1)   '交点数セット
        Dim rvecptr As IntPtr = cvCreateMat(CAPTURECOUNT, 3, CV_64FC1)   '回転ベクトル
        Dim tvecptr As IntPtr = cvCreateMat(CAPTURECOUNT, 3, CV_64FC1)   '移動ベクトル

        'ワールド座標セット作成
        For y As Integer = 0 To CAPTURECOUNT - 1
            For x As Integer = 0 To CORNERCOUNT - 1
                cvSetReal2D(wmatptr, y * CORNERCOUNT + x, 0, (x Mod CORNERCOUNTX) * CORNERUNIT)
                cvSetReal2D(wmatptr, y * CORNERCOUNT + x, 1, (x \ CORNERCOUNTX) * CORNERUNIT)
                cvSetReal2D(wmatptr, y * CORNERCOUNT + x, 2, 0)
            Next
        Next

        '交点数セット作成
        For x As Integer = 0 To CAPTURECOUNT - 1
            cvSetReal2D(cmatptr, x, 0, CORNERCOUNT)
        Next

        '交点検索の準備
        Dim corners(CORNERCOUNT - 1) As CvPoint2D32f
        Dim cornerscnt As Integer = 0 '検索された交点数
        Dim findflg As Integer = 0  '全ての交点が検索されたかどうか

        'キャリブレーションループ
        Dim capcnt As Integer = 0 'キャプチャ数
        Dim img As New IplImageWrapper
        img.Window.Create("Calibration")
        Do

            'イメージ取得
            img.Ptr = cvQueryFrame(Cap)

            '交点(コーナー)検索
            findflg = cvFindChessboardCorners(img.Ptr, mCornerSize, corners, cornerscnt, CV_CALIB_CB_ADAPTIVE_THRESH)

            '交点の描画
            cvDrawChessboardCorners(img.Ptr, mCornerSize, corners, cornerscnt, findflg)

            'キー入力チェック
            Select Case cvWaitKey(1)
                Case 27 'Esc
                    Console.WriteLine("キャリブレーションを中止します。")
                    Exit Do '終了

                Case 32 'Space

                    '全ての交点が検索できたか？
                    If findflg = 0 Then
                        '全ての交点を検索できなかった
                        Console.WriteLine("全ての交点を認識できません。")
                    Else
                        '全ての交点を検索した
                        Console.WriteLine("{0}枚目の画像を取得しました。", capcnt + 1)

                        '座標を退避
                        For x As Integer = 0 To CORNERCOUNT - 1
                            cvSetReal2D(imatptr, capcnt * CORNERCOUNT + x, 0, corners(x).x)
                            cvSetReal2D(imatptr, capcnt * CORNERCOUNT + x, 1, corners(x).y)
                        Next

                        '終了チェック
                        capcnt += 1
                        If capcnt >= CAPTURECOUNT Then
                            '指定回数完了

                            'カメラパラーメタの推定
                            cvCalibrateCamera2(wmatptr, imatptr, cmatptr, cvGetSize(img.Ptr), IntMatPtr, DisMatPtr, rvecptr, tvecptr, 0)

                            'キャリブレーション完了
                            Console.WriteLine("キャリブレーションが終了しました。")
                            ret = True
                            Exit Do
                        End If

                    End If

            End Select

            '表示
            img.Show()

        Loop

        '後片付け
        cvReleaseMat(wmatptr)
        cvReleaseMat(imatptr)
        cvReleaseMat(cmatptr)
        cvReleaseMat(rvecptr)
        cvReleaseMat(tvecptr)
        img.Window.Close()

        Return ret
    End Function

    '----------------------------------------------------------

    '表示
    Private Sub ConvertView(ByVal Cap As IntPtr, ByVal IntMatPtr As IntPtr, ByVal DisMatPtr As IntPtr)


        Dim srcimg As New IplImageWrapper
        srcimg.Window.Create("Source")
        Dim dstimg As IplImageWrapper = Nothing
        Do

            'イメージ取得
            srcimg.Ptr = cvQueryFrame(Cap)

            '変換用イメージ準備
            If dstimg Is Nothing Then
                dstimg = New IplImageWrapper(srcimg)
                dstimg.Window.Create("Undistor")
            End If

            '補正画像作成
            cvUndistort2(srcimg.Ptr, dstimg.Ptr, IntMatPtr, DisMatPtr)

            '画像表示
            srcimg.Show()
            dstimg.Show()

            'キー入力チェック
            Select Case cvWaitKey(1)
                Case 27 'Esc
                    Exit Do

            End Select

        Loop

        '後片付け
        srcimg.Window.Close()
        If dstimg IsNot Nothing Then
            dstimg.Window.Close()
            dstimg.Release()
            dstimg = Nothing
        End If

    End Sub

End Module
