Option Explicit On
Option Strict On


'//////////////////////////////////////////////////////////////
Public Module OpenCVInformation

    'OpenCV DLL�t�@�C���̒�` (Ver1.00�p)
    Public Const Cv As String = "cv100.dll"
    Public Const CxCore As String = "cxcore100.dll"
    Public Const HighGUI As String = "highgui100.dll"

End Module



