﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.MenuStrip_Main = New System.Windows.Forms.MenuStrip
        Me.MenuItem_DeviceMenu = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuItem_SelectCamera = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuItem_DeviceMenuBar = New System.Windows.Forms.ToolStripSeparator
        Me.MenuItem_End = New System.Windows.Forms.ToolStripMenuItem
        Me.Pic_Src = New System.Windows.Forms.PictureBox
        Me.Pic_Dst = New System.Windows.Forms.PictureBox
        Me.Timer_Snap = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip_Main.SuspendLayout()
        CType(Me.Pic_Src, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_Dst, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip_Main
        '
        Me.MenuStrip_Main.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuItem_DeviceMenu})
        Me.MenuStrip_Main.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip_Main.Name = "MenuStrip_Main"
        Me.MenuStrip_Main.Size = New System.Drawing.Size(292, 24)
        Me.MenuStrip_Main.TabIndex = 0
        Me.MenuStrip_Main.Text = "MenuStrip1"
        '
        'MenuItem_DeviceMenu
        '
        Me.MenuItem_DeviceMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuItem_SelectCamera, Me.MenuItem_DeviceMenuBar, Me.MenuItem_End})
        Me.MenuItem_DeviceMenu.Name = "MenuItem_DeviceMenu"
        Me.MenuItem_DeviceMenu.Size = New System.Drawing.Size(71, 20)
        Me.MenuItem_DeviceMenu.Text = "デバイス(&D)"
        '
        'MenuItem_SelectCamera
        '
        Me.MenuItem_SelectCamera.Name = "MenuItem_SelectCamera"
        Me.MenuItem_SelectCamera.Size = New System.Drawing.Size(154, 22)
        Me.MenuItem_SelectCamera.Text = "カメラの選択(&C)"
        '
        'MenuItem_DeviceMenuBar
        '
        Me.MenuItem_DeviceMenuBar.Name = "MenuItem_DeviceMenuBar"
        Me.MenuItem_DeviceMenuBar.Size = New System.Drawing.Size(151, 6)
        '
        'MenuItem_End
        '
        Me.MenuItem_End.Name = "MenuItem_End"
        Me.MenuItem_End.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F4), System.Windows.Forms.Keys)
        Me.MenuItem_End.Size = New System.Drawing.Size(154, 22)
        Me.MenuItem_End.Text = "終了(&X)"
        '
        'Pic_Src
        '
        Me.Pic_Src.Location = New System.Drawing.Point(0, 24)
        Me.Pic_Src.Name = "Pic_Src"
        Me.Pic_Src.Size = New System.Drawing.Size(120, 104)
        Me.Pic_Src.TabIndex = 1
        Me.Pic_Src.TabStop = False
        '
        'Pic_Dst
        '
        Me.Pic_Dst.Location = New System.Drawing.Point(128, 24)
        Me.Pic_Dst.Name = "Pic_Dst"
        Me.Pic_Dst.Size = New System.Drawing.Size(120, 104)
        Me.Pic_Dst.TabIndex = 2
        Me.Pic_Dst.TabStop = False
        '
        'Timer_Snap
        '
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 131)
        Me.Controls.Add(Me.Pic_Dst)
        Me.Controls.Add(Me.Pic_Src)
        Me.Controls.Add(Me.MenuStrip_Main)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MainMenuStrip = Me.MenuStrip_Main
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "Camera2"
        Me.MenuStrip_Main.ResumeLayout(False)
        Me.MenuStrip_Main.PerformLayout()
        CType(Me.Pic_Src, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_Dst, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip_Main As System.Windows.Forms.MenuStrip
    Friend WithEvents MenuItem_DeviceMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuItem_SelectCamera As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuItem_DeviceMenuBar As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuItem_End As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Pic_Src As System.Windows.Forms.PictureBox
    Friend WithEvents Pic_Dst As System.Windows.Forms.PictureBox
    Friend WithEvents Timer_Snap As System.Windows.Forms.Timer

End Class
