Option Explicit On
Option Strict On

Imports System.Runtime.InteropServices

Public Module CvTypes
	'/*M///////////////////////////////////////////////////////////////////////////////////////
	'//
	'//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
	'//
	'//  By downloading, copying, installing or using the software you agree to this license.
	'//  If you do not agree to this license, do not download, install,
	'//  copy or use the software.
	'//
	'//
	'//                        Intel License Agreement
	'//                For Open Source Computer Vision Library
	'//
	'// Copyright (C) 2000, Intel Corporation, all rights reserved.
	'// Third party copyrights are property of their respective owners.
	'//
	'// Redistribution and use in source and binary forms, with or without modification,
	'// are permitted provided that the following conditions are met:
	'//
	'//   * Redistribution's of source code must retain the above copyright notice,
	'//     this list of conditions and the following disclaimer.
	'//
	'//   * Redistribution's in binary form must reproduce the above copyright notice,
	'//     this list of conditions and the following disclaimer in the documentation
	'//     and/or other materials provided with the distribution.
	'//
	'//   * The name of Intel Corporation may not be used to endorse or promote products
	'//     derived from this software without specific prior written permission.
	'//
	'// This software is provided by the copyright holders and contributors "as is" and
	'// any express or implied warranties, including, but not limited to, the implied
	'// warranties of merchantability and fitness for a particular purpose are disclaimed.
	'// In no event shall the Intel Corporation or contributors be liable for any direct,
	'// indirect, incidental, special, exemplary, or consequential damages
	'// (including, but not limited to, procurement of substitute goods or services;
	'// loss of use, data, or profits; or business interruption) however caused
	'// and on any theory of liability, whether in contract, strict liability,
	'// or tort (including negligence or otherwise) arising in any way out of
	'// the use of this software, even if advised of the possibility of such damage.
	'//
	'//M*/

	'/* spatial and central moments */
	'typedef struct CvMoments
	'{
	'    double  m00, m10, m01, m20, m11, m02, m30, m21, m12, m03; /* spatial moments */
	'    double  mu20, mu11, mu02, mu30, mu21, mu12, mu03; /* central moments */
	'    double  inv_sqrt_m00; /* m00 != 0 ? 1/sqrt(m00) : 0 */
	'}
	'CvMoments;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvMoments
        Public m00, m10, m01, m20, m11, m02, m30, m21, m12, m03 As Double
        Public mu20, mu11, mu02, mu30, mu21, mu12, mu03 As Double
        Public inv_sqrt_m00 As Double
    End Structure



	'/* Hu invariants */
	'typedef struct CvHuMoments
	'{
	'    double hu1, hu2, hu3, hu4, hu5, hu6, hu7; /* Hu invariants */
	'}
	'CvHuMoments;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvHuMoments
        Public hu1, hu2, hu3, hu4, hu5, hu6, hu7 As Double
    End Structure



	'/**************************** Connected Component  **************************************/

	'typedef struct CvConnectedComp
	'{
	'    double area;    /* area of the connected component  */
	'    CvScalar value; /* average color of the connected component */
	'    CvRect rect;    /* ROI of the component  */
	'    CvSeq* contour; /* optional component boundary
	'                      (the contour might have child contours corresponding to the holes)*/
	'}
	'CvConnectedComp;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvConnectedComp
        Public area As Double
        Public value As CvScalar
        Public rect As CvRect
        Public contour As IntPtr
    End Structure



	'/*
	'Internal structure that is used for sequental retrieving contours from the image.
	'It supports both hierarchical and plane variants of Suzuki algorithm.
	'*/
	'typedef struct _CvContourScanner* CvContourScanner;
	'ToDo : Typedef

	'/* contour retrieval mode */
	'#define CV_RETR_EXTERNAL 0
	public const  CV_RETR_EXTERNAL as integer =  0
	'#define CV_RETR_LIST     1
	public const  CV_RETR_LIST as integer =  1
	'#define CV_RETR_CCOMP    2
	public const  CV_RETR_CCOMP as integer =  2
	'#define CV_RETR_TREE     3
	public const  CV_RETR_TREE as integer =  3

	'/* contour approximation method */
	'#define CV_CHAIN_CODE               0
	public const  CV_CHAIN_CODE as integer =  0
	'#define CV_CHAIN_APPROX_NONE        1
	public const  CV_CHAIN_APPROX_NONE as integer =  1
	'#define CV_CHAIN_APPROX_SIMPLE      2
	public const  CV_CHAIN_APPROX_SIMPLE as integer =  2
	'#define CV_CHAIN_APPROX_TC89_L1     3
	public const  CV_CHAIN_APPROX_TC89_L1 as integer =  3
	'#define CV_CHAIN_APPROX_TC89_KCOS   4
	public const  CV_CHAIN_APPROX_TC89_KCOS as integer =  4
	'#define CV_LINK_RUNS                5
	public const  CV_LINK_RUNS as integer =  5

	'/* Freeman chain reader state */
	'typedef struct CvChainPtReader
	'{
	'    CV_SEQ_READER_FIELDS()
	'    char      code;
	'    CvPoint   pt;
	'    char      deltas[8][2];
	'}
	'CvChainPtReader;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvChainPtReader
#Region "CV_SEQ_READER_FIELDS"
        Public header_size As Integer
        Public seq As IntPtr
        Public block As IntPtr
        Public ptr As IntPtr
        Public block_min As IntPtr
        Public block_max As IntPtr
        Public delta_index As Integer
        Public prev_elem As IntPtr
#End Region
        Public code As Byte
        Public pt As CvPoint
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=8 * 2)> _
        Public deltas As Byte()
    End Structure



	'/* initializes 8-element array for fast access to 3x3 neighborhood of a pixel */
	'#define  CV_INIT_3X3_DELTAS( deltas, step, nch )            \
	'    ((deltas)[0] =  (nch),  (deltas)[1] = -(step) + (nch),  \
	'     (deltas)[2] = -(step), (deltas)[3] = -(step) - (nch),  \
	'     (deltas)[4] = -(nch),  (deltas)[5] =  (step) - (nch),  \
	'     (deltas)[6] =  (step), (deltas)[7] =  (step) + (nch))
	'ToDo : 

	'/* Contour tree header */
	'typedef struct CvContourTree
	'{
	'    CV_SEQUENCE_FIELDS()
	'    CvPoint p1;            /* the first point of the binary tree root segment */
	'    CvPoint p2;            /* the last point of the binary tree root segment */
	'}
	'CvContourTree;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvContourTree
#Region "CV_SEQUENCE_FIELDS"
#Region "CV_TREE_NODE_FIELDS_CvSeq"
        Public flags As Integer
        Public header_size As Integer
        Public h_prev As IntPtr
        Public h_next As IntPtr
        Public v_prev As IntPtr
        Public v_next As IntPtr
#End Region
        Public total As Integer
        Public elem_size As Integer
        Public block_max As IntPtr
        Public ptr As IntPtr
        Public delta_elems As Integer
        Public storage As IntPtr
        Public free_blocks As IntPtr
        Public first As IntPtr
#End Region
        Public p1 As CvPoint
        Public p2 As CvPoint
    End Structure



	'/* Finds a sequence of convexity defects of given contour */
	'typedef struct CvConvexityDefect
	'{
	'    CvPoint* start; /* point of the contour where the defect begins */
	'    CvPoint* end; /* point of the contour where the defect ends */
	'    CvPoint* depth_point; /* the farthest from the convex hull point within the defect */
	'    float depth; /* distance between the farthest point and the convex hull */
	'}
	'CvConvexityDefect;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvConvexityDefect
        Public start As IntPtr
        Public [end] As IntPtr
        Public depth_point As IntPtr
        Public depth As Single
    End Structure



	'/************ Data structures and related enumerations for Planar Subdivisions ************/

	'typedef size_t CvSubdiv2DEdge;
	'ToDo : Typedef

	'#define CV_QUADEDGE2D_FIELDS()     \
	'    int flags;                     \
	'    struct CvSubdiv2DPoint* pt[4]; \
	'    CvSubdiv2DEdge  next[4];
	'ToDo : 

	'#define CV_SUBDIV2D_POINT_FIELDS()\
	'    int            flags;      \
	'    CvSubdiv2DEdge first;      \
	'    CvPoint2D32f   pt;
	'ToDo : 

	'#define CV_SUBDIV2D_VIRTUAL_POINT_FLAG (1 << 30)
	public const  CV_SUBDIV2D_VIRTUAL_POINT_FLAG as integer =  (1 << 30)

	'typedef struct CvQuadEdge2D
	'{
	'    CV_QUADEDGE2D_FIELDS()
	'}
	'CvQuadEdge2D;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvQuadEdge2D
#Region "CV_QUADEDGE2D_FIELDS"
        Public flags As Integer
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=4)> _
        Public pt As IntPtr()
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=4)> _
        Public [next] As Integer()
#End Region
    End Structure



	'typedef struct CvSubdiv2DPoint
	'{
	'    CV_SUBDIV2D_POINT_FIELDS()
	'}
	'CvSubdiv2DPoint;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSubdiv2DPoint
#Region "CV_SUBDIV2D_POINT_FIELDS"
        Public flags As Integer
        Public first As Integer
        Public pt As CvPoint2D32f
#End Region
    End Structure



	'#define CV_SUBDIV2D_FIELDS()    \
	'    CV_GRAPH_FIELDS()           \
	'    int  quad_edges;            \
	'    int  is_geometry_valid;     \
	'    CvSubdiv2DEdge recent_edge; \
	'    CvPoint2D32f  topleft;      \
	'    CvPoint2D32f  bottomright;
	'ToDo : 

	'typedef struct CvSubdiv2D
	'{
	'    CV_SUBDIV2D_FIELDS()
	'}
	'CvSubdiv2D;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvSubdiv2D
#Region "CV_SUBDIV2D_FIELDS"
#Region "CV_GRAPH_FIELDS"
#Region "CV_SET_FIELDS"
#Region "CV_SEQUENCE_FIELDS"
#Region "CV_TREE_NODE_FIELDS_CvSeq"
        Public flags As Integer
        Public header_size As Integer
        Public h_prev As IntPtr
        Public h_next As IntPtr
        Public v_prev As IntPtr
        Public v_next As IntPtr
#End Region
        Public total As Integer
        Public elem_size As Integer
        Public block_max As IntPtr
        Public ptr As IntPtr
        Public delta_elems As Integer
        Public storage As IntPtr
        Public free_blocks As IntPtr
        Public first As IntPtr
#End Region
        Public free_elems As IntPtr
        Public active_count As Integer
#End Region
        Public edges As IntPtr
#End Region
        Public quad_edges As Integer
        Public is_geometry_valid As Integer
        Public recent_edge As Integer
        Public topleft As CvPoint2D32f
        Public bottomright As CvPoint2D32f
#End Region
    End Structure




	'typedef enum CvSubdiv2DPointLocation
	'{
	'    CV_PTLOC_ERROR = -2,
	'    CV_PTLOC_OUTSIDE_RECT = -1,
	'    CV_PTLOC_INSIDE = 0,
	'    CV_PTLOC_VERTEX = 1,
	'    CV_PTLOC_ON_EDGE = 2
	'}
	'CvSubdiv2DPointLocation;
    Public Enum CvSubdiv2DPointLocation
        CV_PTLOC_ERROR = -2
        CV_PTLOC_OUTSIDE_RECT = -1
        CV_PTLOC_INSIDE = 0
        CV_PTLOC_VERTEX = 1
        CV_PTLOC_ON_EDGE = 2
    End Enum



	'typedef enum CvNextEdgeType
	'{
	'    CV_NEXT_AROUND_ORG   = 0x00,
	'    CV_NEXT_AROUND_DST   = 0x22,
	'    CV_PREV_AROUND_ORG   = 0x11,
	'    CV_PREV_AROUND_DST   = 0x33,
	'    CV_NEXT_AROUND_LEFT  = 0x13,
	'    CV_NEXT_AROUND_RIGHT = 0x31,
	'    CV_PREV_AROUND_LEFT  = 0x20,
	'    CV_PREV_AROUND_RIGHT = 0x02
	'}
	'CvNextEdgeType;
    Public Enum CvNextEdgeType
        CV_NEXT_AROUND_ORG = &H0
        CV_NEXT_AROUND_DST = &H22
        CV_PREV_AROUND_ORG = &H11
        CV_PREV_AROUND_DST = &H33
        CV_NEXT_AROUND_LEFT = &H13
        CV_NEXT_AROUND_RIGHT = &H31
        CV_PREV_AROUND_LEFT = &H20
        CV_PREV_AROUND_RIGHT = &H2
    End Enum



	'/* get the next edge with the same origin point (counterwise) */
	'#define  CV_SUBDIV2D_NEXT_EDGE( edge )  (((CvQuadEdge2D*)((edge) & ~3))->next[(edge)&3])
    Public Function CV_SUBDIV2D_NEXT_EDGE(ByVal edge As Integer) As Integer
        Dim ptr As IntPtr = CType(edge And &HFFFFFFFC, IntPtr)
        Dim tmp As CvQuadEdge2D = CType(Marshal.PtrToStructure(ptr, GetType(CvQuadEdge2D)), CvQuadEdge2D)
        Return tmp.next(edge And 3)
    End Function




	'/* Defines for Distance Transform */
	'#define CV_DIST_USER    -1  /* User defined distance */
	public const  CV_DIST_USER as integer =  -1
	'#define CV_DIST_L1      1   /* distance = |x1-x2| + |y1-y2| */
	public const  CV_DIST_L1 as integer =  1
	'#define CV_DIST_L2      2   /* the simple euclidean distance */
	public const  CV_DIST_L2 as integer =  2
	'#define CV_DIST_C       3   /* distance = max(|x1-x2|,|y1-y2|) */
	public const  CV_DIST_C as integer =  3
	'#define CV_DIST_L12     4   /* L1-L2 metric: distance = 2(sqrt(1+x*x/2) - 1)) */
	public const  CV_DIST_L12 as integer =  4
	'#define CV_DIST_FAIR    5   /* distance = c^2(|x|/c-log(1+|x|/c)), c = 1.3998 */
	public const  CV_DIST_FAIR as integer =  5
	'#define CV_DIST_WELSCH  6   /* distance = c^2/2(1-exp(-(x/c)^2)), c = 2.9846 */
	public const  CV_DIST_WELSCH as integer =  6
	'#define CV_DIST_HUBER   7   /* distance = |x|<c ? x^2/2 : c(|x|-c/2), c=1.345 */
	public const  CV_DIST_HUBER as integer =  7


	'/* Filters used in pyramid decomposition */
	'typedef enum CvFilter
	'{
	'    CV_GAUSSIAN_5x5 = 7
	'}
	'CvFilter;
    Public Enum CvFilter
        CV_GAUSSIAN_5x5 = 7
    End Enum



	'/****************************************************************************************/
	'/*                                    Older definitions                                 */
	'/****************************************************************************************/

	'typedef float*   CvVect32f;
	'ToDo : Typedef
	'typedef float*   CvMatr32f;
	'ToDo : Typedef
	'typedef double*  CvVect64d;
	'ToDo : Typedef
	'typedef double*  CvMatr64d;
	'ToDo : Typedef

	'typedef struct CvMatrix3
	'{
	'    float m[3][3];
	'}
	'CvMatrix3;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvMatrix3
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=3 * 3)> _
        Public m As Single()
    End Structure




	'typedef float (CV_CDECL * CvDistanceFunction)( const float* a, const float* b, void* user_param );
	'ToDo : Typedef

	'typedef struct CvConDensation
	'{
	'    int MP;
	'    int DP;
	'    float* DynamMatr;       /* Matrix of the linear Dynamics system  */
	'    float* State;           /* Vector of State                       */
	'    int SamplesNum;         /* Number of the Samples                 */
	'    float** flSamples;      /* arr of the Sample Vectors             */
	'    float** flNewSamples;   /* temporary array of the Sample Vectors */
	'    float* flConfidence;    /* Confidence for each Sample            */
	'    float* flCumulative;    /* Cumulative confidence                 */
	'    float* Temp;            /* Temporary vector                      */
	'    float* RandomSample;    /* RandomVector to update sample set     */
	'    struct CvRandState* RandS; /* Array of structures to generate random vectors */
	'}
	'CvConDensation;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvConDensation
        Public MP As Integer
        Public DP As Integer
        Public DynamMatr As IntPtr
        Public State As IntPtr
        Public SamplesNum As Integer
        Public flSamples As IntPtr
        Public flNewSamples As IntPtr
        Public flConfidence As IntPtr
        Public flCumulative As IntPtr
        Public Temp As IntPtr
        Public RandomSample As IntPtr
        Public RandS As IntPtr
    End Structure



	'/*
	'standard Kalman filter (in G. Welch' and G. Bishop's notation):

	'  x(k)=A*x(k-1)+B*u(k)+w(k)  p(w)~N(0,Q)
	'  z(k)=H*x(k)+v(k),   p(v)~N(0,R)
	'*/
	'typedef struct CvKalman
	'{
	'    int MP;                     /* number of measurement vector dimensions */
	'    int DP;                     /* number of state vector dimensions */
	'    int CP;                     /* number of control vector dimensions */

	'    /* backward compatibility fields */
	'    float* PosterState;         /* =state_pre->data.fl */
	'    float* PriorState;          /* =state_post->data.fl */
	'    float* DynamMatr;           /* =transition_matrix->data.fl */
	'    float* MeasurementMatr;     /* =measurement_matrix->data.fl */
	'    float* MNCovariance;        /* =measurement_noise_cov->data.fl */
	'    float* PNCovariance;        /* =process_noise_cov->data.fl */
	'    float* KalmGainMatr;        /* =gain->data.fl */
	'    float* PriorErrorCovariance;/* =error_cov_pre->data.fl */
	'    float* PosterErrorCovariance;/* =error_cov_post->data.fl */
	'    float* Temp1;               /* temp1->data.fl */
	'    float* Temp2;               /* temp2->data.fl */

	'    CvMat* state_pre;           /* predicted state (x'(k)):
	'                                    x(k)=A*x(k-1)+B*u(k) */
	'    CvMat* state_post;          /* corrected state (x(k)):
	'                                    x(k)=x'(k)+K(k)*(z(k)-H*x'(k)) */
	'    CvMat* transition_matrix;   /* state transition matrix (A) */
	'    CvMat* control_matrix;      /* control matrix (B)
	'                                   (it is not used if there is no control)*/
	'    CvMat* measurement_matrix;  /* measurement matrix (H) */
	'    CvMat* process_noise_cov;   /* process noise covariance matrix (Q) */
	'    CvMat* measurement_noise_cov; /* measurement noise covariance matrix (R) */
	'    CvMat* error_cov_pre;       /* priori error estimate covariance matrix (P'(k)):
	'                                    P'(k)=A*P(k-1)*At + Q)*/
	'    CvMat* gain;                /* Kalman gain matrix (K(k)):
	'                                    K(k)=P'(k)*Ht*inv(H*P'(k)*Ht+R)*/
	'    CvMat* error_cov_post;      /* posteriori error estimate covariance matrix (P(k)):
	'                                    P(k)=(I-K(k)*H)*P'(k) */
	'    CvMat* temp1;               /* temporary matrices */
	'    CvMat* temp2;
	'    CvMat* temp3;
	'    CvMat* temp4;
	'    CvMat* temp5;
	'}
	'CvKalman;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvKalman
        Public MP As Integer
        Public DP As Integer
        Public CP As Integer

        Public PosterState As IntPtr
        Public PriorState As IntPtr
        Public DynamMatr As IntPtr
        Public MeasurementMatr As IntPtr
        Public MNCovariance As IntPtr
        Public PNCovariance As IntPtr
        Public KalmGainMatr As IntPtr
        Public PriorErrorCovariance As IntPtr
        Public PosterErrorCovariance As IntPtr
        Public Temp1F As IntPtr
        Public Temp2F As IntPtr
        Public state_pre As IntPtr
        Public state_post As IntPtr
        Public transition_matrix As IntPtr
        Public control_matrix As IntPtr
        Public measurement_matrix As IntPtr
        Public process_noise_cov As IntPtr
        Public measurement_noise_cov As IntPtr
        Public error_cov_pre As IntPtr
        Public gain As IntPtr
        Public error_cov_post As IntPtr
        Public temp1 As IntPtr
        Public temp2 As IntPtr
        Public temp3 As IntPtr
        Public temp4 As IntPtr
        Public temp5 As IntPtr
    End Structure




	'/*********************** Haar-like Object Detection structures **************************/
	'#define CV_HAAR_MAGIC_VAL    0x42500000
	public const  CV_HAAR_MAGIC_VAL as integer =  &H42500000
	'#define CV_TYPE_NAME_HAAR    "opencv-haar-classifier"
	public const  CV_TYPE_NAME_HAAR as string =  "opencv-haar-classifier"

	'#define CV_IS_HAAR_CLASSIFIER( haar )                                                    \
	'    ((haar) != NULL &&                                                                   \
	'    (((const CvHaarClassifierCascade*)(haar))->flags & CV_MAGIC_MASK)==CV_HAAR_MAGIC_VAL)
	'ToDo : 

	'#define CV_HAAR_FEATURE_MAX  3
	public const  CV_HAAR_FEATURE_MAX as integer =  3

	'typedef struct CvHaarFeature
	'{
	'    int  tilted;
	'    struct
	'    {
	'        CvRect r;
	'        float weight;
	'    } rect[CV_HAAR_FEATURE_MAX];
	'}
	'CvHaarFeature;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvHaarFeature
        Public tilted As Integer
        <MarshalAs(UnmanagedType.ByValArray, sizeconst:=CV_HAAR_FEATURE_MAX)> _
        Public rect As CvHaarFeature_rect()
    End Structure
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvHaarFeature_rect
        Public r As CvRect
        Public weight As Single
    End Structure



	'typedef struct CvHaarClassifier
	'{
	'    int count;
	'    CvHaarFeature* haar_feature;
	'    float* threshold;
	'    int* left;
	'    int* right;
	'    float* alpha;
	'}
	'CvHaarClassifier;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvHaarClassifier
        Public count As Integer
        Public haar_feature As IntPtr
        Public threshold As IntPtr
        Public left As IntPtr
        Public right As IntPtr
        Public alpha As IntPtr
    End Structure



	'typedef struct CvHaarStageClassifier
	'{
	'    int  count;
	'    float threshold;
	'    CvHaarClassifier* classifier;

	'    int next;
	'    int child;
	'    int parent;
	'}
	'CvHaarStageClassifier;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvHaarStageClassifier
        Public count As Integer
        Public threshold As Single
        Public classifier As IntPtr
        Public [next] As Integer
        Public child As Integer
        Public parent As Integer
    End Structure



	'typedef struct CvHidHaarClassifierCascade CvHidHaarClassifierCascade;
	'ToDo : Typedef

	'typedef struct CvHaarClassifierCascade
	'{
	'    int  flags;
	'    int  count;
	'    CvSize orig_window_size;
	'    CvSize real_window_size;
	'    double scale;
	'    CvHaarStageClassifier* stage_classifier;
	'    CvHidHaarClassifierCascade* hid_cascade;
	'}
	'CvHaarClassifierCascade;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvHaarClassifierCascade
        Public flags As Integer
        Public count As Integer
        Public orig_window_size As CxTypes.CvSize
        Public real_window_size As CxTypes.CvSize
        Public scale As Double
        Public stage_classifier As IntPtr
        Public hid_cascade As IntPtr
    End Structure



	'typedef struct CvAvgComp
	'{
	'    CvRect rect;
	'    int neighbors;
	'}
	'CvAvgComp;
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi, Pack:=4)> _
    Public Structure CvAvgComp
        Public rect As CvRect
        Public neighbors As Integer
    End Structure




End Module
