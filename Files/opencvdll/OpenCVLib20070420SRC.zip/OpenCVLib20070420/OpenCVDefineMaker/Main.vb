Option Explicit On
Option Strict On

Imports System.IO
Imports System.IO.Path

Module App

    '//////////////////////////////////////////////////////////

    '//////////////////////////////////////////////////////////

    Private WithEvents mParser As CSourceParser
    Private mOut As StreamWriter
    Private mDLLName As String

    Private mDebug As StreamWriter

    '//////////////////////////////////////////////////////////
    '�J�n
    Sub Main()

        'Trace�ւ̏o�͂��R���\�[���ɂ��o�͂���
        Trace.Listeners.Add(New TextWriterTraceListener(System.Console.Out))

        '������
        InitializeConvertData()

        '�ϊ��J�n
        mDebug = New StreamWriter("d:\iran.txt")

        ConvertMain("Cv.h", "OpenCVInformation.Cv")
        ConvertMain("CvTypes.h", "")
        ConvertMain("CxCore.h", "OpenCVInformation.CxCore")
        ConvertMain("CxTypes.h", "")
        ConvertMain("HighGUI.h", "OpenCVInformation.HighGUI")

        mDebug.Close()

    End Sub

    Private Sub ConvertMain(ByVal SourceFile As String, ByVal DLLName As String)

        '���̌���
        Dim mdlname As String = GetFileNameWithoutExtension(SourceFile)

        '�o�̓X�g���[������
        mOut = New StreamWriter(mdlname + ".vb")

        '�Œ�o��
        DirectOut("Option Explicit On")
        DirectOut("Option Strict On")
        DirectOut("")
        DirectOut("Imports System.Runtime.InteropServices")
        DirectOut("")
        DirectOut("Public Module {0}", mdlname)

        '�p�[�T�[����
        mParser = New CSourceParser

        Dim asm As System.Reflection.Assembly = System.Reflection.Assembly.GetCallingAssembly()
        Dim resname As String = My.Application.Info.ProductName + "." + SourceFile.ToLower
        Dim stm As Stream = asm.GetManifestResourceStream(resname)
        Dim stmreader As New StreamReader(stm, System.Text.Encoding.GetEncoding("Shift_JIS"))

        '�ϊ��J�n
        mDLLName = DLLName
        mParser.Start(stmreader)

        '�I��
        DirectOut("")
        DirectOut("End Module")
        mOut.Close()

        '���
        mOut = Nothing
        mParser = Nothing

    End Sub

    Private Sub ConvertLog(ByVal LogType As String, ByVal Value As String)

        'mDebug.WriteLine("{0}" + vbTab + "{1}", LogType, Value)

    End Sub

    '//////////////////////////////////////////////////////////

    '�s�Ǎ���
    Private Sub mParser_OnReadLine(ByVal Text As String) Handles mParser.OnReadLine

        If Text Is Nothing Then Exit Sub
        Dim tt As String = Text.Trim
        If tt.Length = 0 Then
            '��s�o��
            LineOut()
            Exit Sub
        End If

        '�R�����g�Ƃ��ďo��
        LineOut("'" + Text)

    End Sub

    '�g�[�N�����o����
    Private Sub mParser_OnPickupToken(ByVal TokenValueText As String, ByVal TokenType As CSourceParser.EnumTokenType) Handles mParser.OnPickupToken

    End Sub

    '�v���v���Z�b�T�擾��
    Private Sub mParser_OnPickupPreproccesor(ByVal TokenList As System.Collections.Generic.List(Of CSourceParser.Token)) Handles mParser.OnPickupPreproccesor

        'mOut.Write("' def  :  ")
        'For Each tkn As CSourceParser.Token In TokenList
        '    mOut.Write(tkn.ToString)
        'Next
        'mOut.WriteLine()

        '���O�`�F�b�N
        If TokenList.Count < 4 Then
            '���݂̂̂̒�`
            DebugOut("'Skip : ")
            Exit Sub
        End If
        If TokenList(1).ValueString.ToUpper <> "DEFINE" Then
            '�}�N����`�ȊO
            DebugOut("'Skip : ") 'It is a unsupport excluding 'define'.")
            Exit Sub
        End If
        TokenList.RemoveAt(0) '#
        TokenList.RemoveAt(0) 'define

        '�o�̓f�[�^�쐬�J�n
        Dim stype As String = "public const "   '��`���@
        Dim dname As String = ""    '���O
        Dim dtype As String = ""    '�^�C�v
        Dim dval As String = ""     '�l

        '���O
        dname = TokenList(0).ValueString
        TokenList.RemoveAt(0) '����

        '�ϊ��f�[�^���猟��
        If ConvertData.ContainsKey(dname) Then
            '�ϊ��f�[�^����
            DirectOut(ConvertData(dname))
            ConvertLog("Macro", dname)
            Exit Sub
        End If

        If dname.StartsWith("cv") Then
            '�֐��̃��l�[��
            DebugOut("'Skip : ") 'The definition of the alias of the function doesn't correspond.")
            Exit Sub
        End If
        If Not TokenList(0).HasSpace Then
            '�����t���}�N��
            DebugOut("'ToDo : ") 'The macro with the argument is a unsupport.")
            Exit Sub
        End If

        '�ϊ����O�}�N����`�`�F�b�N
        Select Case dname
            Case "CV_MAKE_TYPE", "CV_IS_CONT_MAT"
                DebugOut("'Skip : ")
                Exit Sub
        End Select

        '�^�`�F�b�N
        If TokenList(0).TokenType = CSourceParser.EnumTokenType.ConstString Then
            '������
            dtype = "as string"
        Else
            '����
            dtype = "as integer"
        End If

        '�l
        Dim toptkn As String = TokenList(0).ValueString
        Dim valconv As Boolean = False
        If toptkn = "CV_MAKETYPE" Then
            '����ϊ�:CV_MAKETYPE
            dval = String.Format("(({0}) + ((({1})-1) << CV_CN_SHIFT))", TokenList(2).ValueString, TokenList(4).ValueString)
        ElseIf toptkn = "cvSlice" Then
            '����ϊ�:cvSlice
            stype = "public readonly"
            dtype = "as " + toptkn
            dval += "new "
            valconv = True
        Else
            '��ʓI�Ȓl�̕ϊ�
            valconv = True
        End If

        If valconv Then
            Dim vv As String
            For Each tkn As CSourceParser.Token In TokenList

                vv = tkn.ValueString
                Select Case vv
                    Case "|", "||"
                        vv = " or "
                    Case "&", "&&"
                        vv = " and "
                    Case "."
                        dtype = "as double"
                    Case "sizeof"
                        dname = ""
                        Exit For
                    Case Else
                        If vv.StartsWith("0x") Then
                            vv = "&H" + vv.Remove(0, 2)
                        End If
                End Select

                If tkn.HasSpace Then dval += " "
                dval = dval + vv
            Next
        End If

        '�o��
        If dname = "" Then
            LineOut("'ToDo : unsupport")
        Else
            LineOut("{0} {1} {2} = {3}", stype, dname, dtype, dval)
        End If
        ConvertLog("Macro", dname)

    End Sub

    '�v���g�^�C�v�錾�擾��
    Private Sub mParser_OnPickupPrototypeDefine(ByVal TokenList As System.Collections.Generic.List(Of CSourceParser.Token)) Handles mParser.OnPickupPrototypeDefine

        'mOut.Write("' api  :  ")
        'For Each tkn As CSourceParser.Token In TokenList
        '    mOut.Write(tkn.ToString)
        'Next
        'mOut.WriteLine()

        '�f�[�^�쐬�J�n
        Dim ftype As String = ""    '�߂�l�^�C�v
        Dim fname As String = ""    '�֐���
        Dim cmt As String = ""      '�R�����g

        '�߂�l�^�C�v�擾
        TokenList.RemoveAt(0)   'CVAPI
        TokenList.RemoveAt(0)   '(
        Do
            Dim vv As String = TokenList(0).ValueString
            TokenList.RemoveAt(0)

            If vv = ")" Then
                '�I��
                Exit Do
            End If

            ftype += vv
        Loop
        ftype = ConvertFunctionType(ftype)

        '����
        fname = TokenList(0).ValueString
        TokenList.RemoveAt(0)   '����
        TokenList.RemoveAt(0)   '(
        Dim fnames As New List(Of String)
        fnames.Add(fname)

        '�ϊ��f�[�^���猟��
        If ConvertData.ContainsKey(fname) Then
            '�ϊ��f�[�^����

            Dim tt As String = ConvertData(fname).Trim
            If tt.StartsWith(":rename ") Then
                '���l�[��
                tt = tt.Substring(8)
                Dim ww() As String = tt.Split(","c)
                For Each wws As String In ww
                    fnames.Add(wws)
                Next
            Else
                DirectOut(ConvertData(fname))
                ConvertLog("Prototype", fname)
                Exit Sub
            End If
        End If

        '�������X�g�̕���
        Dim ptokenlist As New List(Of List(Of CSourceParser.Token))
        Do While TokenList(0).ValueString <> ")"
            Dim ttlist As New List(Of CSourceParser.Token)
            Dim lvl As Integer = 0
            Do
                Dim tt As String = TokenList(0).ValueString
                If (tt = ",") And (lvl = 0) Then Exit Do
                If (tt = ")") And (lvl = 0) Then Exit Do

                ttlist.Add(TokenList(0))
                TokenList.RemoveAt(0)

                If tt = "(" Then
                    lvl += 1
                End If
                If tt = ")" Then
                    lvl -= 1
                End If
            Loop
            ptokenlist.Add(ttlist)

            If TokenList(0).ValueString = "," Then
                TokenList.RemoveAt(0)
            End If
        Loop

        '�������X�g�̕ϊ�
        Dim plist As New List(Of String())    '�������X�g
        For Each pp As List(Of CSourceParser.Token) In ptokenlist

            '�s�v�ȃg�[�N���̍폜
            Dim idx As Integer = 0
            Do While idx < pp.Count
                If pp(idx).ValueString = "const" Then
                    pp.RemoveAt(idx)
                    Continue Do
                End If
                If pp(idx).ValueString = "CV_DEFAULT" Then
                    Dim lvl As Integer = 0
                    Do
                        Dim tt As String = pp(idx).ValueString
                        pp.RemoveAt(idx)

                        If tt = "(" Then
                            lvl += 1
                        ElseIf tt = ")" Then
                            lvl -= 1
                            If lvl = 0 Then Exit Do
                        End If
                    Loop
                    Continue Do
                End If
                If pp(idx).ValueString = "[" Then
                    Do
                        Dim tt As String = pp(idx).ValueString
                        pp.RemoveAt(idx)
                        If tt = "]" Then Exit Do
                    Loop
                    cmt = "Array"
                    Continue Do
                End If

                idx += 1
            Loop

            If pp.Count > 1 Then
                Dim pname As String = pp(pp.Count - 1).ValueString
                pp.RemoveAt(pp.Count - 1)
                Select Case pname
                    Case "step", "end", "dim"
                        pname = "[" + pname + "]"
                End Select

                Dim ptype As String = ""
                For Each pt As CSourceParser.Token In pp
                    ptype += pt.ValueString
                Next

                Dim ss As String = String.Format(ConvertParamType(ptype, fname, pname), pname)
                plist.Add(ss.Split("|"c))
            End If
        Next

        '�o��
        For fidx As Integer = 0 To fnames.Count - 1
            Dim plistidx(plist.Count - 1) As Integer
            Do
                If fidx = 0 Then
                    LineOut("<DllImport({0}, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi)> _", mDLLName)
                Else
                    LineOut("<DllImport({0}, CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Ansi, entrypoint:=""{1}"")> _", mDLLName, fname)
                End If
                If ftype = "" Then
                    Output(vbTab + "public sub ")
                Else
                    Output(vbTab + "public function ")
                End If
                Output(fnames(fidx))
                Output("(")
                Dim cm As String = ""
                Dim ss As String = ""
                For idx As Integer = 0 To plist.Count - 1
                    ss = plist(idx)(plistidx(idx))
                    Output(cm)
                    Output(ss)
                    cm = ","
                Next
                Output(")")
                If ftype <> "" Then
                    Output(" as {0}", ftype)
                    LineOut()
                    LineOut("end function")
                Else
                    LineOut()
                    LineOut("end sub")
                End If

                Dim ck As Integer = 1
                For idx As Integer = 0 To plist.Count - 1
                    plistidx(idx) += ck
                    If plistidx(idx) >= plist(idx).Length Then
                        plistidx(idx) = 0
                        ck = 1
                    Else
                        ck = 0
                    End If
                Next
                If ck <> 0 Then Exit Do
            Loop
        Next
        ConvertLog("Prototype", fname)

    End Sub

    '�^�C�v��`�擾��
    Private Sub mParser_OnPickupTypeDefine(ByVal TokenList As System.Collections.Generic.List(Of CSourceParser.Token)) Handles mParser.OnPickupTypeDefine

        'mOut.Write("' typ  :  ")
        'For Each tkn As CSourceParser.Token In TokenList
        '    mOut.Write(tkn.ToString)
        'Next
        'mOut.WriteLine()

        '�^�C�v���̎擾
        Dim tname As String = TokenList(TokenList.Count - 1).ValueString

        '�ϊ��f�[�^���猟��
        If ConvertData.ContainsKey(tname) Then
            '�ϊ��f�[�^����
            DirectOut(ConvertData(tname))
            ConvertLog("Type", tname)
            Exit Sub
        End If

        '�ϊ��s��
        DebugOut("'ToDo : Typedef")

    End Sub

    '�֐���`�擾��
    Private Sub mParser_OnPickupFunctionDefine(ByVal TokenList As System.Collections.Generic.List(Of CSourceParser.Token)) Handles mParser.OnPickupFunctionDefine

        'mOut.Write("' fun  :  ")
        'For Each tkn As CSourceParser.Token In TokenList
        '    mOut.Write(tkn.ToString)
        'Next
        'mOut.WriteLine()

        '�֐����̎擾
        Dim fname As String = "" '= TokenList(TokenList.Count - 1).ValueString
        For Each tkn As CSourceParser.Token In TokenList
            If tkn.ValueString = "(" Then Exit For
            fname = tkn.ValueString
        Next

        '�ϊ��f�[�^���猟��
        If ConvertData.ContainsKey(fname) Then
            '�ϊ��f�[�^����
            DirectOut(ConvertData(fname))
            ConvertLog("Function", fname)
            Exit Sub
        End If

        '�ϊ��s��
        DebugOut("'ToDo : Function")

    End Sub

    '���̑��̕��擾��
    Private Sub mParser_OnPickupState(ByVal TokenList As System.Collections.Generic.List(Of CSourceParser.Token)) Handles mParser.OnPickupState

        'mOut.Write("' ???  :  ")
        'For Each tkn As CSourceParser.Token In TokenList
        '    mOut.Write(tkn.ToString)
        'Next
        'mOut.WriteLine()

        DebugOut("'Skip : Unknown")
    End Sub

    '//////////////////////////////////////////////////////////

    '�֐��߂�l�^�ϊ�
    Private Function ConvertFunctionType(ByVal SrcType As String) As String

        Select Case SrcType
            '��ʌ^
            Case "void" : Return ""
            Case "int" : Return "integer"
            Case "double" : Return "double"
            Case "float" : Return "single"
            Case "int64" : Return "long"

            Case "CvContourScanner", "CvErrorCallback"
                '�|�C���^
                Return "IntPtr"

            Case "CvPoint", "CvRect", "CvBox2D", "CvScalar", "CvSize", _
                 "CvTermCriteria", "CvString"
                '�\����
                Return SrcType

            Case "CvSubdiv2DPointLocation"
                '�񋓌^
                Return SrcType

            Case Else
                If SrcType.EndsWith("**") Then
                    '�Ȃ�
                End If

                If SrcType.EndsWith("*") Then
                    '�|�C���^�^�͂��ׂ�IntPtr�Ƃ���
                    Return "IntPtr"
                End If

                '�ʑΉ����K�v
                Debug.Print(SrcType)
                Stop

        End Select

        Return ""
    End Function

    '�����^�ϊ�
    Private Function ConvertParamType(ByVal SrcType As String, ByVal FuncName As String, ByVal ParamName As String) As String

        Select Case SrcType
            '��ʌ^
            Case "int" : Return "byval {0} as integer"
            Case "float" : Return "byval {0} as single"
            Case "double" : Return "byval {0} as double"
            Case "size_t" : Return "byval {0} as integer"
            Case "void*" : Return "byval {0} as intptr"
            Case "int*" : Return "byval {0} as integer()|byref {0} as integer|byval {0} as intptr"
            Case "float*" : Return "byval {0} as single()|byref {0} as single|byval {0} as intptr"
            Case "unsigned*" : Return "byval {0} as ushort()|byref {0} as ushort|byval {0} as intptr"

            Case "CvTrackbarCallback", "CvMouseCallback", "CvDistanceFunction", _
                 "CvContourScanner", "CvCmpFunc", "CvErrorCallback", _
                 "CvAllocFunc", "CvFreeFunc", _
                 "Cv_iplCreateImageHeader", "Cv_iplAllocateImageData", "Cv_iplDeallocate", _
                 "Cv_iplCreateROI", "Cv_iplCloneImage"
                '�e��|�C���^
                Return "byval {0} as intptr"

            Case "void**"
                Return "byval {0} as intptr"

            Case "CvArr*"
                Return "byval {0} as intptr"

            Case "CvArr**"
                Select Case FuncName
                    Case "cvMixChannels", "cvInitNArrayIterator", "cvCalcCovarMatrix"
                        '�|�C���^�z��
                        Return "byval {0} as intptr()|byval {0} as intptr"

                    Case "cvCalcArrHist", "cvCalcArrBackProject", "cvCalcArrBackProjectPatch"
                        '�|�C���^
                        Return "byval {0} as intptr"

                End Select

            Case "uchar**"
                Select Case FuncName
                    Case "cvGetRawData"
                        '�|�C���^�̃|�C���^
                        Return "byref {0} as intptr"

                End Select

            Case "float**"
                Select Case FuncName
                    Case "cvSetHistBinRanges", "cvMakeHistHeaderForArray"
                        '�|�C���^�z��
                        Return "byval {0} as intptr()|byval {0} as intptr"

                    Case "cvCreateHist"
                        '�|�C���^
                        Return "byval {0} as intptr"

                    Case Else
                        Stop

                End Select

            Case "CvHistogram**"
                Return "byref {0} as CvHistogram|byval {0} as intptr"

            Case "CvPoint**"
                Return "Byval {0} As CxTypes.CvPoint()|byval {0} as intptr"

            Case "CvSeq**"
                Return "ByRef {0} As intptr"

            Case "CvMatr32f", "CvVect32f"
                Return "byval {0}() as single|byval {0} as intptr"

            Case "char*"
                Return "byval {0} as string|byval {0} as byte()|byval {0} as intptr"

            Case "char**"
                Return "byref {0} as string|byval {0} as intptr"

            Case "CvSeqBlock**", "CvSetElem**", "CvGraphVtx**", "CvGraphEdge**", "CvGraphEdge**"
                Return "byref {0} as " + SrcType.Substring(0, SrcType.Length - 2) + "|byval {0} as intptr"

            Case "CvSubdiv2DEdge*"
                Return "byref {0} as integer|byval {0} as intptr"

            Case "CvContourScanner*", "CvPOSITObject*", "CvFileStorage*", "CvCapture*", "CvVideoWriter*"
                Return "byval {0} as intptr"

            Case "CvRNG*"
                Return "byref {0} as long|byval {0} as intptr"

        End Select

        If SrcType.EndsWith("**") Then
            '�|�C���^�̃|�C���^�^

            If FuncName.StartsWith("cvRelease") Then
                '����n�̏ꍇByref�ɂ���
                Return "byref {0} as intptr"
            End If

            Select Case FuncName
                Case "cvSubdiv2DLocate", "cvSeqElemIdx", "cvSetAdd"
                    '��L�͐ϋɓI��IntPtr�Ƃ���
                    Return "byval {0} as intptr"

            End Select

            '���̑��͂Ƃ肠�����uIntPtr�v�Ƃ���
            mDebug.WriteLine("{0}" + vbTab + "{1}" + vbTab + "{2}", SrcType, FuncName, ParamName)
            'stop
            Return "byval {0} as intptr"
        End If

        If SrcType.EndsWith("*") Then
            '�|�C���^�^

            '�Ƃ肠�����u�\���̃|�C���^�n���v�Ƃ���
            mDebug.WriteLine("{0}" + vbTab + "{1}" + vbTab + "{2}", SrcType, FuncName, ParamName)
            'stop
            Return "byref {0} as " + SrcType.Substring(0, SrcType.Length - 1) + "|byval {0} as intptr"
        End If

        '�\����/�񋓌^
        Return "byval {0} as " + SrcType
    End Function


    '//////////////////////////////////////////////////////////
#Region "�o�͊֌W"

    '��s�o��
    Private Sub LineOut(ByVal Msg As String, ByVal ParamArray Param() As Object)
        mOut.Write(vbTab)
        If Param.Length = 0 Then
            mOut.WriteLine(Msg)
        Else
            mOut.WriteLine(Msg, Param)
        End If
    End Sub
    Private Sub LineOut()
        mOut.WriteLine()
    End Sub

    '���s�Ȃ��o��
    Private Sub Output(ByVal Msg As String, ByVal ParamArray Param() As Object)
        If Param.Length = 0 Then
            mOut.Write(Msg)
        Else
            mOut.Write(Msg, Param)
        End If
    End Sub

    '���ڏo��
    Private Sub DirectOut(ByVal Msg As String, ByVal ParamArray Param() As Object)
        If Param.Length = 0 Then
            mOut.WriteLine(Msg)
        Else
            mOut.WriteLine(Msg, Param)
        End If
    End Sub

    '�f�o�b�O������o��
    Private Sub DebugOut(ByVal Msg As String, ByVal ParamArray Param() As Object)
        mOut.Write(vbTab)
        If Param.Length = 0 Then
            mOut.WriteLine(Msg)
        Else
            mOut.WriteLine(Msg, Param)
        End If
    End Sub

#end region

End Module
