﻿Option Explicit On
Option Strict On

'//////////////////////////////////////////////////////////////
'DShowLib　サンプル　StreamBuffer2
'・ストリームバッファエンジンを使ったサンプルです。
'・Windows7下でのみ動作確認をしています。
'//////////////////////////////////////////////////////////////

'DirectShowクラスライブラリ
Imports DShowLib
Imports System.Runtime.InteropServices
Imports Microsoft.Win32


Public Class Form1


    ''' <summary>
    ''' シンクグラフを保持します。
    ''' </summary>
    ''' <remarks></remarks>
    Private mGrpSnk As IGraphBuilder

    ''' <summary>
    ''' スタブファイル名を保持します。
    ''' </summary>
    ''' <remarks></remarks>
    Private mStubFile As String

    ''' <summary>
    ''' ストリームバッファエンジン用レジストリのキーを保持します。
    ''' </summary>
    ''' <remarks></remarks>
    Private mRegKey As IntPtr

    ''' <summary>
    ''' ストリームバッファシンクフィルタを保持します。
    ''' </summary>
    ''' <remarks></remarks>
    Private mSBSink As IStreamBufferSink

    ''' <summary>
    ''' ストリーム録画オブジェクトを保持します。
    ''' </summary>
    ''' <remarks></remarks>
    Private mRec As IStreamBufferRecordControl

    ''' <summary>
    ''' 保存ファイル名を保持します。
    ''' </summary>
    ''' <remarks></remarks>
    Private mSaveFile As String

    '==========================================================

    ''' <summary>
    ''' フォームが閉じられた時の処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed

        'レジストリキーの破棄
        ReleaseRegistryKey()

    End Sub

    ''' <summary>
    ''' プレビュー開始ボタンがクリックされた時の処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_PreviewStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PreviewStart.Click

        'シンクグラフ作成
        CreateSinkGraph()

        'シンクグラフ開始(バッキングファイルへの記録開始)
        GraphPlay(mGrpSnk)
        Lbl_File.Text = "プレビュー開始"

    End Sub

    ''' <summary>
    ''' プレビュー終了ボタンがクリックされた時の処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_PreviewEnd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PreviewEnd.Click

        'シンクグラフ停止
        GraphStop(mGrpSnk)

        'グラフ解放
        mSBSink = Nothing
        ReleaseInstance(mGrpSnk)
        Lbl_File.Text = "プレビュー終了"

    End Sub

    ''' <summary>
    ''' 録画開始ボタンがクリックされた時の処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_RecordStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_RecordStart.Click

        '状態確認
        If mRec IsNot Nothing Then Exit Sub '録画中
        If mGrpSnk Is Nothing Then Exit Sub '録画不可

        '保存先決定
        Dim wkdir As String = Txt_File.Text                 '保存ディレクトリ
        Dim fname As String = String.Format("{0:yyyyMMddHHmmss}.sbe", Now)
        mSaveFile = IO.Path.Combine(wkdir, fname)          '保存ファイル

        'Recordingオブジェクト作成
        Dim obj As Object = Nothing
        mSBSink.CreateRecorder(mSaveFile, SBERecordingType.RECORDING_TYPE_CONTENT, obj)
        mRec = CType(obj, IStreamBufferRecordControl)

        '録画開始
        Dim tm As Long = 0 '現在位置から保存
        mRec.Start(tm)

        '記録中ファイルの表示
        Lbl_File.Text = "録画中 : " + mSaveFile

    End Sub

    ''' <summary>
    ''' 録画終了ボタンがクリックされた時の処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_RecordEnd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_RecordEnd.Click

        '状態確認
        If mRec Is Nothing Then Exit Sub '録画不可能

        '録画終了
        mRec.Stop(0)
        ReleaseInstance(mRec)

        '記録ファイルの表示
        Lbl_File.Text = "録画終了 : " + mSaveFile

        '変換
        Dim dname As String = IO.Path.GetDirectoryName(mSaveFile)
        Dim fname As String = IO.Path.Combine(dname, IO.Path.GetFileNameWithoutExtension(mSaveFile) + ".avi")
        Lbl_File.Text = "映像変換中 : " + fname
        ConvertVideo(mSaveFile, fname)
        Lbl_File.Text = "映像変換完了 : " + fname

    End Sub

    ''' <summary>
    ''' 録画ファイルを動画ファイルに変換します。
    ''' </summary>
    ''' <param name="SrcFile">入力ファイル(録画ファイル)</param>
    ''' <param name="OutFile">出力ファイル</param>
    ''' <remarks></remarks>
    Private Sub ConvertVideo(ByVal SrcFile As String, ByVal OutFile As String)

        '変換グラフ生成
        Dim grp As IGraphBuilder = CreateNewGraph()

        'ソースファイルフィルタ追加
        Dim srcflt As IBaseFilter = Nothing
        grp.AddSourceFilter(SrcFile, "Source", srcflt)

        'ファイルライタフィルタ追加
        Dim muxflt As IBaseFilter = AddFilter(grp, DSConst.FilterGUID.CLSID_AVIMux)
        Dim wrtflt As IBaseFilter = AddFilter(grp, DSConst.FilterGUID.CLSID_Filewriter)
        Dim snk As IFileSinkFilter = CType(wrtflt, IFileSinkFilter)
        snk.SetFileName(OutFile, Nothing)

        '接続
        Dim srcopin As IPin = FindPin(srcflt, 0, PIN_DIRECTION.PINDIR_OUTPUT)
        grp.Render(srcopin)
        Dim wkdir As String = Txt_File.Text                 '保存ディレクトリ
        'SaveGraphFile(grp, IO.Path.Combine(wkdir, "convert.grf"))

        '変換開始
        GraphPlay(grp)

        '終了するまで待機
        Dim th As Threading.Thread
        th = PlayLoopStart(grp, Function() True)
        PlayLoopStop(th)

    End Sub

    '----------------------------------------------------------

    ''' <summary>
    ''' シンクグラフを作成します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CreateSinkGraph()

        'クリア
        GraphStop(mGrpSnk)
        ReleaseInstance(mGrpSnk)

        'ストリームバッファエンジンの設定
        Dim sbcfg As IStreamBufferConfigure = CType(CoCreateInstance(DSConst.FilterGUID.CLSID_StreamBufferConfig), IStreamBufferConfigure)
        Dim sbi As IStreamBufferInitialize = CType(sbcfg, IStreamBufferInitialize)
        sbi.SetHKEY(GetRegistryKey())           '連絡用のレジストリキー設定
        Dim wkdir As String = Txt_File.Text                     '保存ディレクトリ
        mStubFile = IO.Path.Combine(wkdir, "stub.sbe")          'スタブファイル名
        sbcfg.SetDirectory(IO.Path.GetDirectoryName(mStubFile)) '保存ディレクトリ設定

        '#If WINDOWS7 Then
        Dim sbc As IStreamBufferConfigure3 = CType(sbcfg, IStreamBufferConfigure3)
        sbc.SetNamespace(vbNullString)
        '#End If

        'カメラと出力ピンの選択
        Dim dlg As New DSUSelectCameraDialog
        Dim grpinfo As New DSUSelectCameraDialog.VIDEOCAPTUREGRAPHINFO
        If dlg.ShowDialog(grpinfo) <> Windows.Forms.DialogResult.OK Then Return

        'InfinitePinTeeフィルタを追加
        Dim infflt As IBaseFilter = AddFilter(grpinfo.Graph, FilterGUID.CLSID_InfinitePinTeeFilter, "InfinitePinTee")
        Dim infipin As IPin = FindPin(infflt, 0, PIN_DIRECTION.PINDIR_INPUT)    'InfitePinTeeの入力ピン
        grpinfo.Graph.Connect(grpinfo.Pin, infipin) 'カメラフィルタの出力ピン#0とInfitePinTeeの入力ピンを接続

        'DVエンコーダフィルタをグラフに追加
        Dim dveflt As IBaseFilter = AddFilter(grpinfo.Graph, DSConst.FilterGUID.CLSID_DVVideoEnc)
        Dim infopin1 As IPin = FindPin(infflt, 0, PIN_DIRECTION.PINDIR_OUTPUT)  'InfitePinTeeの出力ピン#0
        Dim dveipin As IPin = FindPin(dveflt, 0, PIN_DIRECTION.PINDIR_INPUT)
        grpinfo.Graph.Connect(infopin1, dveipin) 'InfitePinTeeの出力ピン#0とDVエンコーダフィルタを接続

        'ストリームバッファシンクフィルタをグラフに追加
        Dim sbsflt As IBaseFilter = AddFilter(grpinfo.Graph, DSConst.FilterGUID.CLSID_StreamBufferSink)
        Dim dveopin As IPin = FindPin(dveflt, 0, PIN_DIRECTION.PINDIR_OUTPUT)   'DVエンコーダフィルタの出力ピン
        Dim sbsipin As IPin = FindPin(sbsflt, 0, PIN_DIRECTION.PINDIR_INPUT)    'ストリームバッファシンクフィルタの入力ピン
        grpinfo.Graph.Connect(dveopin, sbsipin)     'DVエンコーダフィルタとストリームバッファシンクフィルタを接続

        'プレビュー用レンダラフィルタをグラフに追加
        Dim viewflt As IBaseFilter = AddFilter(grpinfo.Graph, DSConst.FilterGUID.CLSID_VideoRenderer)
        Dim infopin2 As IPin = FindPin(infflt, 1, PIN_DIRECTION.PINDIR_OUTPUT)  'InfitePinTeeの出力ピン#1
        Dim viewipin As IPin = FindPin(viewflt, 0, PIN_DIRECTION.PINDIR_INPUT)  'ビデオレンダラの入力ピン
        grpinfo.Graph.Connect(infopin2, viewipin)

        'SaveGraphFile(grpinfo.Graph, IO.Path.Combine(wkdir, "sinkgraph.grf"))

        'ストリームバッファシンクフィルタの設定
        Dim sbisnk As IStreamBufferInitialize = CType(sbsflt, IStreamBufferInitialize)
        sbisnk.SetHKEY(GetRegistryKey())
        Dim sbs As IStreamBufferSink = CType(sbsflt, IStreamBufferSink)
        sbs.LockProfile(mStubFile)

        'グラフ生成成功
        mGrpSnk = grpinfo.Graph
        mSBSink = sbs

    End Sub

    ''' <summary>
    ''' レジストリキーを取得します。
    ''' </summary>
    ''' <returns>レジストリキーを返します。</returns>
    ''' <remarks></remarks>
    Private Function GetRegistryKey() As IntPtr

        '状態チェック
        If mRegKey <> IntPtr.Zero Then Return mRegKey

        'キーの作成
        Dim keyname As String = "SOFTWARE\SBTest"
        Dim regkey As RegistryKey = Registry.CurrentUser.CreateSubKey(keyname, RegistryKeyPermissionCheck.ReadWriteSubTree)
        regkey.Close()

        'オープン
        Win32API.RegOpenKeyEx(Win32API.HKEY_CURRENT_USER, keyname, 0, Win32API.STANDARD_RIGHTS_READ Or Win32API.KEY_QUERY_VALUE Or Win32API.STANDARD_RIGHTS_WRITE, mRegKey)

        Return mRegKey
    End Function

    ''' <summary>
    ''' レジストリキーを解放します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ReleaseRegistryKey()

        'クローズ
        If mRegKey <> IntPtr.Zero Then
            Win32API.RegCloseKey(mRegKey)
            mRegKey = IntPtr.Zero
        End If

    End Sub




End Class
