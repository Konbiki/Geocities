﻿Option Explicit On
Option Strict On

Imports DShowLib

Module Start

    Private mCap As New FrameCapture    'フレームキャプチャ

    Private mVMR As IVMRMixerBitmap9    'VMR9フィルタ用インターフェース

    Private WithEvents mFrm As Form     '表示フォーム

    Private mBMP As Bitmap


    'API
    Private Declare Function SetDIBitsToDevice Lib "gdi32" (ByVal hDC As IntPtr, ByVal x As Integer, ByVal y As Integer, ByVal dx As Integer, ByVal dy As Integer, ByVal SrcX As Integer, ByVal SrcY As Integer, ByVal Scan As Integer, ByVal NumScans As Integer, ByVal Bits As IntPtr, ByRef BitsInfo As DSBITMAPINFO, ByVal wUsage As Integer) As Integer

    ''' <summary>
    ''' プログラムの開始位置です。
    ''' </summary>
    ''' <remarks></remarks>
    Sub Main()
#If DEBUG Then
        'デバッグ時はTraceへの出力をコンソールにも出力する
        Trace.Listeners.Add(New TextWriterTraceListener(System.Console.Out))
#End If

        'グラフ作成
        MakeGraph()

        '表示フォームの作成
        mFrm = New Form
        mFrm.ClientSize = GetVideoSize(mCap.Graph)
        SetVideoRendererOwner(mCap.Graph, mFrm, RendererScale.KeepAspect)
        mFrm.Show()

        '再生開始
        GraphPlay(mCap.Graph)

        '閉じられるまで表示
        Do While mFrm.Created
            Application.DoEvents()
        Loop

    End Sub

    ''' <summary>
    ''' ビデオレンダラをVMR9に変更します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub MakeGraph()

        'カメラから取り込むグラフを生成
        mCap.CreateGraph(0, 640, 480)
        Dim grp As IGraphBuilder = mCap.Graph

        'ビデオレンダラを探す
        Dim vflt As IBaseFilter = FindVideoRenderer(Grp)
        If vflt Is Nothing Then Throw New Exception("ビデオレンダラを見つけられません。")

        'ビデオレンダラの接続先情報を取得
        Dim vipin As IPin = FindPin(vflt, 0, PIN_DIRECTION.PINDIR_INPUT)
        Dim uppin As IPin = Nothing
        vipin.ConnectedTo(uppin)
        If uppin Is Nothing Then Throw New Exception("ビデオレンダラが接続されていません。")

        '現在のビデオレンダラをグラフから除外
        Grp.RemoveFilter(vflt)

        'VMR9をグラフに追加
        Dim vmrflt As IBaseFilter = AddFilter(Grp, DShowLib.FilterGUID.CLSID_VideoMixingRenderer9, "VMR9")
        mVMR = CType(vmrflt, IVMRMixerBitmap9)

        'サイズ決定用背景静止画のソースフィルタをグラフに追加
        'Dim bgflt As IBaseFilter = Nothing
        'grp.AddSourceFilter("w:\white_1024x768.JPG", vbNullString, bgflt)
        'Dim bgopin As IPin = FindPin(bgflt, 0, PIN_DIRECTION.PINDIR_OUTPUT)

        '接続
        Dim vmripin0 As IPin = FindPin(vmrflt, 0, PIN_DIRECTION.PINDIR_INPUT)
        'grp.Connect(bgopin, vmripin0)
        'Dim vmripin1 As IPin = FindPin(vmrflt, 1, PIN_DIRECTION.PINDIR_INPUT)
        grp.Connect(uppin, vmripin0)

    End Sub

    ''' <summary>
    ''' グラフ中のビデオレンダラを検索します。
    ''' </summary>
    ''' <param name="Grp">グラフ</param>
    ''' <returns>
    ''' ビデオレンダラのIBaseFilterインターフェース。
    ''' 見つからなかった場合Nothingを返す。</returns>
    ''' <remarks></remarks>
    Private Function FindVideoRenderer(ByVal Grp As IGraphBuilder) As IBaseFilter

        Dim eflt As IEnumFilters = Nothing
        Grp.EnumFilters(eflt)
        Dim fc As Integer = 0
        Dim flt As IBaseFilter = Nothing
        Do While eflt.Next(1, flt, fc) = 0
            If fc = 0 Then Exit Do

            If TypeOf flt Is IVideoWindow Then
                Dim fi As New FILTER_INFO
                flt.QueryFilterInfo(fi)
                Debug.Print("Find : {0}", fi.achName)
                ReleaseInstance(fi.pUnk)
                Exit Do
            End If

            ReleaseInstance(flt)
        Loop

        Return flt
    End Function


    ''' <summary>
    ''' 表示フォームのサイズが変更された時の処理です。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub mFrm_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles mFrm.SizeChanged

        SetVideoRendererOwner(mCap.Graph, mFrm, RendererScale.KeepAspect)

        CreateTelopImage()

        UpdateTelop()

    End Sub

    Private Sub CreateTelopImage()

        '表示サイズを取得
        Dim vw As IVideoWindow = CType(mCap.Graph, IVideoWindow)
        Dim wx As Integer, wy As Integer
        vw.get_Width(wx)
        vw.get_Height(wy)
        Debug.Print("{0},{1}", wx, wy)

        '再利用チェック
        If mBMP IsNot Nothing Then
            If (mBMP.Width <> wx) Or (mBMP.Height <> wy) Then
                'サイズが同じ
                Return
            End If
        End If

        'ライン描画
        mBMP = New Bitmap(wx, wy, Imaging.PixelFormat.Format32bppRgb)
        Dim g As Graphics = Graphics.FromImage(mBMP)
        g.Clear(Color.Black)
        g.DrawLine(Pens.Cyan, wx \ 2, 0, wx \ 2, wy)
        g.DrawLine(Pens.Cyan, 0, wy \ 2, wx, wy \ 2)

    End Sub

    Private Sub UpdateTelop()

        'ワーク用イメージの更新準備
        Dim g As Graphics = Graphics.FromImage(mBMP)
        Dim DC As IntPtr = g.GetHdc

        'テロップ用イメージをロック
        Dim bmp As Bitmap = mBMP
        Dim rct As New Rectangle(0, 0, bmp.Width, bmp.Height)
        Dim bd As New System.Drawing.Imaging.BitmapData
        bmp.LockBits(rct, Imaging.ImageLockMode.ReadWrite, Imaging.PixelFormat.Format32bppArgb, bd)

        'テロップ用イメージをワーク用イメージにコピー
        Dim bi As DSBITMAPINFO
        With bi.BMPHeader
            .Size = System.Runtime.InteropServices.Marshal.SizeOf(bi.BMPHeader)
            .Width = bmp.Width
            .Height = -bmp.Height
            .Planes = 1
            .BitCount = 32
        End With
        SetDIBitsToDevice(DC, 0, 0, bmp.Width, bmp.Height, 0, 0, 0, bmp.Height, bd.Scan0, bi, 0)

        'テロップ用イメージのロックを解除
        bmp.UnlockBits(bd)

        'VMRの設定
        Dim vab As New VMR9AlphaBitmap
        vab.rDest = New VMR9NormalizedRect
        With vab

            'フラグ(イメージをhDCで指定。カラーキーが有効）
            .dwFlags = VMR9AlphaBitmapFlags.VMR9AlphaBitmap_hDC Or VMR9AlphaBitmapFlags.VMR9AlphaBitmap_SrcColorKey

            'イメージが格納されているデバイスコンテキスト
            .hDC = DC

            '転送元イメージ範囲(全体)
            .rSrc.Left = 0
            .rSrc.Top = 0
            .rSrc.Right = bmp.Width
            .rSrc.Bottom = bmp.Height

            '転送先範囲(全体)
            .rDest.Left = 0
            .rDest.Top = 0
            .rDest.Right = 1
            .rDest.Bottom = 1

            'アルファブレンド濃度(0:完全透明、1:完全不透明)
            .fAlpha = 0.8

            'カラーキー
            .clrSrcKey = Color.Black.ToArgb

        End With
        mVMR.SetAlphaBitmap(vab)

        'ワーク用イメージの更新終了
        g.ReleaseHdc(DC)

    End Sub

End Module
