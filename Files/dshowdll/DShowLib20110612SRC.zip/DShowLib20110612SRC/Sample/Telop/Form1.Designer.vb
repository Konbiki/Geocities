﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Pnl_View = New System.Windows.Forms.Panel
        Me.MenuStrip_Main = New System.Windows.Forms.MenuStrip
        Me.MenuItem_DeviceMenu = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuItem_CameraSelect = New System.Windows.Forms.ToolStripMenuItem
        Me.Timer_Update = New System.Windows.Forms.Timer(Me.components)
        Me.Pic_Telop = New System.Windows.Forms.PictureBox
        Me.MenuStrip_Main.SuspendLayout()
        CType(Me.Pic_Telop, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_View
        '
        Me.Pnl_View.Location = New System.Drawing.Point(0, 24)
        Me.Pnl_View.Name = "Pnl_View"
        Me.Pnl_View.Size = New System.Drawing.Size(56, 56)
        Me.Pnl_View.TabIndex = 3
        '
        'MenuStrip_Main
        '
        Me.MenuStrip_Main.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuItem_DeviceMenu})
        Me.MenuStrip_Main.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip_Main.Name = "MenuStrip_Main"
        Me.MenuStrip_Main.Size = New System.Drawing.Size(150, 24)
        Me.MenuStrip_Main.TabIndex = 2
        Me.MenuStrip_Main.Text = "MenuStrip1"
        '
        'MenuItem_DeviceMenu
        '
        Me.MenuItem_DeviceMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuItem_CameraSelect})
        Me.MenuItem_DeviceMenu.Name = "MenuItem_DeviceMenu"
        Me.MenuItem_DeviceMenu.Size = New System.Drawing.Size(71, 20)
        Me.MenuItem_DeviceMenu.Text = "デバイス(&D)"
        '
        'MenuItem_CameraSelect
        '
        Me.MenuItem_CameraSelect.Name = "MenuItem_CameraSelect"
        Me.MenuItem_CameraSelect.Size = New System.Drawing.Size(135, 22)
        Me.MenuItem_CameraSelect.Text = "カメラ選択(&C)"
        '
        'Timer_Update
        '
        Me.Timer_Update.Interval = 1000
        '
        'Pic_Telop
        '
        Me.Pic_Telop.BackColor = System.Drawing.SystemColors.Control
        Me.Pic_Telop.Location = New System.Drawing.Point(56, 24)
        Me.Pic_Telop.Name = "Pic_Telop"
        Me.Pic_Telop.Size = New System.Drawing.Size(56, 56)
        Me.Pic_Telop.TabIndex = 0
        Me.Pic_Telop.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(150, 116)
        Me.Controls.Add(Me.Pic_Telop)
        Me.Controls.Add(Me.Pnl_View)
        Me.Controls.Add(Me.MenuStrip_Main)
        Me.Name = "Form1"
        Me.Text = "Telop"
        Me.MenuStrip_Main.ResumeLayout(False)
        Me.MenuStrip_Main.PerformLayout()
        CType(Me.Pic_Telop, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_View As System.Windows.Forms.Panel
    Friend WithEvents MenuStrip_Main As System.Windows.Forms.MenuStrip
    Friend WithEvents MenuItem_DeviceMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuItem_CameraSelect As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer_Update As System.Windows.Forms.Timer
    Friend WithEvents Pic_Telop As System.Windows.Forms.PictureBox

End Class
