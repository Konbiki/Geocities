﻿Option Explicit On
Option Strict On

Imports DShowLib

Public Class Form1

    Dim mGrpInfo As DSUSelectCameraDialog.VIDEOCAPTUREGRAPHINFO

    ''' <summary>
    ''' Button1ボタンが押されたときの処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        'カメラ選択
        mGrpInfo.Release()
        Dim dlg As New DSUSelectCameraDialog
        If dlg.ShowDialog(mGrpInfo) <> Windows.Forms.DialogResult.OK Then Exit Sub

        'InfinitePinTeeフィルタを追加
        Dim infflt As IBaseFilter = AddFilter(mGrpInfo.Graph, FilterGUID.CLSID_InfinitePinTeeFilter, "InfinitePinTee")

        'カメラフィルタの出力ピンと、InfinitePinTeeフィルタの入力ピンを接続
        Dim inffltpi As IPin = FindPin(infflt, 0, PIN_DIRECTION.PINDIR_INPUT)
        mGrpInfo.Graph.Connect(mGrpInfo.Pin, inffltpi)

        'InfinitePinTeeフィルタの出力ピン0番を取得
        Dim inffltpo0 As IPin = FindPin(infflt, 0, PIN_DIRECTION.PINDIR_OUTPUT)

        'ビデオレンダラ１を追加
        Dim vrflt1 As IBaseFilter = AddFilter(mGrpInfo.Graph, FilterGUID.CLSID_VideoRenderer, "VR1")

        'InfinitePinTeeフィルタの出力ピン0番以降をビデオレンダラに繋げる
        mGrpInfo.Graph.Render(inffltpo0)

        'InfinitePinTeeフィルタの出力ピン1番を取得
        Dim inffltpo1 As IPin = FindPin(infflt, 1, PIN_DIRECTION.PINDIR_OUTPUT)

        'ビデオレンダラ２を追加
        Dim vrflt2 As IBaseFilter = AddFilter(mGrpInfo.Graph, FilterGUID.CLSID_VideoRenderer, "VR2")

        'InfinitePinTeeフィルタの出力ピン1番以降をビデオレンダラに繋げる
        mGrpInfo.Graph.Render(inffltpo1)



        'ビデオレンダラ１をPictureBox1の中へいれる
        SetOwnerPictureBox(vrflt1, PictureBox1)

        'ビデオレンダラ１をPictureBox1の中へいれる
        SetOwnerPictureBox(vrflt2, PictureBox2)



        '開始
        Dim ctl As IMediaControl = CType(mGrpInfo.Graph, IMediaControl)
        ctl.Run()

    End Sub

    ''' <summary>
    ''' ビデオレンダラフィルタのオーナーウィンドウを指定する
    ''' </summary>
    ''' <param name="Renderer"></param>
    ''' <param name="Pic"></param>
    ''' <remarks></remarks>
    Private Sub SetOwnerPictureBox(ByVal Renderer As IBaseFilter, ByVal Pic As PictureBox)

        'レンダラフィルタからIVideoWindowインターフェースを取得
        Dim vw As IVideoWindow = CType(Renderer, IVideoWindow)

        'オーナーウィンドウの設定
        vw.put_Owner(Pic.Handle)

        'ウィンドウスタイル変更
        vw.put_WindowStyle(&H40000000)

        'レンダラの位置とサイズを変更
        vw.SetWindowPosition(0, 0, Pic.ClientSize.Width, Pic.ClientSize.Height) 'ウィンドウ一杯に広げる

    End Sub

End Class
