Option Explicit On
Option Strict On

Imports System.Runtime.InteropServices

'//////////////////////////////////////////////////////////////
''' <summary>
''' DirectShow�֘A�̃C���^�[�t�F�[�X��`�ł��B
''' </summary>
''' <remarks></remarks>
Public Module DSInterface

#Region "�O���t�֌W"

    <ComVisible(True), ComImport(), Guid("56a868a9-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IGraphBuilder
#Region "IFilterGraph Methods"
        Function AddFilter(<[In]()> ByVal pFilter As IBaseFilter, <[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal pName As String) As Integer
        Function RemoveFilter(<[In]()> ByVal pFilter As IBaseFilter) As Integer
        Function EnumFilters(<Out()> ByRef ppEnum As IEnumFilters) As Integer
        Function FindFilterByName(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal pName As String, <Out()> ByRef ppFilter As IBaseFilter) As Integer
        Function ConnectDirect(<[In]()> ByVal ppinOut As IPin, <[In]()> ByVal ppinIn As IPin, <[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
        Function Reconnect(<[In]()> ByVal ppin As IPin) As Integer
        Function Disconnect(<[In]()> ByVal ppin As IPin) As Integer
        Function SetDefaultSyncSource() As Integer
#End Region

        Function Connect(<[In]()> ByVal ppinOut As IPin, <[In]()> ByVal ppinIn As IPin) As Integer
        Function Render(<[In]()> ByVal ppinOut As IPin) As Integer
        Function RenderFile(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal lpcwstrFile As String, <[In](), MarshalAs(UnmanagedType.LPWStr)> Optional ByVal lpcwstrPlayList As String = "") As Integer
        Function AddSourceFilter(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal lpcwstrFileName As String, <[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal lpcwstrFilterName As String, <Out()> ByRef ppFilter As IBaseFilter) As Integer
        Function SetLogFile(ByVal hFile As IntPtr) As Integer
        Function Abort() As Integer
        Function ShouldOperationContinue() As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a8689f-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IFilterGraph
        Function AddFilter(<[In]()> ByVal pFilter As IBaseFilter, <[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal pName As String) As Integer
        Function RemoveFilter(<[In]()> ByVal pFilter As IBaseFilter) As Integer
        Function EnumFilters(<Out()> ByRef ppEnum As IEnumFilters) As Integer
        Function FindFilterByName(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal pName As String, <Out()> ByRef ppFilter As IBaseFilter) As Integer
        Function ConnectDirect(<[In]()> ByVal ppinOut As IPin, <[In]()> ByVal ppinIn As IPin, <[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
        Function Reconnect(<[In]()> ByVal ppin As IPin) As Integer
        Function Disconnect(<[In]()> ByVal ppin As IPin) As Integer
        Function SetDefaultSyncSource() As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a868b1-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsDual)> _
    Public Interface IMediaControl
        Function Run() As Integer
        Function Pause() As Integer
        Function [Stop]() As Integer
        <PreserveSig()> Function GetState(ByVal msTimeout As Integer, ByRef pfs As Integer) As Integer
        Function RenderFile(ByVal strFilename As String) As Integer
        Function AddSourceFilter(<[In]()> ByVal strFilename As String, <Out(), MarshalAs(UnmanagedType.IDispatch)> ByRef ppUnk As Object) As Integer
        Function get_FilterCollection(<Out(), MarshalAs(UnmanagedType.IDispatch)> ByRef ppUnk As Object) As Integer
        Function get_RegFilterCollection(<Out(), MarshalAs(UnmanagedType.IDispatch)> ByRef ppUnk As Object) As Integer
        Function StopWhenReady() As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a868b2-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsDual)> _
    Public Interface IMediaPosition
        Function get_Duration(ByRef pLength As Double) As Integer
        Function put_CurrentPosition(ByVal llTime As Double) As Integer
        Function get_CurrentPosition(ByRef pllTime As Double) As Integer
        Function get_StopTime(ByRef pllTime As Double) As Integer
        Function put_StopTime(ByVal llTime As Double) As Integer
        Function get_PrerollTime(ByRef pllTime As Double) As Integer
        Function put_PrerollTime(ByVal llTime As Double) As Integer
        Function put_Rate(ByVal dRate As Double) As Integer
        Function get_Rate(ByRef pdRate As Double) As Integer
        Function CanSeekForward(ByRef pCanSeekForward As Integer) As Integer
        Function CanSeekBackward(ByRef pCanSeekBackward As Integer) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a868b4-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsDual)> _
    Public Interface IVideoWindow
        Function put_Caption(ByVal caption As String) As Integer
        Function get_Caption(<Out()> ByRef caption As String) As Integer
        Function put_WindowStyle(ByVal windowStyle As Integer) As Integer
        Function get_WindowStyle(ByRef windowStyle As Integer) As Integer
        Function put_WindowStyleEx(ByVal windowStyleEx As Integer) As Integer
        Function get_WindowStyleEx(ByRef windowStyleEx As Integer) As Integer
        Function put_AutoShow(ByVal autoShow As Integer) As Integer
        Function get_AutoShow(ByRef autoShow As Integer) As Integer
        Function put_WindowState(ByVal windowState As Integer) As Integer
        Function get_WindowState(ByRef windowState As Integer) As Integer
        Function put_BackgroundPalette(ByVal backgroundPalette As Integer) As Integer
        Function get_BackgroundPalette(ByRef backgroundPalette As Integer) As Integer
        Function put_Visible(ByVal visible As Integer) As Integer
        Function get_Visible(ByRef visible As Integer) As Integer
        Function put_Left(ByVal left As Integer) As Integer
        Function get_Left(ByRef left As Integer) As Integer
        Function put_Width(ByVal width As Integer) As Integer
        Function get_Width(ByRef width As Integer) As Integer
        Function put_Top(ByVal top As Integer) As Integer
        Function get_Top(ByRef top As Integer) As Integer
        Function put_Height(ByVal height As Integer) As Integer
        Function get_Height(ByRef height As Integer) As Integer
        Function put_Owner(ByVal owner As IntPtr) As Integer
        Function get_Owner(ByRef owner As IntPtr) As Integer
        Function put_MessageDrain(ByVal drain As IntPtr) As Integer
        Function get_MessageDrain(ByRef drain As IntPtr) As Integer
        Function get_BorderColor(ByRef color As Integer) As Integer
        Function put_BorderColor(ByVal color As Integer) As Integer
        Function get_FullScreenMode(ByRef fullScreenMode As Integer) As Integer
        Function put_FullScreenMode(ByVal fullScreenMode As Integer) As Integer
        Function SetWindowForeground(ByVal focus As Integer) As Integer
        Function NotifyOwnerMessage(ByVal hwnd As IntPtr, ByVal msg As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As Integer
        Function SetWindowPosition(ByVal left As Integer, ByVal top As Integer, ByVal width As Integer, ByVal height As Integer) As Integer
        Function GetWindowPosition(ByRef left As Integer, ByRef top As Integer, ByRef width As Integer, ByRef height As Integer) As Integer
        Function GetMinIdealImageSize(ByRef width As Integer, ByRef height As Integer) As Integer
        Function GetMaxIdealImageSize(ByRef width As Integer, ByRef height As Integer) As Integer
        Function GetRestorePosition(ByRef left As Integer, ByRef top As Integer, ByRef width As Integer, ByRef height As Integer) As Integer
        Function HideCursor(ByVal HideCursorValue As Integer) As Integer
        Function IsCursorHidden(ByRef hideCursor As Integer) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("329bb360-f6ea-11d1-9038-00a0c9697298"), InterfaceType(ComInterfaceType.InterfaceIsDual)> _
    Public Interface IBasicVideo2
        Function AvgTimePerFrame(ByRef pAvgTimePerFrame As Double) As Integer
        Function BitRate(ByRef pBitRate As Integer) As Integer
        Function BitErrorRate(ByRef pBitRate As Integer) As Integer
        Function VideoWidth(ByRef pVideoWidth As Integer) As Integer
        Function VideoHeight(ByRef pVideoHeight As Integer) As Integer
        Function put_SourceLeft(ByVal SourceLeft As Integer) As Integer
        Function get_SourceLeft(ByRef pSourceLeft As Integer) As Integer
        Function put_SourceWidth(ByVal SourceWidth As Integer) As Integer
        Function get_SourceWidth(ByRef pSourceWidth As Integer) As Integer
        Function put_SourceTop(ByVal SourceTop As Integer) As Integer
        Function get_SourceTop(ByRef pSourceTop As Integer) As Integer
        Function put_SourceHeight(ByVal SourceHeight As Integer) As Integer
        Function get_SourceHeight(ByRef pSourceHeight As Integer) As Integer
        Function put_DestinationLeft(ByVal DestinationLeft As Integer) As Integer
        Function get_DestinationLeft(ByRef pDestinationLeft As Integer) As Integer
        Function put_DestinationWidth(ByVal DestinationWidth As Integer) As Integer
        Function get_DestinationWidth(ByRef pDestinationWidth As Integer) As Integer
        Function put_DestinationTop(ByVal DestinationTop As Integer) As Integer
        Function get_DestinationTop(ByRef pDestinationTop As Integer) As Integer
        Function put_DestinationHeight(ByVal DestinationHeight As Integer) As Integer
        Function get_DestinationHeight(ByRef pDestinationHeight As Integer) As Integer
        Function SetSourcePosition(ByVal left As Integer, ByVal top As Integer, ByVal width As Integer, ByVal height As Integer) As Integer
        Function GetSourcePosition(ByRef left As Integer, ByRef top As Integer, ByRef width As Integer, ByRef height As Integer) As Integer
        Function SetDefaultSourcePosition() As Integer
        Function SetDestinationPosition(ByVal left As Integer, ByVal top As Integer, ByVal width As Integer, ByVal height As Integer) As Integer
        Function GetDestinationPosition(ByRef left As Integer, ByRef top As Integer, ByRef width As Integer, ByRef height As Integer) As Integer
        Function SetDefaultDestinationPosition() As Integer
        Function GetVideoSize(ByRef pWidth As Integer, ByRef pHeight As Integer) As Integer
        Function GetVideoPaletteEntries(ByVal StartIndex As Integer, ByVal Entries As Integer, ByRef pRetrieved As Integer, ByVal pPalette As IntPtr) As Integer
        Function GetCurrentImage(ByRef pBufferSize As Integer, ByVal pDIBImage As IntPtr) As Integer
        Function IsUsingDefaultSource() As Integer
        Function IsUsingDefaultDestination() As Integer
        Function GetPreferredAspectRatio(ByRef plAspectX As Integer, ByRef plAspectY As Integer) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a868b3-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsDual)> _
    Public Interface IBasicAudio
        Function put_Volume(ByVal lVolume As Integer) As Integer
        Function get_Volume(ByRef plVolume As Integer) As Integer
        Function put_Balance(ByVal lBalance As Integer) As Integer
        Function get_Balance(ByRef plBalance As Integer) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a868b6-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsDual)> _
    Public Interface IMediaEvent
        Function GetEventHandle(ByRef hEvent As IntPtr) As Integer
        Function GetEvent(ByRef lEventCode As DirectShowEventCode, ByRef lParam1 As Integer, ByRef lParam2 As Integer, ByVal msTimeout As Integer) As Integer
        <PreserveSig()> Function WaitForCompletion(ByVal msTimeout As Integer, ByRef pEvCode As Integer) As Integer
        Function CancelDefaultHandling(ByVal lEvCode As Integer) As Integer
        Function RestoreDefaultHandling(ByVal lEvCode As Integer) As Integer
        Function FreeEventParams(ByVal lEvCode As DirectShowEventCode, ByVal lParam1 As Integer, ByVal lParam2 As Integer) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a868c0-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsDual)> _
    Public Interface IMediaEventEx
#Region "IMediaEvent"
        Function GetEventHandle(ByRef hEvent As IntPtr) As Integer
        Function GetEvent(ByRef lEventCode As DirectShowEventCode, ByRef lParam1 As Integer, ByRef lParam2 As Integer, ByVal msTimeout As Integer) As Integer
        Function WaitForCompletion(ByVal msTimeout As Integer, <Out()> ByRef pEvCode As Integer) As Integer
        Function CancelDefaultHandling(ByVal lEvCode As Integer) As Integer
        Function RestoreDefaultHandling(ByVal lEvCode As Integer) As Integer
        Function FreeEventParams(ByVal lEvCode As DirectShowEventCode, ByVal lParam1 As Integer, ByVal lParam2 As Integer) As Integer
#End Region
        Function SetNotifyWindow(ByVal hwnd As IntPtr, ByVal lMsg As Integer, ByVal lInstanceData As IntPtr) As Integer
        Function SetNotifyFlags(ByVal lNoNotifyFlags As Integer) As Integer
        Function GetNotifyFlags(ByRef lplNoNotifyFlags As Integer) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("36b73880-c2c8-11cf-8b46-00805f6cef60"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IMediaSeeking
        Function GetCapabilities(ByRef pCapabilities As AM_SEEKING_SeekingCapabilities) As Integer
        Function CheckCapabilities(<[In](), Out()> ByRef pCapabilities As AM_SEEKING_SeekingCapabilities) As Integer
        Function IsFormatSupported(<[In]()> ByRef pFormat As Guid) As Integer
        Function QueryPreferredFormat(<Out()> ByRef pFormat As Guid) As Integer
        Function GetTimeFormat(<Out()> ByRef pFormat As Guid) As Integer
        Function IsUsingTimeFormat(<[In]()> ByRef pFormat As Guid) As Integer
        Function SetTimeFormat(<[In]()> ByRef pFormat As Guid) As Integer
        Function GetDuration(ByRef pDuration As Long) As Integer
        Function GetStopPosition(ByRef pStop As Long) As Integer
        Function GetCurrentPosition(ByRef pCurrent As Long) As Integer
        Function ConvertTimeFormat(ByRef pTarget As Long, <[In]()> ByRef pTargetFormat As Guid, ByVal [Source] As Long, <[In]()> ByRef pSourceFormat As Guid) As Integer
        Function SetPositions(<[In]()> ByRef pCurrent As Long, ByVal dwCurrentFlags As AM_SEEKING_SEEKING_FLAGS, <[In]()> ByVal pStop As Long, ByVal dwStopFlags As AM_SEEKING_SEEKING_FLAGS) As Integer
        Function GetPositions(ByRef pCurrent As Long, ByRef pStop As Long) As Integer
        Function GetAvailable(ByRef pEarliest As Long, ByRef pLatest As Long) As Integer
        Function SetRate(ByVal dRate As Double) As Integer
        Function GetRate(ByRef pdRate As Double) As Integer
        Function GetPreroll(ByRef pllPreroll As Long) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("93E5A4E0-2D50-11d2-ABFA-00A0C9C6E38D"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface ICaptureGraphBuilder2
        Function SetFiltergraph(<[In]()> ByVal pfg As IGraphBuilder) As Integer
        Function GetFiltergraph(<Out()> ByRef ppfg As IGraphBuilder) As Integer
        Function SetOutputFileName(<[In]()> ByRef pType As Guid, <[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal lpstrFile As String, <Out()> ByRef ppbf As IBaseFilter, <Out()> ByRef ppSink As IFileSinkFilter) As Integer
        Function FindInterface(<[In]()> ByRef pCategory As Guid, <[In]()> ByRef pType As Guid, <[In]()> ByVal pbf As IBaseFilter, <[In]()> ByRef riid As Guid, <Out(), MarshalAs(UnmanagedType.IUnknown)> ByRef ppint As Object) As Integer
        Function RenderStream(<[In]()> ByRef pCategory As Guid, <[In]()> ByRef pType As Guid, <[In](), MarshalAs(UnmanagedType.IUnknown)> ByVal pSource As Object, <[In]()> ByVal pfCompressor As IBaseFilter, <[In]()> ByVal pfRenderer As IBaseFilter) As Integer
        Function ControlStream(<[In]()> ByRef pCategory As Guid, <[In]()> ByRef pType As Guid, <[In]()> ByVal pFilter As IBaseFilter, <[In]()> ByVal pstart As IntPtr, <[In]()> ByVal pstop As IntPtr, <[In]()> ByVal wStartCookie As Short, <[In]()> ByVal wStopCookie As Short) As Integer
        Function AllocCapFile(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal lpstrFile As String, <[In]()> ByVal dwlSize As Long) As Integer
        Function CopyCaptureFile(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal lpwstrOld As String, <[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal lpwstrNew As String, <[In]()> ByVal fAllowEscAbort As Integer, <[In]()> ByVal pFilter As IAMCopyCaptureFileProgress) As Integer
        Function FindPin(<[In]()> ByVal pSource As Object, <[In]()> ByVal pindir As Integer, <[In]()> ByRef pCategory As Guid, <[In]()> ByRef pType As Guid, <[In](), MarshalAs(UnmanagedType.Bool)> ByVal fUnconnected As Boolean, <[In]()> ByVal num As Integer, <Out()> ByRef ppPin As IPin) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("a2104830-7c70-11cf-8bce-00aa00a3f1a6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IFileSinkFilter
        Function SetFileName(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal pszFileName As String, <[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
        Function GetCurFile(<Out(), MarshalAs(UnmanagedType.LPWStr)> ByRef pszFileName As String, <Out(), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("670d1d20-a068-11d0-b3f0-00aa003761c5"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IAMCopyCaptureFileProgress
        Function Progress(ByVal iProgress As Integer) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("C6E13360-30AC-11d0-A18C-00A0C9118956"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IAMVideoProcAmp
        Function GetRange(<[In]()> ByVal [Property] As Integer, <Out()> ByRef pMin As Integer, <Out()> ByRef pMax As Integer, <Out()> ByRef pSteppingDelta As Integer, <Out()> ByRef pDefault As Integer, <Out()> ByRef pCapsFlag As Integer) As Integer
        Function [Set](<[In]()> ByVal [Property] As Integer, <[In]()> ByVal lValue As Integer, <[In]()> ByVal Flags As Integer) As Integer
        Function [Get](<[In]()> ByVal [Property] As Integer, <[Out]()> ByRef lValue As Integer, <[Out]()> ByRef Flags As Integer) As Integer
    End Interface

#End Region

#Region "�t�B���^��{�֌W"

    <ComVisible(True), ComImport(), Guid("56a86895-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IBaseFilter
        'Inherits IPersist
        'Inherits IMediaControl
#Region "IPersist"
        Function GetClassID(<Out()> ByRef pClassID As Guid) As Integer
#End Region
#Region "IMediaFilter"
        Function [Stop]() As Integer
        Function Pause() As Integer
        Function Run(ByVal tStart As Long) As Integer
        Function GetState(ByVal dwMilliSecsTimeout As Integer, <Out()> ByRef filtState As Integer) As Integer
        Function SetSyncSource(<[In]()> ByVal pClock As IReferenceClock) As Integer
        Function GetSyncSource(<Out()> ByRef pClock As IReferenceClock) As Integer
#End Region
        Function EnumPins(<Out()> ByRef ppEnum As IEnumPins) As Integer
        Function FindPin(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal Id As String, <Out()> ByRef ppPin As IPin) As Integer
        Function QueryFilterInfo(<Out()> ByVal pInfo As FILTER_INFO) As Integer
        Function JoinFilterGraph(<[In]()> ByVal pGraph As IFilterGraph, <[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal pName As String) As Integer
        Function QueryVendorInfo(<Out(), MarshalAs(UnmanagedType.LPWStr)> ByRef pVendorInfo As String) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("0000010c-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IPersist
        Function GetClassID(<Out()> ByRef pClassID As Guid) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a86899-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IMediaFilter
        'Inherits IPersist
#Region "IPersist Methods"
        Function GetClassID(<Out()> ByRef pClassID As Guid) As Integer
#End Region
        Function [Stop]() As Integer
        Function Pause() As Integer
        Function Run(ByVal tStart As Long) As Integer
        Function GetState(ByVal dwMilliSecsTimeout As Integer, ByRef filtState As Integer) As Integer
        Function SetSyncSource(<[In]()> ByVal pClock As IReferenceClock) As Integer
        Function GetSyncSource(<Out()> ByRef pClock As IReferenceClock) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a86893-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IEnumFilters
        Function [Next](<[In]()> ByVal cFilters As Integer, <Out()> ByRef ppFilter As IBaseFilter, <Out()> ByRef pcFetched As Integer) As Integer
        Function Skip(<[In]()> ByVal cFilters As Integer) As Integer
        Sub Reset()
        Sub Clone(<Out()> ByRef ppEnum As IEnumFilters)
    End Interface

    <ComVisible(True), ComImport(), Guid("C6E13340-30AC-11d0-A18C-00A0C9118956"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IAMStreamConfig
        Function SetFormat(<[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
        Function GetFormat(<Out(), MarshalAs(UnmanagedType.LPStruct)> ByRef ppmt As AM_MEDIA_TYPE) As Integer
        Function GetNumberOfCapabilities(ByRef piCount As Integer, ByRef piSize As Integer) As Integer
        Function GetStreamCaps(ByVal iIndex As Integer, <Out(), MarshalAs(UnmanagedType.LPStruct)> ByRef ppmt As AM_MEDIA_TYPE, ByVal pSCC As IntPtr) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("c1960960-17f5-11d1-abe1-00a0c905f375"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IAMStreamSelect
        Function Count(ByRef Streams As Integer) As Integer
        Function Info(ByVal Index As Integer, <Out(), MarshalAs(UnmanagedType.LPStruct)> ByRef ppmt As AM_MEDIA_TYPE, ByRef Flags As Integer, ByVal lcid As IntPtr, ByRef Group As Integer, ByRef Name As IntPtr, ByRef Obj As IntPtr, ByRef ppUnk As IntPtr) As Integer
        Function Enable(ByVal Index As Integer, ByVal Flag As Integer) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a8689a-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IMediaSample
        Function GetPointer(ByRef ppBuffer As IntPtr) As Integer
        Function GetSize() As Integer
        Function GetTime(ByRef pTimeStart As Long, ByRef pTimeEnd As Long) As Integer
        Function SetTime(<[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pTimeStart As UInt64, <[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pTimeEnd As UInt64) As Integer
        Function IsSyncPoint() As Integer
        Function SetSyncPoint(<[In](), MarshalAs(UnmanagedType.Bool)> ByVal bIsSyncPoint As Boolean) As Integer
        Function IsPreroll() As Integer
        Function SetPreroll(<[In](), MarshalAs(UnmanagedType.Bool)> ByVal bIsPreroll As Boolean) As Integer
        Function GetActualDataLength() As Integer
        Function SetActualDataLength(ByVal len As Integer) As Integer
        Function GetMediaType(<Out(), MarshalAs(UnmanagedType.LPStruct)> ByRef ppMediaType As AM_MEDIA_TYPE) As Integer
        Function SetMediaType(<[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pMediaType As AM_MEDIA_TYPE) As Integer
        Function IsDiscontinuity() As Integer
        Function SetDiscontinuity(<[In](), MarshalAs(UnmanagedType.Bool)> ByVal bDiscontinuity As Boolean) As Integer
        Function GetMediaTime(ByRef pTimeStart As Long, ByRef pTimeEnd As Long) As Integer
        Function SetMediaTime(<[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pTimeStart As UInt64, <[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pTimeEnd As UInt64) As Integer
    End Interface


    <ComVisible(True), ComImport(), Guid("89c31040-846b-11ce-97d3-00aa0055595a"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IEnumMediaTypes
        Function [Next](<[In]()> ByVal cMediaTypes As Integer, <Out(), MarshalAs(UnmanagedType.LPStruct)> ByRef ppMediaTypes As AM_MEDIA_TYPE, <Out()> ByRef pcFetched As Integer) As Integer
        Function Skip(<[In]()> ByVal cMediaTypes As Integer) As Integer
        Function Reset() As Integer
        Function Clone(<Out()> ByRef ppEnum As IEnumMediaTypes) As Integer
    End Interface

#End Region

#Region "�s���֌W"

    <ComVisible(True), ComImport(), Guid("56a86891-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IPin
        Function Connect(<[In]()> ByVal pReceivePin As IPin, <[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
        Function ReceiveConnection(<[In]()> ByVal pReceivePin As IPin, <[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
        Function Disconnect() As Integer
        Function ConnectedTo(<Out()> ByRef ppPin As IPin) As Integer
        Function ConnectionMediaType(<Out(), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
        Function QueryPinInfo(<Out()> ByVal pInfo As PIN_INFO) As Integer
        Function QueryDirection(ByRef pPinDir As PIN_DIRECTION) As Integer
        Function QueryId(<Out(), MarshalAs(UnmanagedType.LPWStr)> ByRef Id As String) As Integer
        Function QueryAccept(<[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
        Function EnumMediaTypes(<Out()> ByRef ppEnum As IEnumMediaTypes) As Integer
        Function QueryInternalConnections(ByVal apPin As IntPtr, <[In](), Out()> ByRef nPin As Integer) As Integer
        Function EndOfStream() As Integer
        Function BeginFlush() As Integer
        Function EndFlush() As Integer
        Function NewSegment(ByVal tStart As Long, ByVal tStop As Long, ByVal dRate As Double) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("56a86892-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IEnumPins
        '         Function [Next](<[In]()> ByVal cPins As Integer, <Out(), MarshalAs(UnmanagedType.LPArray, SizeParamIndex:=2)> ByRef ppPins() As IPin, <Out()> ByRef pcFetched As Integer) As Integer
        Function [Next](<[In]()> ByVal cPins As Integer, <Out()> ByRef ppPins As IPin, <Out()> ByRef pcFetched As Integer) As Integer
        Function Skip(<[In]()> ByVal cPins As Integer) As Integer
        Sub Reset()
        Sub Clone(<Out()> ByRef ppEnum As IEnumPins)
    End Interface

#End Region

#Region "���̑�"

    <ComVisible(True), ComImport(), Guid("56a86897-0ad4-11ce-b03a-0020af0ba770"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IReferenceClock
        Function GetTime(ByRef pTime As Long) As Integer
        Function AdviseTime(ByVal baseTime As Long, ByVal streamTime As Long, ByVal hEvent As IntPtr, ByRef pdwAdviseCookie As Integer) As Integer
        Function AdvisePeriodic(ByVal startTime As Long, ByVal periodTime As Long, ByVal hSemaphore As IntPtr, ByRef pdwAdviseCookie As Integer) As Integer
        Function Unadvise(ByVal dwAdviseCookie As Integer) As Integer
    End Interface

#End Region

#Region "�e��t�B���^"

#Region "SampleGrabber�֌W"

    'ISampleGrabber
    <ComVisible(True), ComImport(), Guid("6B652FFF-11FE-4fce-92AD-0266B5D7C78F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface ISampleGrabber
        Function SetOneShot(<[In](), MarshalAs(UnmanagedType.Bool)> ByVal OneShot As Boolean) As Integer
        Function SetMediaType(<[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
        Function GetConnectedMediaType(<Out(), MarshalAs(UnmanagedType.LPStruct)> ByVal pmt As AM_MEDIA_TYPE) As Integer
        Function SetBufferSamples(<[In](), MarshalAs(UnmanagedType.Bool)> ByVal BufferThem As Boolean) As Integer
        Function GetCurrentBuffer(ByRef pBufferSize As Integer, ByVal pBuffer As IntPtr) As Integer
        Function GetCurrentSample(ByVal ppSample As IntPtr) As Integer
        Function SetCallback(ByVal pCallback As ISampleGrabberCB, ByVal WhichMethodToCallback As Integer) As Integer
    End Interface

    'ISampleGrabberCB
    <ComVisible(True), ComImport(), Guid("0579154A-2B53-4994-B0D0-E773148EFF85"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface ISampleGrabberCB
        <PreserveSig()> Function SampleCB(ByVal SampleTime As Double, ByVal pSample As IMediaSample) As Integer
        <PreserveSig()> Function BufferCB(ByVal SampleTime As Double, ByVal pBuffer As IntPtr, ByVal BufferLen As Integer) As Integer
    End Interface

    '�����̃t�H�[�}�b�g�`��
    Public Const WAVE_FORMAT_PCM As Integer = 1

#End Region

#Region "VMR9�֌W"

    'VMR9AlphaBitmapFlags
    <Flags(), ComVisible(False)> _
    Public Enum VMR9AlphaBitmapFlags As Integer
        VMR9AlphaBitmap_Disable = &H1
        VMR9AlphaBitmap_hDC = &H2
        VMR9AlphaBitmap_EntireDDS = &H4
        VMR9AlphaBitmap_SrcColorKey = &H8
        VMR9AlphaBitmap_SrcRect = &H10
        VMR9AlphaBitmap_FilterMode = &H20
    End Enum

    'VMR9NormalizedRect
    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Class VMR9NormalizedRect
        Public Left As Single
        Public Top As Single
        Public Right As Single
        Public Bottom As Single
    End Class

    'VMR9AlphaBitmap
    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Class VMR9AlphaBitmap
        Public dwFlags As VMR9AlphaBitmapFlags
        Public hDC As IntPtr
        Public pDDS As IntPtr
        Public rSrc As DSRECT
        Public rDest As VMR9NormalizedRect
        Public fAlpha As Single
        Public clrSrcKey As Integer
        Public dwFilterMode As UInteger
    End Class

    'IVMRMixerBitmap9
    <ComVisible(True), ComImport(), Guid("ced175e5-1935-4820-81bd-ff6ad00c9108"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IVMRMixerBitmap9
        Function SetAlphaBitmap(<[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pBmpParms As VMR9AlphaBitmap) As Integer
        Function UpdateAlphaBitmapParameters(<[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pBmpParms As VMR9AlphaBitmap) As Integer
        Function GetAlphaBitmapParameters(<[Out](), MarshalAs(UnmanagedType.LPStruct)> ByVal pBmpParms As VMR9AlphaBitmap) As Integer
    End Interface

    'VMR9ProcAmpControl
    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Class VMR9ProcAmpControl
        Public dwSize As UInt32
        Public dwFlags As UInt32
        Public Brightness As Single
        Public Contrast As Single
        Public Hue As Single
        Public Saturation As Single
    End Class

    'VMR9ProcAmpControlRange
    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Class VMR9ProcAmpControlRange
        Public dwSize As UInt32
        Public dwProperty As VMR9ProcAmpControl
        Public MinValue As Single
        Public MaxValue As Single
        Public DefaultValue As Single
        Public StepSize As Single
    End Class

    'IVMRMixerControl9
    <ComVisible(True), ComImport(), Guid("1a777eaa-47c8-4930-b2c9-8fee1c1b0f3b"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IVMRMixerControl9
        Function SetAlpha(<[In]()> ByVal dwStreamID As UInt32, <[In]()> ByVal Alpha As Single) As Integer
        Function GetAlpha(<[In]()> ByVal dwStreamID As UInt32, <[Out]()> ByRef Alpha As Single) As Integer
        Function SetZOrder(<[In]()> ByVal dwStreamID As UInt32, <[In]()> ByVal dwZ As UInt32) As Integer
        Function GetZOrder(<[In]()> ByVal dwStreamID As UInt32, <[Out]()> ByRef dwZ As UInt32) As Integer
        Function SetOutputRect(<[In]()> ByVal dwStreamID As UInt32, <[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal pRect As VMR9NormalizedRect) As Integer
        Function GetOutputRect(<[In]()> ByVal dwStreamID As UInt32, <[Out](), MarshalAs(UnmanagedType.LPStruct)> ByVal pRect As VMR9NormalizedRect) As Integer
        Function SetBackgroundClr(<[In]()> ByVal dwMixerPrefs As UInt32) As Integer
        Function GetBackgroundClr(<[Out]()> ByRef dwMixerPrefs As UInt32) As Integer
        Function SetProcAmpControl(<[In]()> ByVal dwStreamID As UInt32, <[In](), MarshalAs(UnmanagedType.LPStruct)> ByVal lpClrControl As VMR9ProcAmpControl) As Integer
        Function GetProcAmpControl(<[In]()> ByVal dwStreamID As UInt32, <[In](), [Out](), MarshalAs(UnmanagedType.LPStruct)> ByVal lpClrControl As VMR9ProcAmpControl) As Integer
        Function GetProcAmpControlRange(<[In]()> ByVal dwStreamID As UInt32, <[In](), [Out](), MarshalAs(UnmanagedType.LPStruct)> ByVal lpClrControl As VMR9ProcAmpControlRange) As Integer
    End Interface


#End Region

#Region "�X�g���[���o�b�t�@�G���W���֌W"

    'IStreamBufferSink
    <ComVisible(True), ComImport(), Guid("afd1f242-7efd-45ee-ba4e-407a25c9a77a"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IStreamBufferSink
        Function LockProfile(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal pszStreamBufferFilename As String) As Integer
        Function CreateRecorder(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal pszStreamBufferFilename As String, <[In]()> ByVal dwRecordType As Integer, <Out(), MarshalAs(UnmanagedType.IUnknown)> ByRef pRecordingIUnknown As Object) As Integer
        Function IsProfileLocked() As Integer
    End Interface

    'IStreamBufferSource
    <ComVisible(True), ComImport(), Guid("1c5bd776-6ced-4f44-8164-5eab0e98db12"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IStreamBufferSource
        Function SetStreamSink(<[In]()> ByVal pIStreamBufferSink As IStreamBufferSink) As Integer
    End Interface


    <ComVisible(True), ComImport(), Guid("f61f5c26-863d-4afa-b0ba-2f81dc978596"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IStreamBufferMediaSeeking
        Function GetCapabilities(ByRef pCapabilities As AM_SEEKING_SeekingCapabilities) As Integer
        Function CheckCapabilities(<[In](), Out()> ByRef pCapabilities As AM_SEEKING_SeekingCapabilities) As Integer
        Function IsFormatSupported(<[In]()> ByRef pFormat As Guid) As Integer
        Function QueryPreferredFormat(<Out()> ByRef pFormat As Guid) As Integer
        Function GetTimeFormat(<Out()> ByRef pFormat As Guid) As Integer
        Function IsUsingTimeFormat(<[In]()> ByRef pFormat As Guid) As Integer
        Function SetTimeFormat(<[In]()> ByRef pFormat As Guid) As Integer
        Function GetDuration(ByRef pDuration As Long) As Integer
        Function GetStopPosition(ByRef pStop As Long) As Integer
        Function GetCurrentPosition(ByRef pCurrent As Long) As Integer
        Function ConvertTimeFormat(ByRef pTarget As Long, <[In]()> ByRef pTargetFormat As Guid, ByVal [Source] As Long, <[In]()> ByRef pSourceFormat As Guid) As Integer
        Function SetPositions(<[In]()> ByRef pCurrent As Long, ByVal dwCurrentFlags As AM_SEEKING_SEEKING_FLAGS, <[In]()> ByVal pStop As Long, ByVal dwStopFlags As AM_SEEKING_SEEKING_FLAGS) As Integer
        Function GetPositions(ByRef pCurrent As Long, ByRef pStop As Long) As Integer
        Function GetAvailable(ByRef pEarliest As Long, ByRef pLatest As Long) As Integer
        Function SetRate(ByVal dRate As Double) As Integer
        Function GetRate(ByRef pdRate As Double) As Integer
        Function GetPreroll(ByRef pllPreroll As Long) As Integer
    End Interface

#End Region


#End Region


End Module

