﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Txt_Filename = New System.Windows.Forms.TextBox
        Me.Btn_End = New System.Windows.Forms.Button
        Me.Btn_Start = New System.Windows.Forms.Button
        Me.Cmb_Codec = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 12)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "出力ファイル"
        '
        'Txt_Filename
        '
        Me.Txt_Filename.Location = New System.Drawing.Point(80, 8)
        Me.Txt_Filename.Name = "Txt_Filename"
        Me.Txt_Filename.Size = New System.Drawing.Size(328, 19)
        Me.Txt_Filename.TabIndex = 8
        Me.Txt_Filename.Text = "c:\iran.avi"
        '
        'Btn_End
        '
        Me.Btn_End.Location = New System.Drawing.Point(144, 64)
        Me.Btn_End.Name = "Btn_End"
        Me.Btn_End.Size = New System.Drawing.Size(128, 32)
        Me.Btn_End.TabIndex = 7
        Me.Btn_End.Text = "キャプチャ終了"
        Me.Btn_End.UseVisualStyleBackColor = True
        '
        'Btn_Start
        '
        Me.Btn_Start.Location = New System.Drawing.Point(8, 64)
        Me.Btn_Start.Name = "Btn_Start"
        Me.Btn_Start.Size = New System.Drawing.Size(128, 32)
        Me.Btn_Start.TabIndex = 6
        Me.Btn_Start.Text = "キャプチャ開始"
        Me.Btn_Start.UseVisualStyleBackColor = True
        '
        'Cmb_Codec
        '
        Me.Cmb_Codec.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Codec.FormattingEnabled = True
        Me.Cmb_Codec.Location = New System.Drawing.Point(80, 32)
        Me.Cmb_Codec.Name = "Cmb_Codec"
        Me.Cmb_Codec.Size = New System.Drawing.Size(328, 20)
        Me.Cmb_Codec.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 12)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "エンコーダ"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(415, 102)
        Me.Controls.Add(Me.Cmb_Codec)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txt_Filename)
        Me.Controls.Add(Me.Btn_End)
        Me.Controls.Add(Me.Btn_Start)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "Capture"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Txt_Filename As System.Windows.Forms.TextBox
    Friend WithEvents Btn_End As System.Windows.Forms.Button
    Friend WithEvents Btn_Start As System.Windows.Forms.Button
    Friend WithEvents Cmb_Codec As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
