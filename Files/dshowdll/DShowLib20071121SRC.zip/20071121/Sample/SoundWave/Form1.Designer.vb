﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Rdo_View3 = New System.Windows.Forms.RadioButton
        Me.Rdo_View2 = New System.Windows.Forms.RadioButton
        Me.Rdo_View1 = New System.Windows.Forms.RadioButton
        Me.Lbl_Info = New System.Windows.Forms.Label
        Me.Btn_Stop = New System.Windows.Forms.Button
        Me.Btn_Play = New System.Windows.Forms.Button
        Me.Btn_Open = New System.Windows.Forms.Button
        Me.Pic_View = New System.Windows.Forms.PictureBox
        Me.Txt_Filename = New System.Windows.Forms.TextBox
        Me.Timer_Draw = New System.Windows.Forms.Timer(Me.components)
        CType(Me.Pic_View, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Rdo_View3
        '
        Me.Rdo_View3.AutoSize = True
        Me.Rdo_View3.Location = New System.Drawing.Point(216, 200)
        Me.Rdo_View3.Name = "Rdo_View3"
        Me.Rdo_View3.Size = New System.Drawing.Size(69, 16)
        Me.Rdo_View3.TabIndex = 13
        Me.Rdo_View3.TabStop = True
        Me.Rdo_View3.Text = "グラエコ風"
        Me.Rdo_View3.UseVisualStyleBackColor = True
        '
        'Rdo_View2
        '
        Me.Rdo_View2.AutoSize = True
        Me.Rdo_View2.Location = New System.Drawing.Point(112, 200)
        Me.Rdo_View2.Name = "Rdo_View2"
        Me.Rdo_View2.Size = New System.Drawing.Size(83, 16)
        Me.Rdo_View2.TabIndex = 14
        Me.Rdo_View2.TabStop = True
        Me.Rdo_View2.Text = "周波数成分"
        Me.Rdo_View2.UseVisualStyleBackColor = True
        '
        'Rdo_View1
        '
        Me.Rdo_View1.AutoSize = True
        Me.Rdo_View1.Checked = True
        Me.Rdo_View1.Location = New System.Drawing.Point(8, 200)
        Me.Rdo_View1.Name = "Rdo_View1"
        Me.Rdo_View1.Size = New System.Drawing.Size(82, 16)
        Me.Rdo_View1.TabIndex = 15
        Me.Rdo_View1.TabStop = True
        Me.Rdo_View1.Text = "モノラル波形"
        Me.Rdo_View1.UseVisualStyleBackColor = True
        '
        'Lbl_Info
        '
        Me.Lbl_Info.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Info.Location = New System.Drawing.Point(248, 32)
        Me.Lbl_Info.Name = "Lbl_Info"
        Me.Lbl_Info.Size = New System.Drawing.Size(272, 16)
        Me.Lbl_Info.TabIndex = 12
        '
        'Btn_Stop
        '
        Me.Btn_Stop.Location = New System.Drawing.Point(168, 32)
        Me.Btn_Stop.Name = "Btn_Stop"
        Me.Btn_Stop.Size = New System.Drawing.Size(72, 24)
        Me.Btn_Stop.TabIndex = 11
        Me.Btn_Stop.Text = "Stop"
        Me.Btn_Stop.UseVisualStyleBackColor = True
        '
        'Btn_Play
        '
        Me.Btn_Play.Location = New System.Drawing.Point(88, 32)
        Me.Btn_Play.Name = "Btn_Play"
        Me.Btn_Play.Size = New System.Drawing.Size(72, 24)
        Me.Btn_Play.TabIndex = 10
        Me.Btn_Play.Text = "Play"
        Me.Btn_Play.UseVisualStyleBackColor = True
        '
        'Btn_Open
        '
        Me.Btn_Open.Location = New System.Drawing.Point(8, 32)
        Me.Btn_Open.Name = "Btn_Open"
        Me.Btn_Open.Size = New System.Drawing.Size(72, 24)
        Me.Btn_Open.TabIndex = 9
        Me.Btn_Open.Text = "Open"
        Me.Btn_Open.UseVisualStyleBackColor = True
        '
        'Pic_View
        '
        Me.Pic_View.BackColor = System.Drawing.Color.White
        Me.Pic_View.Location = New System.Drawing.Point(8, 64)
        Me.Pic_View.Name = "Pic_View"
        Me.Pic_View.Size = New System.Drawing.Size(512, 128)
        Me.Pic_View.TabIndex = 8
        Me.Pic_View.TabStop = False
        '
        'Txt_Filename
        '
        Me.Txt_Filename.Location = New System.Drawing.Point(8, 8)
        Me.Txt_Filename.Name = "Txt_Filename"
        Me.Txt_Filename.Size = New System.Drawing.Size(512, 19)
        Me.Txt_Filename.TabIndex = 7
        Me.Txt_Filename.Text = "C:\Dev\DXSDK90\Samples\Media\piano.mp3"
        '
        'Timer_Draw
        '
        Me.Timer_Draw.Enabled = True
        Me.Timer_Draw.Interval = 50
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(528, 223)
        Me.Controls.Add(Me.Rdo_View3)
        Me.Controls.Add(Me.Rdo_View2)
        Me.Controls.Add(Me.Rdo_View1)
        Me.Controls.Add(Me.Lbl_Info)
        Me.Controls.Add(Me.Btn_Stop)
        Me.Controls.Add(Me.Btn_Play)
        Me.Controls.Add(Me.Btn_Open)
        Me.Controls.Add(Me.Pic_View)
        Me.Controls.Add(Me.Txt_Filename)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "SoundWave"
        CType(Me.Pic_View, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Rdo_View3 As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_View2 As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_View1 As System.Windows.Forms.RadioButton
    Friend WithEvents Lbl_Info As System.Windows.Forms.Label
    Friend WithEvents Btn_Stop As System.Windows.Forms.Button
    Friend WithEvents Btn_Play As System.Windows.Forms.Button
    Friend WithEvents Btn_Open As System.Windows.Forms.Button
    Friend WithEvents Pic_View As System.Windows.Forms.PictureBox
    Friend WithEvents Txt_Filename As System.Windows.Forms.TextBox
    Friend WithEvents Timer_Draw As System.Windows.Forms.Timer

End Class
