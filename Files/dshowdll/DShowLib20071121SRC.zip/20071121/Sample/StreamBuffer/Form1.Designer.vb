﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btn_PreviewStart = New System.Windows.Forms.Button
        Me.Btn_PreviewEnd = New System.Windows.Forms.Button
        Me.Btn_RecordStart = New System.Windows.Forms.Button
        Me.Btn_RecordEnd = New System.Windows.Forms.Button
        Me.Txt_File = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Lbl_File = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Btn_PreviewStart
        '
        Me.Btn_PreviewStart.Location = New System.Drawing.Point(8, 8)
        Me.Btn_PreviewStart.Name = "Btn_PreviewStart"
        Me.Btn_PreviewStart.Size = New System.Drawing.Size(128, 32)
        Me.Btn_PreviewStart.TabIndex = 0
        Me.Btn_PreviewStart.Text = "プレビュー　開始"
        Me.Btn_PreviewStart.UseVisualStyleBackColor = True
        '
        'Btn_PreviewEnd
        '
        Me.Btn_PreviewEnd.Location = New System.Drawing.Point(144, 8)
        Me.Btn_PreviewEnd.Name = "Btn_PreviewEnd"
        Me.Btn_PreviewEnd.Size = New System.Drawing.Size(128, 32)
        Me.Btn_PreviewEnd.TabIndex = 1
        Me.Btn_PreviewEnd.Text = "プレビュー　終了"
        Me.Btn_PreviewEnd.UseVisualStyleBackColor = True
        '
        'Btn_RecordStart
        '
        Me.Btn_RecordStart.Location = New System.Drawing.Point(8, 56)
        Me.Btn_RecordStart.Name = "Btn_RecordStart"
        Me.Btn_RecordStart.Size = New System.Drawing.Size(128, 32)
        Me.Btn_RecordStart.TabIndex = 2
        Me.Btn_RecordStart.Text = "録画　開始"
        Me.Btn_RecordStart.UseVisualStyleBackColor = True
        '
        'Btn_RecordEnd
        '
        Me.Btn_RecordEnd.Location = New System.Drawing.Point(144, 56)
        Me.Btn_RecordEnd.Name = "Btn_RecordEnd"
        Me.Btn_RecordEnd.Size = New System.Drawing.Size(128, 32)
        Me.Btn_RecordEnd.TabIndex = 3
        Me.Btn_RecordEnd.Text = "録画　終了"
        Me.Btn_RecordEnd.UseVisualStyleBackColor = True
        '
        'Txt_File
        '
        Me.Txt_File.Location = New System.Drawing.Point(8, 120)
        Me.Txt_File.Name = "Txt_File"
        Me.Txt_File.Size = New System.Drawing.Size(264, 19)
        Me.Txt_File.TabIndex = 4
        Me.Txt_File.Text = "m:\"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 104)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 12)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "保存先フォルダ/保存中ファイル"
        '
        'Lbl_File
        '
        Me.Lbl_File.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_File.Location = New System.Drawing.Point(8, 144)
        Me.Lbl_File.Name = "Lbl_File"
        Me.Lbl_File.Size = New System.Drawing.Size(264, 16)
        Me.Lbl_File.TabIndex = 6
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(279, 164)
        Me.Controls.Add(Me.Lbl_File)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txt_File)
        Me.Controls.Add(Me.Btn_RecordEnd)
        Me.Controls.Add(Me.Btn_RecordStart)
        Me.Controls.Add(Me.Btn_PreviewEnd)
        Me.Controls.Add(Me.Btn_PreviewStart)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "StreamBuffer"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Btn_PreviewStart As System.Windows.Forms.Button
    Friend WithEvents Btn_PreviewEnd As System.Windows.Forms.Button
    Friend WithEvents Btn_RecordStart As System.Windows.Forms.Button
    Friend WithEvents Btn_RecordEnd As System.Windows.Forms.Button
    Friend WithEvents Txt_File As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Lbl_File As System.Windows.Forms.Label

End Class
