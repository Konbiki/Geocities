﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Pic_Img = New System.Windows.Forms.PictureBox
        Me.MenuStrip_Main = New System.Windows.Forms.MenuStrip
        Me.MenuItem_DeviceMenu = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuItem_CameraSelect = New System.Windows.Forms.ToolStripMenuItem
        Me.Pnl_Src = New System.Windows.Forms.Panel
        CType(Me.Pic_Img, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip_Main.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pic_Img
        '
        Me.Pic_Img.BackColor = System.Drawing.Color.White
        Me.Pic_Img.Location = New System.Drawing.Point(56, 24)
        Me.Pic_Img.Name = "Pic_Img"
        Me.Pic_Img.Size = New System.Drawing.Size(48, 40)
        Me.Pic_Img.TabIndex = 5
        Me.Pic_Img.TabStop = False
        '
        'MenuStrip_Main
        '
        Me.MenuStrip_Main.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuItem_DeviceMenu})
        Me.MenuStrip_Main.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip_Main.Name = "MenuStrip_Main"
        Me.MenuStrip_Main.Size = New System.Drawing.Size(232, 24)
        Me.MenuStrip_Main.TabIndex = 4
        Me.MenuStrip_Main.Text = "MenuStrip1"
        '
        'MenuItem_DeviceMenu
        '
        Me.MenuItem_DeviceMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuItem_CameraSelect})
        Me.MenuItem_DeviceMenu.Name = "MenuItem_DeviceMenu"
        Me.MenuItem_DeviceMenu.Size = New System.Drawing.Size(71, 20)
        Me.MenuItem_DeviceMenu.Text = "デバイス(&D)"
        '
        'MenuItem_CameraSelect
        '
        Me.MenuItem_CameraSelect.Name = "MenuItem_CameraSelect"
        Me.MenuItem_CameraSelect.Size = New System.Drawing.Size(141, 22)
        Me.MenuItem_CameraSelect.Text = "カメラ選択(&C)"
        '
        'Pnl_Src
        '
        Me.Pnl_Src.Location = New System.Drawing.Point(0, 24)
        Me.Pnl_Src.Name = "Pnl_Src"
        Me.Pnl_Src.Size = New System.Drawing.Size(48, 40)
        Me.Pnl_Src.TabIndex = 3
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(232, 95)
        Me.Controls.Add(Me.Pic_Img)
        Me.Controls.Add(Me.MenuStrip_Main)
        Me.Controls.Add(Me.Pnl_Src)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "Snap2"
        CType(Me.Pic_Img, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip_Main.ResumeLayout(False)
        Me.MenuStrip_Main.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pic_Img As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStrip_Main As System.Windows.Forms.MenuStrip
    Friend WithEvents MenuItem_DeviceMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuItem_CameraSelect As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Pnl_Src As System.Windows.Forms.Panel

End Class
