﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Pnl_View = New System.Windows.Forms.Panel
        Me.Trk_Pos = New System.Windows.Forms.TrackBar
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Btn_Stop = New System.Windows.Forms.Button
        Me.Btn_Play = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        CType(Me.Trk_Pos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_View
        '
        Me.Pnl_View.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pnl_View.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_View.Name = "Pnl_View"
        Me.Pnl_View.Size = New System.Drawing.Size(292, 249)
        Me.Pnl_View.TabIndex = 3
        '
        'Trk_Pos
        '
        Me.Trk_Pos.AutoSize = False
        Me.Trk_Pos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Trk_Pos.Location = New System.Drawing.Point(128, 0)
        Me.Trk_Pos.Maximum = 0
        Me.Trk_Pos.Name = "Trk_Pos"
        Me.Trk_Pos.Size = New System.Drawing.Size(164, 24)
        Me.Trk_Pos.TabIndex = 3
        Me.Trk_Pos.TickFrequency = 1000
        Me.Trk_Pos.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Btn_Stop
        '
        Me.Btn_Stop.Dock = System.Windows.Forms.DockStyle.Left
        Me.Btn_Stop.Location = New System.Drawing.Point(64, 0)
        Me.Btn_Stop.Name = "Btn_Stop"
        Me.Btn_Stop.Size = New System.Drawing.Size(64, 24)
        Me.Btn_Stop.TabIndex = 2
        Me.Btn_Stop.Text = "Stop"
        Me.Btn_Stop.UseVisualStyleBackColor = True
        '
        'Btn_Play
        '
        Me.Btn_Play.Dock = System.Windows.Forms.DockStyle.Left
        Me.Btn_Play.Location = New System.Drawing.Point(0, 0)
        Me.Btn_Play.Name = "Btn_Play"
        Me.Btn_Play.Size = New System.Drawing.Size(64, 24)
        Me.Btn_Play.TabIndex = 1
        Me.Btn_Play.Text = "Play"
        Me.Btn_Play.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Trk_Pos)
        Me.Panel1.Controls.Add(Me.Btn_Stop)
        Me.Panel1.Controls.Add(Me.Btn_Play)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 249)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(292, 24)
        Me.Panel1.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Controls.Add(Me.Pnl_View)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "Seek"
        CType(Me.Trk_Pos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_View As System.Windows.Forms.Panel
    Friend WithEvents Trk_Pos As System.Windows.Forms.TrackBar
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Btn_Stop As System.Windows.Forms.Button
    Friend WithEvents Btn_Play As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel

End Class
