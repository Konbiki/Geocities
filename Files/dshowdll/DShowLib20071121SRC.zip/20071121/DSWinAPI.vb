Option Explicit On
Option Strict On

Imports System.Runtime.InteropServices

'//////////////////////////////////////////////////////////////
''' <summary>
''' DirectShow�֘A��API�y��COM�C���^�[�t�F�[�X�̒�`���W���[���ł��B
''' </summary>
''' <remarks></remarks>
Public Module DSWinAPI

#Region "�萔��`"

    <Flags()> _
    Public Enum STREAM_SEEK
        STREAM_SEEK_SET = 0
        STREAM_SEEK_CUR = 1
        STREAM_SEEK_END = 2
    End Enum
    <Flags()> _
    Public Enum STGTY
        STGTY_STORAGE = 1
        STGTY_STREAM = 2
        STGTY_LOCKBYTES = 3
        STGTY_PROPERTY = 4
    End Enum
    <Flags()> _
    Public Enum STGMOVE
        STGMOVE_MOVE = 0
        STGMOVE_COPY = 1
    End Enum
    <Flags()> _
    Public Enum STGM
        STGM_READ = &H0
        STGM_WRITE = &H1
        STGM_READWRITE = &H2
        STGM_SHARE_DENY_NONE = &H40
        STGM_SHARE_DENY_READ = &H30
        STGM_SHARE_DENY_WRITE = &H20
        STGM_SHARE_EXCLUSIVE = &H10
        STGM_PRIORITY = &H40000
        STGM_CREATE = &H1000
        STGM_CONVERT = &H20000
        STGM_FAILIFTHERE = &H0
        STGM_DIRECT = &H0
        STGM_TRANSACTED = &H10000
        STGM_NOSCRATCH = &H100000
        STGM_NOSNAPSHOT = &H200000
        STGM_SIMPLE = &H8000000
        STGM_DIRECT_SWMR = &H400000
        STGM_DELETEONRELEASE = &H4000000
    End Enum
    <Flags()> _
    Public Enum STGFMT
        STGFMT_STORAGE = 0
        STGFMT_FILE = 3
        STGFMT_ANY = 4
        STGFMT_DOCFILE = 5
    End Enum
    <Flags()> _
    Public Enum STGC
        STGC_DEFAULT = 0
        STGC_OVERWRITE = 1
        STGC_ONLYIFCURRENT = 2
        STGC_DANGEROUSLYCOMMITMERELYTODISKCACHE = 4
        STGC_CONSOLIDATE = 8
    End Enum
    <Flags()> _
    Public Enum STATFLAG
        STATFLAG_DEFAULT = 0
        STATFLAG_NONAME = 1
    End Enum
    <Flags()> _
    Public Enum LOCKTYPE
        LOCK_WRITE = 1
        LOCK_EXCLUSIVE = 2
        LOCK_ONLYONCE = 4
    End Enum
    <Flags()> _
    Public Enum PROPSETFLAG
        PROPSETFLAG_DEFAULT = 0
        PROPSETFLAG_NONSIMPLE = 1
        PROPSETFLAG_ANSI = 2
        PROPSETFLAG_UNBUFFERED = 4
        PROPSETFLAG_CASE_SENSITIVE = 8
    End Enum

#End Region

#Region "�\���̒�`"

    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Structure CAUUID
        Public cElems As Integer
        Public pElems As IntPtr
    End Structure

#End Region

#Region "�C���^�[�t�F�[�X��`"

    <ComImport(), Guid("0000000d-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IEnumSTATSTG
        Function [Next](<[In]()> ByVal celt As System.UInt32, <Out(), MarshalAs(UnmanagedType.LPArray, SizeParamIndex:=0)> ByVal rgelt() As ComTypes.STATSTG, <Out()> ByRef pceltFetched As System.UInt32) As Integer
        Function Skip(<[In]()> ByVal celt As System.UInt32) As Integer
        Function Reset() As Integer
        Function Clone(<Out()> ByRef ppenum As IEnumSTATSTG) As Integer
    End Interface

    <ComImport(), Guid("0000000b-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IStorage
        Function CreateStream(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal wcsName As String, <[In](), MarshalAs(UnmanagedType.U4)> ByVal grfMode As STGM, <[In](), MarshalAs(UnmanagedType.U4)> ByVal reserved1 As System.UInt32, <[In](), MarshalAs(UnmanagedType.U4)> ByVal reserved2 As System.UInt32, <Out(), MarshalAs(UnmanagedType.Interface)> ByRef ppstg As ComTypes.IStream) As Integer
        Function OpenStream(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal wcsName As String, <[In]()> ByVal reserved1 As IntPtr, <[In](), MarshalAs(UnmanagedType.U4)> ByVal grfMode As STGM, <[In]()> ByVal reserved2 As System.UInt32, <Out(), MarshalAs(UnmanagedType.Interface)> ByRef ppstg As ComTypes.IStream) As Integer
        Function CreateStorage(<MarshalAs(UnmanagedType.LPWStr)> ByVal pwcsName As String, <[In](), MarshalAs(UnmanagedType.U4)> ByVal grfMode As STGM, <[In](), MarshalAs(UnmanagedType.U4)> ByVal reserved1 As System.UInt32, <[In](), MarshalAs(UnmanagedType.U4)> ByVal reserved2 As System.UInt32, <Out(), MarshalAs(UnmanagedType.Interface)> ByRef ppstg As IStorage) As Integer
        Function OpenStorage(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal wcsName As String, <[In]()> ByVal stgPriority As IntPtr, <[In](), MarshalAs(UnmanagedType.U4)> ByVal grfMode As STGM, <[In]()> ByVal snbExclude As IntPtr, <[In]()> ByVal reserved As System.UInt32, <Out(), MarshalAs(UnmanagedType.Interface)> ByRef ppstg As IStorage) As Integer
        Function CopyTo(<[In](), MarshalAs(UnmanagedType.U4)> ByVal ciidExclude As Integer, <[In](), MarshalAs(UnmanagedType.LPArray, SizeParamIndex:=0)> ByVal rgiidExclude() As Guid, <[In]()> ByVal snbExclude As IntPtr, <[In](), MarshalAs(UnmanagedType.Interface)> ByVal pstgDest As IStorage) As Integer
        Function MoveElementTo(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal wcsName As String, <[In](), MarshalAs(UnmanagedType.Interface)> ByVal stgDest As IStorage, <[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal wcsNewName As String, <[In](), MarshalAs(UnmanagedType.U4)> ByVal grfFlags As STGMOVE) As Integer
        Function Commit(<[In](), MarshalAs(UnmanagedType.U4)> ByVal grfCommitFlags As STGC) As Integer
        Function Revert() As Integer
        Function EnumElements(<[In]()> ByVal reserved1 As System.UInt32, <[In]()> ByVal reserved2 As IntPtr, <[In]()> ByVal reserved3 As System.UInt32, <Out(), MarshalAs(UnmanagedType.Interface)> ByRef ppenum As IEnumSTATSTG) As Integer
        Function DestroyElement(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal wcsName As String) As Integer
        Function RenameElement(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal wcsOldName As String, <[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal wcsNewName As String) As Integer
        Function SetElementTimes(<[In](), MarshalAs(UnmanagedType.LPWStr)> ByVal wcsName As String, <[In]()> ByRef ctime As ComTypes.FILETIME, <[In]()> ByRef atime As ComTypes.FILETIME, <[In]()> ByRef mtime As ComTypes.FILETIME) As Integer
        Function SetClass(<[In]()> ByRef clsid As Guid) As Integer
        Function SetStateBits(<[In](), MarshalAs(UnmanagedType.U4)> ByVal grfStateBits As System.UInt32, <[In](), MarshalAs(UnmanagedType.U4)> ByVal grfMask As System.UInt32) As Integer
        Function Stat(<[In]()> ByRef statstg As ComTypes.STATSTG, <[In](), MarshalAs(UnmanagedType.U4)> ByVal grfStatFlag As STATFLAG) As Integer
    End Interface

    <InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("0000010c-0000-0000-C000-000000000046")> _
    Public Interface IPersist
        Sub GetClassID(ByRef pClassID As Guid)
    End Interface

    <InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("00000109-0000-0000-C000-000000000046")> _
    Public Interface IPersistStream
        Inherits IPersist
        Shadows Sub GetClassID(ByRef pClassID As Guid)

        Function IsDirty() As Integer
        Sub Load(<[In]()> ByVal pStm As ComTypes.IStream)
        Sub Save(<[In]()> ByVal pStm As ComTypes.IStream, <[In](), MarshalAs(UnmanagedType.Bool)> ByVal fClearDirty As Boolean)
        Sub GetSizeMax(ByRef pcbSize As Long)
    End Interface

    <ComVisible(True), ComImport(), Guid("B196B28B-BAB4-101A-B69C-00AA00341D07"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface ISpecifyPropertyPages
        Function GetPages(ByRef pPages As CAUUID) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("29840822-5B84-11D0-BD3B-00A0C911CE86"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface ICreateDevEnum
        Function CreateClassEnumerator(<[In]()> ByRef pType As Guid, <Out()> ByRef ppEnumMoniker As ComTypes.IEnumMoniker, <[In]()> ByVal dwFlags As Integer) As Integer
    End Interface

    <ComVisible(True), ComImport(), Guid("55272A00-42CB-11CE-8135-00AA004BB851"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
    Public Interface IPropertyBag
        Function Read(<MarshalAs(UnmanagedType.LPWStr)> ByVal PropName As String, ByRef Var As Object, ByVal ErrorLog As Integer) As Integer
        Function Write(ByVal PropName As String, ByRef Var As Object) As Integer
    End Interface

#End Region

#Region "API"

    Public Class Win32API

        <DllImport("ole32.dll")> _
        Friend Shared Function StgCreateDocfile(<MarshalAs(UnmanagedType.LPWStr)> ByVal wcsName As String, <[In](), MarshalAs(UnmanagedType.U4)> ByVal grfMode As STGM, ByVal reserved As System.UInt32, <MarshalAs(UnmanagedType.Interface)> ByRef stgOpen As IStorage) As Integer
        End Function

        <DllImport("Ole32.dll"), PreserveSig()> _
        Public Shared Function StgOpenStorage(<MarshalAs(UnmanagedType.LPWStr)> ByVal pwcsName As String, ByVal pstgPriority As IStorage, ByVal grfMode As STGM, ByVal snbExclude As IntPtr, ByVal reserved As Integer, <MarshalAs(UnmanagedType.Interface)> ByRef storage As IStorage) As Integer
        End Function

        <DllImport("Ole32.dll"), PreserveSig()> _
        Public Shared Function StgIsStorageFile(<MarshalAs(UnmanagedType.LPWStr)> ByVal pwcsName As String) As Integer
        End Function

        <DllImport("olepro32.dll", CharSet:=CharSet.Unicode, ExactSpelling:=True)> _
        Public Shared Function OleCreatePropertyFrame(ByVal hwndOwner As IntPtr, ByVal x As Integer, ByVal y As Integer, ByVal lpszCaption As String, ByVal cObjects As Integer, <[In](), MarshalAs(UnmanagedType.Interface)> ByRef ppUnk As Object, ByVal cPages As Integer, ByVal pPageClsID As IntPtr, ByVal lcid As Integer, ByVal dwReserved As Integer, ByVal pvReserved As IntPtr) As Integer
        End Function

        <DllImport("KERNEL32")> _
        Public Shared Function WaitForSingleObject(ByVal handle As IntPtr, ByVal timeOut As Integer) As Integer
        End Function

    End Class

#End Region

End Module
