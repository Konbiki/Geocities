Option Explicit On
Option Strict On

Imports System.Runtime.InteropServices


'//////////////////////////////////////////////////////////////
''' <summary>
''' DirectShow�֘A�̍\���̒�`���W���[���ł��B
''' </summary>
''' <remarks></remarks>
Public Module DSStructure

    'AM_MEDIA_TYPE
    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Class AM_MEDIA_TYPE
        Public majorType As Guid
        Public subType As Guid
        <MarshalAs(UnmanagedType.Bool)> Public fixedSizeSamples As Boolean
        <MarshalAs(UnmanagedType.Bool)> Public temporalCompression As Boolean
        Public sampleSize As Integer
        Public formatType As Guid
        Public unkPtr As IntPtr
        Public formatSize As Integer
        Public formatPtr As IntPtr
    End Class

    'FILTER_INFO
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode), ComVisible(False)> _
    Public Class FILTER_INFO
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=128)> Public achName As String
        <MarshalAs(UnmanagedType.IUnknown)> Public pUnk As Object
    End Class

    'PIN_INFO
    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode), ComVisible(False)> _
    Public Class PIN_INFO
        Public Filter As IBaseFilter
        Public PinDir As PIN_DIRECTION
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=128)> Public Name As String
    End Class

    'RECT
    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Structure DSRECT
        Public Left As Integer
        Public Top As Integer
        Public Right As Integer
        Public Bottom As Integer
    End Structure

    'BITMAPINFOHEADER
    <StructLayout(LayoutKind.Sequential, Pack:=2), ComVisible(False)> _
    Public Structure DSBITMAPINFOHEADER
        Public Size As Integer
        Public Width As Integer
        Public Height As Integer
        Public Planes As Short
        Public BitCount As Short
        Public Compression As Integer
        Public ImageSize As Integer
        Public XPelsPerMeter As Integer
        Public YPelsPerMeter As Integer
        Public ClrUsed As Integer
        Public ClrImportant As Integer
    End Structure

    'DSQUAD
    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Structure DSQUAD
        Public b As Byte
        Public g As Byte
        Public r As Byte
        Public a As Byte
    End Structure

    'DSBITMAPINFO
    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Structure DSBITMAPINFO
        Public BMPHeader As DSBITMAPINFOHEADER
        Public BMPColor As DSQUAD
    End Structure

    'VIDEOINFOHEADER
    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Class DSVIDEOINFOHEADER
        Public SrcRect As DSRECT
        Public TagRect As DSRECT
        Public BitRate As Integer
        Public BitErrorRate As Integer
        Public AvgTimePerFrame As Long
        Public BmiHeader As DSBITMAPINFOHEADER
    End Class

    'WAVEFORMATEX
    <StructLayout(LayoutKind.Sequential), ComVisible(False)> _
    Public Class DSWAVEFORMATEX
        Public FormatTag As UInt16
        Public Channels As UInt16
        Public SamplesPerSec As UInt32
        Public AvgBytesPerSec As UInt32
        Public BlockAlign As Int16
        Public BitsPerSample As Int16
        Public Size As Int16
    End Class

    '�s�N�Z������p�\����
    <StructLayout(LayoutKind.Explicit, Size:=4)> _
    Public Structure DSPIXEL
        <FieldOffset(0)> Public dw As UInt32
        <FieldOffset(0)> Public b As Byte
        <FieldOffset(1)> Public g As Byte
        <FieldOffset(2)> Public r As Byte
        <FieldOffset(3)> Public a As Byte
    End Structure

End Module
