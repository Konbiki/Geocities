﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DSUSelectCameraDialog
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.OK_Button = New System.Windows.Forms.Button
        Me.Cancel_Button = New System.Windows.Forms.Button
        Me.Lbl_Device = New System.Windows.Forms.Label
        Me.Cmb_Device = New System.Windows.Forms.ComboBox
        Me.Cmb_OutPin = New System.Windows.Forms.ComboBox
        Me.Lbl_OutPin = New System.Windows.Forms.Label
        Me.Lbl_Format = New System.Windows.Forms.Label
        Me.Cmb_Format = New System.Windows.Forms.ComboBox
        Me.Btn_Device = New System.Windows.Forms.Button
        Me.Btn_OutPin = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'OK_Button
        '
        Me.OK_Button.Location = New System.Drawing.Point(200, 88)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(72, 24)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(280, 88)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(72, 24)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "キャンセル"
        '
        'Lbl_Device
        '
        Me.Lbl_Device.Location = New System.Drawing.Point(8, 8)
        Me.Lbl_Device.Name = "Lbl_Device"
        Me.Lbl_Device.Size = New System.Drawing.Size(64, 20)
        Me.Lbl_Device.TabIndex = 1
        Me.Lbl_Device.Text = "デバイス"
        Me.Lbl_Device.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Cmb_Device
        '
        Me.Cmb_Device.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Device.FormattingEnabled = True
        Me.Cmb_Device.Location = New System.Drawing.Point(72, 8)
        Me.Cmb_Device.Name = "Cmb_Device"
        Me.Cmb_Device.Size = New System.Drawing.Size(200, 20)
        Me.Cmb_Device.TabIndex = 3
        '
        'Cmb_OutPin
        '
        Me.Cmb_OutPin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_OutPin.FormattingEnabled = True
        Me.Cmb_OutPin.Location = New System.Drawing.Point(72, 32)
        Me.Cmb_OutPin.Name = "Cmb_OutPin"
        Me.Cmb_OutPin.Size = New System.Drawing.Size(200, 20)
        Me.Cmb_OutPin.TabIndex = 5
        '
        'Lbl_OutPin
        '
        Me.Lbl_OutPin.Location = New System.Drawing.Point(8, 32)
        Me.Lbl_OutPin.Name = "Lbl_OutPin"
        Me.Lbl_OutPin.Size = New System.Drawing.Size(64, 20)
        Me.Lbl_OutPin.TabIndex = 4
        Me.Lbl_OutPin.Text = "出力"
        Me.Lbl_OutPin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_Format
        '
        Me.Lbl_Format.Location = New System.Drawing.Point(8, 56)
        Me.Lbl_Format.Name = "Lbl_Format"
        Me.Lbl_Format.Size = New System.Drawing.Size(64, 20)
        Me.Lbl_Format.TabIndex = 6
        Me.Lbl_Format.Text = "フォーマット"
        Me.Lbl_Format.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Cmb_Format
        '
        Me.Cmb_Format.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Format.FormattingEnabled = True
        Me.Cmb_Format.Location = New System.Drawing.Point(72, 56)
        Me.Cmb_Format.Name = "Cmb_Format"
        Me.Cmb_Format.Size = New System.Drawing.Size(200, 20)
        Me.Cmb_Format.TabIndex = 7
        '
        'Btn_Device
        '
        Me.Btn_Device.Location = New System.Drawing.Point(280, 8)
        Me.Btn_Device.Name = "Btn_Device"
        Me.Btn_Device.Size = New System.Drawing.Size(72, 20)
        Me.Btn_Device.TabIndex = 8
        Me.Btn_Device.Text = "プロパティ"
        Me.Btn_Device.UseVisualStyleBackColor = True
        '
        'Btn_OutPin
        '
        Me.Btn_OutPin.Location = New System.Drawing.Point(280, 32)
        Me.Btn_OutPin.Name = "Btn_OutPin"
        Me.Btn_OutPin.Size = New System.Drawing.Size(72, 20)
        Me.Btn_OutPin.TabIndex = 9
        Me.Btn_OutPin.Text = "プロパティ"
        Me.Btn_OutPin.UseVisualStyleBackColor = True
        '
        'DSUSelectCameraDialog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(361, 119)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.OK_Button)
        Me.Controls.Add(Me.Btn_OutPin)
        Me.Controls.Add(Me.Btn_Device)
        Me.Controls.Add(Me.Cmb_Format)
        Me.Controls.Add(Me.Lbl_Format)
        Me.Controls.Add(Me.Cmb_OutPin)
        Me.Controls.Add(Me.Lbl_OutPin)
        Me.Controls.Add(Me.Cmb_Device)
        Me.Controls.Add(Me.Lbl_Device)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DSUSelectCameraDialog"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "カメラの選択"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents Lbl_Device As System.Windows.Forms.Label
    Friend WithEvents Cmb_Device As System.Windows.Forms.ComboBox
    Friend WithEvents Cmb_OutPin As System.Windows.Forms.ComboBox
    Friend WithEvents Lbl_OutPin As System.Windows.Forms.Label
    Friend WithEvents Lbl_Format As System.Windows.Forms.Label
    Friend WithEvents Cmb_Format As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Device As System.Windows.Forms.Button
    Friend WithEvents Btn_OutPin As System.Windows.Forms.Button

End Class
