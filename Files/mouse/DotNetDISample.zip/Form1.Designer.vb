﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Chk_Mouse = New System.Windows.Forms.CheckBox
        Me.Chk_Keyboard = New System.Windows.Forms.CheckBox
        Me.Btn_Exit = New System.Windows.Forms.Button
        Me.Lst_Log = New System.Windows.Forms.ListBox
        Me.SuspendLayout()
        '
        'Chk_Mouse
        '
        Me.Chk_Mouse.Appearance = System.Windows.Forms.Appearance.Button
        Me.Chk_Mouse.Location = New System.Drawing.Point(8, 8)
        Me.Chk_Mouse.Name = "Chk_Mouse"
        Me.Chk_Mouse.Size = New System.Drawing.Size(104, 32)
        Me.Chk_Mouse.TabIndex = 0
        Me.Chk_Mouse.Text = "Mouse"
        Me.Chk_Mouse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Chk_Mouse.UseVisualStyleBackColor = True
        '
        'Chk_Keyboard
        '
        Me.Chk_Keyboard.Appearance = System.Windows.Forms.Appearance.Button
        Me.Chk_Keyboard.Location = New System.Drawing.Point(120, 8)
        Me.Chk_Keyboard.Name = "Chk_Keyboard"
        Me.Chk_Keyboard.Size = New System.Drawing.Size(104, 32)
        Me.Chk_Keyboard.TabIndex = 1
        Me.Chk_Keyboard.Text = "Keyboard"
        Me.Chk_Keyboard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Chk_Keyboard.UseVisualStyleBackColor = True
        '
        'Btn_Exit
        '
        Me.Btn_Exit.Location = New System.Drawing.Point(272, 8)
        Me.Btn_Exit.Name = "Btn_Exit"
        Me.Btn_Exit.Size = New System.Drawing.Size(96, 32)
        Me.Btn_Exit.TabIndex = 2
        Me.Btn_Exit.Text = "Exit"
        Me.Btn_Exit.UseVisualStyleBackColor = True
        '
        'Lst_Log
        '
        Me.Lst_Log.Font = New System.Drawing.Font("ＭＳ ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Lst_Log.FormattingEnabled = True
        Me.Lst_Log.ItemHeight = 12
        Me.Lst_Log.Location = New System.Drawing.Point(8, 48)
        Me.Lst_Log.Name = "Lst_Log"
        Me.Lst_Log.Size = New System.Drawing.Size(360, 184)
        Me.Lst_Log.TabIndex = 3
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(376, 240)
        Me.Controls.Add(Me.Lst_Log)
        Me.Controls.Add(Me.Btn_Exit)
        Me.Controls.Add(Me.Chk_Keyboard)
        Me.Controls.Add(Me.Chk_Mouse)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "DirectInput Sample"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Chk_Mouse As System.Windows.Forms.CheckBox
    Friend WithEvents Chk_Keyboard As System.Windows.Forms.CheckBox
    Friend WithEvents Btn_Exit As System.Windows.Forms.Button
    Friend WithEvents Lst_Log As System.Windows.Forms.ListBox

End Class
