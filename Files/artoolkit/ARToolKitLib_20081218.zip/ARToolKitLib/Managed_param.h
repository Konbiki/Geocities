/*  --------------------------------------------------------------------------
*   Copyright (C) 2004 Hitlab NZ.
*   The distribution policy is describe on the Copyright.txt furnish 
*    with this library.
*   -------------------------------------------------------------------------*/
/**
*  \file param.h
*  \brief ARToolkit global structure (parameters) subroutines.
*
*  This file contains principal routines for loading, saving, and modify
*  camera parameters for of ARToolkit library. Different structures are used
*  for modify in run-time this parameters in the library. A file structure
*  is use for input/output.
*   \remark 
*
*   History :
*
*  \author Takeshi Mita tmita@inolab.sys.es.osaka-u.ac.jp
*  \author Shinsaku Hiura shinsaku@sys.es.osaka-u.ac.jp
*  \author Hirokazu Kato kato@sys.im.hiroshima-cu.ac.jp

*  \version  4.1
*  \date 01/12/07
**/
/*  --------------------------------------------------------------------------
*   History : 
*   Rev		Date		Who		Changes
*
*----------------------------------------------------------------------------*/

////#ifndef AR_PARAM_H
////#define AR_PARAM_H
////#ifdef __cplusplus
////extern "C" {
////#endif

// ============================================================================
//	Public includes.
// ============================================================================

////#include <AR/config.h>

// ============================================================================
//	Public types and defines.
// ============================================================================

/** \struct ARParam
* \brief camera intrinsic parameters.
* 
* This structure contains the main parameters for
* the intrinsic parameters of the camera
* representation. The camera used is a pinhole
* camera with standard parameters. User should
* consult a computer vision reference for more
* information. (e.g. Three-Dimensional Computer Vision 
* (Artificial Intelligence) by Olivier Faugeras).
* \param xsize length of the image (in pixels).
* \param ysize height of the image (in pixels).
* \param mat perspective matrix (K).
* \param dist_factor radial distortions factor
*          dist_factor[0]=x center of distortion
*          dist_factor[1]=y center of distortion
*          dist_factor[2]=distortion factor
*          dist_factor[3]=scale factor
*/
// typedef struct {
//     int      xsize, ysize;
//     double   mat[3][4];
//     double   dist_factor[4];
// } ARParam;
DEFINE_STRUCT( ARParam )
{STRUCT_BASIC( ARParam )
	DEFINE_PROPERTY_V( int, xsize )
	DEFINE_PROPERTY_V( int, ysize )
	DEFINE_PROPERTY_VA2( double, mat, 3, 4 )
	DEFINE_PROPERTY_VA( double, dist_factor, 4 )
};

// typedef struct {
//     int      xsize, ysize;
//     double   matL[3][4];
//     double   matR[3][4];
//     double   matL2R[3][4];
//     double   dist_factorL[4];
//     double   dist_factorR[4];
// } ARSParam;
DEFINE_STRUCT( ARSParam )
{STRUCT_BASIC( ARSParam )
	DEFINE_PROPERTY_V( int, xsize )
	DEFINE_PROPERTY_V( int, ysize )
	DEFINE_PROPERTY_VA2( double, matL, 3, 4 )
	DEFINE_PROPERTY_VA2( double, matR, 3, 4 )
	DEFINE_PROPERTY_VA2( double, matL2R, 3, 4 )
	DEFINE_PROPERTY_VA( double, dist_factorL, 4 )
	DEFINE_PROPERTY_VA( double, dist_factorR, 4 )
};

// ============================================================================
//	Public globals.
// ============================================================================

// ============================================================================
//	Public functions.
// ============================================================================

/** \fn int  arParamGet( double global[][3], double screen[][2], int data_num,
                 double mat[3][4] )
* \brief  XXXBK
*
*  XXXBK
* \param global XXXBK
* \param screen XXXBK
* \param data_num XXXBK
* \param mat XXXBK
* \return  XXXBK
*/
// int  arParamGet( double global[][3], double screen[][2], int data_num,
//                  double mat[3][4] );
DEFINE_FUNCTION( V(int), arParamGet, 4( VA2(double,global,,3), VA2(double,screen,,2), V(int,data_num), VA2(double,mat,3,4) ) ) 
DEFINE_FUNCTION( V(int), arParamGet, 4( P(double(*)[3],global), VA2(double,screen,,2), V(int,data_num), VA2(double,mat,3,4) ) ) 
DEFINE_FUNCTION( V(int), arParamGet, 4( VA2(double,global,,3), P(double(*)[2],screen), V(int,data_num), VA2(double,mat,3,4) ) ) 
DEFINE_FUNCTION( V(int), arParamGet, 4( P(double(*)[3],global), P(double(*)[2],screen), V(int,data_num), VA2(double,mat,3,4) ) ) 
DEFINE_FUNCTION( V(int), arParamGet, 4( VA2(double,global,,3), VA2(double,screen,,2), V(int,data_num), P(double(*)[4],mat) ) ) 
DEFINE_FUNCTION( V(int), arParamGet, 4( P(double(*)[3],global), VA2(double,screen,,2), V(int,data_num), P(double(*)[4],mat) ) ) 
DEFINE_FUNCTION( V(int), arParamGet, 4( VA2(double,global,,3), P(double(*)[2],screen), V(int,data_num), P(double(*)[4],mat) ) ) 
DEFINE_FUNCTION( V(int), arParamGet, 4( P(double(*)[3],global), P(double(*)[2],screen), V(int,data_num), P(double(*)[4],mat) ) ) 

/** \fn int  arParamDecomp( ARParam *source, ARParam *icpara, double trans[3][4] )
* \brief  XXXBK
*
*  XXXBK
* \param source XXXBK
* \param icpara XXXBK
* \param trans XXXBK
* \return  XXXBK
*/
// int  arParamDecomp( ARParam *source, ARParam *icpara, double trans[3][4] );
DEFINE_FUNCTION( V(int), arParamDecomp, 3( SP(ARParam,source), SP(ARParam,icpara), VA2(double,trans,3,4) ) ) 
DEFINE_FUNCTION( V(int), arParamDecomp, 3( SP(ARParam,source), SP(ARParam,icpara), P(double(*)[4],trans) ) ) 

/** \fn int arParamDecompMat( double source[3][4], double cpara[3][4], double trans[3][4] )
* \brief  XXXBK
*
*  XXXBK
* \param source input camera matrix
* \param cpara camera parameter to be set
* \param trans XXXBK
* \return  XXXBK
*/
// int  arParamDecompMat( double source[3][4], double cpara[3][4], double trans[3][4] );
DEFINE_FUNCTION( V(int), arParamDecompMat, 3( VA2(double,source,3,4), VA2(double,cpara,3,4), VA2(double,trans,3,4) ) ) 
DEFINE_FUNCTION( V(int), arParamDecompMat, 3( P(double(*)[4],source), VA2(double,cpara,3,4), VA2(double,trans,3,4) ) ) 
DEFINE_FUNCTION( V(int), arParamDecompMat, 3( VA2(double,source,3,4), P(double(*)[4],cpara), VA2(double,trans,3,4) ) ) 
DEFINE_FUNCTION( V(int), arParamDecompMat, 3( P(double(*)[4],source), P(double(*)[4],cpara), VA2(double,trans,3,4) ) ) 
DEFINE_FUNCTION( V(int), arParamDecompMat, 3( VA2(double,source,3,4), VA2(double,cpara,3,4), P(double(*)[4],trans) ) ) 
DEFINE_FUNCTION( V(int), arParamDecompMat, 3( P(double(*)[4],source), VA2(double,cpara,3,4), P(double(*)[4],trans) ) ) 
DEFINE_FUNCTION( V(int), arParamDecompMat, 3( VA2(double,source,3,4), P(double(*)[4],cpara), P(double(*)[4],trans) ) ) 
DEFINE_FUNCTION( V(int), arParamDecompMat, 3( P(double(*)[4],source), P(double(*)[4],cpara), P(double(*)[4],trans) ) ) 

/** \fn int int arParamIdeal2Observ( const double dist_factor[4], const double ix, const double iy,
						 double *ox, double *oy )

* \brief  Convert ideal screen coordinates of a vertex to observed ones. 
*
* Ideal coordinates mean that the distortion of the camera is compensated (so a straight line looks straight). 
* In observed coordinates the camera-distortion is not compensated and thus a straight line is not shown really straight.
* \param dist_factor distorsion factors of used camera
* \param ix x in ideal screen coordinates
* \param iy y in ideal screen coordinates
* \param ox resulted x in observed screen coordinates
* \param oy resulted y in observed screen coordinates
* \return 0 if success, -1 otherwise
*/
// int arParamIdeal2Observ( const double dist_factor[4], const double ix, const double iy,
//                          double *ox, double *oy );
DEFINE_FUNCTION( V(int), arParamIdeal2Observ, 5( VA(double,dist_factor,4), V(double,ix), V(double,iy), VP(double,ox), VP(double,oy) ) ) 
DEFINE_FUNCTION( V(int), arParamIdeal2Observ, 5( P(double*,dist_factor), V(double,ix), V(double,iy), VP(double,ox), VP(double,oy) ) ) 
DEFINE_FUNCTION( V(int), arParamIdeal2Observ, 5( VA(double,dist_factor,4), V(double,ix), V(double,iy), P(double*,ox), VP(double,oy) ) ) 
DEFINE_FUNCTION( V(int), arParamIdeal2Observ, 5( P(double*,dist_factor), V(double,ix), V(double,iy), P(double*,ox), VP(double,oy) ) ) 
DEFINE_FUNCTION( V(int), arParamIdeal2Observ, 5( VA(double,dist_factor,4), V(double,ix), V(double,iy), VP(double,ox), P(double*,oy) ) ) 
DEFINE_FUNCTION( V(int), arParamIdeal2Observ, 5( P(double*,dist_factor), V(double,ix), V(double,iy), VP(double,ox), P(double*,oy) ) ) 
DEFINE_FUNCTION( V(int), arParamIdeal2Observ, 5( VA(double,dist_factor,4), V(double,ix), V(double,iy), P(double*,ox), P(double*,oy) ) ) 
DEFINE_FUNCTION( V(int), arParamIdeal2Observ, 5( P(double*,dist_factor), V(double,ix), V(double,iy), P(double*,ox), P(double*,oy) ) ) 

/** \fn int arParamObserv2Ideal( const double dist_factor[4], const double ox, const double oy,
                         double *ix, double *iy )

* \brief Convert observed screen coordinates of a vertex to ideal ones. 

* Ideal coordinates mean that the distortion of the camera is compensated (so a straight line looks straight).
* In observed coordinates the camera-distortion is not compensated and thus a straight line is not shown really straight.
* \param dist_factor distorsion factors of used camera
* \param ox x in observed screen coordinates
* \param oy y in observed screen coordinates
* \param ix resulted x in ideal screen coordinates
* \param iy resulted y in ideal screen coordinates
* \return 0 if success, -1 otherwise
*/
// int arParamObserv2Ideal( const double dist_factor[4], const double ox, const double oy,
//                          double *ix, double *iy );
DEFINE_FUNCTION( V(int), arParamObserv2Ideal, 5( VA(double,dist_factor,4), V(double,ox), V(double,oy), VP(double,ix), VP(double,iy) ) ) 
DEFINE_FUNCTION( V(int), arParamObserv2Ideal, 5( P(double*,dist_factor), V(double,ox), V(double,oy), VP(double,ix), VP(double,iy) ) ) 
DEFINE_FUNCTION( V(int), arParamObserv2Ideal, 5( VA(double,dist_factor,4), V(double,ox), V(double,oy), P(double*,ix), VP(double,iy) ) ) 
DEFINE_FUNCTION( V(int), arParamObserv2Ideal, 5( P(double*,dist_factor), V(double,ox), V(double,oy), P(double*,ix), VP(double,iy) ) ) 
DEFINE_FUNCTION( V(int), arParamObserv2Ideal, 5( VA(double,dist_factor,4), V(double,ox), V(double,oy), VP(double,ix), P(double*,iy) ) ) 
DEFINE_FUNCTION( V(int), arParamObserv2Ideal, 5( P(double*,dist_factor), V(double,ox), V(double,oy), VP(double,ix), P(double*,iy) ) ) 
DEFINE_FUNCTION( V(int), arParamObserv2Ideal, 5( VA(double,dist_factor,4), V(double,ox), V(double,oy), P(double*,ix), P(double*,iy) ) ) 
DEFINE_FUNCTION( V(int), arParamObserv2Ideal, 5( P(double*,dist_factor), V(double,ox), V(double,oy), P(double*,ix), P(double*,iy) ) ) 

/** \fn int arParamChangeSize( ARParam *source, int xsize, int ysize, ARParam *newparam )
* \brief change the camera size parameters.
*
* Change the size variable in camera intrinsic parameters.
* \param source name of the source parameters structure
* \param xsize new length size
* \param ysize new height size
* \param newparam name of the destination parameters structure.
* \return 0
*/
// int arParamChangeSize( ARParam *source, int xsize, int ysize, ARParam *newparam );
DEFINE_FUNCTION( V(int), arParamChangeSize, 4( SP(ARParam,source), V(int,xsize), V(int,ysize), SP(ARParam,newparam) ) ) 

/** \fn int arParamSave( char *filename, int num, ARParam *param, ...)
* \brief save a camera intrinsic parameters.
*
* Save manipulated camera intrinsic parameters in a file.
* \param filename name of the parameters file.
* \param num number of variable arguments
* \param param parameters to save
* \return 0 if success, -1 if Error (file not found, file structure problem)
*/
// int    arParamSave( char *filename, int num, ARParam *param, ...);
DEFINE_FUNCTION( V(int), arParamSave, 3( VP(char,filename), V(int,num), SP(ARParam,param) ) ) 
DEFINE_FUNCTION( V(int), arParamSave, 3( P(char*,filename), V(int,num), SP(ARParam,param) ) ) 
DEFINE_FUNCTION( V(int), arParamSave, 3( T(,filename), V(int,num), SP(ARParam,param) ) ) 

/** \fn int arParamLoad( const char *filename, int num, ARParam *param, ...)
* \brief load the camera intrinsic parameters.
*
* Load camera intrinsic parameters in the ARToolkit Library from 
* a file (itself, an output of the calibration step). 
* \param filename name of the parameters file.
* \param num number of variable arguments
* \param param result of the loaded parameters
* \return 0 if success, -1 if Error (file not found, file structure problem)
*/
// int    arParamLoad( const char *filename, int num, ARParam *param, ...);
DEFINE_FUNCTION( V(int), arParamLoad, 3( T(const,filename), V(int,num), SP(ARParam,param) ) ) 

/** \fn int arParamDisp( ARParam *param )
* \brief display parameters.
*
* Display the structure of the camera instrinsic parameters argument.
* \param param structure to display
* \return 0
*/
// int    arParamDisp( ARParam *param );
DEFINE_FUNCTION( V(int), arParamDisp, 1( SP(ARParam,param) ) ) 

/*-------------------*/

// int    arsParamChangeSize( ARSParam *source, int xsize, int ysize, ARSParam *newparam );
DEFINE_FUNCTION( V(int), arsParamChangeSize, 4( SP(ARSParam,source), V(int,xsize), V(int,ysize), SP(ARSParam,newparam) ) ) 

// int    arsParamSave( char *filename, ARSParam *sparam );
DEFINE_FUNCTION( V(int), arsParamSave, 2( VP(char,filename), SP(ARSParam,sparam) ) ) 
DEFINE_FUNCTION( V(int), arsParamSave, 2( P(char*,filename), SP(ARSParam,sparam) ) ) 
DEFINE_FUNCTION( V(int), arsParamSave, 2( T(,filename), SP(ARSParam,sparam) ) ) 

// int    arsParamLoad( char *filename, ARSParam *sparam );
DEFINE_FUNCTION( V(int), arsParamLoad, 2( VP(char,filename), SP(ARSParam,sparam) ) ) 
DEFINE_FUNCTION( V(int), arsParamLoad, 2( P(char*,filename), SP(ARSParam,sparam) ) ) 
DEFINE_FUNCTION( V(int), arsParamLoad, 2( T(,filename), SP(ARSParam,sparam) ) ) 

// int    arsParamDisp( ARSParam *sparam );
DEFINE_FUNCTION( V(int), arsParamDisp, 1( SP(ARSParam,sparam) ) ) 

// int    arsParamGetMat( double matL[3][4], double matR[3][4],
//                        double cparaL[3][4], double cparaR[3][4], double matL2R[3][4] );
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), VA2(double,matR,3,4), VA2(double,cparaL,3,4), VA2(double,cparaR,3,4), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), VA2(double,matR,3,4), VA2(double,cparaL,3,4), VA2(double,cparaR,3,4), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), P(double(*)[4],matR), VA2(double,cparaL,3,4), VA2(double,cparaR,3,4), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), P(double(*)[4],matR), VA2(double,cparaL,3,4), VA2(double,cparaR,3,4), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), VA2(double,matR,3,4), P(double(*)[4],cparaL), VA2(double,cparaR,3,4), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), VA2(double,matR,3,4), P(double(*)[4],cparaL), VA2(double,cparaR,3,4), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), P(double(*)[4],matR), P(double(*)[4],cparaL), VA2(double,cparaR,3,4), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), P(double(*)[4],matR), P(double(*)[4],cparaL), VA2(double,cparaR,3,4), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), VA2(double,matR,3,4), VA2(double,cparaL,3,4), P(double(*)[4],cparaR), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), VA2(double,matR,3,4), VA2(double,cparaL,3,4), P(double(*)[4],cparaR), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), P(double(*)[4],matR), VA2(double,cparaL,3,4), P(double(*)[4],cparaR), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), P(double(*)[4],matR), VA2(double,cparaL,3,4), P(double(*)[4],cparaR), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), VA2(double,matR,3,4), P(double(*)[4],cparaL), P(double(*)[4],cparaR), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), VA2(double,matR,3,4), P(double(*)[4],cparaL), P(double(*)[4],cparaR), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), P(double(*)[4],matR), P(double(*)[4],cparaL), P(double(*)[4],cparaR), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), P(double(*)[4],matR), P(double(*)[4],cparaL), P(double(*)[4],cparaR), VA2(double,matL2R,3,4) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), VA2(double,matR,3,4), VA2(double,cparaL,3,4), VA2(double,cparaR,3,4), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), VA2(double,matR,3,4), VA2(double,cparaL,3,4), VA2(double,cparaR,3,4), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), P(double(*)[4],matR), VA2(double,cparaL,3,4), VA2(double,cparaR,3,4), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), P(double(*)[4],matR), VA2(double,cparaL,3,4), VA2(double,cparaR,3,4), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), VA2(double,matR,3,4), P(double(*)[4],cparaL), VA2(double,cparaR,3,4), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), VA2(double,matR,3,4), P(double(*)[4],cparaL), VA2(double,cparaR,3,4), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), P(double(*)[4],matR), P(double(*)[4],cparaL), VA2(double,cparaR,3,4), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), P(double(*)[4],matR), P(double(*)[4],cparaL), VA2(double,cparaR,3,4), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), VA2(double,matR,3,4), VA2(double,cparaL,3,4), P(double(*)[4],cparaR), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), VA2(double,matR,3,4), VA2(double,cparaL,3,4), P(double(*)[4],cparaR), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), P(double(*)[4],matR), VA2(double,cparaL,3,4), P(double(*)[4],cparaR), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), P(double(*)[4],matR), VA2(double,cparaL,3,4), P(double(*)[4],cparaR), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), VA2(double,matR,3,4), P(double(*)[4],cparaL), P(double(*)[4],cparaR), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), VA2(double,matR,3,4), P(double(*)[4],cparaL), P(double(*)[4],cparaR), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( VA2(double,matL,3,4), P(double(*)[4],matR), P(double(*)[4],cparaL), P(double(*)[4],cparaR), P(double(*)[4],matL2R) ) ) 
DEFINE_FUNCTION( V(int), arsParamGetMat, 5( P(double(*)[4],matL), P(double(*)[4],matR), P(double(*)[4],cparaL), P(double(*)[4],cparaR), P(double(*)[4],matL2R) ) ) 

////#ifdef __cplusplus
////}
////#endif
////#endif
