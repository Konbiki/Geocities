////#ifndef AR_CONFIG_H
////#define AR_CONFIG_H

//
// As of version 2.72, ARToolKit supports an OpenGL-like
// versioning system, with both header versions (for the version
// of the ARToolKit SDK installed) and runtime version reporting
// via arGetVersion().
//

// The MAJOR version number defines non-backwards compatible
// changes in the ARToolKit API. Range: [0-99].
// #define AR_HEADER_VERSION_MAJOR		2
#pragma push_macro( "AR_HEADER_VERSION_MAJOR" )
#undef AR_HEADER_VERSION_MAJOR
static const int AR_HEADER_VERSION_MAJOR
#pragma pop_macro( "AR_HEADER_VERSION_MAJOR" )
	= AR_HEADER_VERSION_MAJOR;

// The MINOR version number defines additions to the ARToolKit
// API, or (occsasionally) other significant backwards-compatible
// changes in runtime functionality. Range: [0-99].
// #define AR_HEADER_VERSION_MINOR		72
#pragma push_macro( "AR_HEADER_VERSION_MINOR" )
#undef AR_HEADER_VERSION_MINOR
static const int AR_HEADER_VERSION_MINOR
#pragma pop_macro( "AR_HEADER_VERSION_MINOR" )
	= AR_HEADER_VERSION_MINOR;

// The TINY version number defines bug-fixes to existing
// functionality. Range: [0-99].
// #define AR_HEADER_VERSION_TINY		0
#pragma push_macro( "AR_HEADER_VERSION_TINY" )
#undef AR_HEADER_VERSION_TINY
static const int AR_HEADER_VERSION_TINY
#pragma pop_macro( "AR_HEADER_VERSION_TINY" )
	= AR_HEADER_VERSION_TINY;

// The BUILD version number will always be zero in releases,
// but may be non-zero in internal builds or in version-control
// repository-sourced code. Range: [0-99].
// #define AR_HEADER_VERSION_BUILD		0
#pragma push_macro( "AR_HEADER_VERSION_BUILD" )
#undef AR_HEADER_VERSION_BUILD
static const int AR_HEADER_VERSION_BUILD
#pragma pop_macro( "AR_HEADER_VERSION_BUILD" )
	= AR_HEADER_VERSION_BUILD;

// The string representation below must match the major, minor
// and tiny release numbers.
// #define AR_HEADER_VERSION_STRING	"2.72.0"
#pragma push_macro( "AR_HEADER_VERSION_STRING" )
#undef AR_HEADER_VERSION_STRING
static const String^ AR_HEADER_VERSION_STRING
#pragma pop_macro( "AR_HEADER_VERSION_STRING" )
	= AR_HEADER_VERSION_STRING;

// The macros below are convenience macros to enable use
// of certain ARToolKit header functionality by the release
// version in which it appeared.
// Each time the major version number is incremented, all
// existing macros must be removed, and just one new one
// added for the new major version.
// Each time the minor version number is incremented, a new
// AR_HAVE_HEADER_VERSION_ macro definition must be added.
// Tiny version numbers (being bug-fix releases, by definition)
// are NOT included in the AR_HAVE_HEADER_VERSION_ system.
// #define AR_HAVE_HEADER_VERSION_2
// Unsupport : AR_HAVE_HEADER_VERSION_2
// #define AR_HAVE_HEADER_VERSION_2_72
// Unsupport : AR_HAVE_HEADER_VERSION_2_72

//
// End version definitions.
//

// #define AR_PIXEL_FORMAT_RGB 1
#pragma push_macro( "AR_PIXEL_FORMAT_RGB" )
#undef AR_PIXEL_FORMAT_RGB
static const int AR_PIXEL_FORMAT_RGB
#pragma pop_macro( "AR_PIXEL_FORMAT_RGB" )
	= AR_PIXEL_FORMAT_RGB;
// #define AR_PIXEL_FORMAT_BGR 2
#pragma push_macro( "AR_PIXEL_FORMAT_BGR" )
#undef AR_PIXEL_FORMAT_BGR
static const int AR_PIXEL_FORMAT_BGR
#pragma pop_macro( "AR_PIXEL_FORMAT_BGR" )
	= AR_PIXEL_FORMAT_BGR;
// #define AR_PIXEL_FORMAT_RGBA 3
#pragma push_macro( "AR_PIXEL_FORMAT_RGBA" )
#undef AR_PIXEL_FORMAT_RGBA
static const int AR_PIXEL_FORMAT_RGBA
#pragma pop_macro( "AR_PIXEL_FORMAT_RGBA" )
	= AR_PIXEL_FORMAT_RGBA;
// #define AR_PIXEL_FORMAT_BGRA 4
#pragma push_macro( "AR_PIXEL_FORMAT_BGRA" )
#undef AR_PIXEL_FORMAT_BGRA
static const int AR_PIXEL_FORMAT_BGRA
#pragma pop_macro( "AR_PIXEL_FORMAT_BGRA" )
	= AR_PIXEL_FORMAT_BGRA;
// #define AR_PIXEL_FORMAT_ABGR 5
#pragma push_macro( "AR_PIXEL_FORMAT_ABGR" )
#undef AR_PIXEL_FORMAT_ABGR
static const int AR_PIXEL_FORMAT_ABGR
#pragma pop_macro( "AR_PIXEL_FORMAT_ABGR" )
	= AR_PIXEL_FORMAT_ABGR;
// #define AR_PIXEL_FORMAT_MONO 6
#pragma push_macro( "AR_PIXEL_FORMAT_MONO" )
#undef AR_PIXEL_FORMAT_MONO
static const int AR_PIXEL_FORMAT_MONO
#pragma pop_macro( "AR_PIXEL_FORMAT_MONO" )
	= AR_PIXEL_FORMAT_MONO;
// #define AR_PIXEL_FORMAT_ARGB 7
#pragma push_macro( "AR_PIXEL_FORMAT_ARGB" )
#undef AR_PIXEL_FORMAT_ARGB
static const int AR_PIXEL_FORMAT_ARGB
#pragma pop_macro( "AR_PIXEL_FORMAT_ARGB" )
	= AR_PIXEL_FORMAT_ARGB;
// #define AR_PIXEL_FORMAT_2vuy 8
#pragma push_macro( "AR_PIXEL_FORMAT_2vuy" )
#undef AR_PIXEL_FORMAT_2vuy
static const int AR_PIXEL_FORMAT_2vuy
#pragma pop_macro( "AR_PIXEL_FORMAT_2vuy" )
	= AR_PIXEL_FORMAT_2vuy;
// #define AR_PIXEL_FORMAT_UYVY AR_PIXEL_FORMAT_2vuy
#pragma push_macro( "AR_PIXEL_FORMAT_UYVY" )
#undef AR_PIXEL_FORMAT_UYVY
static const int AR_PIXEL_FORMAT_UYVY
#pragma pop_macro( "AR_PIXEL_FORMAT_UYVY" )
	= AR_PIXEL_FORMAT_UYVY;
// #define AR_PIXEL_FORMAT_yuvs 9
#pragma push_macro( "AR_PIXEL_FORMAT_yuvs" )
#undef AR_PIXEL_FORMAT_yuvs
static const int AR_PIXEL_FORMAT_yuvs
#pragma pop_macro( "AR_PIXEL_FORMAT_yuvs" )
	= AR_PIXEL_FORMAT_yuvs;
// #define AR_PIXEL_FORMAT_YUY2 AR_PIXEL_FORMAT_yuvs
#pragma push_macro( "AR_PIXEL_FORMAT_YUY2" )
#undef AR_PIXEL_FORMAT_YUY2
static const int AR_PIXEL_FORMAT_YUY2
#pragma pop_macro( "AR_PIXEL_FORMAT_YUY2" )
	= AR_PIXEL_FORMAT_YUY2;

/*--------------------------------------------------------------*/
/*                                                              */
/*  For Linux, you should define one of below 4 input method    */
/*    AR_INPUT_V4L:       use of standard Video4Linux Library   */
/*    AR_INPUT_GSTREAMER: use of GStreamer Media Framework      */
/*    AR_INPUT_DV:        use of DV Camera                      */
/*    AR_INPUT_1394CAM:   use of 1394 Digital Camera            */
/*                                                              */
/*--------------------------------------------------------------*/
////#ifdef __linux
////#undef  AR_INPUT_V4L
////#undef  AR_INPUT_DV
////#undef  AR_INPUT_1394CAM
////#undef  AR_INPUT_GSTREAMER
////
////#  ifdef AR_INPUT_V4L
////#    ifdef USE_EYETOY
////#      define AR_DEFAULT_PIXEL_FORMAT AR_PIXEL_FORMAT_RGB
////#    else
////#      define AR_DEFAULT_PIXEL_FORMAT AR_PIXEL_FORMAT_BGR
////#    endif
////#  endif
////
////#  ifdef AR_INPUT_DV
////#    define  AR_DEFAULT_PIXEL_FORMAT AR_PIXEL_FORMAT_RGB
////#  endif
////
////#  ifdef AR_INPUT_1394CAM
////#    define  AR_DEFAULT_PIXEL_FORMAT AR_PIXEL_FORMAT_RGB
////#  endif
////
////#  ifdef AR_INPUT_GSTREAMER
////#    define  AR_DEFAULT_PIXEL_FORMAT AR_PIXEL_FORMAT_RGB
////#  endif
////
////#  undef   AR_BIG_ENDIAN
////#  define  AR_LITTLE_ENDIAN
////#endif


/*------------------------------------------------------------*/
/*  For SGI                                                   */
/*------------------------------------------------------------*/
////#ifdef __sgi
////#  define  AR_BIG_ENDIAN
////#  undef   AR_LITTLE_ENDIAN
////#  define  AR_DEFAULT_PIXEL_FORMAT AR_PIXEL_FORMAT_ABGR
////#endif

/*------------------------------------------------------------*/
/*  For Windows                                               */
/*------------------------------------------------------------*/
////#ifdef _WIN32
////#  undef   AR_BIG_ENDIAN
// #  define  AR_LITTLE_ENDIAN
// Unsupport : AR_LITTLE_ENDIAN
// #  define  AR_DEFAULT_PIXEL_FORMAT AR_PIXEL_FORMAT_BGRA
#pragma push_macro( "AR_DEFAULT_PIXEL_FORMAT" )
#undef AR_DEFAULT_PIXEL_FORMAT
static const int AR_DEFAULT_PIXEL_FORMAT
#pragma pop_macro( "AR_DEFAULT_PIXEL_FORMAT" )
	= AR_DEFAULT_PIXEL_FORMAT;
////#endif

/*------------------------------------------------------------*/
/*  For Mac OS X                                              */
/*------------------------------------------------------------*/
////#ifdef __APPLE__
////#  if defined(__BIG_ENDIAN__) // Check architecture endianess using gcc's macro.
////#    define  AR_BIG_ENDIAN  // Most Significant Byte has greatest address in memory (ppc).
////#    undef   AR_LITTLE_ENDIAN
////#  elif defined (__LITTLE_ENDIAN__)
////#    undef   AR_BIG_ENDIAN   // Least significant Byte has greatest address in memory (i386).
////#    define  AR_LITTLE_ENDIAN
////#  endif
////#  define  AR_DEFAULT_PIXEL_FORMAT AR_PIXEL_FORMAT_ARGB
////#endif


/*------------------------------------------------------------*/

// #define  AR_DRAW_BY_GL_DRAW_PIXELS    0
#pragma push_macro( "AR_DRAW_BY_GL_DRAW_PIXELS" )
#undef AR_DRAW_BY_GL_DRAW_PIXELS
static const int AR_DRAW_BY_GL_DRAW_PIXELS
#pragma pop_macro( "AR_DRAW_BY_GL_DRAW_PIXELS" )
	= AR_DRAW_BY_GL_DRAW_PIXELS;
// #define  AR_DRAW_BY_TEXTURE_MAPPING   1
#pragma push_macro( "AR_DRAW_BY_TEXTURE_MAPPING" )
#undef AR_DRAW_BY_TEXTURE_MAPPING
static const int AR_DRAW_BY_TEXTURE_MAPPING
#pragma pop_macro( "AR_DRAW_BY_TEXTURE_MAPPING" )
	= AR_DRAW_BY_TEXTURE_MAPPING;
// #define  AR_DRAW_TEXTURE_FULL_IMAGE   0
#pragma push_macro( "AR_DRAW_TEXTURE_FULL_IMAGE" )
#undef AR_DRAW_TEXTURE_FULL_IMAGE
static const int AR_DRAW_TEXTURE_FULL_IMAGE
#pragma pop_macro( "AR_DRAW_TEXTURE_FULL_IMAGE" )
	= AR_DRAW_TEXTURE_FULL_IMAGE;
// #define  AR_DRAW_TEXTURE_HALF_IMAGE   1
#pragma push_macro( "AR_DRAW_TEXTURE_HALF_IMAGE" )
#undef AR_DRAW_TEXTURE_HALF_IMAGE
static const int AR_DRAW_TEXTURE_HALF_IMAGE
#pragma pop_macro( "AR_DRAW_TEXTURE_HALF_IMAGE" )
	= AR_DRAW_TEXTURE_HALF_IMAGE;
// #define  AR_IMAGE_PROC_IN_FULL        0
#pragma push_macro( "AR_IMAGE_PROC_IN_FULL" )
#undef AR_IMAGE_PROC_IN_FULL
static const int AR_IMAGE_PROC_IN_FULL
#pragma pop_macro( "AR_IMAGE_PROC_IN_FULL" )
	= AR_IMAGE_PROC_IN_FULL;
// #define  AR_IMAGE_PROC_IN_HALF        1
#pragma push_macro( "AR_IMAGE_PROC_IN_HALF" )
#undef AR_IMAGE_PROC_IN_HALF
static const int AR_IMAGE_PROC_IN_HALF
#pragma pop_macro( "AR_IMAGE_PROC_IN_HALF" )
	= AR_IMAGE_PROC_IN_HALF;
// #define  AR_FITTING_TO_IDEAL          0
#pragma push_macro( "AR_FITTING_TO_IDEAL" )
#undef AR_FITTING_TO_IDEAL
static const int AR_FITTING_TO_IDEAL
#pragma pop_macro( "AR_FITTING_TO_IDEAL" )
	= AR_FITTING_TO_IDEAL;
// #define  AR_FITTING_TO_INPUT          1
#pragma push_macro( "AR_FITTING_TO_INPUT" )
#undef AR_FITTING_TO_INPUT
static const int AR_FITTING_TO_INPUT
#pragma pop_macro( "AR_FITTING_TO_INPUT" )
	= AR_FITTING_TO_INPUT;

// #define  AR_TEMPLATE_MATCHING_COLOR   0
#pragma push_macro( "AR_TEMPLATE_MATCHING_COLOR" )
#undef AR_TEMPLATE_MATCHING_COLOR
static const int AR_TEMPLATE_MATCHING_COLOR
#pragma pop_macro( "AR_TEMPLATE_MATCHING_COLOR" )
	= AR_TEMPLATE_MATCHING_COLOR;
// #define  AR_TEMPLATE_MATCHING_BW      1
#pragma push_macro( "AR_TEMPLATE_MATCHING_BW" )
#undef AR_TEMPLATE_MATCHING_BW
static const int AR_TEMPLATE_MATCHING_BW
#pragma pop_macro( "AR_TEMPLATE_MATCHING_BW" )
	= AR_TEMPLATE_MATCHING_BW;
// #define  AR_MATCHING_WITHOUT_PCA      0
#pragma push_macro( "AR_MATCHING_WITHOUT_PCA" )
#undef AR_MATCHING_WITHOUT_PCA
static const int AR_MATCHING_WITHOUT_PCA
#pragma pop_macro( "AR_MATCHING_WITHOUT_PCA" )
	= AR_MATCHING_WITHOUT_PCA;
// #define  AR_MATCHING_WITH_PCA         1
#pragma push_macro( "AR_MATCHING_WITH_PCA" )
#undef AR_MATCHING_WITH_PCA
static const int AR_MATCHING_WITH_PCA
#pragma pop_macro( "AR_MATCHING_WITH_PCA" )
	= AR_MATCHING_WITH_PCA;
// #define  DEFAULT_TEMPLATE_MATCHING_MODE     AR_TEMPLATE_MATCHING_COLOR
#pragma push_macro( "DEFAULT_TEMPLATE_MATCHING_MODE" )
#undef DEFAULT_TEMPLATE_MATCHING_MODE
static const int DEFAULT_TEMPLATE_MATCHING_MODE
#pragma pop_macro( "DEFAULT_TEMPLATE_MATCHING_MODE" )
	= DEFAULT_TEMPLATE_MATCHING_MODE;
// #define  DEFAULT_MATCHING_PCA_MODE          AR_MATCHING_WITHOUT_PCA
#pragma push_macro( "DEFAULT_MATCHING_PCA_MODE" )
#undef DEFAULT_MATCHING_PCA_MODE
static const int DEFAULT_MATCHING_PCA_MODE
#pragma pop_macro( "DEFAULT_MATCHING_PCA_MODE" )
	= DEFAULT_MATCHING_PCA_MODE;


////#ifdef __linux
////#  ifdef AR_INPUT_V4L
////#    define   VIDEO_MODE_PAL              0
////#    define   VIDEO_MODE_NTSC             1
////#    define   VIDEO_MODE_SECAM            2
////#    define   DEFAULT_VIDEO_DEVICE        "/dev/video0"
////#    define   DEFAULT_VIDEO_WIDTH         640
////#    define   DEFAULT_VIDEO_HEIGHT        480
////#    define   DEFAULT_VIDEO_CHANNEL       1
////#    define   DEFAULT_VIDEO_MODE          VIDEO_MODE_NTSC
////#  endif
////
////#  ifdef AR_INPUT_DV
/////* Defines all moved into video.c now - they are not used anywhere else */
////#  endif
////
////#  ifdef AR_INPUT_1394CAM
/////* Defines all moved into video.c now - they are not used anywhere else */
////#  endif
////
////#  define   DEFAULT_IMAGE_PROC_MODE     AR_IMAGE_PROC_IN_FULL
////#  define   DEFAULT_FITTING_MODE        AR_FITTING_TO_IDEAL
////#  define   DEFAULT_DRAW_MODE           AR_DRAW_BY_TEXTURE_MAPPING
////#  define   DEFAULT_DRAW_TEXTURE_IMAGE  AR_DRAW_TEXTURE_HALF_IMAGE
////#endif

////#ifdef __sgi
////#  define   VIDEO_FULL                  0
////#  define   VIDEO_HALF                  1
////#  define   DEFAULT_VIDEO_SIZE          VIDEO_FULL
////#  define   DEFAULT_IMAGE_PROC_MODE     AR_IMAGE_PROC_IN_FULL
////#  define   DEFAULT_FITTING_MODE        AR_FITTING_TO_INPUT
////#  define   DEFAULT_DRAW_MODE           AR_DRAW_BY_GL_DRAW_PIXELS
////#  define   DEFAULT_DRAW_TEXTURE_IMAGE  AR_DRAW_TEXTURE_HALF_IMAGE
////#endif

////#ifdef _WIN32
// #  define   DEFAULT_IMAGE_PROC_MODE     AR_IMAGE_PROC_IN_FULL
#pragma push_macro( "DEFAULT_IMAGE_PROC_MODE" )
#undef DEFAULT_IMAGE_PROC_MODE
static const int DEFAULT_IMAGE_PROC_MODE
#pragma pop_macro( "DEFAULT_IMAGE_PROC_MODE" )
	= DEFAULT_IMAGE_PROC_MODE;
// #  define   DEFAULT_FITTING_MODE        AR_FITTING_TO_INPUT
#pragma push_macro( "DEFAULT_FITTING_MODE" )
#undef DEFAULT_FITTING_MODE
static const int DEFAULT_FITTING_MODE
#pragma pop_macro( "DEFAULT_FITTING_MODE" )
	= DEFAULT_FITTING_MODE;
// #  define   DEFAULT_DRAW_MODE           AR_DRAW_BY_TEXTURE_MAPPING
#pragma push_macro( "DEFAULT_DRAW_MODE" )
#undef DEFAULT_DRAW_MODE
static const int DEFAULT_DRAW_MODE
#pragma pop_macro( "DEFAULT_DRAW_MODE" )
	= DEFAULT_DRAW_MODE;
// #  define   DEFAULT_DRAW_TEXTURE_IMAGE  AR_DRAW_TEXTURE_FULL_IMAGE
#pragma push_macro( "DEFAULT_DRAW_TEXTURE_IMAGE" )
#undef DEFAULT_DRAW_TEXTURE_IMAGE
static const int DEFAULT_DRAW_TEXTURE_IMAGE
#pragma pop_macro( "DEFAULT_DRAW_TEXTURE_IMAGE" )
	= DEFAULT_DRAW_TEXTURE_IMAGE;
////#endif

////#ifdef __APPLE__
////#  define   DEFAULT_VIDEO_WIDTH         640
////#  define   DEFAULT_VIDEO_HEIGHT        480
////#  define   DEFAULT_IMAGE_PROC_MODE     AR_IMAGE_PROC_IN_FULL
////#  define   DEFAULT_FITTING_MODE        AR_FITTING_TO_IDEAL
////#  define   DEFAULT_DRAW_MODE           AR_DRAW_BY_TEXTURE_MAPPING
////#  define   DEFAULT_DRAW_TEXTURE_IMAGE  AR_DRAW_TEXTURE_FULL_IMAGE
////#undef    APPLE_TEXTURE_FAST_TRANSFER
////#endif


/*  For NVIDIA OpenGL Driver  */
////#undef    AR_OPENGL_TEXTURE_RECTANGLE



////#if (AR_DEFAULT_PIXEL_FORMAT == AR_PIXEL_FORMAT_ABGR) || (AR_DEFAULT_PIXEL_FORMAT == AR_PIXEL_FORMAT_BGRA) || (AR_DEFAULT_PIXEL_FORMAT == AR_PIXEL_FORMAT_RGBA) || (AR_DEFAULT_PIXEL_FORMAT == AR_PIXEL_FORMAT_ARGB)
// #  define AR_PIX_SIZE_DEFAULT      4
#pragma push_macro( "AR_PIX_SIZE_DEFAULT" )
#undef AR_PIX_SIZE_DEFAULT
static const int AR_PIX_SIZE_DEFAULT
#pragma pop_macro( "AR_PIX_SIZE_DEFAULT" )
	= AR_PIX_SIZE_DEFAULT;
////#elif (AR_DEFAULT_PIXEL_FORMAT == AR_PIXEL_FORMAT_BGR) || (AR_DEFAULT_PIXEL_FORMAT == AR_PIXEL_FORMAT_RGB)
////#  define AR_PIX_SIZE_DEFAULT      3
////#elif (AR_DEFAULT_PIXEL_FORMAT == AR_PIXEL_FORMAT_2vuy) || (AR_DEFAULT_PIXEL_FORMAT == AR_PIXEL_FORMAT_yuvs)
////#  define AR_PIX_SIZE_DEFAULT      2
////#elif (AR_DEFAULT_PIXEL_FORMAT == AR_PIXEL_FORMAT_MONO)
////#  define AR_PIX_SIZE_DEFAULT      1
////#else
////#  error Unknown default pixel format defined in config.h.
////#endif


// #define   AR_GET_TRANS_MAT_MAX_LOOP_COUNT         5
#pragma push_macro( "AR_GET_TRANS_MAT_MAX_LOOP_COUNT" )
#undef AR_GET_TRANS_MAT_MAX_LOOP_COUNT
static const int AR_GET_TRANS_MAT_MAX_LOOP_COUNT
#pragma pop_macro( "AR_GET_TRANS_MAT_MAX_LOOP_COUNT" )
	= AR_GET_TRANS_MAT_MAX_LOOP_COUNT;
// #define   AR_GET_TRANS_MAT_MAX_FIT_ERROR          1.0
#pragma push_macro( "AR_GET_TRANS_MAT_MAX_FIT_ERROR" )
#undef AR_GET_TRANS_MAT_MAX_FIT_ERROR
static const float AR_GET_TRANS_MAT_MAX_FIT_ERROR
#pragma pop_macro( "AR_GET_TRANS_MAT_MAX_FIT_ERROR" )
	= AR_GET_TRANS_MAT_MAX_FIT_ERROR;
// #define   AR_GET_TRANS_CONT_MAT_MAX_FIT_ERROR     1.0
#pragma push_macro( "AR_GET_TRANS_CONT_MAT_MAX_FIT_ERROR" )
#undef AR_GET_TRANS_CONT_MAT_MAX_FIT_ERROR
static const float AR_GET_TRANS_CONT_MAT_MAX_FIT_ERROR
#pragma pop_macro( "AR_GET_TRANS_CONT_MAT_MAX_FIT_ERROR" )
	= AR_GET_TRANS_CONT_MAT_MAX_FIT_ERROR;

// #define   AR_AREA_MAX      100000
#pragma push_macro( "AR_AREA_MAX" )
#undef AR_AREA_MAX
static const int AR_AREA_MAX
#pragma pop_macro( "AR_AREA_MAX" )
	= AR_AREA_MAX;
// #define   AR_AREA_MIN          70
#pragma push_macro( "AR_AREA_MIN" )
#undef AR_AREA_MIN
static const int AR_AREA_MIN
#pragma pop_macro( "AR_AREA_MIN" )
	= AR_AREA_MIN;


// #define   AR_SQUARE_MAX        30
#pragma push_macro( "AR_SQUARE_MAX" )
#undef AR_SQUARE_MAX
static const int AR_SQUARE_MAX
#pragma pop_macro( "AR_SQUARE_MAX" )
	= AR_SQUARE_MAX;
// #define   AR_CHAIN_MAX      10000
#pragma push_macro( "AR_CHAIN_MAX" )
#undef AR_CHAIN_MAX
static const int AR_CHAIN_MAX
#pragma pop_macro( "AR_CHAIN_MAX" )
	= AR_CHAIN_MAX;
// #define   AR_PATT_NUM_MAX      50 
#pragma push_macro( "AR_PATT_NUM_MAX" )
#undef AR_PATT_NUM_MAX
static const int AR_PATT_NUM_MAX
#pragma pop_macro( "AR_PATT_NUM_MAX" )
	= AR_PATT_NUM_MAX;
// #define   AR_PATT_SIZE_X       16 
#pragma push_macro( "AR_PATT_SIZE_X" )
#undef AR_PATT_SIZE_X
static const int AR_PATT_SIZE_X
#pragma pop_macro( "AR_PATT_SIZE_X" )
	= AR_PATT_SIZE_X;
// #define   AR_PATT_SIZE_Y       16 
#pragma push_macro( "AR_PATT_SIZE_Y" )
#undef AR_PATT_SIZE_Y
static const int AR_PATT_SIZE_Y
#pragma pop_macro( "AR_PATT_SIZE_Y" )
	= AR_PATT_SIZE_Y;
// #define   AR_PATT_SAMPLE_NUM   64
#pragma push_macro( "AR_PATT_SAMPLE_NUM" )
#undef AR_PATT_SAMPLE_NUM
static const int AR_PATT_SAMPLE_NUM
#pragma pop_macro( "AR_PATT_SAMPLE_NUM" )
	= AR_PATT_SAMPLE_NUM;

// #define   AR_GL_CLIP_NEAR      50.0
#pragma push_macro( "AR_GL_CLIP_NEAR" )
#undef AR_GL_CLIP_NEAR
static const float AR_GL_CLIP_NEAR
#pragma pop_macro( "AR_GL_CLIP_NEAR" )
	= AR_GL_CLIP_NEAR;
// #define   AR_GL_CLIP_FAR     5000.0
#pragma push_macro( "AR_GL_CLIP_FAR" )
#undef AR_GL_CLIP_FAR
static const float AR_GL_CLIP_FAR
#pragma pop_macro( "AR_GL_CLIP_FAR" )
	= AR_GL_CLIP_FAR;

// #define   AR_HMD_XSIZE        640
#pragma push_macro( "AR_HMD_XSIZE" )
#undef AR_HMD_XSIZE
static const int AR_HMD_XSIZE
#pragma pop_macro( "AR_HMD_XSIZE" )
	= AR_HMD_XSIZE;
// #define   AR_HMD_YSIZE        480
#pragma push_macro( "AR_HMD_YSIZE" )
#undef AR_HMD_YSIZE
static const int AR_HMD_YSIZE
#pragma pop_macro( "AR_HMD_YSIZE" )
	= AR_HMD_YSIZE;

// #define   AR_PARAM_NMIN         6
#pragma push_macro( "AR_PARAM_NMIN" )
#undef AR_PARAM_NMIN
static const int AR_PARAM_NMIN
#pragma pop_macro( "AR_PARAM_NMIN" )
	= AR_PARAM_NMIN;
// #define   AR_PARAM_NMAX      1000
#pragma push_macro( "AR_PARAM_NMAX" )
#undef AR_PARAM_NMAX
static const int AR_PARAM_NMAX
#pragma pop_macro( "AR_PARAM_NMAX" )
	= AR_PARAM_NMAX;
// #define   AR_PARAM_C34        100.0
#pragma push_macro( "AR_PARAM_C34" )
#undef AR_PARAM_C34
static const float AR_PARAM_C34
#pragma pop_macro( "AR_PARAM_C34" )
	= AR_PARAM_C34;

////#endif
