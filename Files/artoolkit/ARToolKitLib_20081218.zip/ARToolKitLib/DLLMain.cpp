///////////////////////////////////////////////////////////////
// OpenCVDotNetLib
///////////////////////////////////////////////////////////////


// Windows�v���b�g�t�H�[���֘A�̐錾
#include <windows.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <math.h>

#include <psapi.h>
#include <locale.h>
#include <errno.h>
#include <imagehlp.h>
#pragma comment(lib, "psapi.lib" )
#pragma comment(lib, "imagehlp.lib" )

///////////////////////////////////////////////////////////////

#define UNAME(name)			UnmanagedARToolKit::##name	// �A���}�l�[�W���ɕϊ�
#define MNAME(name)			name						// �}�l�[�W���ɕϊ�
#define LNAME(name)			AR##name					// ���C�u�����ŗL�̖��̂ɕϊ�
#include "NativeWrapper.h"
#include "NativeWrappercore.h"

///////////////////////////////////////////////////////////////
// �A���}�l�[�W��
#pragma unmanaged
namespace UnmanagedARToolKit
{

	// OpenCV�֘A�̃w�b�_
	#pragma warning( push )
	#pragma warning( disable : 4819 )
	#include <AR\\param.h>
	#include <AR\\matrix.h>
	#include <AR\\arMulti.h>
	#include <AR\\gsub.h>
	#include <AR\\video.h>
	#include <AR\\ar.h>
	#pragma warning( pop )

	// �����N���郉�C�u����
	#pragma comment( lib, "libAR.lib" )
	#pragma comment( lib, "libARgsub.lib" )
//	#pragma comment( lib, "libARgsubUtil.lib" )
	#pragma comment( lib, "libARMulti.lib" )
	#pragma comment( lib, "libARvideo.lib" )
//	#pragma comment( lib, "libARvrml.lib" )

	// LNK4248�΍�
	struct _AR2VideoParamT {};


	// �ϊ��p��`
	typedef void (*ARGSUBMouseFunc)(int button, int state, int x, int y);
	typedef void (*ARGSUBKeyFunc)(unsigned char key, int x, int y);
	typedef void (*ARGSUBMainFunc)(void);
}

///////////////////////////////////////////////////////////////
// �}�l�[�W��
#pragma managed

public ref class ManagedARToolKit abstract // sealed
{
public:

#include "Managed_config.h"
#include "Managed_param.h"
#include "Managed_matrix.h"
#include "Managed_ar.h"
#include "Managed_video.h"
#include "Managed_gsub.h"
#include "Managed_arMulti.h"

#include "Managed_utility.h"

};

