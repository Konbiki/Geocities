﻿Option Explicit On
Option Strict On

Imports ManagedARToolKit
Imports ManagedOpenCV

Module Module1

    Private Const DATAPATH As String = "C:\Dev\ARToolKit\bin\Data\"
    Private Const VIDEOCONFFILE As String = DATAPATH + "WDM_camera_flipV.xml"
    Private Const CAMERAPARAMFILE As String = DATAPATH + "camera_para.dat"
    Private Const PATTERNFILE As String = DATAPATH + "\patt.hiro"


    Sub Main()

        'デバッグ時はTraceへの出力をコンソールにも出力する
        Trace.Listeners.Add(New TextWriterTraceListener(System.Console.Out))

        AR_Initialize()

        Dim cap As CvCapture = cvCaptureFromCAM(0)
        Dim img As IplImage = cvQueryFrame(cap)
        Debug.Print("Capture Size = {0},{1}", img.width, img.height)
        Dim img2 As IplImage
        img2 = cvCreateImage(cvSize_(img.width, img.height), IPL_DEPTH_8U, 4)

        cvNamedWindow("image", CV_WINDOW_AUTOSIZE)

        Do
            img = cvQueryFrame(cap)
            If img Is Nothing Then Exit Do
            cvShowImage("image", img)

            cvCvtColor(img, img2, CV_BGR2BGRA)

            Dim marker As ARMarkerInfo = Nothing
            Dim markercnt As Integer = 0
            If arDetectMarker(img2.imageData.Ptr, 100, marker, markercnt) < 0 Then
                Debug.Print("arDetectMarker() failed")
                Exit Do
            End If
            If markercnt > 0 Then
                Debug.Print("markercnt = {0}", markercnt)
            End If

            Dim choicemarker As Integer = -1
            Dim markers() As ARMarkerInfo = marker.GetArray(markercnt)
            For x As Integer = 0 To markercnt - 1
                If markers(x).id = mPatternID Then
                    If choicemarker < 0 Then
                        choicemarker = x
                    ElseIf markers(x).cf > markers(choicemarker).cf Then
                        choicemarker = x
                    End If
                End If
            Next

            If choicemarker > 0 Then

                Dim patcenter(1) As Double
                Dim patsize As Double
                Dim pattrans(2, 3) As Double
                arGetTransMat(markers(choicemarker), patcenter, patsize, pattrans)

                Debug.Print("--")
                Dim ss As New System.Text.StringBuilder
                For y As Integer = 0 To 2
                    ss.Length = 0
                    For x As Integer = 0 To 3
                        ss.AppendFormat("{0,8} ", pattrans(y, x))
                    Next
                    Debug.Print("{0}", ss.ToString)
                Next

            End If


            If cvWaitKey(10) > 0 Then Exit Do
        Loop

        cvReleaseCapture(cap)
        cvDestroyWindow("image")

    End Sub

    Dim mPatternID As Integer = 0

    Function AR_Initialize() As Boolean

        Dim sx As Integer = 640
        Dim sy As Integer = 480

        Dim loadparam As New ARParam
        If arParamLoad(CAMERAPARAMFILE, 1, loadparam) < 0 Then
            Debug.Print("arParamLoad() failed : {0}", CAMERAPARAMFILE)
            Return True
        End If

        Dim cameraparam As New ARParam
        arParamChangeSize(loadparam, sx, sy, cameraparam)

        arInitCparam(cameraparam)
        arParamDisp(cameraparam)

        mPatternID = arLoadPatt(PATTERNFILE)
        If mPatternID < 0 Then
            Debug.Print("arLoadPatt failed : {0}", PATTERNFILE)
            Return True
        End If
        Debug.Print("mPatternID = {0}", mPatternID)
        Return False
    End Function


End Module
