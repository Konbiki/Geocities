﻿Option Explicit On
Option Strict On

'・このプログラムは、ARToolKitのサンプル simple を移植したものです。
'・元のソースにできるだけ近い形で移植していますが、
'　日本語コメントを追加してあります。
'・3D描画には元サンプル同様にOpenGLを使用しています。
'　OpenGL部分については別途当方で公開しているOpenGLLib.dllを使用しています。

'「ARToolKitLib.dll」と「OpenGLLib.dll」を参照設定してください。
Imports ManagedARToolKit
Imports OpenGLLib

Module simpleTest

    'カメラ設定情報が格納されているファイル名
    Dim vconf As String = GetARToolKitInstallDirectory() + "\bin\data\WDM_camera_flipV.xml"

    Dim xsize, ysize As Integer     '画像サイズ
    Dim thresh As Integer = 100     'マーカー認識時の二値化しきい値
    Dim count As Integer = 0        'フレーム数

    'カメラパラメタが格納されているファイル名
    Dim cparam_name As String = GetARToolKitInstallDirectory() + "\bin\Data\camera_para.dat"
    Dim cparam As New ARParam       'カメラパラメタ

    'マーカーパターンが格納されているファイル名
    Dim patt_name As String = GetARToolKitInstallDirectory() + "\bin\data\patt.hiro"
    Dim patt_id As Integer                      'パターンID
    Dim patt_width As Double = 80.0             '発見パターンのサイズ(大きさ)
    Dim patt_center() As Double = {0.0, 0.0}    '発見パターンの中心位置
    Dim patt_trans(2, 3) As Double              '発見パターンの変換行列


    'プログラム開始位置
    Sub Main()

        'GLUT初期化処理（実は不要）
        Dim argc As Integer = 1
        Dim argv() As String = {My.Application.Info.ProductName}
        glutInit(argc, argv)

        '初期化処理
        init()

        'キャプチャ開始
        arVideoCapStart()

        'メインループ開始(復帰なし)
        argMainLoop(Nothing, keyEvent_Ptr, mainLoop_Ptr)

    End Sub


    'キーイベントハンドラ（キー入力時に呼び出される関数）
    Sub keyEvent(ByVal key As Byte, ByVal x As Integer, ByVal y As Integer)

        'quit if the ESC key is pressed
        'ESCキーが押されたら終了
        If key = &H1B Then
            Console.WriteLine("*** {0} (frame/sec)", count / arUtilTimer())
            cleanup()
            End
        End If

    End Sub
    Dim keyEvent_Ptr As New ARGSUBKeyFunc(AddressOf keyEvent)   'キーイベントハンドラのデリゲート

    'main loop
    'メインループ処理(argMainLoopから繰り返し呼び出される）
    Sub mainLoop()
        Dim dataPtr As ARUPointer                   'イメージデータのアドレス
        Dim marker_info As ARMarkerInfo = Nothing   '発見したマーカー情報
        Dim marker_num As Integer                   '発見したマーカーの数
        Dim j, k As Integer

        'grab a vide frame
        'カメラから１フレーム読み込み
        dataPtr = arVideoGetImage()
        If dataPtr.IsNull Then
            arUtilSleep(2)  '読み込み失敗時は2ms待機し、次のフレームへ
            Return
        End If
        If count = 0 Then arUtilTimerReset() 'フレームレート計算用のタイマーをリセット
        count += 1  'フレーム数加算

        argDrawMode2D()                 '２Ｄ描画モードへ
        argDispImage(dataPtr, 0, 0)     '読み込んだ画像を描画

        'detect the markers in the video frame  
        '画像からマーカーを検索
        If arDetectMarker(dataPtr, thresh, marker_info, marker_num) < 0 Then
            cleanup()   '検索に失敗した場合、終了
            End
        End If

        arVideoCapNext()    '次のフレームの準備

        'check for object visibility
        '発見されたマーカー情報の中で、最もスコアが大きい位置を選出
        Dim marker_info_arr() As ARMarkerInfo = marker_info.GetArray(marker_num)
        k = -1
        For j = 0 To marker_num - 1
            If patt_id = marker_info_arr(j).id Then
                If k = -1 Then
                    k = j   '初見のマーカー情報を仮選択
                ElseIf marker_info_arr(k).cf < marker_info_arr(j).cf Then
                    k = j   'よりスコアの大きいマーカー情報を選択
                End If
            End If
        Next
        If k = -1 Then
            argSwapBuffers() '見つからなかった場合、何もしないで次のフレームへ
            Return
        End If

        'get the transformation between the marker and the real camera
        'マーカーの位置情報(2D位置)から実際の位置情報(3D位置)へ変換する行列(マーカー変換行列)を取得
        arGetTransMat(marker_info_arr(k), patt_center, patt_width, patt_trans)

        draw()  'マーカー上にボックスを描画

        argSwapBuffers()    'バッファ切り替えを行い、画面を更新

    End Sub
    Dim mainLoop_Ptr As New ARGSUBMainFunc(AddressOf mainLoop)  'メインループ処理のデリゲート

    '初期化処理
    Sub init()

        Dim wparam As New ARParam

        'open the video path 
        'カメラの起動
        If arVideoOpen(vconf) < 0 Then
            End
        End If

        'find the size of the window
        '画像サイズを取得
        If arVideoInqSize(xsize, ysize) < 0 Then
            End
        End If
        Console.WriteLine("Image size (x,y) = ({0},{1})", xsize, ysize)

        'set the initial camera parameters
        'カメラパラメタを読み込む
        If arParamLoad(cparam_name, 1, wparam) < 0 Then
            Console.WriteLine("Camera parameter load error !!")
            End
        End If
        arParamChangeSize(wparam, xsize, ysize, cparam) '読み込んだカメラパラメタを画像サイズに合わせて調整
        arInitCparam(cparam)    'カメラを初期化
        Console.WriteLine("*** Camera Parameter ***")
        arParamDisp(cparam)     'カメラパラメタの表示

        'マーカーパターンの読み込み/登録
        patt_id = arLoadPatt(patt_name)
        If patt_id < 0 Then
            Console.WriteLine("pattern load error !!")  '
            End
        End If

        'open the graphics window
        '描画ウィンドウの準備
        argInit(cparam, 1.0, 0, 0, 0, 0)

    End Sub

    '後片付け処理
    Sub cleanup()
        arVideoCapStop()    '画像キャプチャの終了
        arVideoClose()      'カメラの停止
        argCleanup()        'その他画面関係の後処理
    End Sub

    'ボックスの描画処理
    Sub draw()
        Dim gl_para(15) As Double   '描画用の変換行列
        Dim mat_ambient() As Single = {0.0, 0.0, 1.0, 1.0}  'ボックスのアンビエント情報（色）
        Dim mat_flash() As Single = {0.0, 0.0, 1.0, 1.0}    'ボックスのスペキュラ情報（反射具合）
        Dim mat_flash_shiny() As Single = {50.0}            'ボックスの輝度情報（明るさ具合）

        Dim light_position() As Single = {100.0, -200.0, 200.0, 0.0}    'ライト位置
        Dim ambi() As Single = {0.1, 0.1, 0.1, 0.1}                     '環境光
        Dim lightZeroColor() As Single = {0.9, 0.9, 0.9, 0.1}           'ライト色

        argDrawMode3D()                 '３Ｄ描画モードへ
        argDraw3dCamera(0, 0)           '３Ｄ描画のビュー設定
        glClearDepth(1.0)               '深度バッファクリア時の値セット
        glClear(GL_DEPTH_BUFFER_BIT)    '深度バッファクリア
        glEnable(GL_DEPTH_TEST)         '深度テストを有効
        glDepthFunc(GL_LEQUAL)          '深度比較の方法設定

        ' load the camera transformation matrix
        'マーカー変換行列を描画用のモデル変換行列に変換
        argConvGlpara(patt_trans, gl_para)
        glMatrixMode(GL_MODELVIEW)      'ワールド変換行列を選択
        glLoadMatrixd(gl_para)          'ワールド変換行列を更新

        glEnable(GL_LIGHTING)           'ライト計算を有効
        glEnable(GL_LIGHT0)             'ライト０番を有効
        glLightfv(GL_LIGHT0, GL_POSITION, light_position)   'ライト位置の設定
        glLightfv(GL_LIGHT0, GL_AMBIENT, ambi)              'ライト環境色の設定
        glLightfv(GL_LIGHT0, GL_DIFFUSE, lightZeroColor)    'ライト色の設定
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_flash)          'ボックスのスペキュラ情報設定
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_flash_shiny)   'ボックスの輝度情報設定
        glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient)         'ボックスの色情報設定
        glMatrixMode(GL_MODELVIEW)      'ワールド変換行列を選択
        glTranslatef(0.0, 0.0, 25.0)    'Ｚ方向に原点を移動
        glutSolidCube(50.0)             'ボックスを描画

        glDisable(GL_LIGHTING)          'ライト計算を無効

        glDisable(GL_DEPTH_TEST)        '深度テストを無効
    End Sub


End Module
