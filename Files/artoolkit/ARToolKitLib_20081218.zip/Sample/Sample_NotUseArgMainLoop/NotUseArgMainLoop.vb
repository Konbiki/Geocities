﻿Option Explicit On
Option Strict On

'このサンプルは、
'　OpenCVでカメラから画像を取得し、
'　ARToolKitでマーカーを検索し、
'　OpenGLでカメラ画像及びマーカーオブジェクトを描画
'しています。
'ARToolKitのargMainLoopを使えばこんなに面倒なことをする必要はありませんが、
'argMainLoopを使いたくない場合のサンプルとして参考になれば幸いです。

'ARToolKitLib.dllとOpenCVLib???.dllとOpenGLLib.dllを参照設定してください。
Imports ManagedARToolKit
Imports ManagedOpenCV
Imports OpenGLLib

'System.Windows.FormとSystem.Drawingコンポーネントを参照設定してください。
'（コンソールアプリで作成しているため）
Imports System.Windows.Forms
Imports System.Drawing


Module NotUseArgMainLoop

    'カメラパラメタファイル名
    Private CAMERAPARAMFILE As String = GetARToolKitInstallDirectory() + "\bin\Data\camera_para.dat"

    'マーカーイメージファイル名
    Private MARKERIMAGEFILE As String = GetARToolKitInstallDirectory() + "\bin\data\patt.hiro"

    '二値化しきい値
    Private Const THRESHVALUE As Integer = 100

    '----------------------------------------------------------
    'メイン
    Sub Main()

        'カメラキャプチャの作成(カメラの準備)
        Dim cap As CvCapture
        cap = cvCreateCameraCapture(0) '0番のカメラを使用
        If cap Is Nothing Then
            Throw New Exception("カメラが使用できません。")
        End If

        '画像サイズの取得
        Dim sx As Integer, sy As Integer
        Dim img As IplImage
        img = cvQueryFrame(cap)
        sx = img.width
        sy = img.height

        '表示フォームの準備
        Dim frm As New Form
        frm.ClientSize = New Size(sx, sy)
        AddHandler frm.KeyDown, AddressOf OnKeyDown 'キー押下イベントハンドラ登録
        frm.Show()
        frm.Refresh()

        'OpenGL関連の初期化処理
        Dim hGL As IntPtr = GLHelper.StartOpenGL(frm.Handle)
        Dim g As Graphics = frm.CreateGraphics
        Dim hDC As IntPtr = g.GetHdc

        'カメラパラメタの準備
        Dim wparam As New ARParam
        If arParamLoad(CAMERAPARAMFILE, 1, wparam) < 0 Then
            Throw New Exception(String.Format("カメラパラメタファイルが読み込めません。- {0}", CAMERAPARAMFILE))
        End If
        Dim cparam As New ARParam
        arParamChangeSize(wparam, sx, sy, cparam)   'サイズに合わせて調整
        arInitCparam(cparam)                        '初期化
        Dim glcpara(15) As Double
        argConvGLcpara(cparam, AR_GL_CLIP_NEAR, AR_GL_CLIP_FAR, glcpara)    '描画用射影変換行列取得

        'マーカーの準備
        Dim patid As Integer = arLoadPatt(MARKERIMAGEFILE)
        If patid < 0 Then
            Throw New Exception(String.Format("マーカーイメージファイルが読み込めません。- {0}", MARKERIMAGEFILE))
        End If

        'メインループ
        Dim img_for_draw As IplImage = cvCreateImage(cvSize_(sx, sy), IPL_DEPTH_8U, 3)      '描画用イメージ
        Dim img_for_detect As IplImage = cvCreateImage(cvSize_(sx, sy), IPL_DEPTH_8U, 4)    '検索用イメージ
        Dim markers_ptr As ARMarkerInfo = Nothing   '検索されたマーカー情報の先頭
        Dim markers_cnt As Integer = 0              '検索されたマーカー情報の数
        Dim markers() As ARMarkerInfo               '検索された各マーカー情報
        Dim gltrans(15) As Double                   '描画用変換行列
        Do While frm.Created

            'キャプチャ
            img = cvQueryFrame(cap)
            cvCvtColor(img, img_for_draw, CV_BGR2RGB)       '描画用(BGR形式からRGB形式へ変換)
            cvCvtColor(img, img_for_detect, CV_BGR2BGRA)    '検索用画像生成(24bppから32bppへ変換)
            If img.origin = 0 Then cvFlip(img_for_detect) '上下反転

            '画像表示
            DrawImage(img_for_draw.imageData.Ptr, sx, sy)

            'マーカー検索
            If arDetectMarker(img_for_detect.imageData.Ptr, THRESHVALUE, markers_ptr, markers_cnt) < 0 Then
                Throw New Exception("マーカー検出で重大な問題が発生しました。")
            End If
            Dim idx As Integer = -1
            markers = markers_ptr.GetArray(markers_cnt)
            For x As Integer = 0 To markers_cnt - 1
                If markers(x).id = patid Then
                    If (idx < 0) OrElse (markers(x).cf > markers(idx).cf) Then
                        idx = x '最もスコアの高いマーカー候補を選出
                    End If
                End If
            Next

            If idx >= 0 Then
                '描画

                '変換行列の取得
                Dim center() As Double = {0, 0}
                Dim sz As Double = 80.0
                Dim trans(2, 3) As Double
                arGetTransMat(markers(idx), center, sz, trans)

                '変換行列の設定
                glMatrixMode(GL_PROJECTION)     '射影変換行列のリセット
                glLoadMatrixd(glcpara)
                argConvGlpara(trans, gltrans)   '変換行列を元にモデルビュー変換行列を設定
                glMatrixMode(GL_MODELVIEW)
                glLoadMatrixd(gltrans)

                '物体の描画
                DrawObject()

            End If

            '画面更新
            SwapBuffers(hDC)

            'メッセージ処理
            Application.DoEvents()
        Loop

        '後片付け
        frm.Close()

        g.ReleaseHdc(hDC)
        g.Dispose()
        GLHelper.EndOpenGL(hGL)

        cvReleaseCapture(cap)

    End Sub

    'フォームでキーが押された時の処理です。
    Private Sub OnKeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)

        'フォームを閉じる
        Dim frm As Form = TryCast(sender, Form)
        If frm IsNot Nothing Then
            frm.Close()
        End If

    End Sub

    'カメラ画像を描画します。
    Private Sub DrawImage(ByVal ImagePtr As IntPtr, ByVal SizeX As Integer, ByVal SizeY As Integer)

        Static tid As UInteger = 0

        If tid = 0 Then
            'テクスチャ未登録

            'テクスチャの登録処理
            glGenTextures(1, tid)
            glBindTexture(GL_TEXTURE_2D, tid)
            glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP)
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP)
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
            glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL)
        End If

        '描画処理
        glDisable(GL_DEPTH_TEST)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        glBindTexture(GL_TEXTURE_2D, tid)
        glEnable(GL_TEXTURE_2D)
        glPixelStorei(GL_UNPACK_ROW_LENGTH, SizeX)
        glDisable(GL_BLEND)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, SizeX, SizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, ImagePtr)
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0) : glVertex3f(-1, 1, 0)
        glTexCoord2f(1, 0) : glVertex3f(1, 1, 0)
        glTexCoord2f(1, 1) : glVertex3f(1, -1, 0)
        glTexCoord2f(0, 1) : glVertex3f(-1, -1, 0)
        glEnd()
        glDisable(GL_TEXTURE_2D)

    End Sub

    'マーカーの上に物体を描画します。
    Private Sub DrawObject()

        '描画物体の属性データ
        Dim mat_ambient() As Single = {0.0, 0.0, 1.0, 1.0}  'ボックスのアンビエント情報（色）
        Dim mat_flash() As Single = {0.0, 0.0, 1.0, 1.0}    'ボックスのスペキュラ情報（反射具合）
        Dim mat_flash_shiny() As Single = {50.0}            'ボックスの輝度情報（明るさ具合）
        Dim light_position() As Single = {100.0, -200.0, 200.0, 0.0}    'ライト位置
        Dim ambi() As Single = {0.1, 0.1, 0.1, 0.1}                     '環境光
        Dim lightZeroColor() As Single = {0.9, 0.9, 0.9, 0.1}           'ライト色


        glClear(GL_DEPTH_BUFFER_BIT)    '深度バッファクリア
        glEnable(GL_DEPTH_TEST)         '深度テストを有効
        glDepthFunc(GL_LEQUAL)          '深度比較の方法設定

        glEnable(GL_LIGHTING)           'ライト計算を有効
        glEnable(GL_LIGHT0)             'ライト０番を有効
        glLightfv(GL_LIGHT0, GL_POSITION, light_position)   'ライト位置の設定
        glLightfv(GL_LIGHT0, GL_AMBIENT, ambi)              'ライト環境色の設定
        glLightfv(GL_LIGHT0, GL_DIFFUSE, lightZeroColor)    'ライト色の設定
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_flash)          'ボックスのスペキュラ情報設定
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_flash_shiny)   'ボックスの輝度情報設定
        glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient)         'ボックスの色情報設定
        glMatrixMode(GL_MODELVIEW)      'ワールド変換行列を選択
        glTranslatef(0.0, 0.0, 15.0)    'Ｚ方向に原点を移動（ティーポットの中心をマーカーのちょっと上にする）
        glRotatef(90, 1, 0, 0)          'Ｘ軸を９０度回転（そのままだとティーポットが倒れているため）
        glutSolidTeapot(30.0)           'ティーポットの描画
        glDisable(GL_LIGHTING)          'ライト計算を無効
        glDisable(GL_DEPTH_TEST)        '深度テストを無効

    End Sub

End Module
