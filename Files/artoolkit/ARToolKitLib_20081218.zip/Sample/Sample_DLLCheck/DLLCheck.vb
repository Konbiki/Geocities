﻿Option Explicit On
Option Strict On

'ARToolKitLib.dllが動作できるかどうかを確認するためのサンプルです。
'ARToolKitLib.dllを使う最低限のコード例になります。


'ManagedARToolKitをインポートするには、
'「参照の追加」で「ARToolKitLib.dll」を追加する必要があります。
Imports ManagedARToolKit

Module DLLCheck

    Sub Main()

        Console.WriteLine("DLL Check (ARToolKitLib.dll)")

        'バージョン名の取得
        Dim ver As String = ""
        arGetVersion(ver)
        Console.WriteLine("Version : {0}", ver)

        'インストールフォルダの取得
        Console.WriteLine("Install Path : {0}", GetARToolKitInstallDirectory)

        'キー入力待ち
        Console.WriteLine()
        Console.WriteLine("エンターキーを押してください。")
        Console.ReadLine()

    End Sub

End Module
