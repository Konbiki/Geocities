﻿Option Explicit On
Option Strict On

'・このプログラムは、ARToolKitのサンプル simple を移植したものです。
'・元のソースにできるだけ近い形で移植していますが、
'　日本語コメントを追加してあります。
'・3D描画には元サンプル同様にOpenGLを使用しています。
'　OpenGL部分については別途当方で公開しているOpenGLLib.dllを使用しています。

'「ARToolKitLib.dll」と「OpenGLLib.dll」を参照設定してください。
Imports ManagedARToolKit
Imports OpenGLLib

Module multiTest

    'カメラ設定情報が格納されているファイル名
    Dim vconf As String = GetARToolKitInstallDirectory() + "\bin\data\WDM_camera_flipV.xml"

    Dim xsize, ysize As Integer     '画像サイズ
    Dim thresh As Integer = 100     'マーカー認識時の二値化しきい値
    Dim count As Integer = 0        'フレーム数

    'カメラパラメタが格納されているファイル名
    Dim cparam_name As String = GetARToolKitInstallDirectory() + "\bin\Data\camera_para.dat"
    Dim cparam As New ARParam       'カメラパラメタ

    Dim config_name As String = GetARToolKitInstallDirectory() + "\bin\Data\multi\marker.dat"
    Dim config As ARMultiMarkerInfoT


    Sub Main()

        'GLUT初期化処理（実は不要）
        Dim argc As Integer = 1
        Dim argv() As String = {My.Application.Info.ProductName}
        glutInit(argc, argv)

        '初期化処理
        init()

        'キャプチャ開始
        arVideoCapStart()

        argMainLoop(Nothing, keyEvent_Ptr, mainLoop_ptr)

    End Sub

    'キーイベントハンドラ（キー入力時に呼び出される関数）
    Sub keyEvent(ByVal key As Byte, ByVal x As Integer, ByVal y As Integer)

        If key = &H1B Then
            Console.WriteLine("*** {0} (frame/sec)", CSng(count) / arUtilTimer())
            cleanup()
            End
        End If

        If key = Asc("t") Then
            Console.WriteLine("*** {0} (frame/sec)", CSng(count) / arUtilTimer())
            Console.Write("Enter new threshold value (current = {0}): ", thresh)
            Dim newvalue As String = Console.ReadLine()
            Integer.TryParse(newvalue, thresh)
            count = 0
        End If

        'turn on and off the debug mode with right mouse
        If key = Asc("d") Then
            Console.WriteLine("*** {0} (frame/sec)", CSng(count) / arUtilTimer())
            arDebug = 1 - arDebug
            If arDebug = 0 Then
                glClearColor(0.0, 0.0, 0.0, 0.0)
                glClear(GL_COLOR_BUFFER_BIT)
                argSwapBuffers()
                glClear(GL_COLOR_BUFFER_BIT)
                argSwapBuffers()
            End If
            count = 0
        End If

    End Sub
    Dim keyEvent_Ptr As New ARGSUBKeyFunc(AddressOf keyEvent)   'キーイベントハンドラのデリゲート

    'main loop
    'メインループ処理(argMainLoopから繰り返し呼び出される）
    Sub mainLoop()
        Dim dataPtr As ARUPointer                   'イメージデータのアドレス
        Dim marker_info As ARMarkerInfo = Nothing   '発見したマーカー情報
        Dim marker_num As Integer                   '発見したマーカーの数
        Dim err As Double
        Dim i As Integer

        'grab a vide frame
        'カメラから１フレーム読み込み
        dataPtr = arVideoGetImage()
        If dataPtr.IsNull Then
            arUtilSleep(2)  '読み込み失敗時は2ms待機し、次のフレームへ
            Return
        End If
        If count = 0 Then arUtilTimerReset() 'フレームレート計算用のタイマーをリセット
        count += 1  'フレーム数加算

        'detect the markers in the video frame
        'マーカーを検索（arDetectMarkerLiteはエラー訂正機能がないがarDetectMarkerより高速）
        If arDetectMarkerLite(dataPtr, thresh, marker_info, marker_num) < 0 Then
            cleanup()
            End
        End If

        argDrawMode2D()
        If arDebug = 0 Then
            'イメージ描画（通常モード）

            argDispImage(dataPtr, 0, 0)
        Else
            'イメージ描画（デバッグモード）

            argDispImage(dataPtr, 1, 1)
            If arImageProcMode = AR_IMAGE_PROC_IN_HALF Then
                argDispHalfImage(arImage, 0, 0)
            Else
                argDispImage(arImage, 0, 0)
            End If

            glColor3f(1.0, 0.0, 0.0)
            glLineWidth(1.0)
            Dim marker_info_arr() As ARMarkerInfo = marker_info.GetArray(marker_num)
            For i = 0 To marker_num - 1
                argDrawSquare(marker_info_arr(i).vertexPtr, 0, 0)
            Next
            glLineWidth(1.0)
        End If

        arVideoCapNext()

        'マーカー検索（マルチパターン）
        err = arMultiGetTransMat(marker_info, marker_num, config)
        If err < 0 Then
            argSwapBuffers()
            Return
        End If
        Console.WriteLine("err = {0}", err)
        If err > 100.0 Then
            argSwapBuffers()
            Return
        End If

        '検索したマーカーの位置にボックスを描画
        argDrawMode3D()
        argDraw3dCamera(0, 0)
        glClearDepth(1.0)
        glClear(GL_DEPTH_BUFFER_BIT)
        Dim config_marker_arr() As ARMultiEachMarkerInfoT = config.marker.GetArray(config.marker_num)
        For i = 0 To config.marker_num - 1
            If config_marker_arr(i).visible >= 0 Then
                draw(config.transPtr, config_marker_arr(i).transPtr, 0)
            Else
                draw(config.transPtr, config_marker_arr(i).transPtr, 1)
            End If
        Next
        argSwapBuffers()

    End Sub
    Dim mainLoop_Ptr As New ARGSUBMainFunc(AddressOf mainLoop)  'メインループ処理のデリゲート

    '初期化処理
    Sub init()

        Dim wparam As New ARParam

        'open the video path 
        'カメラの起動
        If arVideoOpen(vconf) < 0 Then End

        'find the size of the window
        '画像サイズを取得
        If arVideoInqSize(xsize, ysize) < 0 Then End
        Console.WriteLine("Image size (x,y) = ({0},{1})", xsize, ysize)

        'set the initial camera parameters
        'カメラパラメタを読み込む
        If arParamLoad(cparam_name, 1, wparam) < 0 Then
            Console.WriteLine("Camera parameter load error !!")
            End
        End If
        arParamChangeSize(wparam, xsize, ysize, cparam) '読み込んだカメラパラメタを画像サイズに合わせて調整
        arInitCparam(cparam)    'カメラを初期化
        Console.WriteLine("*** Camera Parameter ***")
        arParamDisp(cparam)     'カメラパラメタの表示

        Dim cpath As String = My.Computer.FileSystem.CurrentDirectory
        My.Computer.FileSystem.CurrentDirectory = GetARToolKitInstallDirectory() + "\bin"
        'サンプルのmarker.datはパターンファイルを相対パスで指定しているため、
        'ファイルを正しく検索できるようにカレントフォルダを変更します。
        config = arMultiReadConfigFile(config_name)
        My.Computer.FileSystem.CurrentDirectory = cpath
        If config Is Nothing Then
            Console.WriteLine("config data load error !!")
            End
        End If

        'open the graphics window
        argInit(cparam, 1.0, 0, 2, 1, 0)
        arFittingMode = AR_FITTING_TO_IDEAL
        arImageProcMode = AR_IMAGE_PROC_IN_HALF
        argDrawMode = AR_DRAW_BY_TEXTURE_MAPPING
        argTexmapMode = AR_DRAW_TEXTURE_HALF_IMAGE

    End Sub

    '後片付け処理
    Sub cleanup()
        arVideoCapStop()    '画像キャプチャの終了
        arVideoClose()      'カメラの停止
        argCleanup()        'その他画面関係の後処理
    End Sub

    'ボックスを描画します。
    Sub draw(ByVal trans1 As ARUPointer, ByVal trans2 As ARUPointer, ByVal mode As Integer)

        Dim gl_para(15) As Double   '描画用の変換行列

        Dim mat_ambient() As Single = {0.0, 0.0, 1.0, 1.0}  '青ボックスのアンビエント情報（色）
        Dim mat_flash() As Single = {0.0, 0.0, 1.0, 1.0}    '青ボックスのスペキュラ情報（反射具合）
        Dim mat_flash_shiny() As Single = {50.0}            '青ボックスの輝度情報（明るさ具合）
        Dim mat_ambient1() As Single = {1.0, 0.0, 0.0, 1.0} '赤ボックスのアンビエント情報（色）
        Dim mat_flash1() As Single = {1.0, 0.0, 0.0, 1.0}   '赤ボックスのスペキュラ情報（反射具合）
        Dim mat_flash_shiny1() As Single = {50.0}           '赤ボックスの輝度情報（明るさ具合）

        Dim light_position() As Single = {100.0, -200.0, 200.0, 0.0}    'ライト位置
        Dim ambi() As Single = {0.1, 0.1, 0.1, 0.1}                     '環境光
        Dim lightZeroColor() As Single = {0.9, 0.9, 0.9, 0.1}           'ライト色

        argDrawMode3D()
        argDraw3dCamera(0, 0)
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LEQUAL)

        'load the camera transformation matrix
        glMatrixMode(GL_MODELVIEW)
        argConvGlpara(trans1, gl_para)
        glLoadMatrixd(gl_para)
        argConvGlpara(trans2, gl_para)
        glMultMatrixd(gl_para)

        If mode = 0 Then
            glEnable(GL_LIGHTING)
            glEnable(GL_LIGHT0)
            glLightfv(GL_LIGHT0, GL_POSITION, light_position)
            glLightfv(GL_LIGHT0, GL_AMBIENT, ambi)
            glLightfv(GL_LIGHT0, GL_DIFFUSE, lightZeroColor)
            glMaterialfv(GL_FRONT, GL_SPECULAR, mat_flash)
            glMaterialfv(GL_FRONT, GL_SHININESS, mat_flash_shiny)
            glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient)
        Else
            glEnable(GL_LIGHTING)
            glEnable(GL_LIGHT0)
            glLightfv(GL_LIGHT0, GL_POSITION, light_position)
            glLightfv(GL_LIGHT0, GL_AMBIENT, ambi)
            glLightfv(GL_LIGHT0, GL_DIFFUSE, lightZeroColor)
            glMaterialfv(GL_FRONT, GL_SPECULAR, mat_flash1)
            glMaterialfv(GL_FRONT, GL_SHININESS, mat_flash_shiny1)
            glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient1)
        End If

        glMatrixMode(GL_MODELVIEW)
        glTranslatef(0.0, 0.0, 25.0)
        If arDebug = 0 Then
            glutSolidCube(50.0)
        Else
            glutWireCube(50.0)
        End If
        glDisable(GL_LIGHTING)

        glDisable(GL_DEPTH_TEST)

    End Sub

End Module
