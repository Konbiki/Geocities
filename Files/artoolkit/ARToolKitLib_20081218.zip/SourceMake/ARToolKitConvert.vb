﻿Option Explicit On
Option Strict On

Imports System.IO

Module ARToolKitConvert

    '--------------------------------------------------------------

    ''' <summary>
    ''' ARToolKitソースを解析し、定義情報を取得します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Class ARToolKitConverter
        Implements IARToolKitConverter

        ''' <summary>変換対象のファイルのパスを保持します。</summary>
        Public SourcePath As String

        ''' <summary>変換後ファイルを出力するパスを保持します。</summary>
        Public OutputPath As String

        ''' <summary>手動変換データのリソース名を保持します。</summary>
        Public ConvertDataName As String

        '--------------------------

        ''' <summary>変換対象のファイル名を保持します。</summary>
        Public Shared SourceFiles() As String = _
            {"config.h", "param.h", "matrix.h", "ar.h", "video.h", "gsub.h", "arMulti.h"}

        ''' <summary>読み込まれた定義情報を保持します。</summary>
        Public SourceInfo As New List(Of ARToolKitSourceReader)

        ''' <summary>手動変換データを保持します。</summary>
        Public ConvertData As ManualConvertData

        '--------------------------

        ''' <summary>
        ''' 全てのファイルを変換します。
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub ConvertAll()

            '初期化
            SourceInfo.Clear()
            ConvertData = New ManualConvertData
            ConvertData.ReadConvertData(ConvertDataName)

            '環境表示
            Report("入力フォルダ：{0}", SourcePath)
            Report("出力フォルダ：{0}", OutputPath)

            '手動変換データの準備
            Report("手動変換：{0} {1}件", ConvertDataName, ConvertData.Dic.Count.ToString)

            'コード生成オブジェクト生成
            Dim maker As OpenCVCodeMaker = New OpenCVCodeMakerForCLI
            maker.Converter = Me

            '読込と解析
            Dim cc As ARToolKitSourceReader
            For Each fname As String In SourceFiles

                Report("---- read  {0}", fname)
                cc = New ARToolKitSourceReader
                cc.Converter = Me
                SourceInfo.Add(cc)
                cc.Load(SourcePath + fname)
            Next

            'コード生成と出力
            For Each src As ARToolKitSourceReader In SourceInfo

                Dim oname As String = "Managed_" + IO.Path.GetFileName(src.SourceFilename)
                Report("---- write {0}", oname)
                maker.MakeCode(src)
                maker.Save(OutputPath + oname)

            Next

            '手動変換の確認
            If ConvertData.Dic.Count > 0 Then
                Report("適用されなかった手動変換データがあります。(要確認)")
                For Each pp As KeyValuePair(Of String, String) In ConvertData.Dic
                    Report(vbTab + "{0}", pp.Key)
                Next
            End If

        End Sub

        '--------------------------

        ''' <summary>
        ''' 定義情報を検索します。
        ''' </summary>
        ''' <typeparam name="T"></typeparam>
        ''' <param name="Name"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function FindDefine(Of T As Class)(ByVal Name As String) As T Implements IARToolKitConverter.FindDefine

            For Each si As ARToolKitSourceReader In SourceInfo
                If si.Defines IsNot Nothing Then
                    For Each df As CSourceDefineInfo In si.Defines
                        Dim tp As T = TryCast(df, T)
                        If tp IsNot Nothing Then
                            If df.Name = Name Then
                                Return tp
                            End If
                        End If
                    Next
                End If
            Next

            Return Nothing
        End Function

        ''' <summary>
        ''' 定義情報を検索します。
        ''' </summary>
        ''' <param name="FindFunc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function FindDefine(ByVal FindFunc As IARToolKitConverter.FindDefineCompareDelegate, ByVal Param As Object) As CSourceDefineInfo Implements IARToolKitConverter.FindDefine

            For Each si As ARToolKitSourceReader In SourceInfo
                If si.Defines IsNot Nothing Then
                    For Each df As CSourceDefineInfo In si.Defines
                        If FindFunc(df, Param) Then
                            '終了
                            Return df
                        End If
                    Next
                End If
            Next

            Return Nothing
        End Function

        ''' <summary>
        ''' 手動変換データを返します。
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property ManualConvert() As ManualConvertData Implements IARToolKitConverter.ManualConvert
            Get
                Return ConvertData
            End Get
        End Property

        ''' <summary>
        ''' 警告等のメッセージを出力します。
        ''' </summary>
        ''' <param name="Msg"></param>
        ''' <remarks></remarks>
        Public Sub Report(ByVal Msg As String) Implements IARToolKitConverter.Report

            '出力
            Debug.Print("REPORT : {0}", Msg)
            If mWriter IsNot Nothing Then
                mWriter.WriteLine(Msg)
            End If

        End Sub

        '--------------------------
#Region "レポート関連"

        ''' <summary>レポートを書き出すファイルストリームを保持します。</summary>
        Private mFile As FileStream

        ''' <summary>レポート書き出しに使用するストリームライタを保持します。</summary>
        Private mWriter As StreamWriter

        ''' <summary>
        ''' レポートメッセージがファイルに出力されるようにします。
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub ReportOpen(ByVal Filename As String)

            mFile = New FileStream(Filename, FileMode.Create, FileAccess.Write)
            mWriter = New StreamWriter(mFile)

        End Sub

        ''' <summary>
        ''' レポートのファイル出力を終了します。
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub ReportClose()

            mWriter.Close()
            mFile.Close()

            mWriter = Nothing
            mFile = Nothing

        End Sub

        ''' <summary>
        ''' 書式指定でレポートを出力します。
        ''' </summary>
        ''' <param name="Fmt"></param>
        ''' <param name="Params"></param>
        ''' <remarks></remarks>
        Public Sub Report(ByVal Fmt As String, ByVal ParamArray Params() As String)

            'メッセージ作成
            Dim msg As String
            msg = String.Format(Fmt, Params)

            '出力
            Report(msg)

        End Sub

#End Region

    End Class

    ''' <summary>
    ''' 定義等の検索を行うメソッドのインターフェースです。
    ''' </summary>
    ''' <remarks></remarks>
    Public Interface IARToolKitConverter

        ''' <summary>
        ''' 定義情報検索時の比較用デリゲート関数です。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Delegate Function FindDefineCompareDelegate(ByVal DefInfo As CSourceDefineInfo, ByVal Param As Object) As Boolean

        ''' <summary>
        ''' 定義情報を検索します。
        ''' </summary>
        ''' <typeparam name="T"></typeparam>
        ''' <param name="Name"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Function FindDefine(Of T As Class)(ByVal Name As String) As T

        ''' <summary>
        ''' 定義情報を検索します。
        ''' </summary>
        ''' <param name="FindFunc"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Function FindDefine(ByVal FindFunc As FindDefineCompareDelegate, ByVal Param As Object) As CSourceDefineInfo

        ''' <summary>
        ''' 手動変換データを返します。
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ReadOnly Property ManualConvert() As ManualConvertData

        ''' <summary>
        ''' 警告等の情報を出力します。
        ''' </summary>
        ''' <param name="Msg"></param>
        ''' <remarks></remarks>
        Sub Report(ByVal Msg As String)

    End Interface

    '--------------------------------------------------------------

    ''' <summary>
    ''' ARToolKit用のソース読込クラスです。
    ''' </summary>
    ''' <remarks></remarks>
    Public Class ARToolKitSourceReader
        Inherits CSourceReader

        ''' <summary>ソースファイル名を保持します。</summary>
        Public SourceFilename As String

        ''' <summary>定義情報の検索を行うオブジェクトを保持します。</summary>
        Public Converter As IARToolKitConverter

        ''' <summary>ソースファイルの内容を行単位で保持します。</summary>
        Public SourceList As List(Of String)

        '----------------------------------------------------------

        ''' <summary>
        ''' ソースを読み込み、解析を行います。
        ''' </summary>
        ''' <param name="Filename"></param>
        ''' <remarks></remarks>
        Public Overrides Sub Load(ByVal Filename As String)

            '定義情報の読込
            SourceFilename = Filename
            MyBase.Load(Filename)

            'ソースの読込
            SourceList = New List(Of String)
            Open(Filename)
            Dim sr As New StreamReader(mSrcFile)
            Do While Not sr.EndOfStream
                SourceList.Add(sr.ReadLine())
            Loop
            Close()

        End Sub

        ''' <summary>
        ''' トークンリストに対するフィルタ処理を行います。
        ''' </summary>
        ''' <param name="TokenList"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Protected Overloads Overrides Function Filter(ByVal TokenList As CSourceTokenList) As CSourceTokenList

            Dim ret As New CSourceTokenList
            TokenList.Rewind()
            Dim tkn As CSourceToken
            Dim nexttkn As CSourceToken
            Do
                '次のトークン取り出し
                tkn = TokenList.Token
                If tkn Is Nothing Then Exit Do
                TokenList.MoveNext()

                '内部トークンのフィルタ処理
                If tkn.InnerTokenList IsNot Nothing Then
                    tkn.InnerTokenList = Filter(tkn.InnerTokenList)
                End If

                'フィルタ処理
                Select Case tkn.Text
                    Case "****"
                        '内部トークンを展開する

                        nexttkn = TokenList.Token
                        TokenList.MoveNext()
                        If nexttkn.Text <> "()" Then Stop '後に()がない

                        ret.Add(nexttkn.InnerTokenList)
                        Continue Do


                    Case "AR_DLL_API"
                        '上記マクロは削除する
                        Continue Do


                    Case "****"
                        ''='をつけて中身を展開する

                        nexttkn = TokenList.Token
                        TokenList.MoveNext()
                        If nexttkn.Text <> "()" Then Stop '後に()がない

                        ret.Add("=")
                        ret.Add(nexttkn.InnerTokenList)
                        Continue Do

                    Case "****"
                        '上記マクロは展開する

                        Dim md As CSourceDefineInfoDefineMacro
                        md = Converter.FindDefine(Of CSourceDefineInfoDefineMacro)(tkn.Text)
                        If md IsNot Nothing Then
                            'マクロが定義済み

                            nexttkn = TokenList.Token
                            TokenList.MoveNext()
                            If nexttkn IsNot Nothing Then
                                If nexttkn.Text <> "()" Then Stop '後に()がない

                                'マクロの内容を展開
                                ret.Add(md.GetExpandTokenList(nexttkn.InnerTokenList))

                                Continue Do
                            End If
                        End If

                End Select

                'リストに追加
                ret.Add(tkn)

            Loop

            Return ret
        End Function

    End Class

    '--------------------------------------------------------------

    ''' <summary>
    ''' ソースコードを生成するクラスの基底クラスです。
    ''' </summary>
    ''' <remarks></remarks>
    Public MustInherit Class OpenCVCodeMaker

        '----------------------------------------------------------

        ''' <summary>
        ''' コード生成時のフラグを定義したクラスです。
        ''' </summary>
        ''' <remarks></remarks>
        Public Class DefFlag

            ''' <summary>構造体定義でメンバが定義されていないことを表します。</summary>
            Public Const NoMember As String = "NoMember"

            ''' <summary>既に定義コードが出力されたことを表します。</summary>
            Public Const WasDefined As String = "WasDefined"

        End Class

        '----------------------------------------------------------

        ''' <summary>定義情報の検索を行うオブジェクトを保持します。</summary>
        Public Converter As IARToolKitConverter

        ''' <summary>生成されたソースコードを保持します。</summary>
        Public SourceList As New List(Of String)

        ''' <summary>コード生成時に、対象定義の出力の直前に挿入されるコードを保持します。</summary>
        Protected PreCode As New List(Of String)

        '----------------------------------------------------------

        ''' <summary>
        ''' 解析されたソース情報を元に新しいソースコードを生成します。
        ''' </summary>
        ''' <param name="SourceReader"></param>
        ''' <remarks></remarks>
        Public Overridable Sub MakeCode(ByVal SourceReader As ARToolKitSourceReader)

            'ソースのクリア
            SourceList.Clear()

            '生成処理
            Dim line As Integer = 1
            Dim idx As Integer = 0
            Do While line <= SourceReader.SourceList.Count

                '全ての定義文以降はそのまま出力する
                If SourceReader.Statements.Count <= idx Then
                    SourceList.Add(SourceReader.SourceList(line - 1))
                    line += 1
                    Continue Do
                End If

                '次の定義文まではそのまま出力する
                If line < SourceReader.Statements(idx).StartLine Then
                    SourceList.Add(SourceReader.SourceList(line - 1))
                    line += 1
                    Continue Do
                End If

                '定義文の部分はコメント化して出力する
                Dim st As CSourceStatement = SourceReader.Statements(idx)
                If line <= SourceReader.Statements(idx).EndLine Then
                    SourceList.Add(ToComment(SourceReader.SourceList(line - 1)))
                    If line < SourceReader.Statements(idx).EndLine Then
                        '定義の最終行まではコメント化出力のみ
                        line += 1
                        Continue Do
                    End If
                End If

                '現在位置の定義情報の検索
                Dim def As CSourceDefineInfo = Nothing
                For Each df As CSourceDefineInfo In SourceReader.Defines
                    If df.SourceStatement.EndLine = line Then
                        def = df
                        Exit For
                    End If
                Next
                If def Is Nothing Then Stop '定義情報が見付からない

                '変換コードの出力
                If TypeOf def Is CSourceDefineInfoUnknown Then
                    Report(ReportType.Error, "解析出来なかった文があります。{0}", def.ToString)
                Else

                    '変換コード生成
                    CreateSourceCode(def)

                End If

                '次へ
                line += 1
                idx += 1
            Loop

        End Sub

        ''' <summary>
        ''' コードリストに行を追加します。
        ''' </summary>
        ''' <param name="Text"></param>
        ''' <remarks></remarks>
        Public Sub AddSource(ByVal Text As String)
            SourceList.Add(Text)
        End Sub

        ''' <summary>
        ''' コードリストに行を追加します。
        ''' </summary>
        ''' <param name="Fmt"></param>
        ''' <param name="Params"></param>
        ''' <remarks></remarks>
        Public Sub AddSource(ByVal Fmt As String, ByVal ParamArray Params() As Object)

            'フォーマット文字列内の{}をエスケープ
            Dim wk As String = Fmt
            wk = wk.Replace("{0}", "___$0$___")
            wk = wk.Replace("{1}", "___$1$___")
            wk = wk.Replace("{2}", "___$2$___")
            wk = wk.Replace("{3}", "___$3$___")
            wk = wk.Replace("{4}", "___$4$___")
            wk = wk.Replace("{5}", "___$5$___")
            wk = wk.Replace("{6}", "___$6$___")
            wk = wk.Replace("{7}", "___$7$___")
            wk = wk.Replace("{8}", "___$8$___")
            wk = wk.Replace("{9}", "___$9$___")
            wk = wk.Replace("{", "{{")
            wk = wk.Replace("}", "}}")
            wk = wk.Replace("___$", "{")
            wk = wk.Replace("$___", "}")

            AddSource(String.Format(wk, Params))
        End Sub

        ''' <summary>
        ''' 空白でない場合のみコードリストに行を追加します。
        ''' </summary>
        ''' <param name="Text"></param>
        ''' <remarks></remarks>
        Public Sub AddSourceWithoutNull(ByVal Text As String)
            If Text <> "" Then
                AddSource(Text)
            End If
        End Sub

        ''' <summary>
        ''' 文字列をコメント文にします。
        ''' </summary>
        ''' <param name="Text"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public MustOverride Function ToComment(ByVal Text As String) As String

        ''' <summary>
        ''' 生成したコードをファイルに出力します。
        ''' </summary>
        ''' <param name="Filename"></param>
        ''' <remarks></remarks>
        Public Overridable Sub Save(ByVal Filename As String)

            'ファイルオープン
            Dim fs As New FileStream(Filename, FileMode.Create)
            Dim sw As New StreamWriter(fs, System.Text.Encoding.GetEncoding("Shift_JIS"))

            '出力
            For Each ss As String In SourceList
                sw.WriteLine(ss)
            Next

            'ファイルクローズ
            sw.Close()
            fs.Close()

        End Sub

        '----------------------------------------------------------

        ''' <summary>レポートメッセージの種類を表す定数です。</summary>
        Public Enum ReportType
            ''' <summary>通常メッセージ</summary>
            Message = 0
            ''' <summary>警告メッセージ</summary>
            Warning = 1
            ''' <summary>注意メッセージ</summary>
            Caution = 2
            ''' <summary>エラーメッセージ</summary>
            [Error] = 3
        End Enum

        ''' <summary>
        ''' 警告メッセージなどを出力します。
        ''' </summary>
        ''' <param name="Fmt"></param>
        ''' <param name="Params"></param>
        ''' <remarks></remarks>
        Public Sub Report(ByVal MessageLevel As ReportType, ByVal Fmt As String, ByVal ParamArray Params() As Object)

            Dim msg As String = ""
            Select Case MessageLevel
                Case ReportType.Message
                    msg = "  : "
                Case ReportType.Caution
                    msg = "A : "
                Case ReportType.Warning
                    'Return '警告レベルは出力しない
                    msg = "W : "
                Case ReportType.Error
                    msg = "E : "
            End Select
            msg += String.Format(Fmt, Params)
            If Converter IsNot Nothing Then
                Converter.Report(msg)
            End If

        End Sub

        '----------------------------------------------------------

        ''' <summary>
        ''' 各定義別の変換コードを出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overridable Sub CreateSourceCode(ByVal DefInfo As CSourceDefineInfo)

            '直前挿入コードのクリア
            Dim sline As Integer = SourceList.Count
            PreCode.Clear()

            '変換コード出力
            If DefInfo Is Nothing Then
                Exit Sub
            ElseIf TypeOf DefInfo Is CSourceDefineInfoDefineMacro Then
                OutputSourceCode(CType(DefInfo, CSourceDefineInfoDefineMacro))
            ElseIf TypeOf DefInfo Is CSourceDefineInfoTypeDef Then
                OutputSourceCode(CType(DefInfo, CSourceDefineInfoTypeDef))
            ElseIf TypeOf DefInfo Is CSourceDefineInfoFunction Then
                OutputSourceCode(CType(DefInfo, CSourceDefineInfoFunction))
            ElseIf TypeOf DefInfo Is CSourceDefineInfoTypePrototype Then
                OutputSourceCode(CType(DefInfo, CSourceDefineInfoTypePrototype))
            ElseIf TypeOf DefInfo Is CSourceDefineInfoVariable Then
                OutputSourceCode(CType(DefInfo, CSourceDefineInfoVariable))
            ElseIf TypeOf DefInfo Is CSourceDefineInfoUnknown Then
                OutputSourceCode(CType(DefInfo, CSourceDefineInfoUnknown))
            Else
                '不明な定義情報
                Stop
            End If

            '直前挿入コードの挿入
            SourceList.InsertRange(sline, PreCode)

        End Sub

        ''' <summary>
        ''' マクロ定義の変換コードを出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overridable Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoDefineMacro)
            AddSource("// Unsupport : {0}", DefInfo.ToString)
        End Sub

        ''' <summary>
        ''' 型定義の変換コード出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overridable Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoTypeDef)
            AddSource("// Unsupport : {0}", DefInfo.ToString)
        End Sub

        ''' <summary>
        ''' 関数定義の変換コード出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overridable Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoFunction)
            AddSource("// Unsupport : {0}", DefInfo.ToString)
            Report(ReportType.Caution, "変換処理が実装されていません。: {0}", DefInfo.ToString)
        End Sub

        ''' <summary>
        ''' 型プロトタイプ宣言の変換コード出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overridable Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoTypePrototype)
            AddSource("// Unsupport : {0}", DefInfo.ToString)
            Report(ReportType.Caution, "変換処理が実装されていません。: {0}", DefInfo.ToString)
        End Sub

        ''' <summary>
        ''' 変数定義の変換コード出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overridable Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoVariable)
            AddSource("// Unsupport : {0}", DefInfo.ToString)
            Report(ReportType.Caution, "変換処理が実装されていません。: {0}", DefInfo.ToString)
        End Sub

        ''' <summary>
        ''' 不明な文の変換コード出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overridable Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoUnknown)
            AddSource("// Unsupport : {0}", DefInfo.ToString)
            Report(ReportType.Caution, "変換処理が実装されていません。: {0}", DefInfo.ToString)
        End Sub

    End Class

    ''' <summary>
    ''' C++/CLI用のソースコードを書き出します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Class OpenCVCodeMakerForCLI
        Inherits OpenCVCodeMaker

        '----------------------------------------------------------
#Region "コード生成汎用"

        ''' <summary>
        ''' 文字列をコメント文にします。
        ''' </summary>
        ''' <param name="Text"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Overrides Function ToComment(ByVal Text As String) As String
            Return "// " + Text
        End Function

        ''' <summary>
        ''' 未サポート(サポート予定あり)の定義文を出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Public Sub ToDo(ByVal DefInfo As CSourceDefineInfo)
            AddSource("// ToDo : {0}", DefInfo.Name)
        End Sub

        ''' <summary>
        ''' 未サポート(サポート予定なし)の定義文を出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Public Sub Unsupport(ByVal DefInfo As CSourceDefineInfo)
            AddSource("// Unsupport : {0}", DefInfo.Name)
        End Sub

#End Region

        '----------------------------------------------------------
#Region "マクロ定義関連"

        ''' <summary>
        ''' マクロ定義の変換コードを出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overrides Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoDefineMacro)

            '手動変換チェック
            If CheckManualConvert("define.{0}", DefInfo.Name) Then
                Report(ReportType.Warning, "マクロ定義 {0} は、手動変換されました。", DefInfo.Name)
                Return
            End If

            '汎用処理
            If DefInfo.Params Is Nothing Then
                '引数のないマクロ

                '値の型を決定
                Dim tname As String = GetMacroValueType(DefInfo)

                '出力
                If tname <> "" Then

                    '定数定義用コードの出力
                    '(もちっとスマートなやり方ないかな）
                    AddSource("#pragma push_macro( ""{0}"" )", DefInfo.Name)
                    AddSource("#undef {0}", DefInfo.Name)
                    AddSource("static const {0} {1}", tname, DefInfo.Name)
                    AddSource("#pragma pop_macro( ""{0}"" )", DefInfo.Name)
                    AddSource(vbTab + "= {0};", DefInfo.Name)

                End If

            Else
                '引数のあるマクロ

                Unsupport(DefInfo)
                Report(ReportType.Warning, "引数付きマクロ '{0}' は変換されません。", DefInfo.Name)
            End If

        End Sub

        ''' <summary>
        ''' マクロ(定数)定義時の値の型を決定します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function GetMacroValueType(ByVal DefInfo As CSourceDefineInfoDefineMacro) As String

            If (DefInfo.Value IsNot Nothing) AndAlso (DefInfo.Value.Count = 1) Then
                '値が１トークンである

                Dim ss As String = DefInfo.Value.Text(0)

                '型の判断
                If ss.StartsWith("""") Then Return "String^" '文字列
                If ss.StartsWith("'") Then Return "int" '文字
                If ss.StartsWith("0x") Then Return "int" '16進数なので int
                If ss.EndsWith("f") Then Return "float" '単精度浮動小数点

                '数値データの型判断
                Dim vi As Integer
                If Integer.TryParse(ss, vi) Then Return "int"
                Dim vf As Single
                If Single.TryParse(ss, vf) Then Return "float"
                Dim vd As Double
                If Double.TryParse(ss, vd) Then Return "double"

                'マクロの再定義チェック
                Dim dm As CSourceDefineInfoDefineMacro
                Do
                    '値をマクロ名として検索
                    dm = Converter.FindDefine(Of CSourceDefineInfoDefineMacro)(ss)
                    If dm Is Nothing Then Exit Do '値はマクロ名ではない
                    If dm.Value Is Nothing Then
                        ss = ""
                        Exit Do '値がない
                    End If
                    If dm.Value.Count <> 1 Then Exit Do 'マクロの値が１トークンでない

                    '検索対象を検索した定義の値とし、再度マクロ名検索
                    ss = dm.Value.Text(0)
                Loop

                '値が関数名であった場合、関数の別名定義と判断し出力しない
                Dim df As CSourceDefineInfoFunction
                df = Converter.FindDefine(Of CSourceDefineInfoFunction)(ss) '関数検索
                If df IsNot Nothing Then
                    '値と同じ関数がある

                    If df.Flag(DefFlag.WasDefined) Then
                        '既に定義されている

                        '別名での定義文を出力
                        Report(ReportType.Warning, "マクロ定義 '{0}' は、関数 '{1}' の別名定義マクロと判断し、別名での定義を出力しました。", DefInfo.Name, df.Name)
                        Dim fwd As FunctionConvertWorkData = CType(df.ConvertWorkData, FunctionConvertWorkData)
                        AddSource("#pragma push_macro( ""{0}"" )", DefInfo.Name)
                        AddSource("#undef {0}", DefInfo.Name)
                        For Each pp As String In fwd.ParamList
                            AddSource("DEFINE_FUNCTION_ALIAS( {0}, {1}, {2}, {3} ) ", fwd.ReturnType, ss, DefInfo.Name, pp)
                        Next
                        AddSource("#pragma pop_macro( ""{0}"" )", DefInfo.Name)
                    Else
                        '関数の別名定義と判断されたが、関数が定義されていない

                        Unsupport(DefInfo)
                        Report(ReportType.Caution, "マクロ定義 '{0}' は、関数 '{1}' の別名定義マクロと判断しましたが、関数 '{1}' の定義が見付からない為出力出来ませんでした。", DefInfo.Name, df.Name)
                    End If
                    Return ""
                End If

                If ss <> "" Then
                    'その他はとりあえずint型とする（エラーが出たら手動変換）
                    Report(ReportType.Warning, "定数定義で値の型を特定出来ませんでした。int型と仮定します。{0}", DefInfo.Value.AllText)
                    Return "int"
                End If
            End If

            '空の定義
            Unsupport(DefInfo)
            Report(ReportType.Caution, "マクロ定義 '{0}' は値がない為無視されます。", DefInfo.Name)
            Return ""
        End Function

#End Region

        '----------------------------------------------------------
#Region "型定義関連"

        ''' <summary>
        ''' 型定義の変換コード出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overrides Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoTypeDef)

            '定義内容毎に処理
            Select Case DefInfo.MainDefine.DefineType
                Case "struct", "union"
                    OutputSourceCode_TypeDef_Struct(DefInfo)

                Case "enum"
                    OutputSourceCode_TypeDef_Enum(DefInfo)

                Case "function"
                    OutputSourceCode_TypeDef_Function(DefInfo)

                Case Else
                    '構造体でも共用体でも列挙型でもない
                    Unsupport(DefInfo)

            End Select
        End Sub

        '----------------------

#Region "構造体定義関連"

        ''' <summary>
        ''' 構造体の定義文を出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Sub OutputSourceCode_TypeDef_Struct(ByVal DefInfo As CSourceDefineInfoTypeDef)

            '定義済みにする（自己参照対策）
            DefInfo.Flag(DefFlag.WasDefined) = True

            'メンバ情報の確認
            If DefInfo.MainDefine.Member Is Nothing Then
                'メンバ情報のない定義

                If DefInfo.MainDefine.PointerLevel = 0 Then
                    'ハンドル型として定義文を出力
                    AddSource("DEFINE_HANDLE( {0} )", DefInfo.Name)
                ElseIf DefInfo.MainDefine.PointerLevel = 1 Then
                    'ハンドル型(ポインタタイプ)として定義文を出力
                    AddSource("DEFINE_HANDLEP( {0} )", DefInfo.Name)
                Else
                    '想定外の型
                    Stop
                End If
                Report(ReportType.Warning, "構造体 '{0}' はメンバが定義されていないためハンドル型として定義されます。", DefInfo.Name)

                'メンバなしのフラグをつける
                DefInfo.Flag(DefFlag.NoMember) = True
                Exit Sub
            End If

            '手動変換チェック
            CheckManualConvert("struct.{0}.before", DefInfo.Name)
            If CheckManualConvert("struct.{0}", DefInfo.Name) Then Return '手動定義

            '定義文出力開始
            AddSource("DEFINE_STRUCT( {0} )", DefInfo.Name)
            AddSource("{STRUCT_BASIC( {0} )", DefInfo.Name) '構造体基本セット

            '各メンバの定義文を出力
            For Each vv As CSourceVarInfo In DefInfo.MainDefine.Member

                If CheckManualConvert("struct.{0}.{1}", DefInfo.Name, vv.Name) Then
                    '手動変換

                Else
                    '自動変換

                    '自動的に生成されたコードを出力
                    OutputSourceCode_TypeDef_Struct_Member(DefInfo, vv)
                End If

            Next

            '手動変換チェック
            CheckManualConvert("struct.{0}.property.add", DefInfo.Name)

            '定義文出力終了
            AddSource("};")

        End Sub

        ''' <summary>
        ''' 構造体のメンバ定義文を出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <param name="VarInfo"></param>
        ''' <remarks></remarks>
        Protected Sub OutputSourceCode_TypeDef_Struct_Member(ByVal DefInfo As CSourceDefineInfoTypeDef, ByVal VarInfo As CSourceVarInfo)

            '型変換情報の取得
            Dim cinfo As TypeConvertInfo
            cinfo = GetStructMemberTypeConvertInfo(DefInfo, VarInfo)
            If cinfo Is Nothing Then
                '変換情報が見付からない

                AddSource("// Unsupport : {0}", VarInfo)
                Report(ReportType.Error, "構造体 '{0}' のメンバ '{1}' (型 '{2}') は型の変換が出来ない為、メンバ定義は出力されません。", DefInfo.Name, VarInfo.Name, VarInfo.GetTypeName())
                Exit Sub
            End If

            '定義文出力
            Select Case cinfo.TypeID
                Case "V", "VP", "VPP", "S", "SP", "P", "PC", "F"
                    AddSource(vbTab + "DEFINE_PROPERTY_{0}( {1}, {2} )", cinfo.TypeID, cinfo.TypeName, VarInfo.Name)

                Case "VA", "VPA", "SA", "SPA", "PA"
                    AddSource(vbTab + "DEFINE_PROPERTY_{0}( {1}, {2}, {3} )", cinfo.TypeID, cinfo.TypeName, VarInfo.Name, VarInfo.Dimension(0).AllText)

                Case "VA2"
                    AddSource(vbTab + "DEFINE_PROPERTY_{0}( {1}, {2}, {3}, {4} )", cinfo.TypeID, cinfo.TypeName, VarInfo.Name, VarInfo.Dimension(0).AllText, VarInfo.Dimension(1).AllText)

                Case "T"
                    AddSource(vbTab + "DEFINE_PROPERTY_{0}( {1} )", cinfo.TypeID, VarInfo.Name)

                Case Else
                    Stop

            End Select

            'プロトタイプ宣言の有無チェック
            Dim sd As CSourceDefineInfoTypeDef
            sd = Converter.FindDefine(Of CSourceDefineInfoTypeDef)(cinfo.TypeName)
            If sd IsNot Nothing Then
                If Not sd.Flag(DefFlag.WasDefined) Then
                    'まだ定義コードが出力されていない

                    'プロトタイプ宣言文を追加
                    Dim ss As String
                    ss = String.Format("DEFINE_STRUCT_PROTOTYPE( {0} )", sd.MainDefine.Name)
                    PreCode.Add(ss)

                End If
            End If

        End Sub

        ''' <summary>
        ''' 構造体メンバの型変換情報を決定します。
        ''' </summary>
        ''' <param name="DevInfo"></param>
        ''' <param name="VarInfo"></param>
        ''' <returns></returns>
        ''' <remarks></remarks> 
        Public Function GetStructMemberTypeConvertInfo(ByVal DevInfo As CSourceDefineInfo, ByVal VarInfo As CSourceVarInfo) As TypeConvertInfo
            Dim ret As New TypeConvertInfo

            '初期化
            ret.SourceInfo = VarInfo
            ret.TypeID = ""
            ret.TypeName = VarInfo.TypeName

            '型名の補正
            Dim vinfo As CSourceVarInfo
            vinfo = AdjustmentType(VarInfo)
            ret.TypeName = vinfo.TypeName

            '変換
            If IsNormalType(ret.TypeName) Then
                '値型
                ret.SetTypeID("V", VarInfo)
            Else
                Select Case ret.TypeName
                    Case "void"
                        If VarInfo.PointerLevel > 0 Then
                            ret.TypeID = "P"
                            ret.TypeName = "void" + New String("*"c, VarInfo.PointerLevel)
                        Else
                            '想定外の型
                            Stop
                        End If

                    Case "const void"
                        If VarInfo.PointerLevel > 0 Then
                            ret.TypeID = "PC"
                            ret.TypeName = "void" + New String("*"c, VarInfo.PointerLevel)
                        Else
                            '想定外の型
                            Stop
                        End If

                    Case "const char"
                        ret.TypeName = "char" + New String("*"c, VarInfo.PointerLevel)
                        If (VarInfo.PointerLevel = 1) And (VarInfo.Dimension.Count = 0) Then
                            'const char*型
                            ret.TypeID = "T"
                        ElseIf (VarInfo.PointerLevel = 0) And (VarInfo.Dimension.Count = 1) Then
                            'const char[]型
                            ret.TypeID = "T"
                        ElseIf VarInfo.PointerLevel = 2 Then
                            'const char**型
                            ret.TypeID = "PC"
                            ret.TypeName = "const " + ret.TypeName
                        Else
                            '想定外の型
                            Stop
                        End If

                    Case "const int"
                        ret.TypeName = ret.TypeName.Substring("const".Length).Trim + New String("*"c, VarInfo.PointerLevel)
                        If (VarInfo.PointerLevel = 1) And (VarInfo.Dimension.Count = 0) Then
                            'const ?*型
                            ret.TypeID = "PC"
                        ElseIf (VarInfo.PointerLevel = 0) And (VarInfo.Dimension.Count = 0) Then
                            'const ?型
                            ret.TypeID = "VR"
                        Else
                            '想定外の型
                            Stop
                        End If

                    Case Else

                        '型名が構造体であるか判定
                        Dim isstruct As Boolean = False
                        Dim iscallback As Boolean = False
                        Dim sd As CSourceDefineInfoTypeDef = Nothing
                        Do
                            '構造体名として定義リストを検索
                            sd = Converter.FindDefine(Of CSourceDefineInfoTypeDef)(ret.TypeName)
                            If sd IsNot Nothing Then
                                If sd.MainDefine.DefineType = "struct" Then
                                    '構造体である
                                    isstruct = True
                                    Exit Do '判定後の処理へ
                                ElseIf sd.MainDefine.DefineType = "function" Then
                                    '関数ポインタである
                                    iscallback = True
                                    Exit Do '判定後の処理へ
                                End If
                            End If

                            'タグ名で定義リストを検索
                            If VarInfo.DefineType = "struct" Then
                                Dim tgname As String = ret.TypeName.Substring("struct".Length).Trim
                                If tgname <> "" Then
                                    sd = FindStructTag(tgname)
                                    If sd IsNot Nothing Then
                                        '構造体である
                                        ret.TypeName = sd.MainDefine.Name
                                        isstruct = True
                                        Exit Do '判定後の処理へ
                                    End If
                                End If
                            End If

                            Exit Do '判定後の処理
                        Loop

                        '判定後の処理
                        If isstruct Then
                            '構造体である
                            ret.SetTypeID("S", VarInfo)
                        End If
                        If iscallback Then
                            '関数ポインタである
                            ret.SetTypeID("F", VarInfo)
                        End If

                End Select
            End If

            If ret.TypeID = "" Then Return Nothing '変換ルール不明

            '成功
            Return ret
        End Function

#End Region

#Region "列挙体定義関連"

        ''' <summary> 
        ''' 列挙体の定義文を出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Sub OutputSourceCode_TypeDef_Enum(ByVal DefInfo As CSourceDefineInfoTypeDef)

            '定義済みにする
            DefInfo.Flag(DefFlag.WasDefined) = True

            '手動変換チェック
            CheckManualConvert("enum.{0}.before", DefInfo.Name)
            If CheckManualConvert("enum.{0}", DefInfo.Name) Then Return '手動定義

            '定義文出力開始
            AddSource("DEFINE_ENUM( {0} )", DefInfo.Name)
            AddSource("{")

            '各項目の定義文出力
            For Each vv As CSourceVarInfo In DefInfo.MainDefine.Member

                '手動変換チェック
                If CheckManualConvert("enum.{0}.{1}", DefInfo.Name, vv.Name) Then
                    '手動変換
                Else
                    '自動変換

                    AddSource(vbTab + "DEFINE_ENUMDATA( {0} )", vv.Name)

                End If
            Next

            '手動変換チェック
            CheckManualConvert("enum.{0}.item.add", DefInfo.Name)

            '定義文出力終了
            AddSource("};")

        End Sub

#End Region

#Region "関数ポインタ定義関連"

        ''' <summary> 
        ''' 関数型(コールバック関数)の定義文を出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Sub OutputSourceCode_TypeDef_Function(ByVal DefInfo As CSourceDefineInfoTypeDef)

            '定義済みにする
            DefInfo.Flag(DefFlag.WasDefined) = True

            '手動変換チェック
            CheckManualConvert("callback.{0}.before", DefInfo.Name)
            If CheckManualConvert("callback.{0}", DefInfo.Name) Then Return '手動定義

            '関数情報の生成
            Dim finfo As New CSourceDefineInfoFunction
            finfo.Name = DefInfo.Name
            finfo.FuncInfo = DefInfo.MainDefine

            '戻り値タイプの決定
            Dim rettype As String = GetFunctionReturnType(finfo)
            If rettype = "" Then
                '変換不可
                Unsupport(DefInfo)
                Exit Sub
            End If

            '引数リストの変換
            Dim paramlist As List(Of String) = GetFunctionParameterList(finfo)
            If paramlist Is Nothing Then
                '変換不可
                Unsupport(DefInfo)
                Exit Sub
            End If

            '定義済みにする
            DefInfo.Flag(DefFlag.WasDefined) = True

            '定義文出力開始（複数の引数パターンがあっても先頭のみ出力する）
            'For Each pp As String In paramlist
            '    AddSource("DEFINE_CALLBACK( {0}, {1}, {2} ) ", rettype, DefInfo.Name, pp)
            'Next
            AddSource("DEFINE_CALLBACK( {0}, {1}, {2} ) ", rettype, DefInfo.Name, paramlist(0))
            Report(ReportType.Warning, "型定義 '{0}' は、デリゲート関数として定義されます。", DefInfo.Name)

        End Sub

#End Region

#End Region

        '----------------------------------------------------------
#Region "関数定義関連"

        ''' <summary>
        ''' 関数変換用の作業用データを保持します。
        ''' </summary>
        ''' <remarks></remarks>
        Private Structure FunctionConvertWorkData

            ''' <summary>戻り値の型情報を保持します。</summary>
            Public ReturnType As String

            ''' <summary>引数リストパターンを保持します。</summary>
            Public ParamList As List(Of String)

        End Structure

        ''' <summary>
        ''' 関数定義の変換コード出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overrides Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoFunction)

            '定義済みチェック
            Dim fd As CSourceDefineInfoFunction
            fd = Converter.FindDefine(Of CSourceDefineInfoFunction)(DefInfo.Name)
            If fd Is Nothing Then Stop
            If fd.Flag(DefFlag.WasDefined) Then Exit Sub '定義済み

            '宣言タイプの判断
            Dim ftype As String = ""
            If DefInfo.SourceTokens.Last.Text = "{}" Then
                '関数定義
                ftype = "function"
            Else
                'プロトタイプ宣言
                ftype = "functionprototype"
            End If

            '手動変換チェック
            CheckManualConvert("{0}.{1}.before", ftype, DefInfo.Name)
            If CheckManualConvert("{0}.{1}", ftype, DefInfo.Name) Then
                Report(ReportType.Warning, "関数 {0} は、手動変換されました。", DefInfo.Name)
                Return
            End If

            '戻り値タイプの決定
            Dim rettype As String = GetFunctionReturnType(DefInfo)
            If rettype = "" Then
                '変換不可
                Unsupport(DefInfo)
                Exit Sub
            End If

            '引数リストの変換
            Dim paramlist As List(Of String) = GetFunctionParameterList(DefInfo)
            If paramlist Is Nothing Then
                '変換不可
                Unsupport(DefInfo)
                Exit Sub
            End If

            '定義済みにする
            DefInfo.Flag(DefFlag.WasDefined) = True
            Dim fwd As New FunctionConvertWorkData
            fwd.ReturnType = rettype
            fwd.ParamList = paramlist
            DefInfo.ConvertWorkData = fwd '変換情報を退避

            '関数名のチェック
            Dim sd As CSourceDefineInfoTypeDef
            sd = FindStructIgnoreCase(DefInfo.Name)
            If sd IsNot Nothing Then
                Report(ReportType.Warning, "関数 '{0}' はVB上で同名となる構造体がある為、別名で定義されます。 {0} => {0}_", DefInfo.Name)
                For Each pp As String In paramlist
                    AddSource("DEFINE_FUNCTION_ALIAS( {0}, {1}, {1}_, {2} ) ", rettype, DefInfo.Name, pp)
                Next
                Exit Sub
            End If

            '定義文出力開始
            If paramlist.Count > 5 Then
                Report(ReportType.Warning, "オーバーロードされる定義の数が多すぎます。関数={0},件数={1}", DefInfo.Name, paramlist.Count)
            End If
            For Each pp As String In paramlist
                AddSource("DEFINE_FUNCTION( {0}, {1}, {2} ) ", rettype, DefInfo.Name, pp)
            Next

            '手動変換チェック
            CheckManualConvert("function.{0}.after", DefInfo.Name)

        End Sub

        ''' <summary>
        ''' 関数戻り値の定義文字列を生成します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetFunctionReturnType(ByVal DefInfo As CSourceDefineInfoFunction) As String

            '型情報の調整
            Dim finfo As CSourceVarInfo = AdjustmentType(DefInfo.FuncInfo)
            Dim tname As String = finfo.TypeName
            Dim cname As String = ""
            If tname.StartsWith("const ") Then
                tname = tname.Substring("const ".Length)
                cname = "const "
            End If

            'Nタイプの判定
            If tname = "void" Then
                If finfo.PointerLevel = 0 Then
                    'ポインタでない
                    If finfo.Dimension.Count = 0 Then
                        '配列でない
                        Return "N(" + tname + ")" 'Nタイプに決定
                    End If
                End If
            End If

            'Vタイプの判定
            If IsNormalType(tname) Then
                If finfo.PointerLevel = 0 Then
                    'ポインタでない
                    If finfo.Dimension.Count = 0 Then
                        '配列でない
                        Return "V(" + cname + tname + ")" 'Vタイプに決定
                    End If
                End If
            End If

            'Tタイプの判定
            If (cname <> "") And (tname = "char") Then
                If (finfo.PointerLevel = 1) And (finfo.Dimension.Count = 0) Then
                    'const char*である
                    Return "T(" + cname + tname + ")" 'Tタイプに決定
                End If
            End If

            'S/SP/F/Eタイプの判定
            Dim sd As CSourceDefineInfoTypeDef
            sd = Converter.FindDefine(Of CSourceDefineInfoTypeDef)(tname)
            If sd IsNot Nothing Then
                If sd.MainDefine.DefineType = "struct" Then
                    '構造体である

                    If (finfo.PointerLevel = 0) And (finfo.Dimension.Count = 0) Then
                        '構造体戻し(S)
                        Return "S(" + tname + ")"
                    ElseIf (finfo.PointerLevel = 1) And (finfo.Dimension.Count = 0) Then
                        '構造体ポインタ戻り(SP)

                        If cname <> "" Then
                            Return "SPC(" + tname + ")"
                        Else
                            Return "SP(" + tname + ")"
                        End If

                    ElseIf finfo.PointerLevel > 1 Then
                        'Pタイプとする

                    Else
                        '想定していない戻り値型である
                        Stop
                    End If

                ElseIf sd.MainDefine.DefineType = "function" Then
                    '関数ポインタ(F)
                    Return "F(" + tname + ")"

                ElseIf sd.MainDefine.DefineType = "enum" Then
                    '列挙体(E)
                    Return "E(" + tname + ")"

                End If
            End If

            'Pタイプ
            If finfo.PointerLevel > 0 Then
                Return "P(" + cname + tname + New String("*"c, finfo.PointerLevel) + ")"
            End If

            'タイプ判定不可
            Report(ReportType.Error, "関数/関数ポインタ '{0}' の戻り値型 '{1}'('{2}') を変換できない為、定義は出力されません。", DefInfo.Name, DefInfo.FuncInfo.GetTypeName, finfo.GetTypeName)
            Return ""
        End Function

        ''' <summary>
        ''' 関数引数リストの定義文字列を生成します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetFunctionParameterList(ByVal DefInfo As CSourceDefineInfoFunction) As List(Of String)

            Dim ret As New List(Of String)

            '引数リストがvoidの場合の処理
            If DefInfo.FuncInfo.Member.Count = 1 Then
                Dim vv As CSourceVarInfo
                vv = DefInfo.FuncInfo.Member(0)
                If (vv.TypeName = "void") And (vv.PointerLevel = 0) And (vv.Dimension.Count = 0) Then
                    '引数リストにvoidが指定されている

                    '引数なしの引数リストのみ追加
                    ret.Add("0()")

                    Return ret
                End If
            End If

            '引数パターンリストの作成
            Dim defparamcnt As Integer = 0 '省略値ありパラメタ数
            Dim finddefparam As Boolean = False
            Do
                finddefparam = False

                '各引数を変換
                Dim ptn As New List(Of String)
                Dim ptnwk As New List(Of String)
                Dim pcnt As Integer = 0
                For x As Integer = 0 To DefInfo.FuncInfo.Member.Count - 1 - defparamcnt

                    Dim vv As CSourceVarInfo = DefInfo.FuncInfo.Member(x)
                    If vv.DefaultValue IsNot Nothing Then finddefparam = True

                    '変換
                    Dim ssall As String
                    ssall = GetFunctionParameterList(vv)
                    Select Case ssall
                        Case "" '変換失敗
                            Report(ReportType.Error, "関数/関数ポインタ '{0}' の引数 '{1}' (型 '{2}') を変換でない為、定義は出力されません。", DefInfo.Name, vv.Name, vv.TypeName)
                            Return Nothing  '変換不可

                        Case "..." '可変引数
                            Report(ReportType.Caution, "関数/関数ポインタ '{0}' は可変引数です。最小個数の引数で定義されます。", DefInfo.Name)
                            Exit For   '終了

                    End Select

                    '追加
                    Dim ssptn() As String = ssall.Split("|"c)
                    If ptn.Count = 0 Then
                        For Each ss As String In ssptn
                            ptn.Add(ss)
                        Next
                    Else
                        ptnwk.Clear()
                        For Each ss As String In ssptn
                            For Each tt As String In ptn
                                ptnwk.Add(tt & ", " & ss)
                            Next
                        Next
                        ptn.Clear()
                        ptn.AddRange(ptnwk)
                    End If

                    pcnt += 1

                Next

                'パラメタ数を追加し、引数パターンリストに追加
                If pcnt > 15 Then Stop '引数多すぎ
                For Each tt As String In ptn
                    ret.Add(String.Format("{0}( {1} )", pcnt, tt))
                Next

                '他のパターンの有無チェック
                If finddefparam Then
                    '他のパターンあり
                    defparamcnt += 1
                Else
                    '他のパターンなし
                    Exit Do
                End If

            Loop

            '引数パターンリストを返す
            Return ret
        End Function

        ''' <summary>
        ''' 関数引数の定義文字列を生成します。
        ''' </summary>
        ''' <param name="VarInfo"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Function GetFunctionParameterList(ByVal VarInfo As CSourceVarInfo) As String

            '可変引数のチェック
            If VarInfo.TypeName = "..." Then
                Return "..."
            End If

            '型情報の調整
            Dim vinfo As CSourceVarInfo = AdjustmentType(VarInfo)
            Dim tname As String = vinfo.TypeName
            Dim cname As String = ""
            If tname.StartsWith("const ") Then
                tname = tname.Substring("const ".Length)
                cname = "const "
            End If
            Dim plvl As String = New String("*"c, vinfo.PointerLevel)

            'T/TPタイプの判定
            If (tname = "char") And (cname <> "") Then
                If vinfo.Dimension.Count = 0 Then
                    If vinfo.PointerLevel = 1 Then
                        '[const] char*型
                        Return MakeType("T", cname.Trim, vinfo.Name)
                    ElseIf vinfo.PointerLevel = 2 Then
                        '[const] char**型
                        Return MakeType("TP", cname.Trim, vinfo.Name)
                    End If
                End If
            End If

            'Vタイプ系の判定
            If IsNormalType(tname) Then
                If (vinfo.PointerLevel = 0) And (vinfo.Dimension.Count = 0) Then
                    '値型
                    Return MakeType("V", tname, vinfo.Name)
                ElseIf (vinfo.PointerLevel = 1) And (vinfo.Dimension.Count = 0) Then
                    '値型ポインタ
                    Dim ret As String = MakeType("VP", tname, vinfo.Name) + "|" + MakeType("P", cname + tname + plvl, vinfo.Name)
                    If tname = "char" Then
                        ret += "|" + MakeType("T", cname.Trim, vinfo.Name)
                    End If
                    Return ret
                ElseIf (vinfo.PointerLevel = 2) And (vinfo.Dimension.Count = 0) And (tname = "char") Then
                    'char型ダブルポインタ
                    Return MakeType("TP", cname.Trim, vinfo.Name) + "|" + MakeType("P", cname + tname + plvl, vinfo.Name)
                ElseIf (vinfo.PointerLevel = 0) And (vinfo.Dimension.Count = 1) Then
                    '値型一次元配列
                    Return MakeType("VA", tname, vinfo.Name, vinfo.Dimension(0).AllText) + "|" + MakeType("P", tname + "*", vinfo.Name)
                ElseIf (vinfo.PointerLevel = 0) And (vinfo.Dimension.Count = 2) Then
                    '値型二次元配列
                    Return MakeType("VA2", tname, vinfo.Name, vinfo.Dimension(0).AllText, vinfo.Dimension(1).AllText) + "|" + MakeType("P", tname + "(*)[" + vinfo.Dimension(1).AllText + "]", vinfo.Name)
                ElseIf (vinfo.PointerLevel = 0) And (vinfo.Dimension.Count = 3) Then
                    '値型三次元配列
                    Return MakeType("VA3", tname, vinfo.Name, vinfo.Dimension(0).AllText, vinfo.Dimension(1).AllText, vinfo.Dimension(2).AllText)
                Else
                    'その他、ポインタ型とする
                    Return MakeType("P", cname + tname + plvl, vinfo.Name)
                End If
            End If

            'Sタイプ系の判定
            Dim sd As CSourceDefineInfoTypeDef
            sd = Converter.FindDefine(Of CSourceDefineInfoTypeDef)(tname)
            If sd IsNot Nothing Then
                If sd.MainDefine.DefineType = "struct" Then
                    '構造体である

                    If (vinfo.PointerLevel = 0) And (vinfo.Dimension.Count = 0) Then
                        '構造体値
                        Return MakeType("S", tname, vinfo.Name)
                    ElseIf (vinfo.PointerLevel = 1) And (vinfo.Dimension.Count = 0) Then
                        '構造体ポインタ
                        Return MakeType("SP", tname, vinfo.Name)
                    ElseIf (vinfo.PointerLevel = 2) And (vinfo.Dimension.Count = 0) Then
                        '構造体ポインタポインタ
                        Return MakeType("SPP", tname, vinfo.Name)
                    ElseIf (vinfo.PointerLevel = 0) And (vinfo.Dimension.Count = 1) Then
                        '構造体配列
                        Return MakeType("SA", tname, vinfo.Name, vinfo.Dimension(0).AllText)
                    ElseIf (vinfo.PointerLevel = 1) And (vinfo.Dimension.Count = 1) Then
                        '構造体ポインタ配列
                        Return MakeType("SPA", tname, vinfo.Name, vinfo.Dimension(0).AllText)
                    ElseIf vinfo.PointerLevel > 2 Then
                        '構造体の多段ポインタ
                        'Pタイプとする
                    Else
                        '不明な型
                        Stop
                    End If

                ElseIf sd.MainDefine.DefineType = "function" Then
                    '関数ポインタ
                    Return MakeType("F", tname, vinfo.Name)

                ElseIf sd.MainDefine.DefineType = "enum" Then
                    '列挙体
                    Return MakeType("E", tname, vinfo.Name)

                End If
            End If

            'Pタイプの判定
            If vinfo.PointerLevel > 0 Then
                If tname = "void" Then
                    Return MakeType("P", cname + tname + plvl, vinfo.Name)
                Else
                    Return MakeType("P", cname + MakeUNAME(tname) + plvl, vinfo.Name)
                End If
            End If
            If tname = "IntPtr" Then
                Return MakeType("P", tname, vinfo.Name)
            End If

            'タイプ判定不可
            Return ""
        End Function

#End Region

        '----------------------------------------------------------
#Region "型プロトタイプ宣言定義関連"

        ''' <summary>
        ''' 型プロトタイプ宣言の変換コード出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overrides Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoTypePrototype)

            '手動変換チェック
            If CheckManualConvert("prototype.{0}", DefInfo.Name) Then
                Report(ReportType.Warning, "プロトタイプ宣言 {0} は、手動変換されました。", DefInfo.Name)
                Return
            End If

            '定義文出力
            '//AddSource("DEFINE_STRUCT_PROTOTYPE( {0} );", DefInfo.Name)
            '何も出力しない

        End Sub

#End Region

        '----------------------------------------------------------
#Region "変数定義関連"

        ''' <summary>
        ''' 変数定義の変換コード出力します。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <remarks></remarks>
        Protected Overrides Sub OutputSourceCode(ByVal DefInfo As CSourceDefineInfoVariable)

            '手動変換チェック
            If CheckManualConvert("variable.{0}", DefInfo.Name) Then
                Report(ReportType.Warning, "変数定義 {0} は、手動変換されました。", DefInfo.Name)
                Return
            End If

            '型変換情報の取得
            Dim vinfo As CSourceVarInfo = DefInfo.VarInfo
            Dim cinfo As TypeConvertInfo
            cinfo = GetStructMemberTypeConvertInfo(DefInfo, vinfo)
            If cinfo Is Nothing Then
                '変換情報が見付からない

                AddSource("// Unsupport : {0}", vinfo)
                Report(ReportType.Error, "グローバル変数 '{0}'(型 '{1}') は型の変換が出来ない為、定義は出力されません。", vinfo.Name, vinfo.GetTypeName)
                Exit Sub
            End If

            '同名定義の検索
            Dim binfo As CSourceDefineInfoTypeDef
            binfo = FindStructIgnoreCase(vinfo.Name)
            If binfo IsNot Nothing Then
                '変数名と同名の構造体が存在する

                Report(ReportType.Caution, "グローバル変数 '{0}'(型 '{1}') はVB上で同名となる構造体がある為、別名で定義されます。 {0} => {0}_", vinfo.Name, vinfo.GetTypeName)
                Select Case cinfo.TypeID
                    Case "S"
                        AddSource("DEFINE_GLOBAL_{0}_ALIAS( {1}, {2}, {2}_ )", cinfo.TypeID, cinfo.TypeName, vinfo.Name)
                        Exit Sub

                    Case Else
                        'サポートしていない別名定義
                        Stop

                End Select
            End If

            '定義文出力
            Select Case cinfo.TypeID
                Case "V", "VPP", "S", "SP", "P", "PC", "VR"
                    AddSource("DEFINE_GLOBAL_{0}( {1}, {2} )", cinfo.TypeID, cinfo.TypeName, vinfo.Name)

                Case "VP"
                    AddSource("DEFINE_GLOBAL_{0}( {1}*, {2} )", cinfo.TypeID, cinfo.TypeName, vinfo.Name)

                Case "VA", "VPA", "SA", "SPA", "PA"
                    AddSource("DEFINE_GLOBAL_{0}( {1}, {2}, {3} )", cinfo.TypeID, cinfo.TypeName, vinfo.Name, vinfo.Dimension(0).AllText)

                Case "VA2"
                    AddSource("DEFINE_GLOBAL_{0}( {1}, {2}, {3}, {4} )", cinfo.TypeID, cinfo.TypeName, vinfo.Name, vinfo.Dimension(0).AllText, vinfo.Dimension(1).AllText)

                Case "T"
                    AddSource("DEFINE_GLOBAL_TR( {1} )", cinfo.TypeID, vinfo.Name) 'TタイプはTRとして定義する

                Case Else
                    Stop

            End Select

        End Sub

#End Region

        '----------------------------------------------------------
#Region "手動変換関連"

        ''' <summary>
        ''' 手動変換データをチェックし、一致するキーがある場合そのコードを出力します。
        ''' </summary>
        ''' <param name="KeyFmt"></param>
        ''' <param name="Params"></param>
        ''' <returns>コード出力が合った場合True、なかった場合False</returns>
        ''' <remarks></remarks>
        Public Function CheckManualConvert(ByVal KeyFmt As String, ByVal ParamArray Params() As Object) As Boolean

            'キー値作成
            Dim key As String
            key = String.Format(KeyFmt, Params)

            '検索
            Dim cd As String = Converter.ManualConvert(key)
            If cd = "" Then Return False

            'コード出力
            AddSource(cd)

            '変換ルールの削除（変換漏れのチェックの為）
            Converter.ManualConvert.Dic.Remove(key)

            Return True
        End Function

#End Region

#Region "型変換関連"

        ''' <summary>
        ''' 型変換情報を保持します。
        ''' </summary>
        Public Class TypeConvertInfo

            ''' <summary>元の型情報</summary>
            Public SourceInfo As CSourceVarInfo

            ''' <summary>型タイプ(V,S,SP等)</summary>
            Public TypeID As String

            ''' <summary>型名(変換後の型名)</summary>
            Public TypeName As String


            '------------------

            ''' <summary>
            ''' 変換タイプを設定します。
            ''' </summary>
            ''' <param name="BaseTypeID"></param>
            ''' <param name="VarInfo"></param>
            ''' <remarks></remarks>
            Public Sub SetTypeID(ByVal BaseTypeID As String, ByVal VarInfo As CSourceVarInfo)

                If (VarInfo.PointerLevel = 0) And (VarInfo.Dimension.Count = 0) Then
                    '値
                    Me.TypeID = BaseTypeID

                ElseIf (VarInfo.PointerLevel = 0) And (VarInfo.Dimension.Count = 1) Then
                    '一次元配列
                    Me.TypeID = BaseTypeID + "A"

                ElseIf (VarInfo.PointerLevel = 0) And (VarInfo.Dimension.Count = 2) Then
                    '二次元配列
                    Me.TypeID = BaseTypeID + "A2"

                ElseIf (VarInfo.PointerLevel = 1) And (VarInfo.Dimension.Count = 0) Then
                    'ポインタ
                    Me.TypeID = BaseTypeID + "P"

                ElseIf (VarInfo.PointerLevel = 1) And (VarInfo.Dimension.Count = 1) Then
                    'ポインタ配列
                    Me.TypeID = BaseTypeID + "PA"

                ElseIf (VarInfo.PointerLevel = 2) And (VarInfo.Dimension.Count = 0) Then
                    'ポインタポインタ
                    Me.TypeID = BaseTypeID + "PP"

                Else
                    '上記以外は単純なポインタとして扱う
                    Me.TypeID = "P"
                    Me.TypeName = "UNAME(" + Me.TypeName + ")" + New String("*"c, VarInfo.PointerLevel)

                End If

            End Sub


        End Class

        ''' <summary> 
        ''' 型名称を基本的な型へ修正します。
        ''' </summary>
        ''' <param name="TypeName"></param>
        ''' <remarks></remarks>
        Public Function GetNormalTypeName(ByVal TypeName As String) As String
            Dim ret As String = TypeName
            Select Case TypeName
                Case "int64" : ret = "long long"
                Case "uint64" : ret = "unsigned long long"
                Case "uchar" : ret = "unsigned char"
                Case "schar" : ret = "signed char"
                Case "CvRNG" : ret = "unsigned long long"
                Case "HWND" : ret = "IntPtr"
                Case "UINT" : ret = "unsigned int"
                Case "WPARAM" : ret = "unsigned int"
                Case "LPARAM" : ret = "long"
                Case "__int64" : ret = "long long"
            End Select
            Return ret
        End Function

        ''' <summary>
        ''' 型が基本型であるかを調査します。
        ''' </summary>
        ''' <param name="Typename"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Shared Function IsNormalType(ByVal Typename As String) As Boolean
            Select Case Typename
                Case "char", "short", "int", "long", "long long", "float", "double", _
                     "unsigned char", "unsigned short", "unsigned int", "unsigned long", "unsigned long long", _
                     "unsigned", "signed char", "size_t"
                    '上記型である

                    '基本型である
                    Return True
            End Select

            '基本型でない
            Return False
        End Function

        ''' <summary>
        ''' 調整した型情報を返します。
        ''' </summary>
        ''' <param name="Src"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function AdjustmentType(ByVal Src As CSourceVarInfo) As CSourceVarInfo

            '個別処理
            If Src.TypeName = "CvArr" Then Return Src

            'コピー
            Dim ret As New CSourceVarInfo
            ret.CopyFrom(Src)

            '型定義の検索
            Dim sd As CSourceDefineInfoTypeDef
            sd = Converter.FindDefine(Of CSourceDefineInfoTypeDef)(ret.TypeName)
            If sd IsNot Nothing Then
                If sd.MainDefine.DefineType = "" Then
                    'typedefによる型定義があった

                    '定義情報をコピー
                    ret.CopyFrom(sd.MainDefine)
                    ret.Dimension = Src.Dimension

                    'ポインタレベルは加算
                    ret.PointerLevel += Src.PointerLevel
                End If
            End If

            '調整
            ret.TypeName = GetNormalTypeName(ret.TypeName)

            'データ名称は変更しない
            ret.Name = Src.Name
            Return ret
        End Function

        ''' <summary>
        ''' 型定義文字列を生成します。
        ''' </summary>
        ''' <param name="TypeID"></param>
        ''' <param name="Params"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Shared Function MakeType(ByVal TypeID As String, ByVal ParamArray Params() As Object) As String
            Dim ret As String = ""
            Dim ss As String = ""
            For Each vv As Object In Params
                If ret <> "" Then ret += ","
                ss = CStr(vv)
                If ret = "" And ss = "" Then
                    ret = " "
                Else
                    ret += ss
                End If
            Next
            Return TypeID + "(" + Trim(ret) + ")"
        End Function

        ''' <summary>
        ''' 型名をアンマネージの型名に修飾します。
        ''' </summary>
        ''' <param name="TypeName"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Shared Function MakeUNAME(ByVal TypeName As String) As String

            If TypeName.StartsWith("struct ") Then
                Return "struct UNAME(" + TypeName.Substring("struct ".Length).Trim + ")"
            End If

            Return "UNAME(" + TypeName + ")"
        End Function

#End Region

#Region "定義検索関連"

        ''' <summary>
        ''' 構造体検索用パラメタを格納するクラスです。
        ''' </summary>
        ''' <remarks></remarks>
        Private Class FindStructParameter

            ''' <summary>
            ''' 比較方式を表す定数です。
            ''' </summary>
            ''' <remarks></remarks>
            Public Enum FindStructCompareType

                ''' <summary>タグ名で比較します。</summary>
                CompareTagName = 1

                ''' <summary>大文字小文字を無視して名称で比較します。</summary>
                IgnoreCase = 2

            End Enum

            ''' <summary>検索する構造体名を保持します。</summary>
            Public Name As String

            ''' <summary>比較方法を保持します。</summary>
            Public CompareType As FindStructCompareType

            '------------------

            ''' <summary>
            ''' クラスを初期化します。
            ''' </summary>
            ''' <remarks></remarks>
            Public Sub New()

            End Sub

            ''' <summary>
            ''' クラスを初期化します。
            ''' </summary>
            ''' <param name="Name"></param>
            ''' <param name="CompareType"></param>
            ''' <remarks></remarks>
            Public Sub New(ByVal Name As String, ByVal CompareType As FindStructCompareType)
                Me.Name = Name
                Me.CompareType = CompareType
            End Sub

        End Class

        ''' <summary>
        ''' 構造体定義情報をタグ名で検索します。
        ''' </summary>
        ''' <param name="TypeName"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function FindStructTag(ByVal TypeName As String) As CSourceDefineInfoTypeDef
            Return CType(Converter.FindDefine(AddressOf FindStructDefFunc, New FindStructParameter(TypeName, FindStructParameter.FindStructCompareType.CompareTagName)), CSourceDefineInfoTypeDef)
        End Function

        ''' <summary>
        ''' 大文字小文字を無視して構造体定義情報を検索します。
        ''' </summary>
        ''' <param name="StructName"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function FindStructIgnoreCase(ByVal StructName As String) As CSourceDefineInfoTypeDef
            Return CType(Converter.FindDefine(AddressOf FindStructDefFunc, New FindStructParameter(StructName, FindStructParameter.FindStructCompareType.IgnoreCase)), CSourceDefineInfoTypeDef)
        End Function

        ''' <summary>
        ''' 構造体定義情報を検索する関数です。
        ''' </summary>
        ''' <param name="DefInfo"></param>
        ''' <param name="Param"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Shared Function FindStructDefFunc(ByVal DefInfo As CSourceDefineInfo, ByVal Param As Object) As Boolean

            '型チェック
            Dim sd As CSourceDefineInfoTypeDef
            sd = TryCast(DefInfo, CSourceDefineInfoTypeDef)
            If sd Is Nothing Then Return False

            '比較方法取得
            Dim pr As FindStructParameter
            pr = TryCast(Param, FindStructParameter)
            If pr Is Nothing Then Return False

            '比較
            Select Case pr.CompareType
                Case FindStructParameter.FindStructCompareType.CompareTagName
                    'タグ名称で比較
                    If sd.MainDefine.TagName = pr.Name Then Return True

                Case FindStructParameter.FindStructCompareType.IgnoreCase
                    '大文字小文字を無視して名称で比較
                    If String.Compare(sd.MainDefine.Name, pr.Name, True) = 0 Then Return True

            End Select

            '不一致
            Return False
        End Function

#End Region

    End Class

End Module
